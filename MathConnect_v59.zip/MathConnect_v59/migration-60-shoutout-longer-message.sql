-- ============================================================================
-- MathConnect — migration 60
-- Shout-outs: let students write more when the teacher has "short_text" mode
-- on — raises the message cap from 80 to 200 characters.
--
-- Run once in Supabase → SQL Editor. Safe to re-run.
--
-- WHAT THIS CHANGES: only the length cap in public.send_shoutout (80 → 200).
-- WHAT THIS DELIBERATELY DOES NOT CHANGE (see migration-57-shoutouts.sql for
-- the full design — this app is used by minors):
--   • The teacher still controls the mode per section (off / kinds_only /
--     short_text). This migration does not turn free text on for anyone —
--     it only gives more room to sections where the teacher already enabled
--     "short_text".
--   • public._shoutout_text_problem (the filter for links, contact details,
--     insults and profanity in English, Filipino and Bisaya) is untouched.
--   • Daily limits, one-per-classmate-per-day, and the report/hide flow are
--     untouched.
-- ============================================================================

create or replace function public.send_shoutout(p_from uuid, p_to uuid, p_kind text, p_message text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_from students%rowtype; v_to students%rowtype; v_mode text; v_msg text; v_problem text;
  v_today date := (now() at time zone 'Asia/Manila')::date; v_id uuid;
begin
  select * into v_from from students where id = p_from;
  select * into v_to from students where id = p_to;
  if v_from.id is null or v_to.id is null then return jsonb_build_object('ok', false, 'error', 'student_not_found'); end if;
  if p_from = p_to then return jsonb_build_object('ok', false, 'error', 'not_self'); end if;
  if v_from.section_id is distinct from v_to.section_id then return jsonb_build_object('ok', false, 'error', 'not_classmates'); end if;
  if coalesce(v_from.account_status, 'active') <> 'active' then return jsonb_build_object('ok', false, 'error', 'account_paused'); end if;
  if p_kind not in ('helped', 'teamwork', 'effort', 'improved', 'creative', 'kind') then return jsonb_build_object('ok', false, 'error', 'bad_kind'); end if;
  select shoutout_mode into v_mode from sections where id = v_from.section_id;
  if v_mode = 'off' then return jsonb_build_object('ok', false, 'error', 'disabled'); end if;

  v_msg := nullif(trim(coalesce(p_message, '')), '');
  if v_msg is not null then
    if v_mode <> 'short_text' then v_msg := null;                              -- kinds-only: any typed text is simply dropped
    else
      if char_length(v_msg) > 200 then return jsonb_build_object('ok', false, 'error', 'message_too_long'); end if;  -- was 80 (migration-57)
      v_problem := public._shoutout_text_problem(v_msg);
      if v_problem is not null then return jsonb_build_object('ok', false, 'error', 'message_not_allowed', 'why', v_problem); end if;
    end if;
  end if;

  if (select count(*) from shoutouts where from_student_id = p_from and (created_at at time zone 'Asia/Manila')::date = v_today) >= 5 then
    return jsonb_build_object('ok', false, 'error', 'daily_limit');
  end if;
  if exists (select 1 from shoutouts where from_student_id = p_from and to_student_id = p_to and (created_at at time zone 'Asia/Manila')::date = v_today) then
    return jsonb_build_object('ok', false, 'error', 'already_thanked_today');
  end if;
  if exists (select 1 from shoutouts where from_student_id = p_from and created_at > now() - interval '4 seconds') then
    return jsonb_build_object('ok', false, 'error', 'too_fast');
  end if;

  insert into shoutouts (section_id, from_student_id, to_student_id, kind, message)
    values (v_from.section_id, p_from, p_to, p_kind, v_msg) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;
