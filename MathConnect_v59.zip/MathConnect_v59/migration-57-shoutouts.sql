-- ============================================================================
-- MathConnect — migration 57
-- Shout-outs: classmates thanking and cheering each other, in a live side panel.
--
-- Run once in Supabase → SQL Editor. Safe to re-run.
--
-- DESIGN (read this before changing anything — most of it is about safety,
-- because the users are minors):
--   • It is a WALL of appreciation, not a free chat: no private messages, no
--     open replies, no images, no links. A shout-out is "<me> → <classmate>:
--     <one of six kinds of thanks>", plus (only if the teacher allows it) a
--     short message of up to 80 characters. Others can tap a 👏 🔥 🌟 reaction.
--   • The TEACHER controls each section's mode:
--        off         — nothing is shown or sent
--        kinds_only  — the six kinds of thanks only, no typed text  (DEFAULT)
--        short_text  — kinds + an optional 80-character message that must pass
--                      a filter (no links, contact details, insults or
--                      profanity in English, Filipino or Bisaya)
--     The filter is a first line of defence, not a guarantee — that is what the
--     teacher's Hide button and the students' Report button are for.
--   • Students can only reach their OWN section. Sending is limited to 5 a day,
--     one per classmate per day, and a few seconds apart, so it stays
--     meaningful and can't be used to spam.
--   • Anything reported by 2 different students disappears for everyone at once
--     and waits for the teacher. The teacher can hide, restore or delete any
--     shout-out and sees who has not yet received one this week, so nobody is
--     left out.
--   • No points, coins or streaks are attached. It is voluntary and it should
--     feel that way.
--   • The tables cannot be read or written directly by students — only through
--     the functions below, which check the student's section. (That is stricter
--     than most of the app on purpose: names + messages should not be readable
--     across sections by anyone holding the public API key.) Live updates use
--     Realtime *broadcast* pings that carry no content; the content is then
--     fetched through the safe functions.
-- ============================================================================

alter table sections add column if not exists shoutout_mode text not null default 'kinds_only';
alter table sections drop constraint if exists sections_shoutout_mode_check;
alter table sections add constraint sections_shoutout_mode_check check (shoutout_mode in ('off', 'kinds_only', 'short_text'));

create table if not exists shoutouts (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references sections(id) on delete cascade,
  from_student_id uuid not null references students(id) on delete cascade,
  to_student_id uuid not null references students(id) on delete cascade,
  kind text not null check (kind in ('helped', 'teamwork', 'effort', 'improved', 'creative', 'kind')),
  message text,
  status text not null default 'visible' check (status in ('visible', 'hidden')),
  hidden_reason text,                       -- 'teacher' | 'reports'
  report_count integer not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists shoutouts_section_idx on shoutouts (section_id, created_at desc);
create index if not exists shoutouts_from_idx on shoutouts (from_student_id, created_at desc);
create index if not exists shoutouts_to_idx on shoutouts (to_student_id, created_at desc);

create table if not exists shoutout_reactions (
  shoutout_id uuid not null references shoutouts(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  emoji text not null check (emoji in ('clap', 'fire', 'star')),
  created_at timestamptz not null default now(),
  primary key (shoutout_id, student_id)
);
create table if not exists shoutout_reports (
  shoutout_id uuid not null references shoutouts(id) on delete cascade,
  reporter_id uuid not null references students(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (shoutout_id, reporter_id)
);

-- Locked down: RLS on, and deliberately NO policies for anon/authenticated.
alter table shoutouts enable row level security;
alter table shoutout_reactions enable row level security;
alter table shoutout_reports enable row level security;

-- ---------------------------------------------------------------------------
-- Text filter. Returns NULL if the message is fine, else why it was refused.
-- ---------------------------------------------------------------------------
create or replace function public._shoutout_text_problem(p_text text) returns text
language plpgsql immutable as $$
declare
  v_raw text := coalesce(p_text, '');
  v_norm text; v_tokens text[]; v_collapsed_tokens text[]; v_all text;
  v_blocked text[] := array[
    -- English
    'fuck','fucker','fucking','fck','shit','bitch','bastard','asshole','dick','pussy','cunt','slut','whore','retard','retarded',
    'stupid','idiot','dumb','loser','ugly','fatso','hate','hater',
    -- Filipino / Bisaya
    'puta','putang','putangina','tangina','tanginamo','gago','gaga','ulol','bobo','boba','tanga','tarantado','engot','abnoy',
    'pakshet','pakyu','leche','lintik','peste','piste','yawa','buang','bilat','pekpek','puke','tite','titi',
    'kantot','hindot','pokpok','bwisit','buwisit','inutil'
  ];
begin
  -- undo common letter swaps (0→o 1→i 3→e 4→a 5→s 7→t @→a $→s), keep letters only
  v_norm := lower(translate(v_raw, '013457@$', 'oieastas'));
  v_norm := regexp_replace(v_norm, '[^a-z]+', ' ', 'g');
  v_tokens := regexp_split_to_array(trim(v_norm), '\s+');
  select array_agg(regexp_replace(t, '([a-z])\1+', '\1', 'g')) into v_collapsed_tokens from unnest(v_tokens) t;   -- "gagooo" -> "gago"
  if v_tokens && v_blocked or coalesce(v_collapsed_tokens, '{}'::text[]) && v_blocked then return 'language'; end if;
  -- long stems hidden inside spaced-out or joined words ("f u c k", "putanginamo")
  v_all := regexp_replace(v_norm, '\s+', '', 'g');
  if v_all ~ '(fuck|shit|bitch|putang|tangina|pakshet|pakyu|kantot|hindot|pekpek|pokpok)' then return 'language'; end if;
  -- (checked last so leetspeak like "g@g0" is reported as language, not as a link)
  if v_raw ~* '(https?:|www\.|\.com|\.net|\.org|\.ph\M|@|facebook|messenger|instagram|tiktok|snapchat|discord|telegram|viber|gcash)' then return 'links'; end if;
  if v_raw ~ '[0-9]([ .-]?[0-9]){6,}' then return 'contact'; end if;   -- a phone-number-like run of 7+ digits (spaces, dots, dashes allowed between)
  return null;
end;
$$;

-- (Deliberately NOT blocked: everyday words that matter at an agricultural school, e.g. "animal", "hayop", "fat".)

-- Small helper: a display name = first name + last initial ("Ana C.").
create or replace function public._shoutout_name(p_student_id uuid) returns text
language sql stable security definer set search_path = public as $$
  select coalesce(nullif(trim(st.first_name), ''), split_part(trim(st.full_name), ' ', 1))
         || case when nullif(trim(coalesce(st.last_name, '')), '') is not null then ' ' || upper(left(trim(st.last_name), 1)) || '.' else '' end
  from students st where st.id = p_student_id;
$$;

-- ---------------------------------------------------------------------------
-- SEND
-- ---------------------------------------------------------------------------
create or replace function public.send_shoutout(p_from uuid, p_to uuid, p_kind text, p_message text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_from students%rowtype; v_to students%rowtype; v_mode text; v_msg text; v_problem text;
  v_today date := (now() at time zone 'Asia/Manila')::date; v_id uuid;
begin
  select * into v_from from students where id = p_from;
  select * into v_to from students where id = p_to;
  if v_from.id is null or v_to.id is null then return jsonb_build_object('ok', false, 'error', 'student_not_found'); end if;
  if p_from = p_to then return jsonb_build_object('ok', false, 'error', 'not_self'); end if;
  if v_from.section_id is distinct from v_to.section_id then return jsonb_build_object('ok', false, 'error', 'not_classmates'); end if;
  if coalesce(v_from.account_status, 'active') <> 'active' then return jsonb_build_object('ok', false, 'error', 'account_paused'); end if;
  if p_kind not in ('helped', 'teamwork', 'effort', 'improved', 'creative', 'kind') then return jsonb_build_object('ok', false, 'error', 'bad_kind'); end if;
  select shoutout_mode into v_mode from sections where id = v_from.section_id;
  if v_mode = 'off' then return jsonb_build_object('ok', false, 'error', 'disabled'); end if;

  v_msg := nullif(trim(coalesce(p_message, '')), '');
  if v_msg is not null then
    if v_mode <> 'short_text' then v_msg := null;                              -- kinds-only: any typed text is simply dropped
    else
      if char_length(v_msg) > 80 then return jsonb_build_object('ok', false, 'error', 'message_too_long'); end if;
      v_problem := public._shoutout_text_problem(v_msg);
      if v_problem is not null then return jsonb_build_object('ok', false, 'error', 'message_not_allowed', 'why', v_problem); end if;
    end if;
  end if;

  if (select count(*) from shoutouts where from_student_id = p_from and (created_at at time zone 'Asia/Manila')::date = v_today) >= 5 then
    return jsonb_build_object('ok', false, 'error', 'daily_limit');
  end if;
  if exists (select 1 from shoutouts where from_student_id = p_from and to_student_id = p_to and (created_at at time zone 'Asia/Manila')::date = v_today) then
    return jsonb_build_object('ok', false, 'error', 'already_thanked_today');
  end if;
  if exists (select 1 from shoutouts where from_student_id = p_from and created_at > now() - interval '4 seconds') then
    return jsonb_build_object('ok', false, 'error', 'too_fast');
  end if;

  insert into shoutouts (section_id, from_student_id, to_student_id, kind, message)
    values (v_from.section_id, p_from, p_to, p_kind, v_msg) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

-- ---------------------------------------------------------------------------
-- FEED (what a student sees) — own section only, visible items only
-- ---------------------------------------------------------------------------
create or replace function public.shoutout_feed(p_student_id uuid, p_limit integer default 30) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v_st students%rowtype; v_mode text; v_items jsonb; v_roster jsonb; v_sent integer; v_today date := (now() at time zone 'Asia/Manila')::date;
begin
  select * into v_st from students where id = p_student_id;
  if v_st.id is null then return jsonb_build_object('ok', false, 'error', 'student_not_found'); end if;
  select shoutout_mode into v_mode from sections where id = v_st.section_id;
  if v_mode = 'off' then return jsonb_build_object('ok', true, 'mode', 'off', 'items', '[]'::jsonb, 'roster', '[]'::jsonb, 'sent_today', 0, 'daily_limit', 5); end if;

  select coalesce(jsonb_agg(x.j order by x.created_at desc), '[]'::jsonb) into v_items from (
    select s.created_at, jsonb_build_object(
      'id', s.id, 'from_id', s.from_student_id, 'from_name', public._shoutout_name(s.from_student_id),
      'to_id', s.to_student_id, 'to_name', public._shoutout_name(s.to_student_id),
      'kind', s.kind, 'message', s.message, 'created_at', s.created_at,
      'reactions', jsonb_build_object(
        'clap', (select count(*) from shoutout_reactions r where r.shoutout_id = s.id and r.emoji = 'clap'),
        'fire', (select count(*) from shoutout_reactions r where r.shoutout_id = s.id and r.emoji = 'fire'),
        'star', (select count(*) from shoutout_reactions r where r.shoutout_id = s.id and r.emoji = 'star')),
      'my_reaction', (select r.emoji from shoutout_reactions r where r.shoutout_id = s.id and r.student_id = p_student_id)
    ) as j
    from shoutouts s
    where s.section_id = v_st.section_id and s.status = 'visible' and s.created_at > now() - interval '30 days'
    order by s.created_at desc limit greatest(1, least(coalesce(p_limit, 30), 60))
  ) x;

  select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'name', public._shoutout_name(c.id)) order by c.first_name, c.full_name), '[]'::jsonb) into v_roster
    from students c where c.section_id = v_st.section_id and c.id <> p_student_id;
  select count(*) into v_sent from shoutouts where from_student_id = p_student_id and (created_at at time zone 'Asia/Manila')::date = v_today;

  return jsonb_build_object('ok', true, 'mode', v_mode, 'items', v_items, 'roster', v_roster, 'sent_today', v_sent, 'daily_limit', 5);
end;
$$;

-- ---------------------------------------------------------------------------
-- REACT (tap again to remove; tap another to switch) and REPORT
-- ---------------------------------------------------------------------------
create or replace function public.react_shoutout(p_student_id uuid, p_shoutout_id uuid, p_emoji text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_sec uuid; v_mine text;
begin
  if p_emoji not in ('clap', 'fire', 'star') then return jsonb_build_object('ok', false, 'error', 'bad_emoji'); end if;
  select s.section_id into v_sec from shoutouts s where s.id = p_shoutout_id and s.status = 'visible';
  if v_sec is null or v_sec is distinct from (select section_id from students where id = p_student_id) then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  select emoji into v_mine from shoutout_reactions where shoutout_id = p_shoutout_id and student_id = p_student_id;
  if v_mine = p_emoji then delete from shoutout_reactions where shoutout_id = p_shoutout_id and student_id = p_student_id;
  else insert into shoutout_reactions (shoutout_id, student_id, emoji) values (p_shoutout_id, p_student_id, p_emoji)
       on conflict (shoutout_id, student_id) do update set emoji = excluded.emoji, created_at = now(); end if;
  return jsonb_build_object('ok', true, 'my_reaction', case when v_mine = p_emoji then null else p_emoji end);
end;
$$;

create or replace function public.report_shoutout(p_student_id uuid, p_shoutout_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_sec uuid; v_count integer;
begin
  select s.section_id into v_sec from shoutouts s where s.id = p_shoutout_id;
  if v_sec is null or v_sec is distinct from (select section_id from students where id = p_student_id) then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  insert into shoutout_reports (shoutout_id, reporter_id) values (p_shoutout_id, p_student_id) on conflict do nothing;
  select count(*) into v_count from shoutout_reports where shoutout_id = p_shoutout_id;
  update shoutouts set report_count = v_count,
    status = case when v_count >= 2 then 'hidden' else status end,
    hidden_reason = case when v_count >= 2 and status = 'visible' then 'reports' else hidden_reason end
  where id = p_shoutout_id;
  return jsonb_build_object('ok', true);
end;
$$;

-- ---------------------------------------------------------------------------
-- TEACHER: overview, moderation, mode
-- ---------------------------------------------------------------------------
create or replace function public.teacher_shoutout_overview(p_section_id uuid, p_limit integer default 60) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v_week timestamptz; v_items jsonb; v_part jsonb; v_mode text;
begin
  if not (public.is_teacher_of_section(p_section_id) or public.is_admin()) then return jsonb_build_object('ok', false, 'error', 'not_allowed'); end if;
  select shoutout_mode into v_mode from sections where id = p_section_id;
  v_week := (date_trunc('week', now() at time zone 'Asia/Manila')) at time zone 'Asia/Manila';
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', s.id, 'from_id', s.from_student_id, 'from_name', f.full_name, 'to_id', s.to_student_id, 'to_name', t.full_name,
      'kind', s.kind, 'message', s.message, 'status', s.status, 'hidden_reason', s.hidden_reason, 'report_count', s.report_count, 'created_at', s.created_at
    ) order by s.created_at desc), '[]'::jsonb) into v_items
  from (select * from shoutouts where section_id = p_section_id order by created_at desc limit greatest(1, least(coalesce(p_limit, 60), 200))) s
  join students f on f.id = s.from_student_id join students t on t.id = s.to_student_id;

  select coalesce(jsonb_agg(jsonb_build_object(
      'student_id', st.id, 'full_name', st.full_name,
      'sent_week', (select count(*) from shoutouts x where x.from_student_id = st.id and x.created_at >= v_week and x.status = 'visible'),
      'received_week', (select count(*) from shoutouts x where x.to_student_id = st.id and x.created_at >= v_week and x.status = 'visible'),
      'sent_total', (select count(*) from shoutouts x where x.from_student_id = st.id and x.status = 'visible'),
      'received_total', (select count(*) from shoutouts x where x.to_student_id = st.id and x.status = 'visible')
    ) order by st.full_name), '[]'::jsonb) into v_part
  from students st where st.section_id = p_section_id;
  return jsonb_build_object('ok', true, 'mode', v_mode, 'items', v_items, 'participation', v_part);
end;
$$;

create or replace function public.moderate_shoutout(p_shoutout_id uuid, p_action text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_sec uuid;
begin
  select section_id into v_sec from shoutouts where id = p_shoutout_id;
  if v_sec is null then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if not (public.is_teacher_of_section(v_sec) or public.is_admin()) then return jsonb_build_object('ok', false, 'error', 'not_allowed'); end if;
  if p_action = 'hide' then update shoutouts set status = 'hidden', hidden_reason = 'teacher' where id = p_shoutout_id;
  elsif p_action = 'restore' then update shoutouts set status = 'visible', hidden_reason = null where id = p_shoutout_id;
  elsif p_action = 'delete' then delete from shoutouts where id = p_shoutout_id;
  else return jsonb_build_object('ok', false, 'error', 'bad_action'); end if;
  return jsonb_build_object('ok', true);
end;
$$;

create or replace function public.set_shoutout_mode(p_section_id uuid, p_mode text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not (public.is_teacher_of_section(p_section_id) or public.is_admin()) then return jsonb_build_object('ok', false, 'error', 'not_allowed'); end if;
  if p_mode not in ('off', 'kinds_only', 'short_text') then return jsonb_build_object('ok', false, 'error', 'bad_mode'); end if;
  update sections set shoutout_mode = p_mode where id = p_section_id;
  return jsonb_build_object('ok', true, 'mode', p_mode);
end;
$$;

grant execute on function public.send_shoutout(uuid, uuid, text, text) to anon, authenticated;
grant execute on function public.shoutout_feed(uuid, integer) to anon, authenticated;
grant execute on function public.react_shoutout(uuid, uuid, text) to anon, authenticated;
grant execute on function public.report_shoutout(uuid, uuid) to anon, authenticated;
grant execute on function public.teacher_shoutout_overview(uuid, integer) to authenticated;
grant execute on function public.moderate_shoutout(uuid, text) to authenticated;
grant execute on function public.set_shoutout_mode(uuid, text) to authenticated;
revoke execute on function public._shoutout_name(uuid) from public, anon, authenticated;
