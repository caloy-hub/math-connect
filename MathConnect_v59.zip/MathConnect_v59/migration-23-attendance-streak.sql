-- ============================================================================
-- MathConnect — Migration 23: Attendance Streak (TikTok-style flame)
-- ----------------------------------------------------------------------------
-- Replaces the old "did the student do a drill/challenge today" streak with
-- an ATTENDANCE-driven streak:
--   - Every date the teacher marks a student 'present' or 'late' extends the
--     streak by one.
--   - Marking a student 'absent_excused' or 'absent_unexcused' turns the
--     streak OFF (like a TikTok streak going out). The count they had is
--     remembered so it can be restored.
--   - A student can pay coins to restore an OFF streak back to what it was.
--     Unexcused absences cost more coins to restore than excused ones.
--
-- The streak now recomputes itself automatically from the `attendance` table
-- any time a teacher/admin adds, edits, or deletes an attendance row — via a
-- trigger — so it's always in sync with the official attendance record and
-- self-heals if a teacher corrects a past entry.
--
-- Also adds one new Shop item: buying a legendary mathematician's name as a
-- display title (reuses the existing purchase_shop_item plumbing from
-- migration-17 — no new purchase code needed).
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- Safe to re-run.
-- ============================================================================

-- ---------- New columns on the per-student wallet ----------
-- current_streak / longest_streak / last_active_date already exist
-- (migration-16) — they keep their names but their MEANING changes: from
-- here on they're driven by attendance, not by finishing a drill/challenge.
alter table student_engagement add column if not exists streak_off boolean not null default false;
alter table student_engagement add column if not exists streak_off_value integer not null default 0;
alter table student_engagement add column if not exists streak_off_reason text; -- 'absent_excused' | 'absent_unexcused'
alter table student_engagement add column if not exists streak_off_date date;

-- ---------- Restore log (audit trail, parallels shop_purchases) ----------
create table if not exists streak_restores (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  reason text not null,
  cost_paid integer not null,
  restored_streak_value integer not null,
  restored_at timestamptz default now()
);
create index if not exists streak_restores_student_idx on streak_restores (student_id);
alter table streak_restores enable row level security;
drop policy if exists "public read streak_restores" on streak_restores;
create policy "public read streak_restores" on streak_restores for select using (true);
-- No insert policy on purpose — only restore_streak() (security definer) writes here.

-- ----------------------------------------------------------------------------
-- recompute_attendance_streak(student_id) — walks that student's attendance
-- history newest-first and derives the streak from scratch every time. This
-- (rather than a simple +1/-1 counter) is what makes the streak self-correct
-- when a teacher edits or deletes a past attendance entry.
--
--   - If the MOST RECENT attendance record is present/late: current_streak is
--     the number of consecutive present/late records ending there.
--   - If the MOST RECENT record is an absence: the streak is OFF. We keep
--     walking backward past that single absence to remember what the streak
--     WOULD be if restored (streak_off_value), plus which kind of absence
--     caused it (streak_off_reason) and when (streak_off_date).
--
-- Every 7 days (LE_STREAK_MILESTONE in streakEngine.js — keep these two in
-- sync if you ever change the milestone) that lands on an ACTUAL increase
-- awards the same 24h 2x-coins power-up + 1 skip pass the old system gave.
-- ----------------------------------------------------------------------------
create or replace function public.recompute_attendance_streak(p_student_id uuid)
returns void
language plpgsql security definer as $$
declare
  rec record;
  running_streak integer := 0;
  is_first_row boolean := true;
  broke_on_absence boolean := false;
  broke_reason text := null;
  broke_date date := null;
  most_recent_date date := null;
  final_current_streak integer := 0;
  final_off boolean := false;
  final_off_value integer := 0;
  prev_streak integer := 0;
  cur_longest integer := 0;
  hit_milestone boolean := false;
begin
  select coalesce(current_streak,0), coalesce(longest_streak,0)
    into prev_streak, cur_longest
    from student_engagement where student_id = p_student_id;

  for rec in
    select attendance_date, status
    from attendance
    where student_id = p_student_id
    order by attendance_date desc
    limit 500
  loop
    if most_recent_date is null then most_recent_date := rec.attendance_date; end if;

    if is_first_row and rec.status in ('absent_excused','absent_unexcused') then
      -- The latest thing on record is an absence: the flame is OFF. Keep
      -- walking backward to see what streak it interrupted.
      broke_on_absence := true;
      broke_reason := rec.status;
      broke_date := rec.attendance_date;
      is_first_row := false;
      continue;
    end if;
    is_first_row := false;

    if rec.status in ('present','late') then
      running_streak := running_streak + 1;
    else
      exit; -- an older absence caps how far back the streak goes
    end if;
  end loop;

  if broke_on_absence then
    final_current_streak := 0;
    final_off := true;
    final_off_value := running_streak;
  else
    final_current_streak := running_streak;
    final_off := false;
    final_off_value := 0;
  end if;

  cur_longest := greatest(cur_longest, final_current_streak);
  hit_milestone := final_current_streak > 0 and final_current_streak % 7 = 0 and final_current_streak <> prev_streak;

  update student_engagement se set
    current_streak = final_current_streak,
    longest_streak = cur_longest,
    last_active_date = most_recent_date,
    streak_off = final_off,
    streak_off_value = final_off_value,
    streak_off_reason = broke_reason,
    streak_off_date = broke_date,
    active_powerup = case when hit_milestone then '2x_coins' else se.active_powerup end,
    powerup_expires_at = case when hit_milestone then now() + interval '24 hours' else se.powerup_expires_at end,
    skip_passes = case when hit_milestone then coalesce(se.skip_passes,0) + 1 else se.skip_passes end,
    updated_at = now()
  where se.student_id = p_student_id;

  if not found then
    insert into student_engagement (student_id, current_streak, longest_streak, last_active_date, streak_off, streak_off_value, streak_off_reason, streak_off_date)
    values (p_student_id, final_current_streak, cur_longest, most_recent_date, final_off, final_off_value, broke_reason, broke_date);
  end if;
end;
$$;

create or replace function public.trg_attendance_streak() returns trigger
language plpgsql security definer as $$
begin
  perform public.recompute_attendance_streak(coalesce(new.student_id, old.student_id));
  return coalesce(new, old);
end;
$$;

drop trigger if exists attendance_streak_trigger on attendance;
create trigger attendance_streak_trigger
after insert or update or delete on attendance
for each row execute function public.trg_attendance_streak();

-- Backfill: compute the streak for every student who already has attendance
-- history, so this migration doesn't leave everyone at 0 until their next
-- attendance edit.
do $$
declare s record;
begin
  for s in select id from students loop
    perform public.recompute_attendance_streak(s.id);
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- restore_streak — the "streak saver": spends coins to turn an OFF streak
-- back on, restoring it to the value it had before the absence. Does NOT
-- change the underlying attendance record (the absence stays on the books
-- for grading/attendance % purposes) — it only forgives the flame.
--
-- PRICING — tune here (keep in sync with STREAK_RESTORE_COST in
-- streakEngine.js, which mirrors these numbers for display purposes):
--   absent_unexcused -> 25 coins (costs more — it was avoidable)
--   absent_excused    -> 10 coins (costs less — valid excuse)
-- ----------------------------------------------------------------------------
create or replace function public.restore_streak(target_student_id uuid)
returns table(success boolean, message text, new_coins integer, new_current_streak integer, new_longest_streak integer)
language plpgsql security definer as $$
declare
  is_off boolean;
  off_value integer;
  off_reason text;
  cur_coins integer;
  cur_longest integer;
  restore_cost integer;
begin
  select coalesce(streak_off,false), coalesce(streak_off_value,0), streak_off_reason,
         coalesce(coins,0), coalesce(longest_streak,0)
    into is_off, off_value, off_reason, cur_coins, cur_longest
    from student_engagement where student_id = target_student_id for update;

  if is_off is null then
    return query select false, 'No engagement record found yet — try again after your first activity.', null::integer, null::integer, null::integer;
    return;
  end if;

  if not is_off then
    return query select false, 'Your streak is not off right now.', cur_coins, null::integer, cur_longest;
    return;
  end if;

  restore_cost := case when off_reason = 'absent_unexcused' then 25 else 10 end;

  if cur_coins < restore_cost then
    return query select false, format('Not enough coins to restore — need %s, have %s.', restore_cost, cur_coins), cur_coins, null::integer, cur_longest;
    return;
  end if;

  cur_coins := cur_coins - restore_cost;
  cur_longest := greatest(cur_longest, off_value);

  update student_engagement set
    coins = cur_coins, current_streak = off_value, longest_streak = cur_longest,
    streak_off = false, streak_off_value = 0, streak_off_reason = null, streak_off_date = null,
    updated_at = now()
  where student_id = target_student_id;

  insert into streak_restores (student_id, reason, cost_paid, restored_streak_value)
    values (target_student_id, off_reason, restore_cost, off_value);

  return query select true, format('Streak restored to %s days!', off_value), cur_coins, off_value, cur_longest;
end;
$$;
grant execute on function public.restore_streak(uuid) to anon, authenticated;

-- ---------- Shop: buy a mathematician's name (collectible title) ----------
-- Same pattern as the existing 'profile_title' item — purchase_shop_item()
-- from migration-17 already handles any item_id generically, so this is
-- just a new catalog row. shopEngine.js unlocks names from MATH_BIOS in a
-- fixed order, same mechanism as unlockedTitles().
insert into shop_items (id, name, description, cost, effect_type, effect_duration_seconds, sort_order) values
  ('mathematician_name', 'Mathematician Name', 'Unlocks a legendary mathematician''s name as your title.', 35, 'collectible', null, 6)
on conflict (id) do update set
  name = excluded.name, description = excluded.description, cost = excluded.cost,
  effect_type = excluded.effect_type, sort_order = excluded.sort_order, active = true;

-- ============================================================================
-- Security note (same tradeoff already documented in migration-17): the
-- student_engagement table stays client-writable ("using (true)") for the
-- rest of this app's existing columns, which means a technically-inclined
-- student could still write current_streak/coins directly via devtools,
-- bypassing the trigger/RPC. The well-behaved client (this app's own UI)
-- no longer does that itself — streakEngine.js's saveEngagement() was
-- updated to stop writing current_streak/longest_streak/streak_off* — but
-- this migration does not add new column-level REVOKEs, to stay consistent
-- with the rest of the app's low-stakes-classroom trust model. If you want
-- the streak to be tamper-proof, REVOKE UPDATE on those specific columns
-- from anon/authenticated and route every legitimate change through
-- recompute_attendance_streak()/restore_streak() only.
-- ============================================================================

-- Done. Redeploy streakEngine.js, streak-ui.js, engagement-ui.js, shopEngine.js,
-- shop-ui.js, and student.js/student.html — the flame will pick up your
-- existing attendance history immediately.
-- ============================================================================
