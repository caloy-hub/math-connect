# MathConnect — Exam Feature (Core) — Deploy Notes v2

Now harmonized directly into your actual site (from `MathConnect_v27.zip`) —
no manual HTML edits needed this time.

## What changed in this drop
- **`exam_schema.sql`** (new) — run this in Supabase Dashboard → SQL Editor
  before deploying. Creates `exams`, `exam_questions`, `exam_attempts`,
  `exam_responses`, RLS policies, and 3 RPCs (`start_exam_attempt`,
  `save_exam_response`, `submit_exam_attempt`) that handle server-side timing
  and scoring so nothing can be tampered with from the browser (your students
  use the same localStorage-session model as your other apps, not Supabase
  Auth, so writes go through these SECURITY DEFINER functions rather than
  raw table RLS).
- **`teacherExamEngine.js`** (new) — exam creation, manual question editor
  (MC / True-False), publish/lock toggles, per-student results with class
  average + pass rate.
- **`studentExamEngine.js`** (new) — exam dashboard, one-question-at-a-time
  timed taker with countdown, autosave, auto-submit at 0:00, scored results
  + review.
- **`teacher.html`** — added a "📝 Exams" tab button + panel, and loads
  `teacherExamEngine.js` after `teacher.js`.
- **`student.html`** — added a "📝 Exams" tab button + panel, and loads
  `studentExamEngine.js` after `championshipEngine.js`.
- **`teacher.js` / `student.js`** — one line each added, wiring `exams` into
  the existing `renderCurrentTab()` / `switchStudentTab()` dispatch. Nothing
  else in these two files was touched.
- Everything else in your site (index.html, admin.html/js, drills, quest,
  battles, all `migration-*.sql`, `supabase-schema.sql`, style.css, etc.) is
  untouched, byte-for-byte.

## Scope (Core, as agreed)
Teachers build exams by manually adding MC/True-False questions — no PDF/DOCX
upload-and-parse yet, and no analytics/item-analysis dashboards yet. Both are
natural next slices from the original guide once this core flow is tested
live, the same way Drill Arena grew from 6→12 stations over a few passes.

## Deploy (Netlify Drop)
1. Open Supabase → SQL Editor → paste and run `exam_schema.sql`.
2. Zip the `MathConnect_v27` folder as-is (or drag the folder straight into
   Netlify Drop — it's a complete, ready-to-go site).
3. Done — no other manual steps.

## Testing checklist
- [ ] Create an exam as teacher, add 3–4 questions, publish it.
- [ ] As a student, start it, answer a few, jump between questions via the
      number pills, submit.
- [ ] Confirm score matches your answer key, and review shows correct
      answers (if `show_correct_answers` is on).
- [ ] Let the timer hit 0:00 — confirm it auto-submits.
- [ ] Lock the exam as teacher — confirm a student can't start/resume it.
- [ ] With `allow_multiple_attempts` off, confirm a second "Start" is blocked
      with a clear message.

## Known trade-off
Exam *listings* (title/duration/description) are readable by anyone with the
anon key once published — question content and correct answers are not
(locked behind RLS + the RPCs). This mirrors the permissive-but-scoped RLS
pattern already used elsewhere in your apps (e.g. SILAB, PMS self-report
policies).

## Update — Bulk add + per-student shuffle (`migration-28-exam-bulk-and-shuffle.sql`)
- **Run `migration-28-exam-bulk-and-shuffle.sql`** in Supabase SQL Editor
  (after `exam_schema.sql`). Adds `exams.shuffle_options` and
  `exam_attempts.shuffle_map`, and replaces `start_exam_attempt` /
  `submit_exam_attempt` plus three small helper functions.
- **Bulk Add** — in the Questions panel, "📥 Bulk Add" opens a textarea where
  a teacher pastes several questions at once (blank line between each,
  `Q:`/`A)`/`B)`/`ANSWER:`/`EXPLANATION:`/`POINTS:` markers — "Load an
  example" fills in the exact format). Preview flags anything unparseable
  per-question before inserting, so a typo in one question never blocks the
  rest. No schema change was needed for this part — it's just a batch
  insert into `exam_questions` instead of one row at a time.
- **Per-student option shuffle** — new "Shuffle answer options per student"
  checkbox on exam creation (default on), plus a 🔀 toggle on each exam row.
  When on, each student's multiple-choice options are randomly reordered
  the first time they start the exam (stays fixed if they resume) so
  students sitting near each other can't just match letters. Scoring and
  the review screen automatically account for each student's shuffled
  order — no changes needed in `studentExamEngine.js`. True/False questions
  are never shuffled (nothing to shuffle). Toggling shuffle on/off only
  affects attempts started after the change.

### Testing checklist (additions)
- [ ] Bulk Add 3 questions (mix of MC + True/False) via the textarea, hit
      Preview, confirm all show ✅, then Add — question count updates.
- [ ] Bulk Add one deliberately broken question (e.g. `ANSWER: E` with only
      A–D given) alongside a valid one — confirm the valid one is still
      addable and the broken one is flagged with a reason.
- [ ] With shuffle on, start the same exam as two different students —
      confirm the option order differs between them but each student's
      order stays the same on resume.
- [ ] Submit as a shuffled student and confirm the score is correct and the
      review's "Correct answer: X" matches the option they actually saw
      lettered X.

## v29 patch notes (2026-08-08)

1. **Grade-level shared visibility (Blended Learning + Exams, student side)**
   - New `loadGradeLevelScope()` in `student.js`, called once at login after
     the student's term is resolved. It looks up every section that shares
     the same `grade_level`, `subject`, and `school_year`, then finds each
     of their terms with the matching `term_number`.
   - `renderStudentBlended()` (LAS/modules + weekly schedule) and
     `renderStudentExams()` (in `studentExamEngine.js`) now query with
     `.in("term_id", scope.termIds)` / `.in("section_id", scope.sectionIds)`
     instead of being pinned to the student's own section — so anything a
     teacher posts in ONE section of a grade level shows up for every
     section of that same grade level and subject. Items posted for a
     different section than the student's own are labeled with a small
     "Posted for [section name]" badge so it's clear where it came from.
   - No RLS/database changes were needed — `modules`, `schedule`, and
     `exams` already had public-read policies with no section restriction;
     this was purely a client-side query change.

2. **Subject-restricted teacher tabs**
   - New `applySubjectTabRestriction()` in `teacher.js`, called every time
     the teacher switches sections (`onSectionChange`).
   - If the selected section's `subject` is NOT "Mathematics" or "General
     Mathematics" (case-insensitive), these tabs are hidden: Status, Other
     Concerns, Math Drills, Quest Mode, Boss Battles, Learning Heatmap,
     Exams. Only Roster, Class Record, Attendance, Weekly Check-In, Blended
     Learning, and Groups & Picker remain visible — these are the only
     features that make sense for a non-Math class record-keeping section.
   - If the teacher was on one of the now-hidden tabs when they switch to a
     non-Math section, they're bounced back to Roster automatically.
   - Sections with no `subject` saved (legacy rows) default to
     "Mathematics" and are treated as unrestricted.

## v30 patch notes (2026-08-08)

1. **Exams un-restricted (both dashboards)**
   - Removed "exams" from `MATH_ONLY_TABS` in `teacher.js`. Teachers of any
     subject can now create/publish/lock exams for their sections.

2. **Subject-restricted student tabs**
   - New `applySubjectTabRestrictionStudent()` in `student.js`, called once
     at login right after the student's section loads.
   - If the section's `subject` is NOT "Mathematics" or "General
     Mathematics", these tabs are hidden: My Status, Math Drills, Quest
     Mode, Intelligent Practice, Challenges, Shop, Boss Battles, Legends.
   - Kept visible for every subject: This Week (overview), My Grades, My
     Attendance, Blended Learning, and Exams — Exams is intentionally
     unrestricted since it's useful outside Math too.
   - Same "Mathematics" default for sections with no saved subject, so
     nothing existing gets locked out unexpectedly.

## v31 patch notes (2026-08-08) — bugfix

**Root cause found:** grade-level sharing (Blended Learning + Exams) wasn't
kicking in for most sections. `grade_level`, `subject`, and `school_year` are
free-text fields retyped by hand every time a section is created — there's no
dropdown enforcing a consistent value. The original sibling lookup used an
exact `.eq()` match, so something as small as "Grade 8" vs "Grade 8 " (a
trailing space) or a casing difference silently made two sections of the
same grade level invisible to each other.

**Fix (`student.js`, `loadGradeLevelScope()`):** sibling sections are now
matched by normalized text (trimmed + lowercased) instead of an exact
database-level match, so stray whitespace/casing differences no longer break
the grouping. The lookup is also now scoped to sections owned by the same
teacher (`teacher_id`), so two different teachers who happen to use the same
grade-level label for unrelated classes can't accidentally see each other's
posts.

If a section still isn't showing up as a sibling after this update, open
that section in the teacher dashboard → Edit Section and double-check its
Grade Level and Subject fields are typed exactly the same way (case doesn't
matter now, but the words themselves need to match, e.g. "Grade 8" in one
section and "Grade Eight" in another still won't be treated as the same
grade level).

## v32 patch notes (2026-08-08) — added missing Edit Section feature

There was no way to actually fix a section's Grade Level/Subject/School Year
once it was created — those fields could only be set at creation time. Added:

- **New "Edit Section" button** next to "+ New Section" on the teacher
  dashboard, opens a modal to edit Section Name, Grade Level, Subject, and
  School Year for the currently selected section (`openEditSectionModal()` /
  `saveSectionEdit()` in `teacher.js`). The class code students use to log in
  is untouched.
- The modal explicitly reminds you that Grade Level/Subject/School Year need
  to be typed the same way across sections for them to share Blended
  Learning posts and Exams (per the v31 fix).
- After saving, the section list, class-code box, and Math-only tab
  visibility all refresh automatically.

## v33 patch notes (2026-08-13) — Login Audit Log for Admin

Admin Overview now has a **📋 Login Audit Log** card showing who's signing
into the app and when, across all three roles.

- **`migration-29-login-audit-log.sql`** (new) — run this in Supabase
  Dashboard → SQL Editor. Adds a `login_audit_log` table (one row per
  successful sign-in: role, user id, name snapshot, timestamp) plus a
  `record_login_event()` RPC that's the only way rows get written — direct
  client inserts are blocked by RLS, same defensive pattern as
  `record_student_login`. Only admins can read the table. Also folded into
  `supabase-schema.sql` for fresh installs.
- **`auth.js`** — `studentLogin`, `teacherLogin`, and `adminLogin` each
  fire-and-forget a call to `record_login_event` right after a successful
  sign-in, so a slow/failed audit write can never block someone from
  actually logging in.
- **`admin.js` / `admin.html`** — new card with a **Range** selector
  (Today / Last 7 days / Last 30 days / All time) driving two inline-SVG
  charts (no external chart library): a **pie chart** of sign-ins by role
  (Admin / Teacher / Student) and a **line chart** of sign-in volume over
  time (hourly for Today, daily otherwise), plus a plain "Recent Sign-Ins"
  table underneath (most recent 20).
- Logins from before this migration are **not** retroactively logged — the
  trail starts from the first sign-in after you run it.

## v33.1 patch notes (2026-08-13) — Admin Actions tab

Extended the audit log with a second trail for what admins *do*, not just
who signs in.

- **`migration-30-admin-action-log.sql`** (new, run after migration-29) —
  adds `admin_action_log` (admin, action type, target, optional details,
  timestamp) and a `record_admin_action()` RPC that re-checks `is_admin()`
  server-side and looks up the admin's name itself, so the client can't
  spoof who performed an action. Folded into `supabase-schema.sql` too.
- **`admin.js`** now calls `logAdminAction()` (fire-and-forget, same
  never-block-the-real-action pattern as logins) from every admin write:
  account status changes, "joined" date edits, account deletes, drill
  station / practice domain lock toggles, attendance/score/drill entry
  corrections and deletes, and champion finalization.
- **`admin.html`** — the audit card is now tabbed: **🔑 Logins** and
  **🛠️ Admin Actions**, sharing one Range selector. The Admin Actions tab
  shows a pie chart of actions by type, a trend line, and a recent list with
  admin name, action, target, and details.
- Run migration-29 first if you haven't already — migration-30 depends on
  the `admins` table and `is_admin()` function it assumes are already there
  (both are from the base schema, so this only matters for very old installs
  that somehow skipped migration-6).

## v34 (2026-08-14) — Math Pet, v1: adopt + feed

A new Green Points economy and a "🐾 My Pet" tab. This is the first slice
only — adopt a free pet, feed it two ways. Pet dialogue/reactions (hungry,
lonely, cheering during play) are a deliberate follow-up, not in this drop.

- **`migration-32-math-pet.sql`** (new, run after migration-30/31) — adds
  `green_points` to `student_engagement`; `pet_types` and `pet_food_items`
  catalogs (seeded with 5 pets / 3 foods, admin-retunable); `student_pets`
  (one pet per student — hunger, cumulative growth points, food inventory);
  `pet_feed_log` audit trail; and four RPCs — `adopt_pet`,
  `feed_pet_green_points`, `purchase_pet_food`, `feed_pet_food` — that move
  Green Points/coins the same row-locked, server-priced way
  `purchase_shop_item` already does. Folded into `supabase-schema.sql` too.
- **Earning Green Points** stays client-writable, same trust tier Coins
  already use (see the security note at the bottom of migration-17) —
  `awardGreenPoints()` in `streakEngine.js` is the Green Points equivalent
  of `awardCoins()`. **Spending** them (feeding, buying food, adopting)
  only happens through the RPCs above — `student_pets` has no general
  "anyone update" RLS policy on purpose.
- Wired into every activity a student can do: Drills (+1/correct), Intelligent
  Practice (+1/correct), Quest (+3/level cleared, +20 chapter-complete bonus,
  gated on genuine improvement so replays don't farm it), Boss Battles
  (+3 participation, once per battle), Tournament (+15 champion bonus, once
  per tournament — regular round wins already earn it via the underlying
  battle), Exams (+10/submission), Daily Challenge (+5), and the weekly Topic
  Rating check-in (+5, first rating per lesson only, Math sections only).
- **`petEngine.js` / `pet-ui.js`** (new) — pet/food catalogs, growth-stage
  and hunger display logic, and the "🐾 My Pet" tab UI. "Adopt a Pet" (free)
  and "Pet Food" (coins) sections were added into the existing Shop tab via
  `renderShopPetSections()`, called from `shop-ui.js`.
- **`student.html` / `student.js`** — new Pet tab wired into
  `switchStudentTab()`; restricted to Math sections (`STUDENT_MATH_ONLY_TABS`),
  same as Shop/Drills/Quest/Battles, since that's where it's earned and spent.
- Topbar badge now shows 💚 Green Points next to 🪙 Coins.
- **Next slice (not in this migration):** hunger decay over time, and the
  pet asking for food / acting lonely / cheering during play — needs a
  small "personality" state machine layered on `hunger` + `last_fed_at`,
  intentionally left for a follow-up so this drop stays testable on its own.

## v34.1 (2026-08-14) — Math Pet: reactions, movement, dashboard visibility

Follow-up to v34, closing out the "next slice" noted above. No new
migration — everything here is computed client-side from data the pet
already had (`hunger`, `last_fed_at`, `growth_points`).

- **Live hunger decay** (`petLiveHunger()` in `petEngine.js`) — hunger now
  drains on its own over real time since the pet was last fed (full drain,
  100→0, over 24 unfed hours), the same "computed at display time, not
  written back" approach `flameTierProgress()` already uses for the streak
  flame. The stored `hunger` column still only changes on an actual feed.
- **Mood + dialogue** (`petMood()`) — one hunger-driven mood dimension
  (happy → content → peckish → hungry → starving) covers both "asks for
  food" and "lonely" together: the longer it's been since a feed, the
  hungrier AND lonelier the pet's line reads. Each mood has a few lines it
  picks from at random, shown as a speech bubble on the Pet tab and the new
  dashboard widget.
- **Cheering during play** (`showPetCheerBubble()`) — a small floating
  toast with an encouraging line from the pet, shown once (throttled to
  every 2 min) when a student starts Drills, Quest, a Boss Battle,
  Intelligent Practice, or an Exam. Tone shifts if hunger is low (still
  cheers, but hints it wants food after).
- **Little movements** — CSS-only, no JS animation loop: an idle bob
  (happy pets bob a bit more energetically), a droopy sad sway below 35%
  hunger, and a one-shot bounce on the pet icon right after a feed
  (`style.css`, `.pet-anim-*` classes).
- **Dashboard visibility** — a new pet status card (icon, mood line, hunger
  bar) now renders on the "This Week" tab itself, right under the stat
  cards, so a student sees their pet's status the moment they log in
  instead of having to find the Pet tab. Shows an "Adopt a Pet" nudge card
  instead if they don't have one yet. (`dashboardPetWidgetHtml()` in
  `pet-ui.js`, wired into `renderDashboardHeader()` in `student.js`.)

## v34.2 (2026-08-15) — Tournament: roster-based bracketing + Pet: deeper evolution & class adoption view

No new migration — everything here reuses existing tables/RPCs from
migration-31 (tournaments) and migration-32 (math pet); this is a JS/UI-only
update.

- **Tournament — teacher can pre-build the bracket from the roster.** While
  a tournament is `open`, the teacher's Tournament tab now lists the whole
  class roster with an "Add" button per student (and an "Add Everyone"
  shortcut), calling the exact same `tournament_participants` insert a
  student's own "Join" button makes (`joinTournament()` in
  `tournamentEngine.js`) — just triggered from the teacher side. This means
  a teacher can fully set the pairing/bracket before any student has logged
  in that day; each student only needs to sign in once their match comes up
  (they can spectate or check the bracket without an account too, since
  `tournament_matches`/`tournament_participants` reads are public). Students
  can still self-join from their Boss Battles tab exactly as before — the
  two paths write to the same table and don't conflict.
  (`teacher-tournament.js`: `handleTeacherAddToBracket()`,
  `handleTeacherAddAllToBracket()`, `handleTeacherRemoveParticipant()`.)

- **Math Pet — more evolution stages, each meaningfully harder to reach.**
  `PET_GROWTH_STAGES` in `petEngine.js` grew from 4 stages (peaking at 350
  growth pts) to 8 (Hatchling → Growing → Juvenile → Thriving → Radiant →
  Ascendant → Champion → Legendary, peaking at 5,000 growth pts). Since
  Green Points are only earned in small amounts through everyday play, this
  is a deliberate pacing change so a pet's later forms take sustained,
  ongoing computation practice to unlock rather than a single binge session
  — the pet stays a reason to keep coming back. The top four stages get a
  small badge (✨🌠🏆👑) next to the pet's name and a pulsing glow animation
  (`.pet-glow-*` in `style.css`) as a visible "you've reached something
  special" cue. Purely cosmetic — nothing here touches scoring/mastery.

- **Teacher Status tab — see who's adopted a pet and their current status.**
  The consolidated `📋 Status` table (`statusEngine.js`) now has a 🐾 Pet
  column per student (icon, name, evolution stage, growth points, and a
  live hunger indicator), a "Pet Growth" sort option, and a small roll-up
  card under the table showing how many of the class have adopted a pet at
  all and how they're spread across evolution stages. Requires
  `petEngine.js` to be loaded on the teacher side too (added to
  `teacher.html`, after `teacher-learning-heatmap.js`) for the shared
  growth-stage/hunger helpers — no separate pet logic was duplicated.

## v34.3 (2026-08-15) — Math Pet: naming, care items, real neglect consequences, 3-adoption cap, 5 more pets, mythical legendary forms

**Run `migration-33-pet-care-and-legacy.sql` in Supabase → SQL Editor**
(after migration-32, before deploying these files). No changes needed to
migration-31/32 — this only adds to what's already there. This migration
was built and exercised end-to-end against a real local Postgres instance
before shipping (adopt → feed → sicken → die → re-adopt → hit the 3-cap →
blocked, plus the vitamin/vaccine/equipment/cheat-food paths and the
partial-unique-index race guard) — three real bugs (two ambiguous-column
errors, one bad foreign key) were caught and fixed in that process, not
just eyeballed.

- **Pet naming.** Students can name their pet right at adoption (optional —
  can rename later too), and rename it any time from the My Pet tab
  (`rename_pet` RPC, free).

- **Pet Care shop section** (`pet_care_items` table + `purchase_pet_care_item`
  / `use_pet_care_item` / `equip_pet_item` RPCs): 💊 Growth Vitamins (slows
  hunger decay 50% for 48h), 💉 Wellness Vaccine (cures sickness + protects
  for 72h), 🍔 Cheat Meal (cheap, restores 60 hunger, but a real ~25% chance
  of causing sickness unless currently vaccinated — a genuine trade-off, not
  a free lunch), and two Equipment items (🛏️ Cozy Bed / 📚 Study Desk — buy
  once, equip one at a time, permanent 15% slower decay while equipped).

- **Neglect has real, permanent consequences.** A pet that's fully starved
  and unvaccinated falls sick; if sickness goes untreated for 24h it dies
  (or after 72h of total neglect regardless). Death is decided **server-side**
  in `check_pet_wellbeing()`, recomputed from the DB's own clock — not
  something a client can dodge or fake. It's called opportunistically
  whenever a pet loads (student's own tabs) AND now from the teacher's
  Status tab too, so a teacher sees accurate sick/passed-away states even
  for a student who hasn't opened the app. **Death is permanent** — no
  revive, no auto-replacement; the row just stops being the "alive" one.

- **3 adoptions per student for the school year.** `adopt_pet` now counts
  every adoption a student has ever made (alive or dead) and blocks a 4th.
  `student_pets` was re-keyed (surrogate `id` primary key + a partial unique
  index enforcing "at most one *alive* pet per student") so a student's
  adoption history survives across pet deaths instead of being overwritten
  — see the migration file's design notes for why.

- **5 new pets (10 total):** Tala the Tally Turtle, Byte the Binary Cat,
  Kiri the Kirin Calf, Vex the Vector Wolf, Zeta the Zeal Steed — joining
  Numo, Pico, Digit, Sumi, and Ari.

- **Every pet evolves into a mythical Legendary form** at the top growth
  stage (5,000 growth pts) — Azure Dragon, Vermilion Phoenix, Kitsune,
  Fenrir, Pegasus, and more (`PET_TYPE_META` in `petEngine.js`: each pet now
  has a `championIcon` for the second-to-top stage and a `legendaryIcon` +
  `legendaryTitle` for the top one). Purely cosmetic, same trust tier as the
  glow effects added in v34.2 — nothing here touches scoring.

Files touched: `migration-33-pet-care-and-legacy.sql` (new), `petEngine.js`,
`pet-ui.js`, `shop-ui.js` (one new container div), `statusEngine.js`.

## v47 (2026-09-20) — Team Boss Raids; Tournament removed

See `CHANGELOG-v47.md`. Run `migration-53-boss-raids.sql`. The Tournament feature is gone (UI + hooks);
`migration-54-drop-tournament-data.sql` is an optional, destructive cleanup of its data.

## v49 (2026-09-21) — kinder pets, real Most Improved, Shout-outs

See `CHANGELOG-v49.md`. Run migrations 55, 56, 57 (and optionally 58). BOKYA removed; pets rest instead of dying.

