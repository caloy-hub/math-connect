// ============================================================================
// MathConnect — Shout-outs (engine)
// A wall of appreciation: classmates thank and cheer each other in a live side
// panel. Deliberately NOT a free chat — see migration-57-shoutouts.sql for the
// safety design (teacher-controlled modes, filter, daily limits, reports,
// no private messages, no points).
//
// Everything goes through the migration's functions — students cannot read or
// write the tables directly. "Live" is done with Realtime BROADCAST pings that
// carry no content ("something changed, refresh"); the content itself is then
// pulled through shoutout_feed(), which only ever returns the student's own
// section. A 30-second poll (10 s while the panel is open) is the safety net.
// Depends on: supabase-client.js (supabase, toast, escapeHtml), student.js (sstate).
// shoutout-ui.js draws the panel.
// ============================================================================

const SHOUTOUT_KINDS = {
  helped:   { icon: "🤝", label: "helped me understand" },
  teamwork: { icon: "👥", label: "was a great teammate" },
  effort:   { icon: "💪", label: "never gave up" },
  improved: { icon: "📈", label: "is improving so fast" },
  creative: { icon: "💡", label: "found a clever way to solve it" },
  kind:     { icon: "💛", label: "was kind to me" },
};
const SHOUTOUT_REACTIONS = { clap: "👏", fire: "🔥", star: "🌟" };
const SHOUTOUT_MAX_MESSAGE = 200;

var sostate = {
  started: false, loaded: false, mode: "kinds_only",
  items: [], roster: [], sentToday: 0, dailyLimit: 5,
  open: false, composeOpen: false,
  channel: null, pollId: null, refreshTimer: null,
  knownIds: {}, firstLoad: true,
  seenKey: null, lastSeenAt: 0,
};

function shoutoutMe() { return sstate.student.id; }

function shoutoutErrorText(code, res) {
  return ({
    not_self: "You can't thank yourself — pick a classmate! 🙂",
    not_classmates: "You can only thank people in your own class.",
    account_paused: "⏸️ Your account is in read-only mode, so sending is paused. You can still read and react!",
    disabled: "Shout-outs are turned off for your class right now.",
    daily_limit: "That's 5 shout-outs today — wonderful! Save some kindness for tomorrow 💛",
    already_thanked_today: "You already thanked them today — you can thank someone else!",
    too_fast: "One moment — try again in a few seconds.",
    message_too_long: `Keep it short — ${SHOUTOUT_MAX_MESSAGE} characters or fewer.`,
    message_not_allowed: (res && res.why === "links") ? "Please don't include links, handles or @names."
      : (res && res.why === "contact") ? "Please don't include phone numbers or contact details."
      : "Let's keep shout-outs kind and positive — try different words.",
    bad_kind: "Pick what they did first.",
  })[code] || "Something went wrong — please try again.";
}

// ---------------------------------------------------------------------------
// Feed
// ---------------------------------------------------------------------------
async function loadShoutoutFeed() {
  const { data, error } = await supabase.rpc("shoutout_feed", { p_student_id: shoutoutMe(), p_limit: 30 });
  if (error || !data || !data.ok) return false;
  const previous = sostate.knownIds;
  sostate.mode = data.mode;
  sostate.items = data.items || [];
  sostate.roster = data.roster || [];
  sostate.sentToday = data.sent_today || 0;
  sostate.dailyLimit = data.daily_limit || 5;
  sostate.loaded = true;

  // Tell the student (once each) about NEW shout-outs addressed to them.
  const fresh = sostate.items.filter((i) => i.to_id === shoutoutMe() && !previous[i.id]);
  sostate.knownIds = {}; sostate.items.forEach((i) => { sostate.knownIds[i.id] = true; });
  if (!sostate.firstLoad && fresh.length) {
    const f = fresh[0];
    toast(`🌟 ${f.from_name} gave you a shout-out — ${SHOUTOUT_KINDS[f.kind] ? SHOUTOUT_KINDS[f.kind].label : "thank you"}!`);
    if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_FEED");
  }
  sostate.firstLoad = false;
  if (typeof renderShoutoutAll === "function") renderShoutoutAll();
  return true;
}

function shoutoutUnseenCount() {
  return sostate.items.filter((i) => i.to_id === shoutoutMe() && Date.parse(i.created_at) > sostate.lastSeenAt).length;
}
function markShoutoutsSeen() {
  sostate.lastSeenAt = Date.now();
  try { localStorage.setItem(sostate.seenKey, String(sostate.lastSeenAt)); } catch (e) { /* private mode — badge just resets next load */ }
  if (typeof renderShoutoutBadge === "function") renderShoutoutBadge();
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------
async function sendShoutout(toId, kind, message) {
  if (sstate.readOnly) { toast(shoutoutErrorText("account_paused")); return { ok: false }; }
  const { data, error } = await supabase.rpc("send_shoutout", { p_from: shoutoutMe(), p_to: toId, p_kind: kind, p_message: message || null });
  if (error || !data) { toast("Couldn't send — check your connection and try again."); return { ok: false }; }
  if (!data.ok) { toast(shoutoutErrorText(data.error, data)); return data; }
  pingShoutouts();
  await loadShoutoutFeed();
  return data;
}

async function reactShoutout(id, emoji) {
  const { data } = await supabase.rpc("react_shoutout", { p_student_id: shoutoutMe(), p_shoutout_id: id, p_emoji: emoji });
  if (data && data.ok) { pingShoutouts(); await loadShoutoutFeed(); }
}

async function reportShoutout(id) {
  if (!confirm("Report this shout-out to your teacher? It will be hidden while they take a look.")) return;
  const { data } = await supabase.rpc("report_shoutout", { p_student_id: shoutoutMe(), p_shoutout_id: id });
  if (data && data.ok) { toast("Thank you — your teacher will take a look."); pingShoutouts(); await loadShoutoutFeed(); }
}

// ---------------------------------------------------------------------------
// Live updates (broadcast pings + poll)
// ---------------------------------------------------------------------------
function pingShoutouts() {
  try { if (sostate.channel) sostate.channel.send({ type: "broadcast", event: "shoutout-ping", payload: {} }); } catch (e) { /* the poll will catch up */ }
}
function scheduleShoutoutRefresh() {
  if (sostate.refreshTimer) return;
  sostate.refreshTimer = setTimeout(() => { sostate.refreshTimer = null; loadShoutoutFeed(); }, 400);
}
function startShoutoutPolling() {
  if (sostate.pollId) clearInterval(sostate.pollId);
  const every = sostate.open ? 10000 : 30000;
  sostate.pollId = setInterval(() => { if (!document.hidden) loadShoutoutFeed(); }, every);
}

async function initShoutouts() {
  if (sostate.started || !sstate.student || !sstate.section) return;
  sostate.started = true;
  sostate.seenKey = `mc_shoutouts_seen_${shoutoutMe()}`;
  try { sostate.lastSeenAt = parseInt(localStorage.getItem(sostate.seenKey) || "0", 10) || 0; } catch (e) { sostate.lastSeenAt = 0; }
  const ok = await loadShoutoutFeed();
  if (!ok) { sostate.started = false; return; }        // migration-57 not run (or offline) — stay invisible rather than break anything
  if (typeof mountShoutoutUI === "function") mountShoutoutUI();
  try {
    sostate.channel = supabase.channel(`shoutouts-${sstate.section.id}`, { config: { broadcast: { self: false } } })
      .on("broadcast", { event: "shoutout-ping" }, scheduleShoutoutRefresh)
      .subscribe();
  } catch (e) { sostate.channel = null; }
  startShoutoutPolling();
}

function teardownShoutouts() {
  try { if (sostate.channel) supabase.removeChannel(sostate.channel); } catch (e) {}
  if (sostate.pollId) clearInterval(sostate.pollId);
  sostate.channel = null; sostate.pollId = null; sostate.started = false;
}
