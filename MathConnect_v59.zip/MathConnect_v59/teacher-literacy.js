// ============================================================================
// MathConnect — Teacher view of the Literacy Arena
// Read-only. Unlike teacher-drills.js, this shows for EVERY subject's
// section, not just Math — literacy is cross-subject by design (see
// migration-59). Numbers come from section_literacy_roster(), a SECURITY
// DEFINER function that resolves each student to their shared learner_id
// progress where one exists, so a student's numbers are the same no matter
// which of their teachers is looking.
// Depends on: state (teacher.js), escapeHtml (supabase-client.js).
// ============================================================================

var tliteracyLoad = { rows: [], loadedAt: null, error: null };

async function fetchSectionLiteracyRoster(sectionId) {
  const { data, error } = await supabase.rpc("section_literacy_roster", { target_section_id: sectionId });
  tliteracyLoad = { rows: data || [], loadedAt: new Date(), error: error ? error.message : null };
  return tliteracyLoad.rows;
}

async function renderTeacherLiteracyPanel() {
  const container = document.getElementById("tab-literacy");
  if (!container) return;
  container.innerHTML = `<p>Loading literacy standings...</p>`;

  const rows = await fetchSectionLiteracyRoster(state.section.id);
  if (tliteracyLoad.error) {
    container.innerHTML = `<p style="color:#c62828;">Couldn't load literacy data: ${escapeHtml(tliteracyLoad.error)}</p>`;
    return;
  }
  if (rows.length === 0) {
    container.innerHTML = `<p>No students in this section yet.</p>`;
    return;
  }

  const unlinked = rows.filter((r) => !r.has_shared_identity).length;
  const noteUnlinked = unlinked > 0
    ? `<p style="color:#b26a00;font-size:0.9rem;">⚠️ ${unlinked} student${unlinked === 1 ? "" : "s"} in this class ${unlinked === 1 ? "isn't" : "aren't"} linked to the shared student directory yet, so their literacy progress won't carry over from/to their other classes until linked (Roster → search/merge).</p>`
    : "";

  const rowsHtml = rows
    .sort((a, b) => b.total_points - a.total_points)
    .map((r) => `
      <tr>
        <td>${escapeHtml(r.full_name)}${r.has_shared_identity ? "" : " ⚠️"}</td>
        <td>${r.total_points}</td>
        <td>${(r.station_points && r.station_points.vocabulary) || 0}</td>
        <td>${(r.station_points && r.station_points.grammar) || 0}</td>
        <td>${(r.station_points && r.station_points.comprehension) || 0}</td>
        <td>${r.last_attempt_at ? new Date(r.last_attempt_at).toLocaleDateString() : "—"}</td>
      </tr>
    `).join("");

  container.innerHTML = `
    <h2>📚 Literacy Arena — Class Standings</h2>
    ${noteUnlinked}
    <table class="table">
      <thead>
        <tr><th>Student</th><th>Total</th><th>Vocabulary</th><th>Grammar</th><th>Comprehension</th><th>Last Played</th></tr>
      </thead>
      <tbody>${rowsHtml}</tbody>
    </table>
  `;
}
