// ============================================================================
// MathConnect — The Archimedes Trial
// The gate above the Eureka gem ladder (rankEngine.js). Unlike the gem
// ladder, this is NEVER a stored pass/fail flag — every check is computed
// LIVE against current content (see migration-24's eureka_trial_status()),
// so as Term 2/3 add stations, practice domains, and Quest chapters, the
// Mission Card naturally re-locks itself without any extra code here.
// migration-44 replaced the old "beat half your grade level" 6th
// requirement with "helped your class complete a Class Quest" — same slot,
// cooperative instead of dominance-based.
//
// Loaded AFTER rankEngine.js, drills.js, since it reuses escapeHtml (from
// supabase-client.js) and renders alongside the rank badge.
// ============================================================================

const TRIAL_CHECKLIST_LABELS = {
  practice_expert: { icon: "🧠", label: "Expert in every Intelligent Practice domain", detail: (p) => `${p.progress}/${p.needed} domains at Expert (tier 4) + 100% mastery` },
  all_stations_attempted: { icon: "🎮", label: "Attempted every unlocked Drill station", detail: (p) => `${p.progress}/${p.needed} stations attempted` },
  all_stations_level15: { icon: "⬆️", label: "Reached Level 15 on every unlocked station", detail: (p) => `${p.progress}/${p.needed} stations at Level 15` },
  quest_half_cleared: { icon: "🗺️", label: "Cleared more than half of Quest Mode", detail: (p) => `${p.progress}/${p.needed}+ chapters fully cleared` },
  attendance_streak_30: { icon: "🗓️", label: "30-day attendance streak, active right now", detail: (p) => `${p.progress}/${p.needed} days` },
  class_quest_contributor: { icon: "🌱", label: "Helped your class complete a Class Quest", detail: (p) => `${p.progress}/${p.needed} completed Class Quests you contributed to` },
};
const TRIAL_CHECKLIST_ORDER = ["practice_expert", "all_stations_attempted", "all_stations_level15", "quest_half_cleared", "attendance_streak_30", "class_quest_contributor"];

var tstate = { status: null, loaded: false };

// Calls the one write path — safe to call repeatedly, only records a fresh
// clear on a false->true transition (see migration-24).
async function loadTrialStatus(forceRefresh) {
  if (tstate.loaded && !forceRefresh) return tstate.status;
  const { data, error } = await supabase.rpc("eureka_trial_check_and_record", { target_student_id: sstate.student.id });
  if (error) { console.error("Trial status error:", error); return null; }
  tstate.status = data;
  tstate.loaded = true;
  return data;
}

function renderTrialChecklistItem(key, item) {
  const passed = !!item.passed;
  const meta = TRIAL_CHECKLIST_LABELS[key];
  return `
  <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid var(--paper-line);">
    <div style="font-size:1.2rem;line-height:1;">${passed ? "✅" : "⬜"}</div>
    <div style="flex:1;">
      <div style="font-weight:600;${passed ? "" : "color:var(--ink-soft);"}">${meta.icon} ${escapeHtml(meta.label)}</div>
      <div class="muted" style="font-size:.8rem;margin-top:2px;">${escapeHtml(meta.detail(item))}</div>
    </div>
  </div>`;
}

// Renders the full Mission Card. Call with a fresh status object (from
// loadTrialStatus). `compact` renders a smaller teaser for the Overview tab.
function renderArchimedesTrialCard(status, opts) {
  opts = opts || {};
  if (!status) return `<div class="card"><p class="muted">Trial status unavailable right now — try again in a moment.</p></div>`;
  const cleared = !!status.overall_cleared;
  const clearedCount = TRIAL_CHECKLIST_ORDER.filter((k) => status[k] && status[k].passed).length;

  if (opts.compact) {
    return `
    <div class="card" style="border-left:4px solid ${cleared ? "var(--gold)" : "var(--sky)"};">
      <div class="pill" style="background:${cleared ? "var(--gold-light)" : "var(--sky-light)"};color:${cleared ? "var(--forest-dark)" : "var(--forest)"};">🏛️ The Archimedes Trial</div>
      <h3 style="margin:10px 0 4px;">${cleared ? "Cleared! You are a Living Legend." : `${clearedCount}/6 requirements met`}</h3>
      <p class="muted" style="font-size:.85rem;">${cleared ? "Keep an eye out — new content in future terms may reopen this Trial." : "Complete all six to claim the title."}</p>
      <button class="btn-outline btn-sm" style="margin-top:8px;" onclick="switchStudentTab('legends')">View Full Trial</button>
    </div>`;
  }

  return `
  <div id="archimedesTrialFull" class="card" style="border-left:4px solid ${cleared ? "var(--gold)" : "var(--sky)"};">
    <div class="pill" style="background:${cleared ? "var(--gold-light)" : "var(--sky-light)"};color:${cleared ? "var(--forest-dark)" : "var(--forest)"};">🏛️ Mission: The Archimedes Trial</div>
    <h2 style="margin:10px 0 4px;">${cleared ? "👑✨ Living Legend" : "Prove you belong at the top"}</h2>
    <p class="muted">Six requirements, checked live. Clear all six and you're crowned a <strong>Living Legend</strong> — but as new stations, practice domains, and Quest chapters arrive in later terms, this Trial can reopen. Legends keep earning it.</p>
    <div style="margin-top:14px;">
      ${TRIAL_CHECKLIST_ORDER.map((k) => renderTrialChecklistItem(k, status[k])).join("")}
    </div>
    ${cleared ? `<div class="empty" style="margin-top:14px;background:var(--gold-light);color:var(--forest-dark);border-radius:8px;padding:10px;">🎉 Trial cleared! This unlocks your spot on the Grade Champion board (see the 🏆 Championship section below).</div>` : ""}
  </div>`;
}
