-- ============================================================================
-- MathConnect — Database Schema for Supabase (PostgreSQL)
-- Online Math Classroom: Class Record, Attendance, Lessons/Tasks, Blended Learning
-- Aligned with DepEd Order No. 015, s. 2026 (Three-Term Calendar, SY 2026-2027)
-- ============================================================================
-- HOW TO USE:
-- 1. Go to your Supabase project → SQL Editor → New query
-- 2. Paste this whole file and click "Run"
-- 3. Done. All tables, policies, and starter data are created.
-- ============================================================================

-- ---------- EXTENSIONS ----------
create extension if not exists "pgcrypto";

-- ---------- TEACHERS ----------
-- Teachers sign in with Supabase Auth (email + password).
-- This table stores their profile info, linked to auth.users.
create table if not exists teachers (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  position text default 'Master Teacher I',
  school text default 'Maria Cristina P. Belcar Agricultural High School',
  created_at timestamptz default now()
);

-- ---------- ADMINS ----------
-- Read-only oversight role across ALL teachers' classes. Deliberately NOT
-- self-service like teacher sign-up — admin rows must be inserted manually
-- by whoever controls this Supabase project. See README for how.
create table if not exists admins (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  created_at timestamptz default now()
);

-- ---------- SECTIONS (CLASSES) ----------
create table if not exists sections (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid references teachers(id) on delete cascade,
  section_name text not null,          -- e.g. "Grade 8 - Rizal"
  grade_level text not null,           -- e.g. "Grade 8"
  subject text default 'Mathematics',
  school_year text default '2026-2027',
  class_code text not null unique,     -- short code students use to log in, e.g. "MATH8R-4T2K"
  -- Grading weights per DepEd DO 015, s. 2026 (Table 9):
  --   'core'      = English/Filipino/Math/Science/AP/GMRC:  WW 20 / PT 50 / EX 30
  --   'mapeh_tle' = EPP-TLE/MAPEH:                           WW 20 / PT 60 / EX 20
  --   'custom'    = teacher-defined (e.g. Senior High subjects with their own weights)
  weight_preset text not null default 'core' check (weight_preset in ('core','mapeh_tle','sls_numeracy','custom')),
  custom_ww numeric,                   -- only used when weight_preset = 'custom'
  custom_pt numeric,
  custom_ex numeric,
  created_at timestamptz default now()
);

-- ---------- LEARNERS (shared school-wide directory) ----------
-- One canonical record per real student, shared across ALL teachers on this
-- Supabase project (i.e. your school). Lets any teacher search for a student
-- already enrolled by another teacher instead of retyping their name —
-- each teacher still keeps their own separate class roster/grades/attendance
-- (a "students" row per section), just linked back to this shared record.
create table if not exists learners (
  id uuid primary key default gen_random_uuid(),
  last_name text not null,
  first_name text not null,
  middle_name text,
  full_name text not null,
  lrn text,
  sex text,
  grade_level text,                 -- e.g. "Grade 8" — helps narrow searches
  created_by uuid references teachers(id),
  created_at timestamptz default now()
);

-- ---------- STUDENTS ----------
create table if not exists students (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  learner_id uuid references learners(id) on delete set null,  -- link to shared directory (nullable)
  lrn text,                             -- Learner Reference Number (optional)
  full_name text not null,              -- auto-generated "First Middle Last" — used for display
  last_name text,                       -- surname, used for alphabetical roster sorting/grouping
  first_name text,
  middle_name text,
  sex text,
  login_code text,                      -- teacher-assigned code students use to sign in (with class code)
  login_count integer not null default 0,
  last_login_at timestamptz,
  auth_user_id uuid references auth.users(id) on delete set null,  -- unused, kept for backward compatibility
  auth_email_version integer not null default 1,                    -- unused, kept for backward compatibility
  created_at timestamptz default now()
);
create unique index if not exists students_section_login_code_idx on students (section_id, login_code);

-- Narrow, purpose-built function students use (anonymously) to record a
-- login — only increments the counter/timestamp for one row, nothing else.
create or replace function public.record_student_login(target_student_id uuid)
returns void language plpgsql security definer as $$
begin
  update students
  set login_count = coalesce(login_count, 0) + 1,
      last_login_at = now()
  where id = target_student_id;
end;
$$;
grant execute on function public.record_student_login(uuid) to anon, authenticated;

-- ---------- TERMS (3-Term Calendar per DepEd DO 9, s. 2026) ----------
create table if not exists terms (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  term_number int not null check (term_number in (1,2,3)),
  term_name text not null,              -- e.g. "Term 1"
  school_year text default '2026-2027',
  start_date date,
  end_date date,
  is_active boolean default false
);

-- ---------- ASSESSMENTS (Written Works / Performance Tasks / Examinations) ----------
-- DepEd DO 015 s.2026 weights for Math (core subject): WW 20% | PT 50% | EXs 30%
-- Within EXs: ST1 30% | ST2 30% | TE 40%
create table if not exists assessments (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  component text not null check (component in ('WW','PT','EX')),
  ex_subtype text check (ex_subtype in ('ST1','ST2','TE')), -- only used when component = 'EX'
  title text not null,
  description text,
  highest_possible_score numeric not null default 100,
  date_given date,
  week_number int,
  -- Performance Task specific details
  pt_instructions text,
  pt_rubric text,
  pt_due_date date,
  created_at timestamptz default now()
);

-- ---------- SCORES ----------
create table if not exists scores (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid references assessments(id) on delete cascade,
  student_id uuid references students(id) on delete cascade,
  raw_score numeric,
  status text not null default 'scored' check (status in ('scored', 'excused', 'unexcused')),
  updated_at timestamptz default now(),
  unique (assessment_id, student_id)
);

-- ---------- ATTENDANCE ----------
create table if not exists attendance (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  student_id uuid references students(id) on delete cascade,
  attendance_date date not null,
  status text not null check (status in ('present','absent_excused','absent_unexcused','late')),
  remarks text,
  created_at timestamptz default now(),
  unique (student_id, attendance_date)
);

-- ---------- WEEKLY LESSONS ----------
create table if not exists lessons (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  week_number int not null,
  title text not null,
  objectives text,
  content text,
  material_url text,           -- optional Google Drive / Docs / Slides link (migration 65)
  date_start date,
  date_end date,
  created_at timestamptz default now()
);

-- ---------- WEEKLY TASKS (linked optionally to an assessment) ----------
create table if not exists tasks (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  assessment_id uuid references assessments(id) on delete set null,
  week_number int not null,
  title text not null,
  task_type text check (task_type in ('WW','PT','EX','Activity')),
  instructions text,
  due_date date,
  created_at timestamptz default now()
);

-- ---------- WEEKLY TOPIC RATINGS (understanding check-in, one per student per lesson) ----------
create table if not exists topic_ratings (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  section_id uuid not null references sections(id) on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (lesson_id, student_id)
);
create index if not exists idx_topic_ratings_lesson on topic_ratings(lesson_id);
create index if not exists idx_topic_ratings_section on topic_ratings(section_id);

-- ---------- BLENDED LEARNING: MODULES ----------
create table if not exists modules (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  week_number int,
  title text not null,
  description text,
  file_url text,               -- link to uploaded material (Supabase Storage or external link)
  modality text check (modality in ('online','offline','face_to_face')),
  created_at timestamptz default now()
);

-- ---------- BLENDED LEARNING: WEEKLY SCHEDULE ----------
create table if not exists schedule (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  week_number int not null,
  day_label text not null,      -- e.g. "Monday"
  modality text check (modality in ('online','offline','face_to_face')),
  activity text,
  created_at timestamptz default now()
);

-- ---------- BLENDED LEARNING: ANNOUNCEMENTS ----------
create table if not exists announcements (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  title text not null,
  content text not null,
  created_at timestamptz default now()
);

-- ---------- BLENDED LEARNING: SUBMISSIONS ----------
create table if not exists submissions (
  id uuid primary key default gen_random_uuid(),
  task_id uuid references tasks(id) on delete cascade,
  student_id uuid references students(id) on delete cascade,
  file_url text,
  notes text,
  submitted_at timestamptz default now(),
  status text default 'submitted' check (status in ('submitted','late','checked','returned')),
  unique (task_id, student_id)
);

-- ---------- BLENDED LEARNING: REFLECTIONS (plain-text, replaces file submissions) ----------
create table if not exists reflections (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references modules(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  section_id uuid not null references sections(id) on delete cascade,
  reflection_text text not null,
  submitted_at timestamptz default now(),
  updated_at timestamptz default now(),
  teacher_feedback text,
  feedback_at timestamptz,
  unique (module_id, student_id)
);
create index if not exists idx_reflections_module on reflections(module_id);
create index if not exists idx_reflections_section on reflections(section_id);

-- ---------- OTHER CONCERNS (roster notes) ----------
create table if not exists other_concerns (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  student_id uuid references students(id) on delete cascade,
  concern_date date default current_date,
  category text default 'General', -- e.g. Behavior, Health, Family, Academic
  note text not null,
  visible_to_student boolean not null default false, -- teacher opts in per-note to share as feedback
  created_at timestamptz default now()
);

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
-- NOTE ON SECURITY MODEL:
-- Students log in with a class code + their name (no email/password), so they
-- are NOT Supabase-authenticated users — their requests use the public "anon"
-- role. To support that while still protecting teacher data from each other,
-- every policy below follows this rule: "anon" requests (students) can read
-- freely (scoped in practice by needing the right class code/section first),
-- but a SIGNED-IN teacher can only read/write data belonging to THEIR OWN
-- sections — not other teachers'. This is enforced with
-- `auth.role() = 'anon' or <owns this row>` on every read policy.
-- Residual limitation: because student access doesn't require a password,
-- anyone who has your Supabase anon key (not just enrolled students) could
-- still read data anonymously, the same way a student's browser does. This
-- is an acceptable tradeoff for a low-stakes classroom tool, but avoid
-- storing highly sensitive personal data (e.g. home addresses, medical
-- records) beyond what's described here.

-- ============================================================================
-- RLS HELPER FUNCTIONS
-- ----------------------------------------------------------------------------
-- These are SECURITY DEFINER, meaning they bypass row-level security when
-- run — which is essential here: "sections" policies need to check
-- "students", and "students" policies need to check "sections". If those
-- checks were plain subqueries, evaluating one policy would trigger the
-- other's policy, which triggers the first again — infinite recursion.
-- Routing the cross-table checks through these functions breaks that cycle.
-- ============================================================================
create or replace function public.is_teacher_of_section(sec_id uuid)
returns boolean language sql security definer stable as $$
  select exists (select 1 from sections s where s.id = sec_id and s.teacher_id = auth.uid());
$$;

create or replace function public.is_registered_student_of_section(sec_id uuid)
returns boolean language sql security definer stable as $$
  select exists (select 1 from students st where st.section_id = sec_id and st.auth_user_id = auth.uid());
$$;

create or replace function public.is_own_student_row(target_student_id uuid)
returns boolean language sql security definer stable as $$
  select exists (select 1 from students st where st.id = target_student_id and st.auth_user_id = auth.uid());
$$;

create or replace function public.is_teacher_of_assessment(target_assessment_id uuid)
returns boolean language sql security definer stable as $$
  select exists (select 1 from assessments a join sections s on s.id = a.section_id where a.id = target_assessment_id and s.teacher_id = auth.uid());
$$;

create or replace function public.is_teacher_of_task(target_task_id uuid)
returns boolean language sql security definer stable as $$
  select exists (select 1 from tasks t join sections s on s.id = t.section_id where t.id = target_task_id and s.teacher_id = auth.uid());
$$;

create or replace function public.is_admin()
returns boolean language sql security definer stable as $$
  select exists (select 1 from admins where id = auth.uid());
$$;

alter table teachers enable row level security;
alter table admins enable row level security;
alter table sections enable row level security;
alter table learners enable row level security;
alter table topic_ratings enable row level security;
alter table reflections enable row level security;
alter table students enable row level security;
alter table terms enable row level security;
alter table assessments enable row level security;
alter table scores enable row level security;
alter table attendance enable row level security;
alter table lessons enable row level security;
alter table tasks enable row level security;
alter table modules enable row level security;
alter table schedule enable row level security;
alter table announcements enable row level security;
alter table submissions enable row level security;
alter table other_concerns enable row level security;

-- Teachers: only the owning teacher can manage their own profile
drop policy if exists "teacher manage own profile" on teachers;
create policy "teacher manage own profile" on teachers
  for all using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "admin reads own profile" on admins;
create policy "admin reads own profile" on admins for select using (auth.uid() = id);

drop policy if exists "admin read teachers" on teachers;
create policy "admin read teachers" on teachers for select using (is_admin());

-- Learners (shared directory): any signed-in teacher can search/add/fix typos;
-- only the teacher who created a record can delete it (to prevent accidental
-- cross-teacher deletions). Not readable by students/anon — this is a
-- teacher-only convenience tool, not part of any student-facing page.
drop policy if exists "teachers read learners" on learners;
create policy "teachers read learners" on learners for select using (auth.uid() is not null);
drop policy if exists "teachers insert learners" on learners;
create policy "teachers insert learners" on learners for insert with check (auth.uid() is not null);
drop policy if exists "teachers update learners" on learners;
create policy "teachers update learners" on learners for update using (auth.uid() is not null);
drop policy if exists "creator deletes learners" on learners;
create policy "creator deletes learners" on learners for delete using (auth.uid() = created_by);

-- Sections: teacher owns/manages; anyone (anon, for student login lookup) can read
drop policy if exists "public read sections" on sections;
create policy "public read sections" on sections for select using (
  auth.role() = 'anon' or teacher_id = auth.uid() or is_admin()
);
drop policy if exists "teacher insert sections" on sections;
create policy "teacher insert sections" on sections for insert with check (auth.uid() = teacher_id);
drop policy if exists "teacher update sections" on sections;
create policy "teacher update sections" on sections for update using (auth.uid() = teacher_id);
drop policy if exists "teacher delete sections" on sections;
create policy "teacher delete sections" on sections for delete using (auth.uid() = teacher_id);

-- Students: public read (needed for class-code login + dashboards); teacher writes
drop policy if exists "public read students" on students;
create policy "public read students" on students for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write students" on students;
create policy "teacher write students" on students for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update students" on students;
create policy "teacher update students" on students for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "student claims own row" on students;
drop policy if exists "teacher delete students" on students;
create policy "teacher delete students" on students for delete using (
  is_teacher_of_section(section_id)
);

-- Generic pattern reused for the rest: public read, teacher-owned write
drop policy if exists "public read terms" on terms;
create policy "public read terms" on terms for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write terms" on terms;
create policy "teacher write terms" on terms for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update terms" on terms;
create policy "teacher update terms" on terms for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete terms" on terms;
create policy "teacher delete terms" on terms for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read assessments" on assessments;
create policy "public read assessments" on assessments for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write assessments" on assessments;
create policy "teacher write assessments" on assessments for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update assessments" on assessments;
create policy "teacher update assessments" on assessments for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete assessments" on assessments;
create policy "teacher delete assessments" on assessments for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read scores" on scores;
create policy "public read scores" on scores for select using (
  auth.role() = 'anon' or is_teacher_of_assessment(assessment_id) or is_admin()
);
drop policy if exists "teacher write scores" on scores;
create policy "teacher write scores" on scores for insert with check (
  is_teacher_of_assessment(assessment_id)
);
drop policy if exists "teacher update scores" on scores;
create policy "teacher update scores" on scores for update using (
  is_teacher_of_assessment(assessment_id)
);
drop policy if exists "teacher delete scores" on scores;
create policy "teacher delete scores" on scores for delete using (
  is_teacher_of_assessment(assessment_id)
);

drop policy if exists "public read attendance" on attendance;
create policy "public read attendance" on attendance for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write attendance" on attendance;
create policy "teacher write attendance" on attendance for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update attendance" on attendance;
create policy "teacher update attendance" on attendance for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete attendance" on attendance;
create policy "teacher delete attendance" on attendance for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read lessons" on lessons;
create policy "public read lessons" on lessons for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write lessons" on lessons;
create policy "teacher write lessons" on lessons for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update lessons" on lessons;
create policy "teacher update lessons" on lessons for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete lessons" on lessons;
create policy "teacher delete lessons" on lessons for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read tasks" on tasks;
create policy "public read tasks" on tasks for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write tasks" on tasks;
create policy "teacher write tasks" on tasks for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update tasks" on tasks;
create policy "teacher update tasks" on tasks for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete tasks" on tasks;
create policy "teacher delete tasks" on tasks for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read topic_ratings" on topic_ratings;
create policy "public read topic_ratings" on topic_ratings for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "anyone insert topic_ratings" on topic_ratings;
create policy "anyone insert topic_ratings" on topic_ratings for insert with check (true);
drop policy if exists "anyone update topic_ratings" on topic_ratings;
create policy "anyone update topic_ratings" on topic_ratings for update using (true);
drop policy if exists "teacher delete topic_ratings" on topic_ratings;
create policy "teacher delete topic_ratings" on topic_ratings for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read modules" on modules;
create policy "public read modules" on modules for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write modules" on modules;
create policy "teacher write modules" on modules for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update modules" on modules;
create policy "teacher update modules" on modules for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete modules" on modules;
create policy "teacher delete modules" on modules for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read schedule" on schedule;
create policy "public read schedule" on schedule for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write schedule" on schedule;
create policy "teacher write schedule" on schedule for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update schedule" on schedule;
create policy "teacher update schedule" on schedule for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete schedule" on schedule;
create policy "teacher delete schedule" on schedule for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read announcements" on announcements;
create policy "public read announcements" on announcements for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher write announcements" on announcements;
create policy "teacher write announcements" on announcements for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update announcements" on announcements;
create policy "teacher update announcements" on announcements for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete announcements" on announcements;
create policy "teacher delete announcements" on announcements for delete using (
  is_teacher_of_section(section_id)
);

-- Submissions: public read + students (anon) can insert/update their own; teacher can also manage
drop policy if exists "public read submissions" on submissions;
create policy "public read submissions" on submissions for select using (
  auth.role() = 'anon' or is_teacher_of_task(task_id) or is_admin()
);
drop policy if exists "anyone insert submissions" on submissions;
drop policy if exists "student or teacher insert submissions" on submissions;
drop policy if exists "anyone insert submissions" on submissions;
create policy "anyone insert submissions" on submissions for insert with check (true);
drop policy if exists "anyone update submissions" on submissions;
drop policy if exists "student or teacher update submissions" on submissions;
create policy "anyone update submissions" on submissions for update using (true);
drop policy if exists "teacher delete submissions" on submissions;
create policy "teacher delete submissions" on submissions for delete using (
  is_teacher_of_task(task_id)
);

drop policy if exists "public read reflections" on reflections;
create policy "public read reflections" on reflections for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "anyone insert reflections" on reflections;
create policy "anyone insert reflections" on reflections for insert with check (true);
drop policy if exists "anyone update reflections" on reflections;
create policy "anyone update reflections" on reflections for update using (true);
drop policy if exists "teacher delete reflections" on reflections;
create policy "teacher delete reflections" on reflections for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read other_concerns" on other_concerns;
create policy "public read other_concerns" on other_concerns for select using (
  (auth.role() = 'anon' and visible_to_student = true)
  or is_teacher_of_section(section_id)
  or is_admin()
);
drop policy if exists "teacher write other_concerns" on other_concerns;
create policy "teacher write other_concerns" on other_concerns for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update other_concerns" on other_concerns;
create policy "teacher update other_concerns" on other_concerns for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete other_concerns" on other_concerns;
create policy "teacher delete other_concerns" on other_concerns for delete using (
  is_teacher_of_section(section_id)
);

-- ============================================================================
-- AUTO-CREATE TEACHER PROFILE ON SIGNUP
-- ============================================================================
create or replace function public.handle_new_teacher()
returns trigger as $$
begin
  -- Only teacher sign-up passes a full_name in the user's metadata (see
  -- teacherSignUp() in auth.js). Student registration never does, so this
  -- correctly skips creating a bogus teacher row for students.
  if new.raw_user_meta_data->>'full_name' is not null then
    insert into public.teachers (id, full_name)
    values (new.id, new.raw_user_meta_data->>'full_name');
  end if;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_teacher();

-- ============================================================================
-- MATH DRILL ARENA — gamified drill exercises + point system + leaderboard
-- ============================================================================
create table if not exists drill_progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade unique,
  total_points integer not null default 0,
  games_played integer not null default 0,
  best_streak integer not null default 0,
  -- highest unlocked level (1-15) per topic
  topic_levels jsonb not null default '{"basic":1,"order":1,"integers":1,"fractions":1,"decimals":1,"algebra":1,"ratio":1,"percent":1,"geometry":1,"patterns":1,"statistics":1,"probability":1}'::jsonb,
  -- cumulative points earned PER STATION (topic) — powers the fair, per-station leaderboard
  topic_points jsonb not null default '{"basic":0,"order":0,"integers":0,"fractions":0,"decimals":0,"algebra":0,"ratio":0,"percent":0,"geometry":0,"patterns":0,"statistics":0,"probability":0}'::jsonb,
  -- MathLegends overall rank (see rankEngine.js) — 15-tier, star-driven,
  -- separate from topic_levels. Stars come from Drills, Daily Challenge, and
  -- Boss Battles. See migration-20-mathlegends-ranks.sql for pre-existing installs.
  mastery_tier int not null default 1 check (mastery_tier between 1 and 15),
  mastery_stars int not null default 0 check (mastery_stars >= 0),
  updated_at timestamptz default now()
);

create table if not exists drill_attempts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  topic text not null,
  level int not null,
  correct_count int not null,
  total_questions int not null,
  points_earned int not null,
  bonus_points int not null default 0,
  penalty_points int not null default 0,
  leveled_up boolean not null default false,
  played_at timestamptz default now()
);
create index if not exists drill_attempts_student_idx on drill_attempts (student_id);

create or replace function public.is_teacher_of_student(target_student_id uuid)
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from students st join sections s on s.id = st.section_id
    where st.id = target_student_id and s.teacher_id = auth.uid()
  );
$$;

alter table drill_progress enable row level security;
alter table drill_attempts enable row level security;

drop policy if exists "public read drill_progress" on drill_progress;
create policy "public read drill_progress" on drill_progress for select using (true);
drop policy if exists "anyone insert drill_progress" on drill_progress;
create policy "anyone insert drill_progress" on drill_progress for insert with check (true);
drop policy if exists "anyone update drill_progress" on drill_progress;
create policy "anyone update drill_progress" on drill_progress for update using (true);
drop policy if exists "teacher delete drill_progress" on drill_progress;
create policy "teacher delete drill_progress" on drill_progress for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read drill_attempts" on drill_attempts;
create policy "public read drill_attempts" on drill_attempts for select using (true);
drop policy if exists "anyone insert drill_attempts" on drill_attempts;
create policy "anyone insert drill_attempts" on drill_attempts for insert with check (true);
-- ---------- Station locks: admin can lock/unlock any station, school-wide ----------
-- (see migration-22-new-drill-stations.sql for the full explanation)
create table if not exists drill_station_locks (
  station_key text primary key,
  locked boolean not null default false,
  note text,
  locked_by uuid references admins(id),
  locked_at timestamptz default now()
);
alter table drill_station_locks enable row level security;
drop policy if exists "public read drill_station_locks" on drill_station_locks;
create policy "public read drill_station_locks" on drill_station_locks for select using (true);
drop policy if exists "admin write drill_station_locks" on drill_station_locks;
create policy "admin write drill_station_locks" on drill_station_locks for insert with check (is_admin());
drop policy if exists "admin update drill_station_locks" on drill_station_locks;
create policy "admin update drill_station_locks" on drill_station_locks for update using (is_admin());
drop policy if exists "admin delete drill_station_locks" on drill_station_locks;
create policy "admin delete drill_station_locks" on drill_station_locks for delete using (is_admin());
insert into drill_station_locks (station_key, locked, note) values
  ('basic', false, null), ('order', false, null), ('integers', false, null),
  ('fractions', false, null), ('decimals', false, null), ('algebra', false, null),
  ('ratio', true, 'Coming for Term 2!'), ('percent', true, 'Coming for Term 2!'),
  ('geometry', true, 'Coming for Term 2!'), ('patterns', true, 'Coming for Term 2!'),
  ('statistics', true, 'Coming for Term 2!'), ('probability', true, 'Coming for Term 2!')
on conflict (station_key) do nothing;

drop policy if exists "teacher delete drill_attempts" on drill_attempts;
create policy "teacher delete drill_attempts" on drill_attempts for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

create or replace function public.grade_level_drill_leaderboard(target_grade_level text, result_limit int default 10)
returns table(student_id uuid, full_name text, section_id uuid, section_name text, total_points integer, games_played integer, best_streak integer)
language sql security definer stable as $$
  select st.id, st.full_name, se.id, se.section_name, dp.total_points, dp.games_played, dp.best_streak
  from drill_progress dp
  join students st on st.id = dp.student_id
  join sections se on se.id = st.section_id
  where se.grade_level = target_grade_level
  order by dp.total_points desc
  limit result_limit;
$$;
grant execute on function public.grade_level_drill_leaderboard(text, int) to anon, authenticated;

create or replace function public.student_drill_rank(target_student_id uuid)
returns table(rnk bigint, total_points integer, total_students bigint)
language sql security definer stable as $$
  with target_grade as (
    select se.grade_level from students st join sections se on se.id = st.section_id where st.id = target_student_id
  ), board as (
    select dp.student_id, dp.total_points, row_number() over (order by dp.total_points desc) as rnk
    from drill_progress dp
    join students st on st.id = dp.student_id
    join sections se on se.id = st.section_id
    where se.grade_level = (select grade_level from target_grade)
  )
  select b.rnk, b.total_points, (select count(*) from board) from board b where b.student_id = target_student_id;
$$;
grant execute on function public.student_drill_rank(uuid) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- STATION leaderboard — top scorers for ONE station (topic), within a grade
-- level, school-wide across every teacher's sections. This is the fair
-- alternative to the combined-total Top 10 above: a student who hasn't
-- touched Fractions can't out-rank a Fractions specialist on points earned
-- elsewhere.
-- ----------------------------------------------------------------------------
create or replace function public.station_leaderboard(target_grade_level text, target_topic text, result_limit int default 10)
returns table(student_id uuid, full_name text, section_id uuid, section_name text, topic_points integer, topic_level integer)
language sql security definer stable as $$
  select st.id, st.full_name, se.id, se.section_name,
    coalesce((dp.topic_points ->> target_topic)::int, 0),
    coalesce((dp.topic_levels ->> target_topic)::int, 1)
  from drill_progress dp
  join students st on st.id = dp.student_id
  join sections se on se.id = st.section_id
  where se.grade_level = target_grade_level
    and coalesce((dp.topic_points ->> target_topic)::int, 0) > 0
  order by coalesce((dp.topic_points ->> target_topic)::int, 0) desc
  limit result_limit;
$$;
grant execute on function public.station_leaderboard(text, text, int) to anon, authenticated;

create or replace function public.student_station_rank(target_student_id uuid, target_topic text)
returns table(rnk bigint, topic_points integer, total_students bigint)
language sql security definer stable as $$
  with target_grade as (
    select se.grade_level from students st join sections se on se.id = st.section_id where st.id = target_student_id
  ), board as (
    select dp.student_id, coalesce((dp.topic_points ->> target_topic)::int, 0) as pts,
      row_number() over (order by coalesce((dp.topic_points ->> target_topic)::int, 0) desc) as rnk
    from drill_progress dp
    join students st on st.id = dp.student_id
    join sections se on se.id = st.section_id
    where se.grade_level = (select grade_level from target_grade)
  )
  select b.rnk, b.pts, (select count(*) from board) from board b where b.student_id = target_student_id;
$$;
grant execute on function public.student_station_rank(uuid, text) to anon, authenticated;

-- ============================================================================
-- QUEST MODE — story-driven chapter map over the Drill Arena question engine
-- (12 subject-themed chapters x 10 levels, stars per level). See
-- questEngine.js / quest-ui.js / teacher-quest.js and
-- migration-21-quest-mode.sql for the standalone-migration version.
-- ============================================================================
create table if not exists quest_progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade unique,
  level_stars jsonb not null default '{}'::jsonb,
  total_stars integer not null default 0,
  chapters_unlocked integer not null default 1,
  runs_played integer not null default 0,
  updated_at timestamptz default now()
);

create table if not exists quest_attempts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  chapter_key text not null,
  level_num int not null,
  correct_count int not null,
  total_questions int not null,
  stars_earned int not null default 0,
  points_earned int not null default 0,
  played_at timestamptz default now()
);
create index if not exists quest_attempts_student_idx on quest_attempts (student_id);

alter table quest_progress enable row level security;
alter table quest_attempts enable row level security;

drop policy if exists "public read quest_progress" on quest_progress;
create policy "public read quest_progress" on quest_progress for select using (true);
drop policy if exists "anyone insert quest_progress" on quest_progress;
create policy "anyone insert quest_progress" on quest_progress for insert with check (true);
drop policy if exists "anyone update quest_progress" on quest_progress;
create policy "anyone update quest_progress" on quest_progress for update using (true);
drop policy if exists "teacher delete quest_progress" on quest_progress;
create policy "teacher delete quest_progress" on quest_progress for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read quest_attempts" on quest_attempts;
create policy "public read quest_attempts" on quest_attempts for select using (true);
drop policy if exists "anyone insert quest_attempts" on quest_attempts;
create policy "anyone insert quest_attempts" on quest_attempts for insert with check (true);
drop policy if exists "teacher delete quest_attempts" on quest_attempts;
create policy "teacher delete quest_attempts" on quest_attempts for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ---------- LOGIN AUDIT LOG (see migration-29 for full design notes) ----------
-- Not a foreign key on user_id on purpose — it must survive account deletion,
-- and full_name is a snapshot at login time for the same reason. Rows can
-- only be created via record_login_event() below; only admins can read it.
create table if not exists login_audit_log (
  id uuid primary key default gen_random_uuid(),
  user_role text not null check (user_role in ('admin', 'teacher', 'student')),
  user_id uuid,
  full_name text not null,
  logged_in_at timestamptz not null default now()
);
create index if not exists login_audit_log_logged_in_at_idx on login_audit_log (logged_in_at desc);
create index if not exists login_audit_log_role_idx on login_audit_log (user_role);

alter table login_audit_log enable row level security;
drop policy if exists "admin read login_audit_log" on login_audit_log;
create policy "admin read login_audit_log" on login_audit_log for select using (is_admin());

create or replace function public.record_login_event(p_role text, p_user_id uuid, p_full_name text)
returns void language plpgsql security definer as $$
begin
  if p_role not in ('admin', 'teacher', 'student') then
    raise exception 'invalid role for login audit: %', p_role;
  end if;
  insert into login_audit_log (user_role, user_id, full_name)
  values (p_role, p_user_id, p_full_name);
end;
$$;
grant execute on function public.record_login_event(text, uuid, text) to anon, authenticated;

-- ---------- ADMIN ACTION LOG (see migration-30 for full design notes) ----------
-- target_name is plain text, not a FK, because the target itself may be
-- deleted by the very action being logged (e.g. delete_account). Rows can
-- only be created via record_admin_action() below; only admins can read it.
create table if not exists admin_action_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references admins(id) on delete set null,
  admin_name text not null,
  action_type text not null check (action_type in (
    'status_change', 'edit_account', 'delete_account',
    'lock_change', 'edit_entry', 'delete_entry', 'finalize_champion'
  )),
  target_table text,
  target_name text,
  details text,
  created_at timestamptz not null default now()
);
create index if not exists admin_action_log_created_at_idx on admin_action_log (created_at desc);
create index if not exists admin_action_log_action_type_idx on admin_action_log (action_type);

alter table admin_action_log enable row level security;
drop policy if exists "admin read admin_action_log" on admin_action_log;
create policy "admin read admin_action_log" on admin_action_log for select using (is_admin());

create or replace function public.record_admin_action(
  p_action_type text, p_target_table text, p_target_name text, p_details text default null
)
returns void language plpgsql security definer as $$
begin
  if not is_admin() then
    raise exception 'only admins can record admin actions';
  end if;
  insert into admin_action_log (admin_id, admin_name, action_type, target_table, target_name, details)
  select auth.uid(), a.full_name, p_action_type, p_target_table, p_target_name, p_details
  from admins a where a.id = auth.uid();
end;
$$;
grant execute on function public.record_admin_action(text, text, text, text) to authenticated;

-- ---------- MATH PET (see migration-32 for full design notes) ----------
alter table student_engagement add column if not exists green_points integer not null default 0;

create table if not exists pet_types (
  key text primary key, name text not null, icon text not null, description text,
  sort_order integer not null default 0, active boolean not null default true
);
insert into pet_types (key, name, icon, description, sort_order) values
  ('numo_fox',      'Numo the Number Fox',    '🦊', 'Quick, clever, and always counting something.',        1),
  ('pico_penguin',  'Pico the Pi Penguin',    '🐧', 'Waddles in perfect circles. Loves rounding up snacks.',  2),
  ('digit_dragon',  'Digit the Digit Dragon', '🐲', 'Breathes out equations instead of fire (mostly).',       3),
  ('sumi_bunny',    'Sumi the Sum Bunny',     '🐰', 'Hops from problem to problem, adding up wins.',          4),
  ('ari_owl',       'Ari the Abacus Owl',     '🦉', 'Wise, patient, and great at late-night reviewing.',      5)
on conflict (key) do update set name = excluded.name, icon = excluded.icon, description = excluded.description,
  sort_order = excluded.sort_order, active = true;
alter table pet_types enable row level security;
drop policy if exists "public read pet_types" on pet_types;
create policy "public read pet_types" on pet_types for select using (true);

create table if not exists pet_food_items (
  key text primary key, name text not null, icon text not null,
  cost_coins integer not null, restore_amount integer not null,
  sort_order integer not null default 0, active boolean not null default true
);
insert into pet_food_items (key, name, icon, cost_coins, restore_amount, sort_order) values
  ('math_snack',    'Math Snack',        '🍪', 5,  20,  1),
  ('number_nuggets','Number Nuggets',    '🍱', 10, 45,  2),
  ('equation_cake', 'Equation Cake',     '🎂', 20, 100, 3)
on conflict (key) do update set name = excluded.name, icon = excluded.icon, cost_coins = excluded.cost_coins,
  restore_amount = excluded.restore_amount, sort_order = excluded.sort_order, active = true;
alter table pet_food_items enable row level security;
drop policy if exists "public read pet_food_items" on pet_food_items;
create policy "public read pet_food_items" on pet_food_items for select using (true);

create table if not exists student_pets (
  student_id uuid primary key references students(id) on delete cascade,
  pet_type_key text not null references pet_types(key), pet_name text,
  hunger integer not null default 100, growth_points integer not null default 0,
  food_inventory jsonb not null default '{}'::jsonb,
  adopted_at timestamptz default now(), last_fed_at timestamptz, updated_at timestamptz default now()
);
alter table student_pets enable row level security;
drop policy if exists "public read student_pets" on student_pets;
create policy "public read student_pets" on student_pets for select using (true);
drop policy if exists "teacher delete student_pets" on student_pets;
create policy "teacher delete student_pets" on student_pets for delete using (
  is_teacher_of_student(student_id) or is_admin()
);
-- No "anyone insert/update" policy on purpose — see migration-32.

create table if not exists pet_feed_log (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  fed_with text not null check (fed_with in ('green_points', 'food')),
  food_key text references pet_food_items(key), amount integer not null, fed_at timestamptz default now()
);
create index if not exists pet_feed_log_student_idx on pet_feed_log (student_id);
alter table pet_feed_log enable row level security;
drop policy if exists "public read pet_feed_log" on pet_feed_log;
create policy "public read pet_feed_log" on pet_feed_log for select using (true);
drop policy if exists "teacher delete pet_feed_log" on pet_feed_log;
create policy "teacher delete pet_feed_log" on pet_feed_log for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

create or replace function public.adopt_pet(target_student_id uuid, target_pet_type_key text, target_pet_name text default null)
returns table(success boolean, message text, pet jsonb)
language plpgsql security definer as $$
declare type_active boolean; existing record;
begin
  select active into type_active from pet_types where key = target_pet_type_key;
  if type_active is null then return query select false, 'That pet does not exist.', null::jsonb; return; end if;
  if not type_active then return query select false, 'That pet is not available right now.', null::jsonb; return; end if;
  select * into existing from student_pets where student_id = target_student_id for update;
  if found then return query select false, 'You already have a pet!', to_jsonb(existing); return; end if;
  insert into student_pets (student_id, pet_type_key, pet_name, hunger, growth_points, food_inventory)
  values (target_student_id, target_pet_type_key, nullif(trim(target_pet_name), ''), 100, 0, '{}'::jsonb)
  returning * into existing;
  return query select true, 'Adopted!', to_jsonb(existing);
end;
$$;
grant execute on function public.adopt_pet(uuid, text, text) to anon, authenticated;

create or replace function public.feed_pet_green_points(target_student_id uuid, amount integer)
returns table(success boolean, message text, new_green_points integer, new_hunger integer, new_growth_points integer)
language plpgsql security definer as $$
declare current_gp integer; pet record;
begin
  if amount is null or amount <= 0 then return query select false, 'Invalid amount.', null::integer, null::integer, null::integer; return; end if;
  select green_points into current_gp from student_engagement where student_id = target_student_id for update;
  if current_gp is null then return query select false, 'No Green Points wallet found yet — go play something first!', null::integer, null::integer, null::integer; return; end if;
  if current_gp < amount then return query select false, format('Not enough Green Points — need %s, have %s.', amount, current_gp), current_gp, null::integer, null::integer; return; end if;
  select * into pet from student_pets where student_id = target_student_id for update;
  if not found then return query select false, 'Adopt a pet first!', current_gp, null::integer, null::integer; return; end if;
  current_gp := current_gp - amount;
  update student_engagement set green_points = current_gp, updated_at = now() where student_id = target_student_id;
  update student_pets set growth_points = pet.growth_points + amount, hunger = least(100, pet.hunger + amount),
    last_fed_at = now(), updated_at = now() where student_id = target_student_id
    returning hunger, growth_points into pet.hunger, pet.growth_points;
  insert into pet_feed_log (student_id, fed_with, amount) values (target_student_id, 'green_points', amount);
  return query select true, 'Fed!', current_gp, pet.hunger, pet.growth_points;
end;
$$;
grant execute on function public.feed_pet_green_points(uuid, integer) to anon, authenticated;

create or replace function public.purchase_pet_food(target_student_id uuid, target_food_key text)
returns table(success boolean, message text, new_coins integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare food_cost integer; food_active boolean; current_coins integer; current_inventory jsonb; owned_count integer;
begin
  select cost_coins, active into food_cost, food_active from pet_food_items where key = target_food_key;
  if food_cost is null then return query select false, 'That food does not exist.', null::integer, null::jsonb; return; end if;
  if not food_active then return query select false, 'That food is no longer available.', null::integer, null::jsonb; return; end if;
  if not exists (select 1 from student_pets where student_id = target_student_id) then
    return query select false, 'Adopt a pet first!', null::integer, null::jsonb; return;
  end if;
  select coins into current_coins from student_engagement where student_id = target_student_id for update;
  if current_coins is null then return query select false, 'No coin wallet found yet — go play something first!', null::integer, null::jsonb; return; end if;
  if current_coins < food_cost then return query select false, format('Not enough coins — need %s, have %s.', food_cost, current_coins), current_coins, null::jsonb; return; end if;
  select coalesce(food_inventory, '{}'::jsonb) into current_inventory from student_pets where student_id = target_student_id for update;
  owned_count := coalesce((current_inventory ->> target_food_key)::integer, 0);
  current_inventory := jsonb_set(current_inventory, array[target_food_key], to_jsonb(owned_count + 1));
  current_coins := current_coins - food_cost;
  update student_engagement set coins = current_coins, updated_at = now() where student_id = target_student_id;
  update student_pets set food_inventory = current_inventory, updated_at = now() where student_id = target_student_id;
  return query select true, 'Purchased!', current_coins, current_inventory;
end;
$$;
grant execute on function public.purchase_pet_food(uuid, text) to anon, authenticated;

create or replace function public.feed_pet_food(target_student_id uuid, target_food_key text)
returns table(success boolean, message text, new_hunger integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare pet record; restore_amt integer; owned_count integer; new_inventory jsonb;
begin
  select restore_amount into restore_amt from pet_food_items where key = target_food_key;
  if restore_amt is null then return query select false, 'That food does not exist.', null::integer, null::jsonb; return; end if;
  select * into pet from student_pets where student_id = target_student_id for update;
  if not found then return query select false, 'Adopt a pet first!', null::integer, null::jsonb; return; end if;
  owned_count := coalesce((pet.food_inventory ->> target_food_key)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that food — buy some in the Shop!', pet.hunger, pet.food_inventory; return;
  end if;
  new_inventory := jsonb_set(pet.food_inventory, array[target_food_key], to_jsonb(owned_count - 1));
  update student_pets set hunger = least(100, pet.hunger + restore_amt), food_inventory = new_inventory,
    last_fed_at = now(), updated_at = now() where student_id = target_student_id returning hunger into pet.hunger;
  insert into pet_feed_log (student_id, fed_with, food_key, amount) values (target_student_id, 'food', target_food_key, restore_amt);
  return query select true, 'Fed!', pet.hunger, new_inventory;
end;
$$;
grant execute on function public.feed_pet_food(uuid, text) to anon, authenticated;

-- ============================================================================
-- Done. Next: create your teacher account in the app (Sign Up), then start
-- adding sections, students, lessons, tasks, and assessments.
--
-- HOW TO CREATE AN ADMIN ACCOUNT (optional, done manually, once per admin):
-- 1. Supabase → Authentication → Users → "Add user" → "Create new user"
--    Enter their email + a temporary password. Leave "Auto Confirm User" ON.
-- 2. Copy the new user's UUID (shown in the users list after creating them).
-- 3. Supabase → SQL Editor → run:
--      insert into admins (id, full_name) values ('paste-the-uuid-here', 'Full Name');
-- 4. Give that person the site URL, their email, and the temporary password.
--    They sign in via the "Admin Sign In" link on the login page.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- TEACHING NOTES (migration 65) — Blended Learning → Teaching Notes tab
-- ----------------------------------------------------------------------------
create table if not exists teaching_notes (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  week_number int,
  title text not null,
  description text,                          -- optional one-liner under the title
  note_text text,                            -- pasted notes; "---page---" starts a new page
  drive_url text,                            -- Google Drive / Docs / Slides / Sheets link
  render_math boolean not null default true, -- show x^2, 1/2, sqrt(), $$…$$ as proper notation
  auto_page boolean not null default true,   -- split very long text into readable pages
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_teaching_notes_term on teaching_notes(term_id);
create index if not exists idx_teaching_notes_section on teaching_notes(section_id);

alter table teaching_notes enable row level security;

-- Same trust model as "modules": students (anon) read, the section's teacher writes.
drop policy if exists "public read teaching_notes" on teaching_notes;
create policy "public read teaching_notes" on teaching_notes for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher insert teaching_notes" on teaching_notes;
create policy "teacher insert teaching_notes" on teaching_notes for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update teaching_notes" on teaching_notes;
create policy "teacher update teaching_notes" on teaching_notes for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete teaching_notes" on teaching_notes;
create policy "teacher delete teaching_notes" on teaching_notes for delete using (
  is_teacher_of_section(section_id)
);
