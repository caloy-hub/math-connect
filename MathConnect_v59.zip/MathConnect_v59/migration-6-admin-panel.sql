-- ============================================================================
-- MathConnect — Migration 6: Admin oversight panel
-- ----------------------------------------------------------------------------
-- Adds a read-only "admin" role that can see, across ALL teachers:
--   - Consolidated general average per class + DepEd proficiency level
--   - Attendance percentage per class
--   - How many teachers and classes are using the app
-- Admins CANNOT edit anything — this is oversight-only, and deliberately
-- does NOT expose lesson content, blended learning materials, submissions,
-- or "Other Concerns" notes (those stay teacher/student-only).
--
-- ⚠️ IMPORTANT — admin accounts are NOT self-service on purpose (unlike
-- teacher sign-up). Only someone with direct access to your Supabase project
-- can create one. See "How to create an admin account" at the bottom of
-- this file.
--
-- Safe to run on your existing database — nothing is deleted.
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

create table if not exists admins (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  created_at timestamptz default now()
);
alter table admins enable row level security;

drop policy if exists "admin reads own profile" on admins;
create policy "admin reads own profile" on admins for select using (auth.uid() = id);

create or replace function public.is_admin()
returns boolean language sql security definer stable as $$
  select exists (select 1 from admins where id = auth.uid());
$$;

-- ---------- Grant admins read-only visibility on exactly what they need ----------
drop policy if exists "admin read teachers" on teachers;
create policy "admin read teachers" on teachers for select using (is_admin());

drop policy if exists "admin read sections" on sections;
create policy "admin read sections" on sections for select using (is_admin());

drop policy if exists "admin read students" on students;
create policy "admin read students" on students for select using (is_admin());

drop policy if exists "admin read terms" on terms;
create policy "admin read terms" on terms for select using (is_admin());

drop policy if exists "admin read assessments" on assessments;
create policy "admin read assessments" on assessments for select using (is_admin());

drop policy if exists "admin read scores" on scores;
create policy "admin read scores" on scores for select using (is_admin());

drop policy if exists "admin read attendance" on attendance;
create policy "admin read attendance" on attendance for select using (is_admin());

-- ============================================================================
-- HOW TO CREATE AN ADMIN ACCOUNT (do this once per admin, manually):
-- 1. Supabase → Authentication → Users → "Add user" → "Create new user"
--    Enter their email + a temporary password. Leave "Auto Confirm User" ON.
-- 2. Copy the new user's UUID (shown in the users list after creating them).
-- 3. Supabase → SQL Editor → run:
--      insert into admins (id, full_name) values ('paste-the-uuid-here', 'Full Name');
-- 4. Give that person the site URL, their email, and the temporary password.
--    They sign in via the "Admin Sign In" link on the login page, and can
--    change their password from there afterward.
-- ============================================================================
