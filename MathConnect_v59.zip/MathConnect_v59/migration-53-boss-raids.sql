-- ============================================================================
-- MathConnect — migration 53
-- Boss Battles become TEAM BOSS RAIDS  (and the Tournament feature is retired)
--
-- Run once in Supabase → SQL Editor. Safe to re-run.
--
-- THE NEW GAME
--   A team of 3–8 classmates fights one station's boss monster together
--   against a clock. Every correct answer damages the boss; every wrong answer
--   (or skip) heals it. Beat the boss before time runs out to win.
--     • Boss HP  = HP-per-player x team size   (easy 70 / normal 100 / hard 150)
--     • Time     = 240 seconds after a 4-second countdown
--     • Correct  = 10 damage + 0..5 speed bonus (answers under 10 s)
--     • Wrong    = boss heals 8 HP (never above its max HP)
--   Everyone answers their OWN question stream at their OWN station level, at
--   the same time — nobody waits on anybody. The boss's HP and the clock are
--   the only shared state, and both live in the database:
--     • every hit goes through raid_submit_answer(), which locks the raid row,
--       so simultaneous answers from different students can never overwrite
--       each other's damage;
--     • the clock is the server's ends_at, so a wrong laptop clock can't
--       cheat or cut short a raid;
--     • rewards are claimed through claim_boss_raid_rewards(), once per
--       student per raid, even across reloads or two devices.
--   The tables have NO direct client write access — students can only change a
--   raid through these functions (a tighter rule than the rest of the app).
--   Correctness is still checked in the student's browser, the same trust model
--   as Math Drills; a small pacing guard (>= 0.5 s between answers) stops a
--   student from flooding the boss with fake hits.
--
-- WHAT ELSE THIS MIGRATION DOES
--   1. Retires the tournament trigger/functions that hooked into `battles`
--      (the tournament TABLES are left alone here — run migration-54 if you
--      also want their data deleted).
--   2. championship_score(): the Boss Battles component (10%) now counts Team
--      Raids. It is a verbatim copy of migration 44's function with only that
--      component changed. The older PvP win-rate is kept as a floor
--      (GREATEST), so no student's score goes down because of this change.
--   3. Updates the Shield shop item text — a Shield now absorbs the first wrong
--      answer in a raid, so the boss doesn't heal from it.
--   Old 1-v-1 data (battles, battle_rounds, ...) is NOT touched; it stays
--   readable for reports.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Retire tournament hooks
-- ---------------------------------------------------------------------------
drop trigger if exists trg_handle_tournament_battle_complete on battles;
drop function if exists public.handle_tournament_battle_complete();
drop function if exists public.generate_tournament_bracket(uuid);
drop function if exists public.advance_tournament_match(uuid, uuid);
drop function if exists public.tournament_force_winner(uuid, uuid);

-- ---------------------------------------------------------------------------
-- 2. Tables
-- ---------------------------------------------------------------------------
create table if not exists boss_raids (
  id uuid primary key default gen_random_uuid(),
  host_id uuid references students(id) on delete set null,
  section_id uuid not null references sections(id) on delete cascade,
  grade_level text not null,
  scope text not null default 'section' check (scope in ('section', 'grade')),
  topic text not null default 'mixed',                         -- a drill station key (one boss per station) or 'mixed' (the Grand Boss)
  difficulty text not null default 'normal' check (difficulty in ('easy', 'normal', 'hard')),
  status text not null default 'lobby' check (status in ('lobby', 'active', 'won', 'lost', 'cancelled')),
  duration_seconds int not null default 240,
  team_size int,
  boss_max_hp int,
  boss_hp int,
  event_seq bigint not null default 0,                         -- +1 per accepted answer; lets clients ignore out-of-order updates
  created_at timestamptz not null default now(),
  started_at timestamptz,                                      -- fight begins here (a few seconds after Start, for the countdown)
  ends_at timestamptz,
  ended_at timestamptz
);
create index if not exists boss_raids_status_idx on boss_raids (status, created_at);
create index if not exists boss_raids_section_idx on boss_raids (section_id, status);

create table if not exists boss_raid_members (
  id uuid primary key default gen_random_uuid(),
  raid_id uuid not null references boss_raids(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  joined_at timestamptz not null default now(),
  correct_count int not null default 0,
  wrong_count int not null default 0,
  damage_dealt int not null default 0,
  healed_boss int not null default 0,                          -- HP the boss regained because of this student's wrong answers
  shield_used int not null default 0,
  last_answer_at timestamptz,
  rewards_claimed boolean not null default false,
  unique (raid_id, student_id)
);
create index if not exists boss_raid_members_student_idx on boss_raid_members (student_id);
create index if not exists boss_raid_members_raid_idx on boss_raid_members (raid_id);

-- Read-only for everyone; every change goes through the functions below.
alter table boss_raids enable row level security;
alter table boss_raid_members enable row level security;
drop policy if exists "public read boss_raids" on boss_raids;
create policy "public read boss_raids" on boss_raids for select using (true);
drop policy if exists "public read boss_raid_members" on boss_raid_members;
create policy "public read boss_raid_members" on boss_raid_members for select using (true);
drop policy if exists "teacher delete boss_raids" on boss_raids;
create policy "teacher delete boss_raids" on boss_raids for delete using (
  (host_id is not null and is_teacher_of_student(host_id)) or is_admin()
);

do $$
begin
  begin alter publication supabase_realtime add table boss_raids; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table boss_raid_members; exception when duplicate_object then null; end;
end $$;

-- ---------------------------------------------------------------------------
-- 3. Game functions
-- ---------------------------------------------------------------------------
-- Tidy-up run at the start of the entry points: stale lobbies expire after 15
-- minutes; a fight whose clock ran out (plus a 1.5 s grace for in-flight
-- answers) is closed as lost.
create or replace function public._boss_raid_housekeeping() returns void
language plpgsql security definer set search_path = public as $$
begin
  update boss_raids set status = 'cancelled', ended_at = now()
    where status = 'lobby' and created_at < now() - interval '15 minutes';
  update boss_raids set status = 'lost', ended_at = now()
    where status = 'active' and ends_at < now() - interval '1500 milliseconds';
end;
$$;

-- The raid (if any) this student is currently tied up in.
create or replace function public._boss_raid_open_for(p_student_id uuid) returns uuid
language sql security definer set search_path = public stable as $$
  select r.id from boss_raid_members m join boss_raids r on r.id = m.raid_id
  where m.student_id = p_student_id and r.status in ('lobby', 'active')
  order by r.created_at desc limit 1;
$$;

create or replace function public.create_boss_raid(
  p_student_id uuid, p_topic text, p_difficulty text default 'normal', p_scope text default 'section'
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_student students%rowtype; v_grade text; v_locked boolean; v_busy uuid; v_raid boss_raids%rowtype;
begin
  perform public._boss_raid_housekeeping();
  select * into v_student from students where id = p_student_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'student_not_found'); end if;
  if coalesce(v_student.account_status, 'active') <> 'active' then return jsonb_build_object('ok', false, 'error', 'account_paused'); end if;
  if p_difficulty not in ('easy', 'normal', 'hard') then return jsonb_build_object('ok', false, 'error', 'bad_difficulty'); end if;
  if p_scope not in ('section', 'grade') then return jsonb_build_object('ok', false, 'error', 'bad_scope'); end if;
  if p_topic <> 'mixed' then
    select locked into v_locked from drill_station_locks where station_key = p_topic;
    if not found then return jsonb_build_object('ok', false, 'error', 'bad_topic'); end if;
    if v_locked then return jsonb_build_object('ok', false, 'error', 'station_locked'); end if;
  end if;
  v_busy := public._boss_raid_open_for(p_student_id);
  if v_busy is not null then return jsonb_build_object('ok', false, 'error', 'already_in_raid', 'raid_id', v_busy); end if;
  select grade_level into v_grade from sections where id = v_student.section_id;
  insert into boss_raids (host_id, section_id, grade_level, scope, topic, difficulty)
    values (p_student_id, v_student.section_id, coalesce(v_grade, ''), p_scope, p_topic, p_difficulty)
    returning * into v_raid;
  insert into boss_raid_members (raid_id, student_id) values (v_raid.id, p_student_id);
  return jsonb_build_object('ok', true, 'raid', to_jsonb(v_raid));
end;
$$;

create or replace function public.join_boss_raid(p_raid_id uuid, p_student_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_raid boss_raids%rowtype; v_student students%rowtype; v_grade text; v_busy uuid; v_count int;
begin
  perform public._boss_raid_housekeeping();
  select * into v_raid from boss_raids where id = p_raid_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'raid_not_found'); end if;
  -- already on the team (re-opening the app, second device): just let them back in
  if exists (select 1 from boss_raid_members where raid_id = p_raid_id and student_id = p_student_id)
     and v_raid.status in ('lobby', 'active') then
    return jsonb_build_object('ok', true, 'raid', to_jsonb(v_raid), 'rejoined', true);
  end if;
  if v_raid.status <> 'lobby' then return jsonb_build_object('ok', false, 'error', 'not_open'); end if;
  select * into v_student from students where id = p_student_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'student_not_found'); end if;
  if coalesce(v_student.account_status, 'active') <> 'active' then return jsonb_build_object('ok', false, 'error', 'account_paused'); end if;
  select grade_level into v_grade from sections where id = v_student.section_id;
  if v_raid.scope = 'section' and v_student.section_id is distinct from v_raid.section_id then
    return jsonb_build_object('ok', false, 'error', 'wrong_section');
  end if;
  if v_raid.scope = 'grade' and coalesce(v_grade, '') <> v_raid.grade_level then
    return jsonb_build_object('ok', false, 'error', 'wrong_grade');
  end if;
  v_busy := public._boss_raid_open_for(p_student_id);
  if v_busy is not null then return jsonb_build_object('ok', false, 'error', 'already_in_raid', 'raid_id', v_busy); end if;
  select count(*) into v_count from boss_raid_members where raid_id = p_raid_id;
  if v_count >= 8 then return jsonb_build_object('ok', false, 'error', 'raid_full'); end if;
  insert into boss_raid_members (raid_id, student_id) values (p_raid_id, p_student_id);
  return jsonb_build_object('ok', true, 'raid', to_jsonb(v_raid));
end;
$$;

-- Leaving before the fight starts. If the host leaves, the lobby closes.
create or replace function public.leave_boss_raid(p_raid_id uuid, p_student_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_raid boss_raids%rowtype;
begin
  select * into v_raid from boss_raids where id = p_raid_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'raid_not_found'); end if;
  if v_raid.status <> 'lobby' then return jsonb_build_object('ok', false, 'error', 'already_started'); end if;
  if v_raid.host_id = p_student_id then
    update boss_raids set status = 'cancelled', ended_at = now() where id = p_raid_id;
  else
    delete from boss_raid_members where raid_id = p_raid_id and student_id = p_student_id;
  end if;
  return jsonb_build_object('ok', true);
end;
$$;

create or replace function public.start_boss_raid(p_raid_id uuid, p_student_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_raid boss_raids%rowtype; v_count int; v_hp_per int; v_start timestamptz;
begin
  select * into v_raid from boss_raids where id = p_raid_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'raid_not_found'); end if;
  if v_raid.host_id is distinct from p_student_id then return jsonb_build_object('ok', false, 'error', 'host_only'); end if;
  if v_raid.status <> 'lobby' then return jsonb_build_object('ok', false, 'error', 'not_open'); end if;
  select count(*) into v_count from boss_raid_members where raid_id = p_raid_id;
  if v_count < 3 then return jsonb_build_object('ok', false, 'error', 'need_more_players', 'have', v_count, 'need', 3); end if;
  v_hp_per := case v_raid.difficulty when 'easy' then 70 when 'hard' then 150 else 100 end;
  v_start := now() + interval '4 seconds';
  update boss_raids set
    status = 'active', team_size = v_count,
    boss_max_hp = v_hp_per * v_count, boss_hp = v_hp_per * v_count,
    started_at = v_start, ends_at = v_start + make_interval(secs => v_raid.duration_seconds)
  where id = p_raid_id returning * into v_raid;
  return jsonb_build_object('ok', true, 'raid', to_jsonb(v_raid), 'server_now', now());
end;
$$;

-- One answer from one student. Correct -> damage; wrong/skip -> the boss heals
-- (unless the student's one Shield per raid absorbs it).
create or replace function public.raid_submit_answer(
  p_raid_id uuid, p_student_id uuid, p_correct boolean, p_ms int default null, p_shielded boolean default false
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_raid boss_raids%rowtype; v_m boss_raid_members%rowtype;
  v_delta int; v_new_hp int; v_dmg int; v_heal int := 0; v_shield boolean := false;
begin
  select * into v_raid from boss_raids where id = p_raid_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'raid_not_found'); end if;
  if v_raid.status <> 'active' then
    return jsonb_build_object('ok', false, 'error', 'not_active', 'status', v_raid.status, 'boss_hp', v_raid.boss_hp, 'event_seq', v_raid.event_seq, 'server_now', now());
  end if;
  if now() < v_raid.started_at then return jsonb_build_object('ok', false, 'error', 'not_started', 'server_now', now()); end if;
  if now() > v_raid.ends_at + interval '1500 milliseconds' then
    update boss_raids set status = 'lost', ended_at = now() where id = p_raid_id and status = 'active';
    return jsonb_build_object('ok', false, 'error', 'time_up', 'status', 'lost', 'boss_hp', v_raid.boss_hp, 'server_now', now());
  end if;
  select * into v_m from boss_raid_members where raid_id = p_raid_id and student_id = p_student_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_member'); end if;
  if v_m.last_answer_at is not null and now() - v_m.last_answer_at < interval '500 milliseconds' then
    return jsonb_build_object('ok', false, 'error', 'too_fast', 'server_now', now());
  end if;

  if p_correct then
    v_dmg := 10 + greatest(0, least(5, floor((10000 - least(greatest(coalesce(p_ms, 10000), 0), 10000)) / 2000.0)))::int;
    v_new_hp := greatest(0, v_raid.boss_hp - v_dmg);
    v_delta := -(v_raid.boss_hp - v_new_hp);
    update boss_raid_members set correct_count = correct_count + 1, damage_dealt = damage_dealt + (v_raid.boss_hp - v_new_hp),
      last_answer_at = now() where id = v_m.id;
  else
    if p_shielded and v_m.shield_used < 1 then v_shield := true; else v_heal := 8; end if;
    v_new_hp := least(v_raid.boss_max_hp, v_raid.boss_hp + v_heal);
    v_delta := v_new_hp - v_raid.boss_hp;
    update boss_raid_members set wrong_count = wrong_count + 1, healed_boss = healed_boss + (v_new_hp - v_raid.boss_hp),
      shield_used = shield_used + (case when v_shield then 1 else 0 end), last_answer_at = now() where id = v_m.id;
  end if;

  update boss_raids set boss_hp = v_new_hp, event_seq = event_seq + 1,
    status = case when v_new_hp <= 0 then 'won' else 'active' end,
    ended_at = case when v_new_hp <= 0 then now() else null end
  where id = p_raid_id returning * into v_raid;

  return jsonb_build_object('ok', true, 'correct', p_correct, 'delta', v_delta, 'shield_absorbed', v_shield,
    'boss_hp', v_raid.boss_hp, 'boss_max_hp', v_raid.boss_max_hp, 'status', v_raid.status,
    'event_seq', v_raid.event_seq, 'ends_at', v_raid.ends_at, 'server_now', now());
end;
$$;

-- Any client calls this when its copy of the clock hits zero. Idempotent.
create or replace function public.finish_boss_raid(p_raid_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_raid boss_raids%rowtype;
begin
  select * into v_raid from boss_raids where id = p_raid_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'raid_not_found'); end if;
  if v_raid.status = 'active' and now() >= v_raid.ends_at + interval '1500 milliseconds' then
    update boss_raids set status = 'lost', ended_at = now() where id = p_raid_id returning * into v_raid;
  end if;
  return jsonb_build_object('ok', true, 'raid', to_jsonb(v_raid), 'server_now', now());
end;
$$;

-- Everything a raid screen needs in one round-trip, plus the server's clock so
-- the browser can correct for a wrong device clock.
create or replace function public.boss_raid_sync(p_raid_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_raid boss_raids%rowtype; v_members jsonb;
begin
  select * into v_raid from boss_raids where id = p_raid_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'raid_not_found'); end if;
  if v_raid.status = 'active' and now() >= v_raid.ends_at + interval '1500 milliseconds' then
    update boss_raids set status = 'lost', ended_at = now() where id = p_raid_id returning * into v_raid;
  elsif v_raid.status = 'lobby' and v_raid.created_at < now() - interval '15 minutes' then
    update boss_raids set status = 'cancelled', ended_at = now() where id = p_raid_id returning * into v_raid;
  end if;
  select coalesce(jsonb_agg(jsonb_build_object(
      'student_id', m.student_id, 'full_name', s.full_name, 'is_host', (m.student_id = v_raid.host_id),
      'correct_count', m.correct_count, 'wrong_count', m.wrong_count, 'damage_dealt', m.damage_dealt,
      'healed_boss', m.healed_boss, 'joined_at', m.joined_at
    ) order by m.joined_at), '[]'::jsonb)
  into v_members
  from boss_raid_members m join students s on s.id = m.student_id where m.raid_id = p_raid_id;
  return jsonb_build_object('ok', true, 'server_now', now(), 'raid', to_jsonb(v_raid), 'members', v_members);
end;
$$;

-- Once per student per raid. A student "really fought" with >= 5 correct answers
-- (so someone who joined and idled doesn't collect the team's reward).
create or replace function public.claim_boss_raid_rewards(p_raid_id uuid, p_student_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_raid boss_raids%rowtype; v_m boss_raid_members%rowtype;
begin
  select * into v_raid from boss_raids where id = p_raid_id;
  if not found or v_raid.status not in ('won', 'lost') then return jsonb_build_object('ok', false, 'error', 'not_finished'); end if;
  select * into v_m from boss_raid_members where raid_id = p_raid_id and student_id = p_student_id for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_member'); end if;
  if v_m.rewards_claimed then return jsonb_build_object('ok', true, 'claimed', false); end if;
  update boss_raid_members set rewards_claimed = true where id = v_m.id;
  return jsonb_build_object('ok', true, 'claimed', true, 'won', v_raid.status = 'won',
    'contributed', v_m.correct_count >= 5, 'correct_count', v_m.correct_count);
end;
$$;

grant execute on function public.create_boss_raid(uuid, text, text, text) to anon, authenticated;
grant execute on function public.join_boss_raid(uuid, uuid) to anon, authenticated;
grant execute on function public.leave_boss_raid(uuid, uuid) to anon, authenticated;
grant execute on function public.start_boss_raid(uuid, uuid) to anon, authenticated;
grant execute on function public.raid_submit_answer(uuid, uuid, boolean, int, boolean) to anon, authenticated;
grant execute on function public.finish_boss_raid(uuid) to anon, authenticated;
grant execute on function public.boss_raid_sync(uuid) to anon, authenticated;
grant execute on function public.claim_boss_raid_rewards(uuid, uuid) to anon, authenticated;
-- the two helpers are internal
revoke execute on function public._boss_raid_housekeeping() from public, anon, authenticated;
revoke execute on function public._boss_raid_open_for(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- 4. championship_score — Boss component now counts Team Raids
--    (verbatim copy of migration 44 except the marked block)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.championship_score(target_student_id UUID)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER STABLE AS $$
DECLARE
  dp drill_progress%ROWTYPE; eng student_engagement%ROWTYPE;
  les learning_engine_state%ROWTYPE; qp quest_progress%ROWTYPE;
  eligible BOOLEAN := false;
  gem_score NUMERIC := 0; trial_score NUMERIC := 0; rank_progress NUMERIC := 0;
  avg_level NUMERIC := 0; accuracy NUMERIC := 0; drill_score NUMERIC := 0;
  chapter_total INT := 0; chapter_cleared INT := 0; quest_score NUMERIC := 0;
  max_stars INT := 0;
  capped_wins INT := 0; capped_games INT := 0; win_rate NUMERIC := 0; battle_score NUMERIC := 0;
  raid_wins INT := 0; raid_games INT := 0; raid_score NUMERIC := 0;
  domain_total INT := 0; domain_sum NUMERIC := 0; practice_score NUMERIC := 0;
  streak_score NUMERIC := 0; daily_count INT := 0; daily_score NUMERIC := 0; consistency_score NUMERIC := 0;
  cq_contrib_total INT := 0; cq_distinct_completed INT := 0; cooperation_score NUMERIC := 0;
  total NUMERIC := 0;
  station_count INT := 0;
  r RECORD;
  gem_index INT := 0;
BEGIN
  SELECT * INTO dp FROM drill_progress WHERE student_id = target_student_id;
  SELECT * INTO eng FROM student_engagement WHERE student_id = target_student_id;
  SELECT * INTO les FROM learning_engine_state WHERE student_id = target_student_id;
  SELECT * INTO qp FROM quest_progress WHERE student_id = target_student_id;

  eligible := dp.id IS NOT NULL AND dp.mastery_tier = 15;

  -- ---- 1. Rank Progress (25%) ----
  IF dp.post_eureka_stars >= 125 THEN gem_index := 9 + floor((dp.post_eureka_stars - 125) / 30.0);
  ELSIF dp.post_eureka_stars >= 95 THEN gem_index := 8;
  ELSIF dp.post_eureka_stars >= 70 THEN gem_index := 7;
  ELSIF dp.post_eureka_stars >= 50 THEN gem_index := 6;
  ELSIF dp.post_eureka_stars >= 35 THEN gem_index := 5;
  ELSIF dp.post_eureka_stars >= 25 THEN gem_index := 4;
  ELSIF dp.post_eureka_stars >= 15 THEN gem_index := 3;
  ELSIF dp.post_eureka_stars >= 10 THEN gem_index := 2;
  ELSIF dp.post_eureka_stars >= 5 THEN gem_index := 1;
  ELSE gem_index := 0; END IF;
  gem_score := LEAST(gem_index / 14.0 * 60, 60);
  trial_score := LEAST(COALESCE(dp.trial_clears_count, 0), 2) * 20;
  rank_progress := gem_score + trial_score;

  -- ---- 2. Drill Mastery (20%) ----
  SELECT COUNT(*) INTO station_count FROM drill_station_locks WHERE NOT locked;
  IF dp.id IS NOT NULL AND station_count > 0 THEN
    SELECT avg((dp.topic_levels ->> sl.station_key)::INT) INTO avg_level
    FROM (SELECT station_key FROM drill_station_locks WHERE NOT locked) sl;
    avg_level := COALESCE(avg_level, 1);
  END IF;
  SELECT CASE WHEN COALESCE(sum(total_questions), 0) = 0 THEN 0
    ELSE sum(correct_count)::NUMERIC / sum(total_questions) * 100 END
  INTO accuracy FROM drill_attempts WHERE student_id = target_student_id;
  drill_score := (COALESCE(avg_level, 1) / 15.0 * 100) * 0.5 + COALESCE(accuracy, 0) * 0.5;

  -- ---- 3. Quest Mode (10%) ----
  FOR r IN SELECT chapter_key FROM quest_chapters_registry WHERE active LOOP
    chapter_total := chapter_total + 1;
    IF qp.id IS NOT NULL AND jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       AND jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e WHERE e::INT < 1)
    THEN chapter_cleared := chapter_cleared + 1; END IF;
  END LOOP;
  max_stars := chapter_total * 10 * 3;
  quest_score := CASE WHEN chapter_total = 0 THEN 0 ELSE (chapter_cleared::NUMERIC / chapter_total * 100) * 0.5 END
    + CASE WHEN max_stars = 0 THEN 0 ELSE (COALESCE(qp.total_stars, 0)::NUMERIC / max_stars * 100) * 0.5 END;

  -- ---- 4. Cooperation (15%, NEW) — Class Quest contributions. Half from
  -- cumulative volume contributed (capped at 300 pts), half from how many
  -- DIFFERENT Class Quests that contribution helped push over the goal
  -- line (capped at 3) — rewards showing up for the team repeatedly, not
  -- just once.
  SELECT COALESCE(SUM(c.points_contributed), 0) INTO cq_contrib_total
  FROM class_quest_contributions c WHERE c.student_id = target_student_id;
  SELECT COUNT(DISTINCT c.quest_id) INTO cq_distinct_completed
  FROM class_quest_contributions c JOIN class_quests q ON q.id = c.quest_id
  WHERE c.student_id = target_student_id AND q.completed_at IS NOT NULL;
  cooperation_score := LEAST(cq_contrib_total / 300.0, 1) * 100 * 0.5
    + LEAST(cq_distinct_completed / 3.0, 1) * 100 * 0.5;

  -- ---- 5. Boss Battles / Raids (10%) ----
  SELECT COALESCE(sum(LEAST(w, 3)), 0), COALESCE(sum(LEAST(g, 3)), 0) INTO capped_wins, capped_games
  FROM (
    SELECT CASE WHEN student_a_id = target_student_id THEN student_b_id ELSE student_a_id END AS opp,
      count(*) FILTER (WHERE winner_id = target_student_id) AS w,
      count(*) AS g
    FROM battles
    WHERE status = 'completed' AND (student_a_id = target_student_id OR student_b_id = target_student_id)
    GROUP BY 1
  ) x;
  win_rate := CASE WHEN capped_games = 0 THEN 0 ELSE capped_wins::NUMERIC / capped_games * 100 END;
  -- Team Boss Raids (migration 53): a raid counts once the student really
  -- fought in it (>= 5 correct answers). Score = half "how many raids you have
  -- won" (capped at 5) + half "victory rate". The older PvP win-rate above is
  -- kept as a floor (GREATEST) so nobody's standing drops because PvP was retired.
  -- (aliases rm/rr, NOT r — `r` is this function's loop RECORD variable)
  SELECT COALESCE(count(*) FILTER (WHERE rr.status = 'won'), 0), COALESCE(count(*), 0) INTO raid_wins, raid_games
  FROM boss_raid_members rm JOIN boss_raids rr ON rr.id = rm.raid_id
  WHERE rm.student_id = target_student_id AND rr.status IN ('won', 'lost') AND rm.correct_count >= 5;
  raid_score := LEAST(raid_wins, 5) / 5.0 * 100 * 0.5
    + CASE WHEN raid_games = 0 THEN 0 ELSE raid_wins::NUMERIC / raid_games * 100 END * 0.5;
  battle_score := GREATEST(win_rate, raid_score);

  -- ---- 6. Intelligent Practice (10%) ----
  FOR r IN SELECT domain_key FROM practice_domains WHERE active LOOP
    domain_total := domain_total + 1;
    domain_sum := domain_sum + COALESCE((les.skill_proficiency ->> r.domain_key)::INT, 0);
  END LOOP;
  practice_score := CASE WHEN domain_total = 0 THEN 0 ELSE domain_sum / domain_total END;

  -- ---- 7. Consistency (10%) ----
  streak_score := LEAST(COALESCE(eng.current_streak, 0), 60) / 60.0 * 100;
  SELECT COUNT(*) INTO daily_count FROM daily_challenge_completions WHERE student_id = target_student_id;
  daily_score := LEAST(daily_count, 60) / 60.0 * 100;
  consistency_score := streak_score * 0.5 + daily_score * 0.5;

  total := rank_progress * 0.25 + drill_score * 0.20 + quest_score * 0.10 + cooperation_score * 0.15
    + battle_score * 0.10 + practice_score * 0.10 + consistency_score * 0.10;

  RETURN jsonb_build_object(
    'eligible', eligible,
    'total', round(total, 2),
    'breakdown', jsonb_build_object(
      'rank_progress', round(rank_progress, 2),
      'drill_mastery', round(drill_score, 2),
      'quest_mode', round(quest_score, 2),
      'cooperation', round(cooperation_score, 2),
      'boss_battles', round(battle_score, 2),
      'intelligent_practice', round(practice_score, 2),
      'consistency', round(consistency_score, 2)
    )
  );
END;
$$;
GRANT EXECUTE ON FUNCTION public.championship_score(UUID) TO anon, authenticated;

-- ---------------------------------------------------------------------------
-- 5. Shield item text
-- ---------------------------------------------------------------------------
update shop_items set description = 'Absorbs your first wrong answer in a Boss Raid — the boss will not heal from it.'
  where id = 'shield';

-- ============================================================================
-- Done. Sanity checks:
--   select id, topic, difficulty, status, team_size, boss_hp, boss_max_hp from boss_raids order by created_at desc limit 5;
--   select championship_score(id) from students limit 1;
-- ============================================================================
