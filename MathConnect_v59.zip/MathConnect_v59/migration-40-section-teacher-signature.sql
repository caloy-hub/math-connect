-- ============================================================================
-- MathConnect — Migration 40: Per-section Subject Teacher signature fields
-- ----------------------------------------------------------------------------
-- SUPERSEDES migration-39-teacher-directory-readonly.sql.
--
-- Migration 39 solved "auto-fill the report card's teacher name" by exposing
-- a read-only view of the `teachers` table. On reflection, a per-SECTION
-- field is the better design:
--   • A teacher can teach several sections/subjects and may want a slightly
--     different printed title per subject (e.g. "TLE Coordinator" for one
--     class, "Subject Teacher" for another).
--   • It's editable right on the section itself, in a proper Class Settings
--     screen, alongside the rest of that section's info — not a separate
--     public view of the teachers table.
--   • `sections` already has an anon-readable RLS policy (students/report
--     card already read it), so no NEW public surface is needed at all.
--
-- If you already ran migration-39, this migration does not require it and
-- you may optionally drop that view afterward (see bottom of this file).
-- ============================================================================

alter table sections add column if not exists subject_teacher_name text;
alter table sections add column if not exists subject_teacher_position text;

-- One-time backfill: seed every existing section's signature fields from the
-- teacher account that owns it, so nothing prints blank on first use. Each
-- section stays independently editable afterward via Class Settings.
update sections s
set subject_teacher_name = coalesce(s.subject_teacher_name, t.full_name),
    subject_teacher_position = coalesce(s.subject_teacher_position, t.position)
from teachers t
where t.id = s.teacher_id
  and (s.subject_teacher_name is null or s.subject_teacher_position is null);

-- ---------------------------------------------------------------------------
-- Optional cleanup if migration-39 was already applied — safe to run, no-op
-- if the view was never created:
-- ---------------------------------------------------------------------------
-- drop view if exists public.teacher_directory;
