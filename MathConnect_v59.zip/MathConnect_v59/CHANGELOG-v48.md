# MathConnect v48 — Exponents & Radicals

**Deploy:** just upload the files. No migration, no database change. (The service worker is bumped to
`mathconnect-v48-1` so installed apps pick up the new questions on the next load.)

## What changed
The ⚡ **Exponent Matrix** drill station is now **⚡ Exponents & Radicals**. A root is a fractional exponent
(√x = x^(1/2)), so the two topics now live in one station. The station key is still `exponents`, so student
progress, leaderboards, the Boss Codex and the Boss Raid "Powerhorn the Bull" are untouched — and there is no new
station and no new boss.

| Level | Before | Now |
|---|---|---|
| 1–8 | Powers, product, quotient, power-of-a-power rules | **unchanged** (verified identical to v45) |
| 9 | Square roots (√4 … √144) | Square roots, up to √225 |
| 10 | Square roots | **Cube roots** (³√8 … ³√512), plus some larger square roots |
| 11 | `b^0 + b^-1 × b` — the answer was **always 2** | Zero and negative exponents: `5^-3 = 1/?`, `7^4 × 7^-2 = 7^?`, `7^0 + 3^3 = ?` (varied answers) |
| 12 | (same always-2 question) | **Rational exponents**: `81^(1/2)`, `125^(1/3)`, `16^(3/2)`, `125^(2/3)` |
| 13 | Scientific notation | **Simplifying radicals**: `√72 = ?√2` — the number in front |
| 14 | Scientific notation | **Adding / subtracting like radicals**: `√48 + √3 = ?√3` |
| 15 | Scientific notation | Scientific notation (unchanged) |

- Every answer is a whole number, so the existing integer keypad and answer checker are used as-is.
- Levels 10–14 show a short hint under the question that teaches the method without giving the answer
  (e.g. "Pull out the biggest perfect square, e.g. √40 = √4 × √10 = 2√10" — 40 can never be asked at that level).
- The cube-root sign is written ³√ instead of ∛, because ∛ is missing from some phone fonts.
- Boss Raids use the same generator, so the Powerhorn raid now includes radicals at higher station levels.

**Heads-up for students already past level 8:** the station's level numbers didn't move, but what they mean at
levels 9–14 did. A student at level 11 will now meet negative exponents instead of the old constant question, and
scientific notation no longer starts until level 15.

Renamed in: `drills.js`, `teacher-drills.js`, `admin.js`, and the sample card on the landing page.

## Tested
- Levels 1–8: 2,400 questions identical to v45 under the same random seed.
- Levels 9–14: 36,000 generated questions — every answer re-derived by an independent solver that reads only the
  prompt text (including "is this radicand actually simplified to that number?" and "is b square-free?"), all match;
  every answer is a whole number; answers vary at every level; the answer checker accepts the right answer and
  rejects wrong, decimal and blank input; `generateDrillQuestion('exponents', 1–15)` always returns a valid question.
- Not tested: on a phone screen. Worth glancing at how `√`, `³√` and `^(3/2)` render on your students' devices.
