// ============================================================================
// MathConnect — Intelligent Learning Engine (orchestrator)
// This is the ONLY file that ties Adaptive Difficulty + Error Diagnosis +
// Skill Proficiency together. The three engines themselves
// (difficultyEngine.js, diagnosisEngine.js, skillEngine.js) never call each
// other or touch Supabase/the DOM — this file is the seam.
// Depends on: supabase-client.js (supabase, escapeHtml), sstate (student.js),
// difficultyEngine.js, diagnosisEngine.js, skillEngine.js — load all of
// those BEFORE this file.
// ============================================================================

const LE_DOMAINS = [
  { key: "addition", icon: "➕", name: "Addition" },
  { key: "subtraction", icon: "➖", name: "Subtraction" },
  { key: "multiplication", icon: "✖️", name: "Multiplication" },
  { key: "division", icon: "➗", name: "Division" },
  { key: "fractions", icon: "🍕", name: "Fractions" },
  { key: "decimals", icon: "💯", name: "Decimals" },
  // ---- Term 2 domains — locked by default, see practice_domains'
  // `locked` column (migration-25). Keys match the Term 2 Drill Stations
  // for consistency, but these are separate, simpler 4-tier generators. ----
  { key: "ratio", icon: "⚖️", name: "Ratio & Proportion" },
  { key: "percent", icon: "💸", name: "Percent" },
  { key: "geometry", icon: "📐", name: "Geometry" },
  { key: "patterns", icon: "🧩", name: "Patterns & Sequences" },
  { key: "statistics", icon: "📊", name: "Statistics" },
  { key: "probability", icon: "🎡", name: "Probability" },
  // ---- High-school domains (v55) — keys match the Drill Stations added in
  // migration-47 so Drills and Intelligent Practice now cover the same 18
  // areas. Shipped UNLOCKED (see migration-62); admins can still lock them
  // from the Intelligent Practice Domains card. ----
  { key: "exponents", icon: "⚡", name: "Exponents & Radicals" },
  { key: "equations", icon: "⚖️", name: "Equation Scale" },
  { key: "factoring", icon: "🧩", name: "Factor Vault" },
  { key: "measurement", icon: "🌾", name: "Farm Measure" },
  { key: "coordinates", icon: "📈", name: "Grid Navigator" },
  { key: "pythagoras", icon: "📐", name: "Surveyor's Post" },
];

// ============================================================================
// LOCKS — mirrors drills.js's dstate.locks / isStationLocked exactly, just
// against practice_domains' locked column instead of drill_station_locks.
// Loaded on demand by adaptive-practice.js's renderLearningHub().
// ============================================================================
var lockstate = { domainLocks: {}, loaded: false };
async function loadPracticeDomainLocks() {
  const { data } = await supabase.from("practice_domains").select("domain_key, locked, note");
  const map = {};
  (data || []).forEach((r) => (map[r.domain_key] = { locked: r.locked, note: r.note }));
  lockstate.domainLocks = map;
  lockstate.loaded = true;
}
function isPracticeDomainLocked(domainKey) {
  const l = lockstate.domainLocks[domainKey];
  return !!(l && l.locked);
}

// ============================================================================
// UNIFIED STUDENT OBJECT — defaults + load/save
// Shape (see README section "Unified Database Schema" for the annotated version):
//   { studentId, adaptiveLevel: {domain:1-4}, skillProficiency: {domain:0-100},
//     recentAnswers: {domain:[0/1,...up to 5]} }
// ============================================================================
function leDefaultAdaptiveLevels() { const o = {}; LE_DOMAINS.forEach((d) => (o[d.key] = 1)); return o; }
function leDefaultSkillProficiency() { const o = {}; LE_DOMAINS.forEach((d) => (o[d.key] = 0)); return o; }
function leDefaultRecentAnswers() { const o = {}; LE_DOMAINS.forEach((d) => (o[d.key] = [])); return o; }

var lestate = { student: null, loaded: false };

async function loadLearningState() {
  const { data } = await supabase.from("learning_engine_state").select("*").eq("student_id", sstate.student.id).maybeSingle();
  if (data) {
    lestate.student = {
      studentId: sstate.student.id,
      adaptiveLevel: { ...leDefaultAdaptiveLevels(), ...data.adaptive_levels },
      skillProficiency: { ...leDefaultSkillProficiency(), ...data.skill_proficiency },
      recentAnswers: { ...leDefaultRecentAnswers(), ...data.recent_answers },
    };
  } else {
    lestate.student = {
      studentId: sstate.student.id,
      adaptiveLevel: leDefaultAdaptiveLevels(),
      skillProficiency: leDefaultSkillProficiency(),
      recentAnswers: leDefaultRecentAnswers(),
    };
    await supabase.from("learning_engine_state").insert({
      student_id: sstate.student.id,
      adaptive_levels: lestate.student.adaptiveLevel,
      skill_proficiency: lestate.student.skillProficiency,
      recent_answers: lestate.student.recentAnswers,
    });
  }
  lestate.loaded = true;
}

async function saveLearningState() {
  const s = lestate.student;
  await supabase.from("learning_engine_state").update({
    adaptive_levels: s.adaptiveLevel, skill_proficiency: s.skillProficiency,
    recent_answers: s.recentAnswers, updated_at: new Date().toISOString(),
  }).eq("student_id", sstate.student.id);
}

async function logAnswer(domain, tier, attemptNumber, isCorrect, mistakeType, q, userAnswer, pointsAwarded) {
  await supabase.from("learning_engine_log").insert({
    student_id: sstate.student.id, domain, tier, attempt_number: attemptNumber, is_correct: isCorrect,
    mistake_type: mistakeType, question_prompt: q.prompt, correct_answer: leFmtAnswer(q), student_answer: String(userAnswer),
    points_awarded: pointsAwarded,
  });
}

// ============================================================================
// QUESTION GENERATION — one generator per domain, scaled by tier 1-4.
// Kept self-contained (not reusing drills.js's generators) so every question
// here carries `operands`, which diagnosisEngine.js needs for its
// carry-over / borrow / operator-confusion checks.
// ============================================================================
function leRandInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function leGcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }
function leReduceFrac(f) { let { n, d } = f; if (d < 0) { n = -n; d = -d; } const g = leGcd(n, d); return { n: n / g, d: d / g }; }
function leFracStr(f) { return f.d === 1 ? `${f.n}` : `${f.n}/${f.d}`; }
function leRandFrac(maxD) { const d = leRandInt(2, maxD); const n = leRandInt(1, d - 1); return { n, d }; }

function genAddition(tier) {
  const range = [20, 100, 500, 999][tier - 1];
  const a = leRandInt(1, range), b = leRandInt(1, range);
  return { domain: "addition", type: "integer", prompt: `${a} + ${b} = ?`, answer: a + b, operands: { a, b, op: "+" } };
}
function genSubtraction(tier) {
  const range = [20, 100, 500, 999][tier - 1];
  const a = leRandInt(1, range), b = leRandInt(1, a);
  return { domain: "subtraction", type: "integer", prompt: `${a} - ${b} = ?`, answer: a - b, operands: { a, b, op: "-" } };
}
function genMultiplication(tier) {
  const maxF = [5, 12, 20, 50][tier - 1];
  const a = leRandInt(2, maxF), b = leRandInt(2, tier <= 2 ? maxF : 12);
  return { domain: "multiplication", type: "integer", prompt: `${a} × ${b} = ?`, answer: a * b, operands: { a, b, op: "×" } };
}
function genDivision(tier) {
  const maxQ = [10, 12, 20, 30][tier - 1];
  const b = leRandInt(2, tier <= 2 ? 10 : 15), q = leRandInt(2, maxQ), a = b * q;
  return { domain: "division", type: "integer", prompt: `${a} ÷ ${b} = ?`, answer: q, operands: { a, b, op: "÷" } };
}
function genFractions(tier) {
  const hint = "Enter as a fraction (e.g. 3/4) or whole number.";
  if (tier === 1) {
    const d = leRandInt(2, 6); const f1 = { n: leRandInt(1, d - 1), d }, f2 = { n: leRandInt(1, d - 1), d };
    return { domain: "fractions", type: "fraction", prompt: `${leFracStr(f1)} + ${leFracStr(f2)} = ?`, answer: leReduceFrac({ n: f1.n + f2.n, d }), operands: { op: "+" }, hint };
  }
  if (tier === 2) {
    const f1 = leRandFrac(8), f2 = leRandFrac(8);
    return { domain: "fractions", type: "fraction", prompt: `${leFracStr(f1)} + ${leFracStr(f2)} = ?`, answer: leReduceFrac({ n: f1.n * f2.d + f2.n * f1.d, d: f1.d * f2.d }), operands: { op: "+" }, hint };
  }
  if (tier === 3) {
    const f1 = leRandFrac(6), f2 = leRandFrac(6);
    return { domain: "fractions", type: "fraction", prompt: `${leFracStr(f1)} × ${leFracStr(f2)} = ?`, answer: leReduceFrac({ n: f1.n * f2.n, d: f1.d * f2.d }), operands: { op: "×" }, hint };
  }
  const f1 = leRandFrac(6), f2 = leRandFrac(6);
  return { domain: "fractions", type: "fraction", prompt: `${leFracStr(f1)} ÷ ${leFracStr(f2)} = ?`, answer: leReduceFrac({ n: f1.n * f2.d, d: f1.d * f2.n }), operands: { op: "÷" }, hint };
}
function genDecimals(tier) {
  const maxWhole = 3 + tier * 2;
  const op = tier <= 2 ? (Math.random() < 0.5 ? "+" : "-") : (Math.random() < 0.5 ? "×" : "÷");
  // Multiplication/division keep operands to 1 decimal place regardless of
  // tier — matches genDecimals() in drills.js.
  const dp = (op === "×" || op === "÷") ? 1 : (tier <= 2 ? 1 : 2), scale = dp === 1 ? 10 : 100;
  const rd = () => +(leRandInt(0, maxWhole) + leRandInt(0, scale - 1) / scale).toFixed(dp);
  let a = rd(), b = rd(), answer;
  if (op === "+") answer = +(a + b).toFixed(2);
  else if (op === "-") { if (a < b) [a, b] = [b, a]; answer = +(a - b).toFixed(2); }
  else if (op === "×") answer = +(a * b).toFixed(2);
  else { b = +(leRandInt(1, 9) / 10).toFixed(1) || 0.1; const q = +(leRandInt(1, maxWhole) + leRandInt(0, 9) / 10).toFixed(1); a = +(b * q).toFixed(2); answer = +q.toFixed(2); }
  return { domain: "decimals", type: "decimal", prompt: `${a} ${op} ${b} = ?`, answer, tolerance: 0.05, operands: { a, b, op }, hint: "Round to 2 decimal places if needed." };
}
const LE_GENERATORS = {
  addition: genAddition, subtraction: genSubtraction, multiplication: genMultiplication,
  division: genDivision, fractions: genFractions, decimals: genDecimals,
  ratio: genRatio, percent: genPercent, geometry: genGeometry,
  patterns: genPatterns, statistics: genStatistics, probability: genProbability,
  exponents: genExponents, equations: genEquations, factoring: genFactoring,
  measurement: genMeasurement, coordinates: genCoordinates, pythagoras: genPythagoras,
};
function generateQuestion(domain, tier) { return LE_GENERATORS[domain](Math.max(1, Math.min(4, tier || 1))); }

// ---- Term 2 generators — same 4-tier scaling pattern as above. Each
// returns type "integer" | "decimal" | "fraction" so checkAnswer() and
// diagnoseMistake() need no changes; operands are included wherever a
// domain-appropriate mistake check (carry/borrow/operator/sign) applies. ----
function genRatio(tier) {
  const pairs = [[2, 3], [3, 4], [4, 5], [2, 5], [3, 5], [5, 6]];
  const [a, b] = pairs[leRandInt(0, pairs.length - 1)];
  const mult = [2, 3, 5, 8][tier - 1];
  const rate = leRandInt(tier <= 2 ? 5 : 10, tier <= 2 ? 20 : 60);
  const sacksKnown = a * mult, sacksAsk = b * mult, costKnown = sacksKnown * rate, answer = sacksAsk * rate;
  return {
    domain: "ratio", type: "integer",
    prompt: `${sacksKnown} sacks of feed cost ₱${costKnown}. At the same rate, how much do ${sacksAsk} sacks cost?`,
    answer, operands: { a: sacksAsk, b: rate, op: "×" },
    hint: "Find the cost per sack first (₱ ÷ sacks), then multiply by the new number of sacks.",
  };
}
function genPercent(tier) {
  const percents = [[10, 20, 25, 50], [10, 20, 25, 50, 5], [15, 12.5, 30, 40, 60], [12.5, 17.5, 33, 45, 62.5]][tier - 1];
  const pct = percents[leRandInt(0, percents.length - 1)];
  const base = leRandInt(tier <= 2 ? 20 : 50, tier <= 2 ? 200 : 900);
  if (tier <= 2) {
    const answer = +(base * pct / 100).toFixed(2);
    return { domain: "percent", type: "decimal", prompt: `What is ${pct}% of ${base}?`, answer, tolerance: 0.5, hint: "Multiply the number by the percent, then divide by 100." };
  }
  const discount = +(base * pct / 100).toFixed(2);
  const answer = +(base - discount).toFixed(2);
  return { domain: "percent", type: "decimal", prompt: `A ₱${base} item is on sale for ${pct}% off. What's the sale price?`, answer, tolerance: 0.5, hint: "Find the discount amount first, then subtract it from the original price." };
}
function genGeometry(tier) {
  if (tier === 1) {
    const l = leRandInt(4, 20), w = leRandInt(3, 15);
    return { domain: "geometry", type: "integer", prompt: `A rectangular garden is ${l}m by ${w}m. What is its perimeter?`, answer: 2 * (l + w), hint: "Perimeter = 2 × (length + width)." };
  }
  if (tier === 2) {
    const l = leRandInt(4, 20), w = leRandInt(3, 15);
    return { domain: "geometry", type: "integer", prompt: `A rectangular garden is ${l}m by ${w}m. What is its area?`, answer: l * w, hint: "Area of a rectangle = length × width." };
  }
  if (tier === 3) {
    const b = leRandInt(4, 24), h = leRandInt(3, 20);
    return { domain: "geometry", type: "decimal", prompt: `A triangular plot has a base of ${b}m and a height of ${h}m. What is its area?`, answer: +(0.5 * b * h).toFixed(2), tolerance: 0.1, hint: "Area of a triangle = ½ × base × height." };
  }
  const r = leRandInt(3, 15);
  return { domain: "geometry", type: "decimal", prompt: `A circular fish pond has a radius of ${r}m. What is its area? (use π ≈ 3.14)`, answer: +(3.14 * r * r).toFixed(2), tolerance: 0.5, hint: "Area of a circle = π × radius²." };
}
function genPatterns(tier) {
  if (tier === 1) {
    const start = leRandInt(1, 10), step = leRandInt(2, 6);
    const seq = [0, 1, 2].map((i) => start + i * step);
    return { domain: "patterns", type: "integer", prompt: `${seq.join(", ")}, ... What's the next number?`, answer: start + 3 * step, hint: "Find the difference between each number and add it again." };
  }
  if (tier === 2) {
    const start = leRandInt(30, 60), step = -leRandInt(2, 7);
    const seq = [0, 1, 2].map((i) => start + i * step);
    return { domain: "patterns", type: "integer", prompt: `${seq.join(", ")}, ... What's the next number?`, answer: start + 3 * step, hint: "This sequence is decreasing — find the (negative) common difference." };
  }
  if (tier === 3) {
    const start = leRandInt(1, 5), ratio = leRandInt(2, 3);
    const seq = [0, 1, 2].map((i) => start * Math.pow(ratio, i));
    return { domain: "patterns", type: "integer", prompt: `${seq.join(", ")}, ... What's the next number?`, answer: start * Math.pow(ratio, 3), hint: "This one's geometric — each term is multiplied by the same number." };
  }
  const start = leRandInt(1, 8), step = leRandInt(3, 9);
  const seq = [start, start + step, start + 2 * step, start + 4 * step]; // gap: missing the 3rd term
  return { domain: "patterns", type: "integer", prompt: `${seq[0]}, ${seq[1]}, ___, ${seq[3]}, ... What number is missing?`, answer: start + 3 * step, hint: "Work out the common difference from the terms you can see, then fill the gap." };
}
function genStatistics(tier) {
  const n = tier <= 2 ? 5 : 6;
  const data = Array.from({ length: n }, () => leRandInt(1, tier <= 2 ? 20 : 40));
  if (tier === 1) {
    return { domain: "statistics", type: "integer", prompt: `Data set: ${data.join(", ")}. What is the range (highest − lowest)?`, answer: Math.max(...data) - Math.min(...data), hint: "Range = highest value − lowest value." };
  }
  if (tier === 2) {
    const withRepeat = [...data, data[0], data[0]]; // guarantee a mode
    return { domain: "statistics", type: "integer", prompt: `Data set: ${withRepeat.sort((a, b) => a - b).join(", ")}. What is the mode (most frequent value)?`, answer: data[0], hint: "The mode is the value that appears most often." };
  }
  if (tier === 3) {
    const sum = data.reduce((a, b) => a + b, 0);
    return { domain: "statistics", type: "decimal", prompt: `Data set: ${data.join(", ")}. What is the mean (average)?`, answer: +(sum / n).toFixed(2), tolerance: 0.1, hint: "Mean = sum of all values ÷ how many values there are." };
  }
  const sorted = [...data].sort((a, b) => a - b);
  const mid = sorted[Math.floor(n / 2)];
  const isEven = n % 2 === 0;
  const answer = isEven ? +((sorted[n / 2 - 1] + sorted[n / 2]) / 2).toFixed(1) : mid;
  return { domain: "statistics", type: isEven ? "decimal" : "integer", prompt: `Data set: ${data.join(", ")}. What is the median (middle value when sorted)?`, answer, tolerance: 0.1, hint: "Sort the numbers first, then find the middle one." };
}
function genProbability(tier) {
  const colors = ["red", "blue", "green", "yellow", "white"];
  if (tier === 1) {
    const total = leRandInt(5, 10), fav = leRandInt(1, total - 1);
    return { domain: "probability", type: "fraction", prompt: `A bag has ${total} marbles, ${fav} of them red. What is the probability of picking a red marble? (as a fraction)`, answer: leReduceFrac({ n: fav, d: total }), hint: "Probability = favorable outcomes ÷ total outcomes." };
  }
  if (tier === 2) {
    const total = leRandInt(6, 12), fav = leRandInt(1, total - 1);
    return { domain: "probability", type: "fraction", prompt: `A bag has ${total} balls, ${fav} of them ${colors[0]}. What is the probability of NOT picking a ${colors[0]} ball? (as a fraction)`, answer: leReduceFrac({ n: total - fav, d: total }), hint: "\"Not\" means every outcome except the one mentioned — subtract from the total first." };
  }
  if (tier === 3) {
    const total = leRandInt(10, 20), fav = leRandInt(2, total - 2);
    return { domain: "probability", type: "fraction", prompt: `A jar has ${total} candies, ${fav} of them ${colors[1]}. What is the probability of picking a ${colors[1]} candy? (as a fraction)`, answer: leReduceFrac({ n: fav, d: total }), hint: "Reduce your fraction to simplest form." };
  }
  const d1 = leRandInt(2, 6);
  return { domain: "probability", type: "fraction", prompt: `A spinner has ${d1} equal sections (1 winning) and a coin is flipped. What is the probability of landing on the winning section AND getting heads? (as a fraction)`, answer: leReduceFrac({ n: 1, d: d1 * 2 }), hint: "For two independent events, multiply their individual probabilities." };
}

// ---- High-school generators (v55) — same 4-tier pattern. `commonMistakes`
// (optional) lists wrong answers a student is likely to give and the
// diagnosis key to answer them with (see diagnoseMistake()). ----
const LE_SUP = { 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹" };
function leSup(n) { return String(n).split("").map((c) => LE_SUP[c] || c).join(""); }
function lePick(arr) { return arr[leRandInt(0, arr.length - 1)]; }
function leN(n) { return Math.abs(n) >= 1000 ? n.toLocaleString("en-US") : String(n); }

function genExponents(tier) {
  if (tier === 1) {
    const cube = Math.random() < 0.3, b = cube ? leRandInt(2, 5) : leRandInt(2, 9), e = cube ? 3 : 2;
    return { domain: "exponents", type: "integer", prompt: `What is ${b}${leSup(e)}?`, answer: Math.pow(b, e),
      hint: "The exponent tells you how many times to multiply the base by itself.",
      commonMistakes: [{ type: "exponent_multiplied", value: b * e }] };
  }
  if (tier === 2) {
    const b = leRandInt(2, 9), m = leRandInt(2, 6), n = leRandInt(2, 6);
    if (Math.random() < 0.5) return { domain: "exponents", type: "integer", prompt: `${b}${leSup(m)} × ${b}${leSup(n)} = ${b}^?  (find the missing exponent)`, answer: m + n,
      hint: "Same base: when you multiply, add the exponents.", commonMistakes: [{ type: "exponent_multiplied", value: m * n }] };
    const big = m + n;
    return { domain: "exponents", type: "integer", prompt: `${b}${leSup(big)} ÷ ${b}${leSup(m)} = ${b}^?  (find the missing exponent)`, answer: n,
      hint: "Same base: when you divide, subtract the exponents.", commonMistakes: [{ type: "exponent_multiplied", value: big + m }] };
  }
  if (tier === 3) {
    if (Math.random() < 0.7) { const r = leRandInt(2, 15); return { domain: "exponents", type: "integer", prompt: `√${r * r} = ?`, answer: r, hint: "Which number multiplied by itself gives this?", commonMistakes: [{ type: "forgot_square_root", value: r * 2 }] }; }
    const r = leRandInt(2, 6);
    return { domain: "exponents", type: "integer", prompt: `∛${r * r * r} = ?`, answer: r, hint: "Which number multiplied by itself three times gives this?" };
  }
  const kind = leRandInt(0, 2);
  if (kind === 0) { const m = leRandInt(2, 4), n = leRandInt(2, 3); return { domain: "exponents", type: "integer", prompt: `(2${leSup(m)})${leSup(n)} = 2^?  (find the missing exponent)`, answer: m * n, hint: "Power of a power: multiply the exponents.", commonMistakes: [{ type: "exponent_multiplied", value: m + n }] }; }
  if (kind === 1) { const z = leRandInt(2, 9), b = leRandInt(2, 5), e = leRandInt(2, 3); return { domain: "exponents", type: "integer", prompt: `${z}⁰ + ${b}${leSup(e)} = ?`, answer: 1 + Math.pow(b, e), hint: "Any non-zero number to the power 0 equals 1." }; }
  const digits = leRandInt(2, 4), lead = (leRandInt(11, 99) / 10);
  return { domain: "exponents", type: "integer", prompt: `${(lead * Math.pow(10, digits)).toLocaleString("en-US")} = ${lead} × 10^?  (scientific notation — find the exponent)`, answer: digits, hint: "Count how many places the decimal point moves to get a number between 1 and 10." };
}

function genEquations(tier) {
  if (tier === 1) { const a = leRandInt(2, 20), x = leRandInt(2, 20); return { domain: "equations", type: "integer", prompt: `x + ${a} = ${x + a}.  x = ?`, answer: x, hint: "Do the opposite operation to both sides.", commonMistakes: [{ type: "inverse_operation", value: x + 2 * a }] }; }
  if (tier === 2) { const a = leRandInt(2, 9), x = leRandInt(2, 12); return { domain: "equations", type: "integer", prompt: `${a}x = ${a * x}.  x = ?`, answer: x, hint: "Divide both sides by the number next to x.", commonMistakes: [{ type: "inverse_operation", value: a * a * x }] }; }
  if (tier === 3) {
    const a = leRandInt(2, 9), x = leRandInt(-8, 12) || 3, b = leRandInt(1, 15), sign = Math.random() < 0.5 ? 1 : -1, c = a * x + sign * b;
    return { domain: "equations", type: "integer", prompt: `${a}x ${sign > 0 ? "+" : "−"} ${b} = ${c}.  x = ?`, answer: x, hint: "Undo the + or − first, then divide by the number next to x.", commonMistakes: [{ type: "inverse_operation", value: (c + sign * b) / a }] };
  }
  const a = leRandInt(2, 6), x = leRandInt(-6, 10) || 4, k = leRandInt(1, 3), c = a + k * leRandInt(1, 3);
  if (Math.random() < 0.5) { const b = leRandInt(1, 9); return { domain: "equations", type: "integer", prompt: `${a}(x + ${b}) = ${a * (x + b)}.  x = ?`, answer: x, hint: "Divide both sides by the number outside the brackets first, then solve.", commonMistakes: [{ type: "inverse_operation", value: (a * (x + b)) / a + b }] }; }
  // keep an integer solution: ax + p = cx + q  ->  x = (q - p) / (a - c)
  const diff = a - c, p = leRandInt(1, 12), q = p + diff * x;
  return { domain: "equations", type: "integer", prompt: `${a}x + ${p} = ${c}x + ${q < 0 ? "(" + q + ")" : q}.  x = ?`, answer: x, hint: "Collect the x-terms on one side and the plain numbers on the other." };
}

function genFactoring(tier) {
  if (tier === 1) { const g = leRandInt(2, 9), a = g * leRandInt(2, 6); let b = g * leRandInt(2, 6); if (b === a) b += g; return { domain: "factoring", type: "integer", prompt: `Find the GCF (greatest common factor) of ${a} and ${b}.`, answer: leGcd(a, b) === g ? g : leGcd(a, b), hint: "The GCF is the biggest number that divides both evenly." }; }
  if (tier === 2) { const g = leRandInt(2, 9); let c1 = leRandInt(2, 8), c2 = leRandInt(2, 8); if (leGcd(c1, c2) !== 1) { c1 = 3; c2 = 4; } return { domain: "factoring", type: "integer", prompt: `${g * c1}x + ${g * c2}y = ?(${c1}x + ${c2}y).  What is the GCF that goes in front?`, answer: g, hint: "Find the biggest number that divides both coefficients." }; }
  if (tier === 3) { const n = leRandInt(2, 15); return { domain: "factoring", type: "integer", prompt: `x² − ${n * n} = (x − ?)(x + ${n}).  What number goes in the blank?`, answer: n, hint: "Difference of squares: the two brackets use the same number, one with − and one with +.", commonMistakes: [{ type: "forgot_square_root", value: n * n }] }; }
  if (Math.random() < 0.5) { const p = leRandInt(1, 9), q = leRandInt(1, 9); return { domain: "factoring", type: "integer", prompt: `x² + ${p + q}x + ${p * q} = (x + ${p})(x + ?).  What goes in the blank?`, answer: q, hint: "Find two numbers that multiply to the last number and add to the middle number." }; }
  const n = leRandInt(2, 12);
  return { domain: "factoring", type: "integer", prompt: `x² + ${2 * n}x + ${n * n} = (x + ?)².  What number goes in the blank?`, answer: n, hint: "Perfect square trinomial: the blank is half of the middle number." };
}

function genMeasurement(tier) {
  if (tier === 1) {
    const kind = leRandInt(0, 2);
    if (kind === 0) { const n = leRandInt(2, 40); return { domain: "measurement", type: "integer", prompt: `${n} km = ? m`, answer: n * 1000, hint: "1 km = 1,000 m.", commonMistakes: [{ type: "unit_conversion", value: n * 100 }, { type: "unit_conversion", value: n * 10000 }] }; }
    if (kind === 1) { const n = leRandInt(2, 30); return { domain: "measurement", type: "integer", prompt: `${n} m = ? cm`, answer: n * 100, hint: "1 m = 100 cm.", commonMistakes: [{ type: "unit_conversion", value: n * 1000 }, { type: "unit_conversion", value: n * 10 }] }; }
    const n = leRandInt(2, 25); return { domain: "measurement", type: "integer", prompt: `${n} kg = ? g`, answer: n * 1000, hint: "1 kg = 1,000 g.", commonMistakes: [{ type: "unit_conversion", value: n * 100 }, { type: "unit_conversion", value: n * 10000 }] };
  }
  if (tier === 2) {
    const kind = leRandInt(0, 2);
    if (kind === 0) { const n = leRandInt(2, 20) * 100; return { domain: "measurement", type: "decimal", prompt: `${leN(n)} cm = ? m`, answer: n / 100, tolerance: 0.01, hint: "Divide by 100 to go from cm to m.", commonMistakes: [{ type: "unit_conversion", value: n / 10 }, { type: "unit_conversion", value: n / 1000 }] }; }
    if (kind === 1) { const n = leRandInt(2, 15) * 500; return { domain: "measurement", type: "decimal", prompt: `${leN(n)} g = ? kg`, answer: n / 1000, tolerance: 0.01, hint: "Divide by 1,000 to go from g to kg.", commonMistakes: [{ type: "unit_conversion", value: n / 100 }, { type: "unit_conversion", value: n / 10000 }] }; }
    const n = leRandInt(2, 20); return { domain: "measurement", type: "integer", prompt: `${n} L = ? mL`, answer: n * 1000, hint: "1 L = 1,000 mL.", commonMistakes: [{ type: "unit_conversion", value: n * 100 }, { type: "unit_conversion", value: n * 10000 }] };
  }
  if (tier === 3) {
    if (Math.random() < 0.5) { const h = leRandInt(2, 12); return { domain: "measurement", type: "integer", prompt: `${h} hectares = ? m²  (1 hectare = 10,000 m²)`, answer: h * 10000, hint: "Multiply the hectares by 10,000.", commonMistakes: [{ type: "unit_conversion", value: h * 1000 }, { type: "unit_conversion", value: h * 100000 }] }; }
    const m = leRandInt(2, 12) * 5000; return { domain: "measurement", type: "decimal", prompt: `${leN(m)} m² = ? hectares  (1 hectare = 10,000 m²)`, answer: m / 10000, tolerance: 0.01, hint: "Divide the m² by 10,000.", commonMistakes: [{ type: "unit_conversion", value: m / 1000 }, { type: "unit_conversion", value: m / 100000 }] };
  }
  const rate = leRandInt(2, 12) * 10, h = lePick([2, 2.5, 3, 4, 4.5, 5, 6, 7.5, 8, 10]);
  return { domain: "measurement", type: "decimal", prompt: `A farm applies ${rate} kg of fertilizer per hectare. How many kg are needed for ${h} hectares?`, answer: +(rate * h).toFixed(2), tolerance: 0.05, hint: "Rate × number of hectares.", operands: { a: rate, b: h, op: "×" } };
}

function genCoordinates(tier) {
  if (tier === 1) {
    const y = leRandInt(-5, 8), x1 = leRandInt(-8, 2), x2 = x1 + leRandInt(3, 12);
    return { domain: "coordinates", type: "integer", prompt: `How many units apart are the points (${x1}, ${y}) and (${x2}, ${y}) on the grid?`, answer: x2 - x1, hint: "They share the same y, so just count the gap between the x-values.", commonMistakes: [{ type: "sign_error", value: x2 + x1 }] };
  }
  if (tier === 2) {
    const m = leRandInt(-5, 6) || 2, x1 = leRandInt(-4, 3), y1 = leRandInt(-6, 6), dx = leRandInt(1, 4), x2 = x1 + dx, y2 = y1 + m * dx;
    return { domain: "coordinates", type: "integer", prompt: `What is the slope of the line through (${x1}, ${y1}) and (${x2}, ${y2})?`, answer: m, hint: "Slope = (y₂ − y₁) ÷ (x₂ − x₁)  —  rise over run.", commonMistakes: [{ type: "sign_error", value: -m }] };
  }
  if (tier === 3) {
    const m = leRandInt(-6, 8) || 3, b = leRandInt(-12, 15) || 5;
    return { domain: "coordinates", type: "integer", prompt: `For the line y = ${m}x ${b >= 0 ? "+" : "−"} ${Math.abs(b)}, what is the y-intercept?`, answer: b, hint: "In y = mx + b, the y-intercept is b — where the line crosses the y-axis." };
  }
  let dx = leRandInt(2, 6), dy = leRandInt(-7, 7) || 3;
  if (leGcd(dx, dy) !== 1 && Math.random() < 0.7) dy = dx + 1;
  const x1 = leRandInt(-4, 2), y1 = leRandInt(-5, 5), x2 = x1 + dx, y2 = y1 + dy, ans = leReduceFrac({ n: dy, d: dx });
  return { domain: "coordinates", type: "fraction", prompt: `What is the slope of the line through (${x1}, ${y1}) and (${x2}, ${y2})? (as a fraction in simplest form)`, answer: ans, hint: "Slope = rise ÷ run. Reduce your fraction; keep the negative sign if the line goes down.",
    commonMistakes: [{ type: "rise_run_flip", value: leReduceFrac({ n: dx, d: dy }) }] };
}

function genPythagoras(tier) {
  const triples = [[3, 4, 5], [5, 12, 13], [8, 15, 17], [7, 24, 25], [20, 21, 29]];
  if (tier === 1) { const mult = leRandInt(1, 3), [a, b, c] = [3, 4, 5].map((v) => v * mult); return { domain: "pythagoras", type: "integer", prompt: `A rectangular plot is ${a} m by ${b} m. How long is the diagonal fence?`, answer: c, hint: "Diagonal² = a² + b², then take the square root.", commonMistakes: [{ type: "forgot_square_root", value: a * a + b * b }] }; }
  if (tier === 2) { const [a, b, c] = lePick(triples.slice(0, 3)); const mult = leRandInt(1, 2); return { domain: "pythagoras", type: "integer", prompt: `A ladder ${c * mult} m long leans on a wall and its foot is ${a * mult} m from the wall. How high up the wall does it reach?`, answer: b * mult, hint: "Find the missing leg: leg² = hypotenuse² − other leg², then take the square root.", commonMistakes: [{ type: "forgot_square_root", value: (c * c - a * a) * mult * mult }, { type: "operator_confusion", value: (c + a) * mult }] }; }
  if (tier === 3) { const [a, b, c] = lePick(triples), mult = leRandInt(1, 2), legFirst = Math.random() < 0.5; return legFirst ? { domain: "pythagoras", type: "integer", prompt: `The legs of a right triangle are ${a * mult} m and ${b * mult} m. What is the hypotenuse?`, answer: c * mult, hint: "c² = a² + b². Then take the square root.", commonMistakes: [{ type: "forgot_square_root", value: (a * a + b * b) * mult * mult }] } : { domain: "pythagoras", type: "integer", prompt: `A right triangle has a hypotenuse of ${c * mult} m and one leg of ${b * mult} m. How long is the other leg?`, answer: a * mult, hint: "leg² = hypotenuse² − other leg². Then take the square root.", commonMistakes: [{ type: "forgot_square_root", value: (c * c - b * b) * mult * mult }] }; }
  const a = leRandInt(3, 9), b = leRandInt(4, 12), c = Math.sqrt(a * a + b * b);
  return { domain: "pythagoras", type: "decimal", prompt: `Farm boundary: two fences meet at a right angle, ${a} m and ${b} m long. How long is the straight line joining their ends? (round to 1 decimal place)`, answer: +c.toFixed(1), tolerance: 0.06, hint: "c = √(a² + b²). Use a calculator-style estimate and round to 1 decimal.", commonMistakes: [{ type: "forgot_square_root", value: a * a + b * b }, { type: "operator_confusion", value: a + b }] };
}

function leParseFraction(raw) {
  const s = String(raw || "").trim(); let m;
  if ((m = /^-?(\d+)\/(\d+)$/.exec(s))) return { n: +m[1] * (s.startsWith("-") ? -1 : 1), d: +m[2] };
  if ((m = /^-?(\d+)$/.exec(s))) return { n: +m[1] * (s.startsWith("-") ? -1 : 1), d: 1 };
  return null;
}
function checkAnswer(q, raw) {
  const s = String(raw == null ? "" : raw).trim();
  if (!s) return false;
  if (q.type === "integer") { if (!/^-?\d+$/.test(s)) return false; return parseInt(s, 10) === q.answer; }
  if (q.type === "decimal") { if (!/^-?\d+(\.\d+)?$/.test(s)) return false; return Math.abs(parseFloat(s) - q.answer) <= (q.tolerance || 0.05); }
  if (q.type === "fraction") { const f = leParseFraction(s); if (!f) return false; const r = leReduceFrac(f); return r.n === q.answer.n && r.d === q.answer.d; }
  return false;
}
function leFmtAnswer(q) { return q.type === "fraction" ? leFracStr(q.answer) : String(q.answer); }

// ============================================================================
// THE MASTER FUNCTION
// processAnswer(studentObject, questionData, userAnswer, attemptNumber = 1)
//
// Calls, in order:
//   1. diagnoseMistake()    — only when the answer is wrong
//   2. updateSkillBar()     — always, correct or wrong
//   3. calculateNextTier()  — only once the question's attempts are FINAL
//      (i.e. correct, or already used the one allowed retry) — a mid-retry
//      miss shouldn't yet count against the rolling "last 5" history, since
//      the student hasn't finished answering that question.
// Mutates `studentObject` in place (so the UI can re-render straight from
// it) and also returns a result object describing what just happened.
// ============================================================================
function processAnswer(studentObject, questionData, userAnswer, attemptNumber) {
  attemptNumber = attemptNumber || 1;
  const domain = questionData.domain;
  const tier = studentObject.adaptiveLevel[domain] || 1;
  const isCorrect = checkAnswer(questionData, userAnswer);

  // ---- 1. Error Diagnosis Engine ----
  let feedback = null, mistakeType = null;
  if (!isCorrect) {
    const diagnosis = diagnoseMistake(questionData, userAnswer);
    feedback = diagnosis.message;
    mistakeType = diagnosis.mistakeType;
  }

  // ---- 2. Skill Tree Engine (always runs) ----
  const { newProficiency, pointsAwarded } = updateSkillBar(studentObject.skillProficiency[domain] || 0, tier, isCorrect, attemptNumber);
  studentObject.skillProficiency = { ...studentObject.skillProficiency, [domain]: newProficiency };

  // A question is "final" once it's correct, or the one allowed retry has been used.
  const isFinal = isCorrect || attemptNumber >= 2;
  const allowRetry = !isCorrect && attemptNumber === 1;

  // ---- 3. Adaptive Difficulty Engine (only on the final outcome of this question) ----
  let nextTier = tier;
  if (isFinal) {
    // Only an UNASSISTED first-try correct counts as a "win" for difficulty purposes —
    // a question that needed a retry still shows the student found this tier hard.
    const outcomeForHistory = isCorrect && attemptNumber === 1 ? 1 : 0;
    const updatedHistory = pushRecentAnswer(studentObject.recentAnswers[domain], outcomeForHistory);
    studentObject.recentAnswers = { ...studentObject.recentAnswers, [domain]: updatedHistory };
    nextTier = calculateNextTier(updatedHistory, tier);
    studentObject.adaptiveLevel = { ...studentObject.adaptiveLevel, [domain]: nextTier };
  }

  return {
    isCorrect, attemptNumber, isFinal, allowRetry,
    feedback, mistakeType,
    pointsAwarded, skillProficiency: newProficiency,
    tierUsed: tier, nextTier, tierChanged: isFinal && nextTier !== tier,
    correctAnswerDisplay: leFmtAnswer(questionData),
  };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { LE_DOMAINS, generateQuestion, checkAnswer, processAnswer };
}
