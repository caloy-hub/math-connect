# MathConnect v46

## Deploy (2 steps)
1. **Supabase → SQL Editor:** run `migration-52-exam-explanations-review.sql` (safe to re-run).
2. **Deploy the files** as usual (Netlify). The service worker version is bumped to `mathconnect-v46-1`, so
   installed apps pick up the new files on the next load.

The app keeps working if step 1 is skipped (exams still save; only the new "after I lock the exam" setting
is unavailable and a toast says so), but run it before your standardized-test review.

---

## 1. Math Drills status showed "0/23 players" for stations students had played

**Cause.** The teacher dashboard loaded `drill_attempts` with a plain query. Supabase silently caps that at
~1,000 rows, and the dropped rows are the newest ones, i.e. the newest stations. A failed request was also
indistinguishable from "nobody has played".

To confirm on your data (replace the section id):
```sql
select topic, count(*) from drill_attempts
where student_id in (select id from students where section_id = '<your section id>')
group by topic order by 2 desc;
-- total over 1000 = you were hitting the cap
```

**Fixes**
- `supabase-client.js` — new `fetchAllRowsChecked()`: pages through every row, works even if the project's
  "Max rows" API setting is below 1000, and reports errors instead of hiding them.
- `teacher-drills.js` — uses it; a raised level or banked points in `drill_progress` now also counts as
  "played" (so a station can't read 0 when the student clearly has points there); new **Runs** column;
  a status line ("Counted from N logged runs · updated hh:mm · Refresh"); warning banners for load failures,
  for runs logged under a station key the dashboard doesn't know, and for students whose progress exists
  without run history; "least-played" ignores admin-locked stations; "last played" per student; leaderboard
  RPC errors are shown instead of "No scores yet".
- Same truncation bug fixed on **Quest Mode** (`teacher-quest.js`), **Boss Battles** (`teacher-battles.js` —
  stats used only the latest 200 battles; the log now shows the latest 100 of all; newer station names
  resolve) and the **Status tab** (`statusEngine.js` — Daily Challenge streaks and W-L records).
- `drills.js` (student side) — run history and progress saves used to ignore failures. Now: retry once,
  then queue on the device and resend automatically; each run has a client-generated id so retries can never
  double-count; progress uses upsert. The student's own "stations attempted" uses the same rules as the
  teacher's view.

Runs that were never saved cannot be reconstructed; those students/stations are shown as "Played (run history
not saved)" with no accuracy figure.

## 2. Exam explanations for review

Already existed: `exam_questions.explanation`. New in v46:

**Teacher**
- **💡 Explanations** button (exam list and question panel): one screen listing every item with its correct
  answer and a box for the explanation; "show only items without one"; **paste numbered explanations** from
  an answer key (`1. …`, `2) …`, `Q3: …`) to fill the boxes; saves only what changed.
- Coverage everywhere: "💡 12/40 explained" on each exam, a ⚠️ on each item lacking one, and a confirm
  when publishing with gaps.
- Bulk Add: an `EXPLANATION:` (or `RATIONALE:` / `SOLUTION:`) may now run over several lines — before, extra
  lines were glued onto the question text. Preview shows which items have one.
- New exam setting **"When do students see the review?"** — *right after they submit* (default, same as
  before) or *only after I lock the exam* (recommended for a class-wide test). Enforced in the database.

**Student**
- Review shows every item with all options, "Your answer", the green ✓ correct answer, and the
  💡 explanation; filters for All / Correct / Incorrect / Not answered.
- While a review is held, students see their score and a clear "opens when the exam closes" message.
- **Bug fixed:** locking an exam used to hide "View Result" from students who had already finished. They can
  now always open their result/review; locking only blocks starting, resuming and retaking.

**Database (`migration-52`)** — adds `exams.review_release`; rebuilds `submit_exam_attempt` (grading logic
unchanged) to hold/release the review and include `question_type` + `points`; and **drops the stale
one-argument `submit_exam_attempt(uuid)`** that migration 42 left beside the new one. Without dropping it,
a student could call it directly and bypass the release setting.

Notes: explanations show only when "Allow review" *and* "Show correct answers" are on (otherwise they'd
reveal the answer). With retakes enabled, students see answers before retaking unless review is set to
"after I lock".

## Tested
Real Postgres (pglite): migrations 1→52 apply and re-apply; grading, shuffled-answer mapping, hold/release,
no bypass, hidden-answer and constraint cases (15 checks). Node harnesses with a mock Supabase capped at
1,000 rows: v45 reproduces the zeros, v46 matches ground truth for all 18 stations, also with a 300-row cap;
failure banner; student retry/queue/no-duplicate (5 checks); review rendering incl. HTML escaping (10);
teacher parsers, badges, publish warning, fallback, editor save (16).
**Not tested:** against your live Supabase project or in a real browser. Please try one full exam
(create → add explanations → publish → submit → lock → review) with a test student before the real test.
