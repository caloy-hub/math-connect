-- ============================================================================
-- MathConnect — Migration 64 (v57)
--   1. AUTOMATIC Legendary Pet certificates, issued by the database itself.
--   2. Makes sure Class Settings' "Subject Teacher" save has the columns it needs.
--
-- WHY: until now a Legendary Pet certificate was only created by the STUDENT'S
-- browser (when they opened the app or watched the evolution). If the pet
-- reached Legendary any other way, or the student never reopened the app — or
-- migration-62 hadn't been run, so the insert was refused and the certificate
-- stayed only on the student's device — the teacher had nothing to view.
--
-- NOW: a trigger on student_pets issues the certificate the moment a pet's
-- growth_points reaches the Legendary threshold (is_pet_peak, 5000), no matter
-- what caused it. Pets that are ALREADY Legendary get theirs from the backfill
-- at the bottom. One certificate per pet (unique on student + pet).
--
-- Run AFTER migration-61 (station_certificates) and migration-35 (student_pets
-- with an id column). SAFE TO RE-RUN.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0. Class Settings needs these two columns (migration-40). Re-asserting them
--    here is harmless if they exist, and fixes "Save Subject Teacher" on any
--    project where migration-40 was skipped. The final NOTIFY makes Supabase's
--    API pick up new columns immediately (otherwise it can keep answering
--    "could not find the column in the schema cache" for a while).
-- ----------------------------------------------------------------------------
alter table sections add column if not exists subject_teacher_name text;
alter table sections add column if not exists subject_teacher_position text;

-- ----------------------------------------------------------------------------
-- 1. station_certificates must accept pet certificates (migration-62 did this;
--    repeated here so ONE file fixes a project that skipped it).
-- ----------------------------------------------------------------------------
do $$
declare
  c record;
begin
  if to_regclass('public.station_certificates') is null then
    raise notice 'station_certificates not found - run migration-61 first, then re-run this migration.';
    return;
  end if;

  for c in
    select conname
    from pg_constraint
    where conrelid = 'public.station_certificates'::regclass
      and contype = 'c'
      and pg_get_constraintdef(oid) ~* '\m(source|kind)\M'
  loop
    execute format('alter table public.station_certificates drop constraint %I', c.conname);
  end loop;

  alter table public.station_certificates
    add constraint station_certificates_source_check
    check (source in ('drills', 'quest', 'practice', 'pet'));

  alter table public.station_certificates
    add constraint station_certificates_kind_check
    check (kind in ('completion', 'excellence', 'perfect', 'chapter', 'legendary'));
end
$$;

-- ----------------------------------------------------------------------------
-- 2. Legendary form names + artwork per pet type (mirrors PET_TYPE_META in
--    petEngine.js). The certificate stores the title and image path INSIDE the
--    row, so the teacher's page can draw it without knowing anything about pets.
-- ----------------------------------------------------------------------------
create table if not exists pet_legendary_forms (
  pet_type_key text primary key,
  title        text not null,
  image        text not null
);
alter table pet_legendary_forms enable row level security;
drop policy if exists "public read pet_legendary_forms" on pet_legendary_forms;
create policy "public read pet_legendary_forms" on pet_legendary_forms for select using (true);

insert into pet_legendary_forms (pet_type_key, title, image) values
  ('numo_fox',     'Kitsune, the Nine-Tailed Fox Spirit',  'assets/pets/legendary/kitsune.png'),
  ('pico_penguin', 'Suzaku, the Vermilion Phoenix',        'assets/pets/legendary/suzaku.png'),
  ('digit_dragon', 'Qinglong, the Azure Dragon',           'assets/pets/legendary/qinglong.png'),
  ('sumi_bunny',   'The Jade Rabbit of the Moon',          'assets/pets/legendary/jaderabbit.png'),
  ('ari_owl',      'The All-Seeing Sage Owl',              'assets/pets/legendary/sageowl.png'),
  ('tala_turtle',  'Xuanwu, the Black Tortoise',           'assets/pets/legendary/xuanwu.png'),
  ('byte_cat',     'Bakeneko, the Twin-Tailed Spirit Cat', 'assets/pets/legendary/bakeneko.png'),
  ('kiri_calf',    'Qilin, the Auspicious Beast',          'assets/pets/legendary/qilin.png'),
  ('vex_wolf',     'Fenrir, the Great Wolf',               'assets/pets/legendary/fenrir.png'),
  ('zeta_steed',   'Pegasus, the Winged Steed',            'assets/pets/legendary/pegasus.png')
on conflict (pet_type_key) do update set title = excluded.title, image = excluded.image;

-- ----------------------------------------------------------------------------
-- 3. The issuing function. Returns true if a NEW certificate was created.
--    Identity fields are snapshotted exactly like the app does (student,
--    section, school year, subject, subject teacher). If the section has no
--    subject teacher saved yet it falls back to the owning teacher's account,
--    so a certificate never prints with a blank signature.
--    NEVER raises: a problem here must not be able to block feeding a pet.
-- ----------------------------------------------------------------------------
create or replace function public.issue_legendary_pet_certificate(p_pet_id uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  pet      record;
  stu      record;
  form     record;
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  code     text;
  short_form text;
  inserted int := 0;
begin
  select * into pet from student_pets where id = p_pet_id;
  if not found or not is_pet_peak(coalesce(pet.growth_points, 0)) then
    return false;
  end if;

  select st.id as student_id, st.full_name,
         sec.section_name, sec.grade_level, sec.school_year, sec.subject,
         coalesce(nullif(btrim(sec.subject_teacher_name), ''), t.full_name)               as teacher_name,
         coalesce(nullif(btrim(sec.subject_teacher_position), ''), t.position, 'Subject Teacher') as teacher_position
    into stu
    from students st
    left join sections sec on sec.id = st.section_id
    left join teachers t   on t.id = sec.teacher_id
   where st.id = pet.student_id;
  if not found then return false; end if;

  select * into form from pet_legendary_forms where pet_type_key = pet.pet_type_key;
  short_form := coalesce(
    nullif(regexp_replace(regexp_replace(split_part(coalesce(form.title, ''), ',', 1), '^The\s+', '', 'i'), '\s+of the .*$', '', 'i'), ''),
    'Legendary');

  select string_agg(substr(alphabet, 1 + floor(random() * 32)::int, 1), '') into code from generate_series(1, 6);

  insert into station_certificates (
    student_id, source, station_key, level_key, station_name, level_label, kind,
    correct_count, total_questions, accuracy, extra,
    student_name, section_name, grade_level, school_year, subject, teacher_name, teacher_position,
    cert_no, earned_at
  ) values (
    pet.student_id, 'pet', pet.id::text, 'legendary',
    coalesce(nullif(btrim(pet.pet_name), ''), 'Math Pet'), 'Legendary', 'legendary',
    null, null, null,
    jsonb_build_object(
      'moduleLine', 'LEGENDARY PET  ·  ' || upper(coalesce(form.title, 'LEGENDARY FORM')),
      'detail',     'Raised from a hatchling to the Legendary stage',
      'petImage',   coalesce(form.image, ''),
      'petTypeKey', pet.pet_type_key,
      'stats', jsonb_build_array(
        jsonb_build_object('label', 'LEGENDARY FORM', 'value', short_form),
        jsonb_build_object('label', 'GROWTH POINTS',  'value', to_char(pet.growth_points, 'FM999,999,999')),
        jsonb_build_object('label', 'ADOPTED',        'value', coalesce(to_char(pet.adopted_at, 'Mon YYYY'), '—'))
      )
    ),
    coalesce(nullif(btrim(stu.full_name), ''), 'Student'), stu.section_name, stu.grade_level, stu.school_year,
    coalesce(stu.subject, 'Mathematics'), stu.teacher_name, stu.teacher_position,
    'MC-' || to_char(now(), 'YYMM') || '-PT-' || code, now()
  )
  on conflict (student_id, source, station_key, level_key) do nothing;

  get diagnostics inserted = row_count;
  return inserted > 0;
exception when others then
  raise warning 'issue_legendary_pet_certificate(%) skipped: %', p_pet_id, sqlerrm;
  return false;
end;
$$;

revoke all on function public.issue_legendary_pet_certificate(uuid) from public, anon, authenticated;

-- ----------------------------------------------------------------------------
-- 4. The trigger: fires when a pet is created or its growth_points change, and
--    only does work once the pet is Legendary. (Re-crossing the line later is
--    harmless: the unique key makes it a no-op.)
-- ----------------------------------------------------------------------------
create or replace function public.trg_legendary_pet_certificate()
returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if is_pet_peak(coalesce(new.growth_points, 0)) then
    perform issue_legendary_pet_certificate(new.id);
  end if;
  return null; -- AFTER trigger: return value is ignored
end;
$$;

drop trigger if exists student_pets_legendary_certificate on student_pets;
create trigger student_pets_legendary_certificate
  after insert or update of growth_points on student_pets
  for each row execute function public.trg_legendary_pet_certificate();

-- ----------------------------------------------------------------------------
-- 5. Backfill: every pet that is ALREADY Legendary gets its certificate now.
-- ----------------------------------------------------------------------------
do $$
declare
  p record;
  made int := 0;
begin
  if to_regclass('public.station_certificates') is null then return; end if;
  for p in select id from student_pets where is_pet_peak(coalesce(growth_points, 0)) loop
    if issue_legendary_pet_certificate(p.id) then made := made + 1; end if;
  end loop;
  raise notice 'Legendary pet certificates issued by backfill: %', made;
end
$$;

-- Make the API notice the new columns right away.
notify pgrst, 'reload schema';

-- ============================================================================
-- Done. From now on a pet that reaches Legendary gets its certificate in the
-- same instant — it shows up in the teacher's Certificates tab and on the
-- teacher Dashboard without the student having to do anything.
-- ============================================================================
