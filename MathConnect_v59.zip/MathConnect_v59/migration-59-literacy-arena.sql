-- ============================================================================
-- Migration 59 — Literacy Arena (reading comprehension, vocabulary, spelling)
-- Unlike every other gamified feature in MathConnect, this one is NOT
-- Math-only and NOT student_id-scoped. It's meant to follow a real student
-- across every subject/section they're enrolled in.
--
-- WHY learner_id, not student_id:
-- `students` rows are per-SECTION (one teacher, one subject) — the same real
-- student has a separate `students.id` for Math, Science, English, etc.
-- `learners` is the one shared, school-wide identity for that real person.
-- So literacy progress is keyed to `learner_id` wherever it's available,
-- which lets a student's vocabulary/spelling/comprehension progress follow
-- them no matter which class they're logged in through.
--
-- FALLBACK: learner_id is nullable (some students predate the shared
-- directory, or a teacher added them without a match). For those, literacy
-- falls back to being scoped to that one student_id/section — same
-- limitation every other feature already has. `progress_key` below encodes
-- this automatically: it's the learner_id when present, else a
-- student-prefixed key, so the rest of the schema never has to special-case
-- the null. Nothing breaks either way — a student without a learner_id just
-- doesn't get cross-class continuity until a teacher links them to one
-- (Roster → search/merge, same flow already used for Math/Science dupes).
-- ============================================================================

-- ---------- PASSAGES (for Reading Comprehension Chamber) ----------
create table if not exists literacy_passages (
  id uuid primary key default gen_random_uuid(),
  grade_level text not null,           -- e.g. "Grade 8" — content targeting, not enrollment
  title text not null,
  body text not null,
  genre text,                          -- e.g. "informational", "narrative" — optional filter
  difficulty int not null default 1 check (difficulty between 1 and 10),
  created_by uuid references teachers(id) on delete set null,
  created_at timestamptz default now()
);

-- ---------- QUESTIONS (shared bank for all 3 stations) ----------
create table if not exists literacy_questions (
  id uuid primary key default gen_random_uuid(),
  skill_type text not null check (skill_type in ('vocabulary', 'spelling', 'comprehension', 'grammar')),
  passage_id uuid references literacy_passages(id) on delete cascade, -- only used by comprehension
  grade_level text not null,
  difficulty int not null default 1 check (difficulty between 1 and 10),
  question_format text not null default 'multiple_choice' check (question_format in ('multiple_choice', 'typed')),
  prompt text not null,                -- the question text, or for spelling: "Spell the word you hear/read: ___"
  choices jsonb,                       -- array of strings, multiple_choice only
  correct_answer text not null,        -- exact text for typed (spelling), or matches one of `choices` for MC
  audio_word text,                     -- the target word for TTS-prompted spelling items (client reads this aloud)
  explanation text,                    -- shown after answering, esp. useful for grammar/comprehension
  created_by uuid references teachers(id) on delete set null,
  created_at timestamptz default now()
);
create index if not exists literacy_questions_skill_idx on literacy_questions (skill_type, grade_level, difficulty);
create index if not exists literacy_questions_passage_idx on literacy_questions (passage_id);

-- ---------- PROGRESS (one row per real student, wherever possible) ----------
create table if not exists literacy_progress (
  id uuid primary key default gen_random_uuid(),
  learner_id uuid references learners(id) on delete set null,
  student_id uuid references students(id) on delete cascade not null, -- the enrollment the row was first created through; kept for RLS + fallback
  progress_key text generated always as (coalesce(learner_id::text, 'S-' || student_id::text)) stored,
  total_points integer not null default 0,
  games_played integer not null default 0,
  best_streak integer not null default 0,
  station_points jsonb not null default '{"vocabulary":0,"spelling":0,"comprehension":0,"grammar":0}'::jsonb,
  mastery_tier int not null default 1 check (mastery_tier between 1 and 15),
  mastery_stars int not null default 0 check (mastery_stars >= 0),
  updated_at timestamptz default now()
);
-- One progress row per resolved identity — whether that identity is a shared
-- learner or (fallback) a single student/section enrollment.
create unique index if not exists literacy_progress_key_idx on literacy_progress (progress_key);
create index if not exists literacy_progress_learner_idx on literacy_progress (learner_id);

-- ---------- ATTEMPTS (every answered question — powers "most-missed words" etc.) ----------
create table if not exists literacy_attempts (
  id uuid primary key default gen_random_uuid(),
  learner_id uuid references learners(id) on delete set null,
  student_id uuid references students(id) on delete cascade not null, -- which login/session recorded it
  progress_key text generated always as (coalesce(learner_id::text, 'S-' || student_id::text)) stored,
  question_id uuid references literacy_questions(id) on delete cascade,
  skill_type text not null,
  is_correct boolean not null,
  response_text text,                  -- what the student typed/picked — needed for spelling error-mining
  points_earned int not null default 0,
  attempted_at timestamptz default now()
);
create index if not exists literacy_attempts_key_idx on literacy_attempts (progress_key);
create index if not exists literacy_attempts_question_idx on literacy_attempts (question_id);

-- ---------- RLS ----------
-- Same security model as the rest of the app (students are anon requests —
-- see supabase-schema.sql): reads/writes on progress+attempts are open
-- client-side; only deletes are restricted to the owning teacher or admin.
-- Content tables (passages/questions) are publicly readable (students need
-- them to play) but only teachers/admins can author them.
alter table literacy_passages enable row level security;
alter table literacy_questions enable row level security;
alter table literacy_progress enable row level security;
alter table literacy_attempts enable row level security;

drop policy if exists "public read literacy_passages" on literacy_passages;
create policy "public read literacy_passages" on literacy_passages for select using (true);
drop policy if exists "teacher write literacy_passages" on literacy_passages;
create policy "teacher write literacy_passages" on literacy_passages for insert with check (auth.uid() is not null);
drop policy if exists "teacher update literacy_passages" on literacy_passages;
create policy "teacher update literacy_passages" on literacy_passages for update using (auth.uid() is not null);
drop policy if exists "teacher delete literacy_passages" on literacy_passages;
create policy "teacher delete literacy_passages" on literacy_passages for delete using (
  created_by = auth.uid() or is_admin()
);

drop policy if exists "public read literacy_questions" on literacy_questions;
create policy "public read literacy_questions" on literacy_questions for select using (true);
drop policy if exists "teacher write literacy_questions" on literacy_questions;
create policy "teacher write literacy_questions" on literacy_questions for insert with check (auth.uid() is not null);
drop policy if exists "teacher update literacy_questions" on literacy_questions;
create policy "teacher update literacy_questions" on literacy_questions for update using (auth.uid() is not null);
drop policy if exists "teacher delete literacy_questions" on literacy_questions;
create policy "teacher delete literacy_questions" on literacy_questions for delete using (
  created_by = auth.uid() or is_admin()
);

drop policy if exists "public read literacy_progress" on literacy_progress;
create policy "public read literacy_progress" on literacy_progress for select using (true);
drop policy if exists "anyone insert literacy_progress" on literacy_progress;
create policy "anyone insert literacy_progress" on literacy_progress for insert with check (true);
drop policy if exists "anyone update literacy_progress" on literacy_progress;
create policy "anyone update literacy_progress" on literacy_progress for update using (true);
drop policy if exists "teacher delete literacy_progress" on literacy_progress;
create policy "teacher delete literacy_progress" on literacy_progress for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read literacy_attempts" on literacy_attempts;
create policy "public read literacy_attempts" on literacy_attempts for select using (true);
drop policy if exists "anyone insert literacy_attempts" on literacy_attempts;
create policy "anyone insert literacy_attempts" on literacy_attempts for insert with check (true);
drop policy if exists "teacher delete literacy_attempts" on literacy_attempts;
create policy "teacher delete literacy_attempts" on literacy_attempts for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ----------------------------------------------------------------------------
-- upsert_literacy_progress — students never write literacy_progress directly
-- from the client with a raw insert/update, because the identity key
-- (progress_key) depends on resolving learner_id first, and two different
-- logins for the same learner racing an upsert-by-student_id would create
-- duplicate rows. This function centralizes that resolution.
-- ----------------------------------------------------------------------------
create or replace function public.upsert_literacy_progress(
  target_student_id uuid, points_delta int, skill text, was_correct boolean
) returns void language plpgsql security definer as $$
declare
  resolved_learner_id uuid;
  resolved_key text;
begin
  select learner_id into resolved_learner_id from students where id = target_student_id;
  resolved_key := coalesce(resolved_learner_id::text, 'S-' || target_student_id::text);

  insert into literacy_progress (learner_id, student_id, total_points, games_played, station_points)
  values (
    resolved_learner_id, target_student_id, greatest(points_delta, 0), 1,
    jsonb_build_object(skill, greatest(points_delta, 0))
  )
  on conflict (progress_key) do update set
    total_points = literacy_progress.total_points + greatest(points_delta, 0),
    games_played = literacy_progress.games_played + 1,
    station_points = jsonb_set(
      literacy_progress.station_points, array[skill],
      to_jsonb(coalesce((literacy_progress.station_points->>skill)::int, 0) + greatest(points_delta, 0))
    ),
    updated_at = now();
end;
$$;
grant execute on function public.upsert_literacy_progress(uuid, int, text, boolean) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- section_literacy_roster — teacher-facing rollup for ONE section's roster,
-- regardless of that section's subject. Resolves each enrolled student to
-- their literacy progress via the same progress_key logic (learner_id when
-- present, else that student's own fallback row), so a Science teacher sees
-- the SAME numbers for a student as their Math teacher would.
-- ----------------------------------------------------------------------------
create or replace function public.section_literacy_roster(target_section_id uuid)
returns table (
  student_id uuid, full_name text, has_shared_identity boolean,
  total_points integer, mastery_tier int, mastery_stars int,
  station_points jsonb, last_attempt_at timestamptz
)
language sql security definer stable as $$
  select
    st.id, st.full_name, st.learner_id is not null,
    coalesce(lp.total_points, 0), coalesce(lp.mastery_tier, 1), coalesce(lp.mastery_stars, 0),
    coalesce(lp.station_points, '{"vocabulary":0,"spelling":0,"comprehension":0,"grammar":0}'::jsonb),
    (select max(la.attempted_at) from literacy_attempts la
      where la.progress_key = coalesce(st.learner_id::text, 'S-' || st.id::text))
  from students st
  left join literacy_progress lp on lp.progress_key = coalesce(st.learner_id::text, 'S-' || st.id::text)
  where st.section_id = target_section_id;
$$;
grant execute on function public.section_literacy_roster(uuid) to anon, authenticated;

-- ============================================================================
-- Done. Next: add the "📚 Literacy" tab to student.html/student.js (shown for
-- EVERY subject, unlike the Math-only tabs) and a matching teacher-literacy.js
-- rollup panel on teacher.html. See CHANGELOG note for the exact wiring.
-- ============================================================================
