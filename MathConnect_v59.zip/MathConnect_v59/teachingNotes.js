// ============================================================================
// MathConnect — Teaching Notes & Attachments (v59)
//
// ONE shared module, loaded on teacher.html AND student.html (after mathText.js).
//
//   1. Teaching Notes tab (Blended Learning). A note can hold pasted TEXT,
//      a GOOGLE DRIVE LINK, or both.
//   2. The same "rich text + Drive link" pieces are reused by the Weekly
//      Check-In: the 2-min recap (reteach note) and the lesson of the week.
//
// TEXT. Pasted notes go through MathText (mathText.js), so x^2, sqrt(), 1/2,
//   pi, <=, ∑, $$ … $$ and pasted Unicode symbols all display as real math.
//   Long text is split into PAGES: teachers can start a page with a line that
//   says ---page---, and anything still too long is paged automatically at
//   paragraph boundaries — never in the middle of a $$ … $$ equation.
//   Lines starting with #, ## or ### become headings. Web links in the text
//   are clickable. Everything is HTML-escaped before display.
//
// GOOGLE DRIVE. driveInfo() recognises Drive files and folders and Google
//   Docs / Slides / Sheets links (including /u/0/ and open?id= forms) and
//   converts them to an embeddable URL, so students read them inside the app.
//   Only Google hosts and direct .pdf links are ever embedded; any other
//   https link becomes an "Open link" button; non-http(s) (javascript:, data:)
//   is rejected.
//
// Public API: window.TN
// ============================================================================
(function (global) {
  "use strict";

  const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  const esc = (t) => (t === null || t === undefined ? "" : String(t).replace(/[&<>"']/g, (m) => ESC[m]));
  const $ = (id) => document.getElementById(id);
  const sid = (id) => String(id).replace(/[^\w-]/g, "");

  // ==========================================================================
  // 1. GOOGLE DRIVE / DOCS LINKS
  // ==========================================================================
  /**
   * Returns null (empty), {kind:"invalid"}, or
   *   { kind, icon, label, embedUrl|null, openUrl, shape }
   * kind: file | folder | doc | slides | sheet | pdf | link
   */
  function driveInfo(raw) {
    let url = String(raw === null || raw === undefined ? "" : raw).trim();
    if (!url) return null;
    // Pasted without a scheme, e.g. "drive.google.com/file/d/…"
    if (!/^[a-z][a-z0-9+.-]*:/i.test(url) && /^[\w-]+(\.[\w-]+)+(\/|$)/.test(url)) url = "https://" + url;
    let u;
    try { u = new URL(url); } catch (e) { return { kind: "invalid" }; }
    if (u.protocol !== "https:" && u.protocol !== "http:") return { kind: "invalid" };

    const host = u.hostname.toLowerCase();
    const path = u.pathname;

    if (host === "drive.google.com") {
      let m = path.match(/\/file\/(?:u\/\d+\/)?d\/([\w-]+)/);
      let id = m ? m[1] : null;
      if (!id && /^\/(open|uc|viewerng\/viewer)$/.test(path)) id = u.searchParams.get("id");
      if (id && /^[\w-]+$/.test(id)) {
        return {
          kind: "file", icon: "📄", label: "Google Drive file", shape: "tall",
          embedUrl: `https://drive.google.com/file/d/${id}/preview`,
          openUrl: `https://drive.google.com/file/d/${id}/view`,
        };
      }
      m = path.match(/\/folders\/([\w-]+)/);
      if (m) {
        return {
          kind: "folder", icon: "📁", label: "Google Drive folder", shape: "folder",
          embedUrl: `https://drive.google.com/embeddedfolderview?id=${m[1]}#list`,
          openUrl: `https://drive.google.com/drive/folders/${m[1]}`,
        };
      }
    }

    if (host === "docs.google.com") {
      const m = path.match(/\/(document|presentation|spreadsheets)\/(?:u\/\d+\/)?d\/(e\/)?([\w-]+)/);
      if (m) {
        const type = m[1], published = !!m[2], id = m[3];
        const base = `https://docs.google.com/${type}/d/${published ? "e/" : ""}${id}`;
        const meta = {
          document: { kind: "doc", icon: "📝", label: "Google Doc", shape: "tall" },
          presentation: { kind: "slides", icon: "📽️", label: "Google Slides", shape: "wide" },
          spreadsheets: { kind: "sheet", icon: "📊", label: "Google Sheet", shape: "tall" },
        }[type];
        let embedUrl;
        if (type === "presentation") embedUrl = `${base}/embed?start=false&loop=false&delayms=3000`;
        else if (published) embedUrl = `${base}/pub?embedded=true`;
        else embedUrl = `${base}/preview`;
        return Object.assign({ embedUrl, openUrl: u.href }, meta);
      }
      if (/\/forms\//.test(path)) return { kind: "link", icon: "📋", label: "Google Form", embedUrl: null, openUrl: u.href, shape: "none" };
    }

    if (/\.pdf$/i.test(path)) {
      return { kind: "pdf", icon: "📕", label: "PDF", shape: "tall", embedUrl: u.href, openUrl: u.href };
    }
    return { kind: "link", icon: "🔗", label: host.replace(/^www\./, ""), embedUrl: null, openUrl: u.href, shape: "none" };
  }

  /** Inline viewer (iframe + "open in new tab") for a Drive/Docs link. */
  function attachmentHtml(raw, opts) {
    const o = opts || {};
    const info = driveInfo(raw);
    if (!info || info.kind === "invalid") return "";
    const open = `<a class="btn-outline btn-sm tn-open" href="${esc(info.openUrl)}" target="_blank" rel="noopener noreferrer">Open in new tab ↗</a>`;
    if (!info.embedUrl) {
      return `<div class="tn-attach"><div class="tn-attach-head"><span>${info.icon} ${esc(o.label || info.label)}</span>${open}</div></div>`;
    }
    const inner = `
      <div class="tn-frame tn-frame-${info.shape}"><iframe src="${esc(info.embedUrl)}" loading="lazy" allow="fullscreen" allowfullscreen title="${esc(o.label || info.label)}"></iframe></div>
      <div class="tn-hint">Can't see it? Tap “Open in new tab” — you may need to sign in with your school Google account.</div>`;
    if (o.compact) {
      return `<details class="tn-attach tn-attach-details">
        <summary>${info.icon} ${esc(o.label || info.label)} — tap to view inside the app</summary>
        <div class="tn-attach-head" style="margin-top:8px;"><span class="muted">${esc(info.label)}</span>${open}</div>${inner}
      </details>`;
    }
    return `<div class="tn-attach"><div class="tn-attach-head"><span>${info.icon} ${esc(o.label || info.label)}</span>${open}</div>${inner}</div>`;
  }

  // ==========================================================================
  // 2. PAGING
  // ==========================================================================
  const AUTO_LIMIT = 2400; // characters per auto-page
  // A line that says ---page---, -- new page --, [page], [page break] … or a form-feed (what Word / Docs put at a page break).
  const PAGE_RE = /^[ \t]*(?:-{2,}[ \t]*(?:new[ \t]*)?page(?:[ \t]*break)?[ \t]*-{2,}|\[[ \t]*(?:new[ \t]*)?page(?:[ \t]*break)?[ \t]*\])[ \t]*$|\f/gim;
  const HEAD_RE = /^(#{1,3})[ \t]+(.+?)[ \t]*#*[ \t]*$/;

  function normalize(t) {
    return String(t === null || t === undefined ? "" : t)
      .replace(/\r\n?/g, "\n")
      .replace(/\u00a0/g, " ")
      .replace(/[\u200b-\u200d\ufeff]/g, "");
  }

  // True when the text leaves a $$ … $$ or \[ … \] equation block open.
  function mathOpen(s) {
    const dd = (s.match(/\$\$/g) || []).length;
    const bo = (s.match(/\\\[/g) || []).length, bc = (s.match(/\\\]/g) || []).length;
    return dd % 2 === 1 || bo > bc;
  }

  // Paragraph "atoms" that must never be torn apart: a display equation stays whole
  // (even if it contains blank lines) and a heading stays glued to what follows it.
  function toUnits(chunk) {
    const paras = chunk.split(/\n[ \t]*\n/);
    const units = [];
    let buf = null;
    for (const raw of paras) {
      const p = raw.replace(/^\n+|\n+$/g, "");
      if (buf !== null) {
        buf += "\n\n" + p;
        if (!mathOpen(buf)) { units.push(buf); buf = null; }
        continue;
      }
      if (!p.trim()) continue;
      if (mathOpen(p)) { buf = p; continue; }
      units.push(p);
    }
    if (buf !== null) units.push(buf);
    const out = [];
    for (let i = 0; i < units.length; i++) {
      let u = units[i];
      while (HEAD_RE.test(u.trim()) && !/\n/.test(u.trim()) && i + 1 < units.length) u += "\n\n" + units[++i];
      out.push(u);
    }
    return out;
  }

  // A single over-long paragraph (a wall of text) is cut at a line break, else a sentence end, else a space.
  function hardSplit(text, limit) {
    const out = [];
    let rest = text.trim();
    while (rest.length > limit * 1.15) {
      const win = rest.slice(0, limit);
      let cut = -1;
      const nl = win.lastIndexOf("\n");
      if (nl > limit * 0.5) cut = nl + 1;
      if (cut < 0) {
        const re = /[.!?]["')\]]?\s/g;
        let m, last = -1;
        while ((m = re.exec(win))) last = m.index + m[0].length;
        if (last > limit * 0.5) cut = last;
      }
      if (cut < 0) { const sp = win.lastIndexOf(" "); cut = sp > limit * 0.5 ? sp + 1 : limit; }
      out.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut).trim();
    }
    if (rest) out.push(rest);
    return out;
  }

  function packUnits(units, limit) {
    const pages = [];
    let cur = "";
    const push = () => { if (cur.trim()) pages.push(cur.trim()); cur = ""; };
    for (const u of units) {
      if (u.length > limit * 1.4 && !/\$\$|\\\[/.test(u)) {
        const parts = hardSplit(u, limit);
        if (parts.length > 1) { push(); parts.forEach((p) => pages.push(p)); continue; }
      }
      if (cur && cur.length + u.length + 2 > limit) push();
      cur = cur ? cur + "\n\n" + u : u;
    }
    push();
    // Don't leave a tiny orphan page at the end.
    if (pages.length > 1) {
      const last = pages[pages.length - 1], prev = pages[pages.length - 2];
      if (last.length < limit * 0.25 && prev.length + last.length + 2 <= limit * 1.3) pages.splice(-2, 2, prev + "\n\n" + last);
    }
    return pages;
  }

  /** Text → array of page strings. */
  function splitPages(text, autoPage, limit) {
    const norm = normalize(text);
    if (!norm.trim()) return [];
    const lim = limit || AUTO_LIMIT;
    const manual = norm.split(PAGE_RE).map((s) => s.trim()).filter(Boolean);
    if (autoPage === false) return manual;
    const out = [];
    manual.forEach((ch) => { if (ch.length > lim) packUnits(toUnits(ch), lim).forEach((p) => out.push(p)); else out.push(ch); });
    return out;
  }

  // ==========================================================================
  // 3. RENDERING ONE PAGE
  // ==========================================================================
  // Web links are lifted OUT of the text before the math renderer sees it — otherwise the "_" in a
  // Drive link (…/d/1AB_C/…) would become a subscript and break the URL — and put back as clickable links.
  const URL_RE = /\bhttps?:\/\/[^\s<>"']+/g;
  function inlineHtml(t, math) {
    const urls = [];
    const guarded = String(t).replace(URL_RE, (m) => {
      const tail = (m.match(/[.,;:!?)\]]+$/) || [""])[0];
      const u = tail ? m.slice(0, m.length - tail.length) : m;
      if (!u) return m;
      urls.push(u);
      return `⟦U${urls.length - 1}⟧${tail}`;
    });
    const html = math && global.MathText ? global.MathText.html(guarded) : `<span class="mt">${esc(guarded)}</span>`;
    return html.replace(/⟦U(\d+)⟧/g, (_, i) => {
      const e = esc(urls[Number(i)]);
      return `<a href="${e}" target="_blank" rel="noopener noreferrer">${e}</a>`;
    });
  }

  function renderPage(text, math) {
    const lines = normalize(text).split("\n");
    const blocks = [];
    let buf = [], open = false;
    const flush = () => {
      const t = buf.join("\n").replace(/^\n+|\n+$/g, "");
      buf = [];
      if (t.trim()) blocks.push(`<div class="tn-block">${inlineHtml(t, math)}</div>`);
    };
    for (const line of lines) {
      if (!open) {
        const m = line.match(HEAD_RE);
        if (m) { flush(); blocks.push(`<div class="tn-h tn-h${m[1].length}">${inlineHtml(m[2], math)}</div>`); continue; }
      }
      buf.push(line);
      if (((line.match(/\$\$/g) || []).length) % 2) open = !open;
      const bo = (line.match(/\\\[/g) || []).length, bc = (line.match(/\\\]/g) || []).length;
      if (bo > bc) open = true; else if (bc > bo) open = false;
    }
    flush();
    return blocks.join("");
  }

  // ==========================================================================
  // 4. THE PAGED READER (student view, and the teacher's preview)
  // ==========================================================================
  const reg = {}; // viewer id → { pages, math, cur, all }

  function pageBodyHtml(id) {
    const r = reg[id];
    if (!r || !r.pages.length) return "";
    if (r.all) return r.pages.map((p, i) => `<div class="tn-pagesep">Page ${i + 1} of ${r.pages.length}</div>${renderPage(p, r.math)}`).join("");
    return renderPage(r.pages[r.cur], r.math);
  }

  function pagerHtml(id, pos) {
    const r = reg[id];
    if (!r || r.pages.length <= 1) return "";
    const n = r.pages.length;
    const pct = r.all ? 100 : Math.round(((r.cur + 1) / n) * 100);
    const opts = r.pages.map((_, i) => `<option value="${i}" ${i === r.cur ? "selected" : ""}>${i + 1}</option>`).join("");
    return `<div class="tn-pager" data-tn="${id}" data-pos="${pos || "top"}">
      <button type="button" class="btn-outline btn-sm" onclick="TN.go('${id}',-1)" ${r.all || r.cur <= 0 ? "disabled" : ""}>◀ Prev</button>
      <span class="tn-pager-mid">${r.all ? `All ${n} pages` : `Page <select aria-label="Jump to page" onchange="TN.jump('${id}',this.value)">${opts}</select> of ${n}`}</span>
      <button type="button" class="btn-outline btn-sm" onclick="TN.go('${id}',1)" ${r.all || r.cur >= n - 1 ? "disabled" : ""}>Next ▶</button>
      <button type="button" class="tn-toggle" onclick="TN.toggleAll('${id}')">${r.all ? "One page at a time" : "Show all pages"}</button>
      <div class="tn-progress"><i style="width:${pct}%"></i></div>
    </div>`;
  }

  /**
   * Full reader markup. opts: { text, url, math, auto, compact, startPage, label }
   * Text pages first, then the attached Drive/Docs file (if any).
   */
  function viewerHtml(rawId, opts) {
    const id = sid(rawId);
    const o = opts || {};
    const pages = splitPages(o.text, o.auto !== false);
    reg[id] = { pages, math: o.math !== false, cur: Math.max(0, Math.min(o.startPage || 0, Math.max(pages.length - 1, 0))), all: false };
    const body = pages.length
      ? `${pagerHtml(id, "top")}<div class="tn-page" id="tnp_${id}">${pageBodyHtml(id)}</div>${pagerHtml(id, "bottom")}`
      : "";
    const attach = o.url ? attachmentHtml(o.url, { compact: o.compact, label: o.label }) : "";
    return `<div class="tn-viewer" id="tnv_${id}">${body}${attach}</div>`;
  }

  function refresh(id, scroll) {
    const r = reg[id];
    const pg = $("tnp_" + id);
    if (!r || !pg) return;
    pg.innerHTML = pageBodyHtml(id);
    document.querySelectorAll(`.tn-pager[data-tn="${id}"]`).forEach((el) => { el.outerHTML = pagerHtml(id, el.dataset.pos); });
    if (scroll) {
      const v = $("tnv_" + id);
      if (v && v.getBoundingClientRect().top < 0) v.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }
  function go(id, d) { const r = reg[id]; if (!r) return; r.cur = Math.max(0, Math.min(r.pages.length - 1, r.cur + d)); refresh(id, true); }
  function jump(id, n) { const r = reg[id]; if (!r) return; r.cur = Math.max(0, Math.min(r.pages.length - 1, Number(n) || 0)); refresh(id, true); }
  function toggleAll(id) { const r = reg[id]; if (!r) return; r.all = !r.all; refresh(id, true); }

  // ==========================================================================
  // 5. TEACHER EDITOR PIECES (shared by Teaching Notes, 2-min recap)
  // ==========================================================================
  function linkChipHtml(url) {
    const info = driveInfo(url);
    if (!info) return `<span class="muted">Optional — paste a share link from Google Drive, Docs, Slides or Sheets.</span>`;
    if (info.kind === "invalid") return `<span class="tn-chip warn">⚠️ That doesn't look like a web link — it should start with https://</span>`;
    if (info.embedUrl) return `<span class="tn-chip ok">✅ ${info.icon} ${esc(info.label)} — students can read it inside the app.</span>`;
    return `<span class="tn-chip">🔗 Students will get an “Open link” button (this site can't be shown inside the app).</span>`;
  }

  /** Text box + symbol palette + page-break/equation helpers + live preview + Drive link. p = id prefix. */
  function editorFieldsHtml(p, v, o) {
    const opt = o || {};
    const val = v || {};
    return `
      <div class="field">
        <label>${opt.textLabel || "Notes"} <span class="muted">(paste here — long text is fine)</span></label>
        <textarea id="${p}_text" data-mt="1" class="tn-textarea" rows="${opt.rows || 10}" placeholder="${esc(opt.placeholder || "Paste or type your notes. Use ---page--- on its own line to start a new page, and $$ … $$ around a big equation.")}">${esc(val.text || "")}</textarea>
        <div class="tn-editor-tools">
          <button type="button" class="btn-outline btn-sm" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" onclick="TN.insertBreak('${p}_text')">➕ Page break</button>
          <button type="button" class="btn-outline btn-sm" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" onclick="TN.insertEquation('${p}_text')">$$ Equation line</button>
          <span class="muted" id="${p}_stats" style="font-size:.78rem;"></span>
        </div>
      </div>
      ${global.MathText ? global.MathText.paletteHtml(`${p}_pal`, `${p}_text`) : ""}
      <details class="tn-tips"><summary>Formatting tips</summary>
        <ul>
          <li><code>---page---</code> on its own line starts a new page. Very long text is also split automatically (never inside an equation).</li>
          <li><code>$$ x^2 + 5x + 6 = 0 $$</code> shows an equation on its own centred line (it may span several lines).</li>
          <li><code># Heading</code>, <code>## Sub-heading</code>, <code>### Small heading</code> make headings.</li>
          <li>Symbols you paste (∠ △ ≤ ≥ π √ ² ½ …) are kept as-is. Web links become clickable.</li>
        </ul>
      </details>
      <div class="mt-preview"><div class="mt-preview-label">👁️ What students will see</div><div id="${p}_preview" class="tn-preview-scroll"></div></div>
      <div class="field">
        <label>📎 Google Drive link <span class="muted">(optional${opt.linkOnlyOk ? "" : ", can be used instead of or together with the text"})</span></label>
        <input id="${p}_url" placeholder="https://drive.google.com/file/d/…  or a Docs / Slides / Sheets link" value="${esc(val.url || "")}" autocomplete="off">
        <div id="${p}_urlchip" class="tn-chipbox"></div>
        <div class="tn-hint">In Google Drive: <strong>Share → General access → “Anyone with the link” → Viewer</strong>. If it stays private, students will see a sign-in page instead of your file.</div>
      </div>`;
  }

  const readVal = (id) => { const el = $(id); return el ? el.value : ""; };
  const readChk = (id, def) => { const el = $(id); return el ? el.checked : def; };

  function updateEditor(p) {
    const box = $(`${p}_preview`);
    if (!box) return;
    const text = readVal(`${p}_text`);
    const pid = `prev_${p}`;
    const old = reg[pid];
    box.innerHTML = text.trim()
      ? viewerHtml(pid, { text, math: readChk(`${p}_math`, true), auto: readChk(`${p}_auto`, true), startPage: old ? old.cur : 0 })
      : `<span class="muted">Start typing or pasting above…</span>`;
    const stats = $(`${p}_stats`);
    if (stats) {
      const n = (reg[pid] && reg[pid].pages.length) || 0;
      stats.textContent = text.trim() ? `${text.length.toLocaleString()} characters · ${n} page${n === 1 ? "" : "s"}` : "";
    }
    const chip = $(`${p}_urlchip`);
    if (chip) chip.innerHTML = linkChipHtml(readVal(`${p}_url`));
  }

  function bindEditor(p) {
    let t = null;
    const sched = () => { clearTimeout(t); t = setTimeout(() => updateEditor(p), 120); };
    [`${p}_text`, `${p}_url`].forEach((id) => { const el = $(id); if (el) el.addEventListener("input", sched); });
    [`${p}_math`, `${p}_auto`].forEach((id) => { const el = $(id); if (el) el.addEventListener("change", () => updateEditor(p)); });
    updateEditor(p);
  }

  function insertInto(fieldId, text, selStart, selEnd) {
    const el = $(fieldId);
    if (!el) return;
    if (global.MathText && global.MathText.insertAt) return global.MathText.insertAt(el, text, selStart, selEnd);
    el.value += text;
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  const insertBreak = (fieldId) => insertInto(fieldId, "\n\n---page---\n\n");
  const insertEquation = (fieldId) => insertInto(fieldId, "\n$$ x^2 + 5x + 6 = 0 $$\n", 4, 22);

  function widenModal() {
    const m = document.querySelector("#modalRoot .modal");
    if (m) { m.style.maxWidth = "800px"; m.classList.add("tn-modal"); }
  }

  function dbMsg(error) {
    const m = (error && error.message) || String(error);
    if (/teaching_notes|link_url|material_url|schema cache|does not exist|column/i.test(m)) {
      return "Setup needed: run migration-65-teaching-notes-and-recap-links.sql in Supabase → SQL Editor, then try again. (" + m + ")";
    }
    return "Error: " + m;
  }

  // ==========================================================================
  // 6. TEACHER — Blended Learning → Teaching Notes
  // ==========================================================================
  const tNotes = {}; // id → row

  async function renderTeacherNotes() {
    const box = $("blContent");
    if (!box) return;
    if (!state.term) { box.innerHTML = `<p class="muted">Set up a term first.</p>`; return; }
    box.innerHTML = `<p class="muted">Loading…</p>`;
    const { data, error } = await supabase.from("teaching_notes").select("*").eq("term_id", state.term.id)
      .order("week_number", { ascending: false }).order("created_at", { ascending: false });
    if (error) {
      box.innerHTML = `<div class="card" style="border-left:4px solid var(--clay);"><strong>One-time setup needed</strong>
        <p class="muted">Run <code>migration-65-teaching-notes-and-recap-links.sql</code> in Supabase → SQL Editor, then reload this page.</p>
        <p class="muted" style="font-size:.78rem;">${esc(error.message)}</p></div>`;
      return;
    }
    (data || []).forEach((n) => (tNotes[n.id] = n));
    box.innerHTML = `
      <p class="muted" style="margin-top:0;">Post your lesson notes for students. <strong>Paste text</strong> (long notes are split into pages, and math like <code>x^2</code>, <code>sqrt(x)</code>, <code>1/2</code>, <code>$$…$$</code> shows as proper notation), <strong>attach a Google Drive link</strong>, or both. Students read it right inside the app.</p>
      <div style="text-align:right;"><button class="btn-gold btn-sm" onclick="TN.openNoteEditor()">+ Add Teaching Notes</button></div>
      ${(data || []).length === 0 ? `<p class="muted">No teaching notes posted yet.</p>` : data.map((n) => {
        const pages = splitPages(n.note_text, n.auto_page !== false).length;
        const info = driveInfo(n.drive_url);
        return `
        <div class="card" style="margin-top:12px;">
          <div class="muted">Week ${n.week_number || "—"}
            ${pages ? ` · <span class="badge badge-ww">${pages} page${pages === 1 ? "" : "s"}</span>` : ""}
            ${info && info.kind !== "invalid" ? ` · <span class="badge badge-pt">${info.icon} ${esc(info.label)}</span>` : ""}
          </div>
          <strong>${esc(n.title)}</strong>
          ${n.description ? `<p class="muted">${esc(n.description)}</p>` : ""}
          <details style="margin-top:8px;" ontoggle="if(this.open) TN.mountTeacherPreview('${sid(n.id)}')">
            <summary class="muted" style="cursor:pointer;">👁️ Preview as students see it</summary>
            <div id="tnprev_${sid(n.id)}" style="margin-top:8px;"></div>
          </details>
          <div style="display:flex;gap:8px;margin-top:10px;">
            <button class="btn-outline btn-sm" onclick="TN.openNoteEditor('${sid(n.id)}')">Edit</button>
            <button class="btn-outline btn-sm" onclick="TN.deleteNote('${sid(n.id)}')">Delete</button>
          </div>
        </div>`;
      }).join("")}`;
  }

  function mountTeacherPreview(id) {
    const mount = $("tnprev_" + id);
    const n = tNotes[id];
    if (!mount || !n || mount.dataset.loaded === "1") return;
    mount.dataset.loaded = "1";
    mount.innerHTML = viewerHtml("tp_" + id, { text: n.note_text, url: n.drive_url, math: n.render_math !== false, auto: n.auto_page !== false });
  }

  function openNoteEditor(id) {
    const n = id ? tNotes[id] : null;
    const nextWeek = Object.values(tNotes).reduce((m, x) => Math.max(m, x.week_number || 0), 0) + 1;
    showModal(`
      <h3>${n ? "Edit" : "Add"} Teaching Notes</h3>
      <div class="field-row">
        <div class="field" style="max-width:110px;"><label>Week</label><input type="number" id="tn_week" min="1" value="${n ? n.week_number || 1 : nextWeek}"></div>
        <div class="field"><label>Title</label><input id="tn_title" placeholder="e.g. Week 3 Notes: Factoring Trinomials" value="${esc(n ? n.title : "")}"></div>
      </div>
      <div class="field"><label>Short description <span class="muted">(optional)</span></label><input id="tn_desc" placeholder="e.g. Read pages 1–3 before the online session" value="${esc(n ? n.description || "" : "")}"></div>
      ${editorFieldsHtml("tn", { text: n ? n.note_text : "", url: n ? n.drive_url : "" }, { textLabel: "Notes", rows: 12 })}
      <div class="field" style="display:flex;gap:18px;flex-wrap:wrap;">
        <label style="display:flex;align-items:center;gap:6px;font-weight:400;cursor:pointer;"><input type="checkbox" id="tn_math" style="width:auto;" ${!n || n.render_math !== false ? "checked" : ""}> Show math notation (x^2, 1/2, sqrt, $$…$$)</label>
        <label style="display:flex;align-items:center;gap:6px;font-weight:400;cursor:pointer;"><input type="checkbox" id="tn_auto" style="width:auto;" ${!n || n.auto_page !== false ? "checked" : ""}> Split very long text into pages automatically</label>
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:10px;">
        <button class="btn-outline" onclick="closeModal()">Cancel</button>
        <button class="btn-primary" onclick="TN.saveNote(${n ? `'${sid(n.id)}'` : "null"})">${n ? "Save Changes" : "Post Notes"}</button>
      </div>`);
    widenModal();
    bindEditor("tn");
  }

  async function saveNote(id) {
    const title = readVal("tn_title").trim();
    const text = normalize(readVal("tn_text")).trim();
    const url = readVal("tn_url").trim();
    if (!title) { toast("Enter a title."); return; }
    if (!text && !url) { toast("Paste some notes or attach a Google Drive link."); return; }
    if (url) { const info = driveInfo(url); if (!info || info.kind === "invalid") { toast("That link doesn't look right — it should start with https://"); return; } }
    const row = {
      week_number: Number(readVal("tn_week")) || 1,
      title,
      description: readVal("tn_desc").trim() || null,
      note_text: text || null,
      drive_url: url || null,
      render_math: readChk("tn_math", true),
      auto_page: readChk("tn_auto", true),
      updated_at: new Date().toISOString(),
    };
    let error;
    if (id) ({ error } = await supabase.from("teaching_notes").update(row).eq("id", id));
    else ({ error } = await supabase.from("teaching_notes").insert(Object.assign({ section_id: state.section.id, term_id: state.term.id }, row)));
    if (error) { toast(dbMsg(error)); return; }
    closeModal();
    toast(id ? "Teaching notes updated." : "Teaching notes posted — students can read them now.");
    renderTeacherNotes();
  }

  async function deleteNote(id) {
    if (!confirm("Delete these teaching notes? Students will no longer see them.")) return;
    const { error } = await supabase.from("teaching_notes").delete().eq("id", id);
    if (error) { toast(dbMsg(error)); return; }
    delete tNotes[id];
    toast("Deleted.");
    renderTeacherNotes();
  }

  // ==========================================================================
  // 7. TEACHER — Weekly Check-In: 2-min recap (reteach note) + lesson link
  // ==========================================================================
  async function openRecapEditor(lessonId) {
    const [{ data: lesson }, { data: rt }] = await Promise.all([
      supabase.from("lessons").select("id, title, week_number").eq("id", lessonId).maybeSingle(),
      supabase.from("reteach_notes").select("*").eq("lesson_id", lessonId).maybeSingle(),
    ]);
    showModal(`
      <h3>🔁 2-min Recap${lesson ? ` <span class="muted" style="font-size:.85rem;font-weight:400;">· Week ${lesson.week_number} · ${esc(lesson.title)}</span>` : ""}</h3>
      <p class="muted" style="margin-top:-4px;">A short re-teach for students who found this week tricky. Type or paste it, attach a Google Drive link (a Slides recap, a worked-solution PDF…), or both.</p>
      <div class="field"><label>Title</label><input id="rc_title" placeholder="e.g. Quick Recap: Factoring Trinomials" value="${esc(rt ? rt.title : "")}"></div>
      ${editorFieldsHtml("rc", { text: rt ? rt.content : "", url: rt ? rt.link_url : "" }, { textLabel: "Recap", rows: 7, linkOnlyOk: true, placeholder: "Type or paste the recap. Math like x^2, sqrt(x+1), 1/2 and $$ … $$ shows as proper notation." })}
      <div style="display:flex;gap:10px;justify-content:space-between;align-items:center;margin-top:10px;flex-wrap:wrap;">
        <div>${rt ? `<button class="btn-outline btn-sm" onclick="TN.removeRecap('${sid(lessonId)}')">Remove recap</button>` : ""}</div>
        <div style="display:flex;gap:10px;">
          <button class="btn-outline" onclick="closeModal()">Cancel</button>
          <button class="btn-primary" onclick="TN.saveRecap('${sid(lessonId)}')">${rt ? "Update Recap" : "Post Recap"}</button>
        </div>
      </div>`);
    widenModal();
    bindEditor("rc");
  }

  async function saveRecap(lessonId) {
    const title = readVal("rc_title").trim();
    const text = normalize(readVal("rc_text")).trim();
    const url = readVal("rc_url").trim();
    if (!title) { toast("Add a title for the recap."); return; }
    if (!text && !url) { toast("Write the recap or attach a Google Drive link."); return; }
    if (url) { const info = driveInfo(url); if (!info || info.kind === "invalid") { toast("That link doesn't look right — it should start with https://"); return; } }
    const { error } = await supabase.from("reteach_notes").upsert(
      { lesson_id: lessonId, section_id: state.section.id, title, content: text, link_url: url || null, updated_at: new Date().toISOString() },
      { onConflict: "lesson_id" }
    );
    if (error) { toast(dbMsg(error)); return; }
    closeModal();
    toast("2-min recap posted! Students will see it on their This Week tab.");
    if (typeof renderLessons === "function") renderLessons();
  }

  async function removeRecap(lessonId) {
    if (!confirm("Remove this recap? Students will no longer see it.")) return;
    const { error } = await supabase.from("reteach_notes").delete().eq("lesson_id", lessonId);
    if (error) { toast(dbMsg(error)); return; }
    closeModal();
    toast("Recap removed.");
    if (typeof renderLessons === "function") renderLessons();
  }

  async function saveLessonLink(lessonId) {
    const el = $(`lm_${lessonId}`);
    const url = el ? el.value.trim() : "";
    if (url) { const info = driveInfo(url); if (!info || info.kind === "invalid") { toast("That link doesn't look right — it should start with https://"); return; } }
    const { error } = await supabase.from("lessons").update({ material_url: url || null }).eq("id", lessonId);
    if (error) { toast(dbMsg(error)); return; }
    toast(url ? "Lesson link saved — students can open it from their This Week tab." : "Lesson link removed.");
    if (typeof renderLessons === "function") renderLessons();
  }

  /** Small "📎 Google Slides" badge for a card summary; empty string when there is no usable link. */
  function linkBadge(url) {
    const info = driveInfo(url);
    return info && info.kind !== "invalid" ? `<span class="badge badge-pt">${info.icon} ${esc(info.label)}</span>` : "";
  }

  function lessonLinkChip(inputId, chipId) {
    const c = $(chipId);
    if (c) c.innerHTML = linkChipHtml(readVal(inputId));
  }

  // ==========================================================================
  // 8. STUDENT — Blended Learning → Teaching Notes
  // ==========================================================================
  const sNotes = {};

  async function renderStudentNotes(mount, ctx) {
    mount.innerHTML = `<p class="muted">Loading teaching notes…</p>`;
    const { data, error } = await supabase.from("teaching_notes").select("*").in("term_id", ctx.termIds)
      .order("week_number", { ascending: false }).order("created_at", { ascending: false });
    if (error || !data || data.length === 0) {
      mount.innerHTML = `<div class="card"><h3 style="margin-top:0;">🗒️ Teaching Notes</h3><p class="muted">No teaching notes posted yet. Check back after your teacher shares this week's notes.</p></div>`;
      return;
    }
    data.forEach((n) => (sNotes[sid(n.id)] = n));
    mount.innerHTML = `
      <p class="muted" style="margin-top:0;">Notes from your teacher. Use <strong>Next ▶</strong> to move through the pages — or “Show all pages” to scroll through everything at once.</p>
      ${data.map((n, i) => {
        const pages = splitPages(n.note_text, n.auto_page !== false).length;
        const info = driveInfo(n.drive_url);
        const other = n.section_id !== ctx.sectionId && ctx.sectionNameById ? ctx.sectionNameById[n.section_id] : null;
        return `
        <details class="card tn-note" ${i === 0 ? "open" : ""} ontoggle="if(this.open) TN.mountStudentNote('${sid(n.id)}')">
          <summary>
            <span class="tn-note-title"><span class="muted">Week ${n.week_number || "—"}</span> <strong>${esc(n.title)}</strong></span>
            <span class="tn-note-chips">
              ${pages ? `<span class="badge badge-ww">${pages} page${pages === 1 ? "" : "s"}</span>` : ""}
              ${info && info.kind !== "invalid" ? `<span class="badge badge-pt">${info.icon} ${esc(info.label)}</span>` : ""}
              ${other ? `<span class="badge badge-pt">Posted for ${esc(other)}</span>` : ""}
            </span>
          </summary>
          ${n.description ? `<p class="muted" style="margin:8px 0 0;">${esc(n.description)}</p>` : ""}
          <div id="tnsn_${sid(n.id)}" class="tn-note-body"></div>
        </details>`;
      }).join("")}`;
    mountStudentNote(sid(data[0].id));
  }

  function mountStudentNote(id) {
    const mount = $("tnsn_" + id);
    const n = sNotes[id];
    if (!mount || !n || mount.dataset.loaded === "1") return;
    mount.dataset.loaded = "1";
    mount.innerHTML = viewerHtml("sn_" + id, { text: n.note_text, url: n.drive_url, math: n.render_math !== false, auto: n.auto_page !== false });
  }

  function studentTabsHtml(active) {
    return `<div class="tabs" style="margin-bottom:16px;">
      <div class="tab ${active !== "notes" ? "active" : ""}" onclick="sstate.blTab='las';renderStudentBlended();">📄 LAS &amp; Schedule</div>
      <div class="tab ${active === "notes" ? "active" : ""}" onclick="sstate.blTab='notes';renderStudentBlended();">🗒️ Teaching Notes</div>
    </div>`;
  }

  // Math-aware inline text (lesson objectives, comments…) — escaped, never raw HTML.
  function mathHtml(t) {
    return t === null || t === undefined || t === "" ? "" : inlineHtml(t, true);
  }

  global.TN = {
    // links
    driveInfo, attachmentHtml, linkChipHtml, linkBadge,
    // paging + rendering
    splitPages, renderPage, viewerHtml, mathHtml, go, jump, toggleAll,
    // editor helpers
    editorFieldsHtml, bindEditor, updateEditor, insertBreak, insertEquation, lessonLinkChip,
    // teacher
    renderTeacherNotes, mountTeacherPreview, openNoteEditor, saveNote, deleteNote,
    openRecapEditor, saveRecap, removeRecap, saveLessonLink,
    // student
    renderStudentNotes, mountStudentNote, studentTabsHtml,
  };
})(typeof window !== "undefined" ? window : globalThis);
