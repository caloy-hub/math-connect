-- ============================================================================
-- MathConnect — migration 44: Cooperative Champion Criteria
-- Revises two systems from migration-24 that currently reward beating
-- classmates rather than working with them:
--
--   1. The Archimedes Trial's 6th requirement, "Grade Dominance" (beat at
--      least half the grade level in Boss Battles), is REPLACED with
--      "Class Quest Contributor" (helped your class complete at least one
--      shared Class Quest — see migration-43). Same slot in the checklist,
--      same all-6-required gate, different spirit: helping your class win
--      something together instead of outscoring half of them 1-on-1.
--
--   2. championship_score()'s Boss Battles component drops its "coverage"
--      sub-score (how many distinct classmates you've beaten) and keeps
--      only win rate. The weight freed up funds a brand-new Cooperation
--      component scored on Class Quest contributions. New weights:
--        Rank Progress 25% (was 30%) · Drill Mastery 20% (unchanged)
--        Quest Mode 10% (was 15%) · Cooperation 15% (NEW)
--        Boss Battles 10% (was 15%, win-rate only) · Intelligent Practice 10%
--        Consistency 10% (unchanged)
--
-- Run this once in Supabase Dashboard → SQL Editor, AFTER migration-24 and
-- migration-43-motivation-cooperation.sql have already been applied (this
-- reads class_quests / class_quest_contributions from migration-43).
--
-- NOTE for teachers: because "Class Quest Contributor" now gates the Trial,
-- a class that has never had a Class Quest running makes this requirement
-- permanently unreachable for its students — same dependency shape as the
-- Trial's other requirements (e.g. Quest Mode chapters, unlocked stations),
-- but worth knowing: keep at least one Class Quest active per section.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. eureka_trial_status — swap "grade_dominance" for "class_quest_contributor"
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.eureka_trial_status(target_student_id UUID)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER STABLE AS $$
DECLARE
  dp drill_progress%ROWTYPE;
  eng student_engagement%ROWTYPE;
  les learning_engine_state%ROWTYPE;
  qp quest_progress%ROWTYPE;
  domain_total INT := 0; domain_pass INT := 0;
  station_total INT := 0; station_attempted INT := 0; station_maxed INT := 0;
  chapter_total INT := 0; chapter_cleared INT := 0;
  r RECORD;
  distinct_completed_quests INT := 0;
  result JSONB;
BEGIN
  SELECT * INTO dp FROM drill_progress WHERE student_id = target_student_id;
  SELECT * INTO eng FROM student_engagement WHERE student_id = target_student_id;
  SELECT * INTO les FROM learning_engine_state WHERE student_id = target_student_id;
  SELECT * INTO qp FROM quest_progress WHERE student_id = target_student_id;

  FOR r IN SELECT domain_key FROM practice_domains WHERE active LOOP
    domain_total := domain_total + 1;
    IF les.id IS NOT NULL
       AND COALESCE((les.adaptive_levels ->> r.domain_key)::INT, 0) = 4
       AND COALESCE((les.skill_proficiency ->> r.domain_key)::INT, 0) = 100
    THEN domain_pass := domain_pass + 1; END IF;
  END LOOP;

  FOR r IN SELECT station_key FROM drill_station_locks WHERE NOT locked LOOP
    station_total := station_total + 1;
    IF EXISTS (SELECT 1 FROM drill_attempts WHERE student_id = target_student_id AND topic = r.station_key) THEN
      station_attempted := station_attempted + 1;
    END IF;
    IF dp.id IS NOT NULL AND COALESCE((dp.topic_levels ->> r.station_key)::INT, 1) = 15 THEN
      station_maxed := station_maxed + 1;
    END IF;
  END LOOP;

  FOR r IN SELECT chapter_key FROM quest_chapters_registry WHERE active LOOP
    chapter_total := chapter_total + 1;
    IF qp.id IS NOT NULL AND jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       AND jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       AND NOT EXISTS (
         SELECT 1 FROM jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e
         WHERE e::INT < 1
       )
    THEN chapter_cleared := chapter_cleared + 1; END IF;
  END LOOP;

  -- NEW: distinct Class Quests (migration-43) this student contributed to
  -- that went on to reach their shared goal — cooperation, not dominance.
  SELECT COUNT(DISTINCT c.quest_id) INTO distinct_completed_quests
  FROM class_quest_contributions c
  JOIN class_quests q ON q.id = c.quest_id
  WHERE c.student_id = target_student_id AND q.completed_at IS NOT NULL;

  result := jsonb_build_object(
    'practice_expert', jsonb_build_object('passed', domain_pass = domain_total AND domain_total > 0, 'progress', domain_pass, 'needed', domain_total),
    'all_stations_attempted', jsonb_build_object('passed', station_attempted = station_total AND station_total > 0, 'progress', station_attempted, 'needed', station_total),
    'all_stations_level15', jsonb_build_object('passed', station_maxed = station_total AND station_total > 0, 'progress', station_maxed, 'needed', station_total),
    'quest_half_cleared', jsonb_build_object('passed', chapter_cleared > (chapter_total / 2.0), 'progress', chapter_cleared, 'needed', floor(chapter_total / 2.0) + 1),
    'attendance_streak_30', jsonb_build_object('passed', COALESCE(eng.current_streak, 0) >= 30 AND COALESCE(eng.streak_off, false) = false, 'progress', COALESCE(eng.current_streak, 0), 'needed', 30),
    'class_quest_contributor', jsonb_build_object('passed', distinct_completed_quests >= 1, 'progress', LEAST(distinct_completed_quests, 1), 'needed', 1)
  );

  result := result || jsonb_build_object('overall_cleared',
    (result -> 'practice_expert' ->> 'passed')::BOOLEAN
    AND (result -> 'all_stations_attempted' ->> 'passed')::BOOLEAN
    AND (result -> 'all_stations_level15' ->> 'passed')::BOOLEAN
    AND (result -> 'quest_half_cleared' ->> 'passed')::BOOLEAN
    AND (result -> 'attendance_streak_30' ->> 'passed')::BOOLEAN
    AND (result -> 'class_quest_contributor' ->> 'passed')::BOOLEAN
  );
  RETURN result;
END;
$$;
GRANT EXECUTE ON FUNCTION public.eureka_trial_status(UUID) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- 2. championship_score — new weights, new Cooperation component, Boss
--    Battles now win-rate only (no "coverage"/dominance sub-score).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.championship_score(target_student_id UUID)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER STABLE AS $$
DECLARE
  dp drill_progress%ROWTYPE; eng student_engagement%ROWTYPE;
  les learning_engine_state%ROWTYPE; qp quest_progress%ROWTYPE;
  eligible BOOLEAN := false;
  gem_score NUMERIC := 0; trial_score NUMERIC := 0; rank_progress NUMERIC := 0;
  avg_level NUMERIC := 0; accuracy NUMERIC := 0; drill_score NUMERIC := 0;
  chapter_total INT := 0; chapter_cleared INT := 0; quest_score NUMERIC := 0;
  max_stars INT := 0;
  capped_wins INT := 0; capped_games INT := 0; win_rate NUMERIC := 0; battle_score NUMERIC := 0;
  domain_total INT := 0; domain_sum NUMERIC := 0; practice_score NUMERIC := 0;
  streak_score NUMERIC := 0; daily_count INT := 0; daily_score NUMERIC := 0; consistency_score NUMERIC := 0;
  cq_contrib_total INT := 0; cq_distinct_completed INT := 0; cooperation_score NUMERIC := 0;
  total NUMERIC := 0;
  station_count INT := 0;
  r RECORD;
  gem_index INT := 0;
BEGIN
  SELECT * INTO dp FROM drill_progress WHERE student_id = target_student_id;
  SELECT * INTO eng FROM student_engagement WHERE student_id = target_student_id;
  SELECT * INTO les FROM learning_engine_state WHERE student_id = target_student_id;
  SELECT * INTO qp FROM quest_progress WHERE student_id = target_student_id;

  eligible := dp.id IS NOT NULL AND dp.mastery_tier = 15;

  -- ---- 1. Rank Progress (25%) ----
  IF dp.post_eureka_stars >= 125 THEN gem_index := 9 + floor((dp.post_eureka_stars - 125) / 30.0);
  ELSIF dp.post_eureka_stars >= 95 THEN gem_index := 8;
  ELSIF dp.post_eureka_stars >= 70 THEN gem_index := 7;
  ELSIF dp.post_eureka_stars >= 50 THEN gem_index := 6;
  ELSIF dp.post_eureka_stars >= 35 THEN gem_index := 5;
  ELSIF dp.post_eureka_stars >= 25 THEN gem_index := 4;
  ELSIF dp.post_eureka_stars >= 15 THEN gem_index := 3;
  ELSIF dp.post_eureka_stars >= 10 THEN gem_index := 2;
  ELSIF dp.post_eureka_stars >= 5 THEN gem_index := 1;
  ELSE gem_index := 0; END IF;
  gem_score := LEAST(gem_index / 14.0 * 60, 60);
  trial_score := LEAST(COALESCE(dp.trial_clears_count, 0), 2) * 20;
  rank_progress := gem_score + trial_score;

  -- ---- 2. Drill Mastery (20%) ----
  SELECT COUNT(*) INTO station_count FROM drill_station_locks WHERE NOT locked;
  IF dp.id IS NOT NULL AND station_count > 0 THEN
    SELECT avg((dp.topic_levels ->> sl.station_key)::INT) INTO avg_level
    FROM (SELECT station_key FROM drill_station_locks WHERE NOT locked) sl;
    avg_level := COALESCE(avg_level, 1);
  END IF;
  SELECT CASE WHEN COALESCE(sum(total_questions), 0) = 0 THEN 0
    ELSE sum(correct_count)::NUMERIC / sum(total_questions) * 100 END
  INTO accuracy FROM drill_attempts WHERE student_id = target_student_id;
  drill_score := (COALESCE(avg_level, 1) / 15.0 * 100) * 0.5 + COALESCE(accuracy, 0) * 0.5;

  -- ---- 3. Quest Mode (10%) ----
  FOR r IN SELECT chapter_key FROM quest_chapters_registry WHERE active LOOP
    chapter_total := chapter_total + 1;
    IF qp.id IS NOT NULL AND jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       AND jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e WHERE e::INT < 1)
    THEN chapter_cleared := chapter_cleared + 1; END IF;
  END LOOP;
  max_stars := chapter_total * 10 * 3;
  quest_score := CASE WHEN chapter_total = 0 THEN 0 ELSE (chapter_cleared::NUMERIC / chapter_total * 100) * 0.5 END
    + CASE WHEN max_stars = 0 THEN 0 ELSE (COALESCE(qp.total_stars, 0)::NUMERIC / max_stars * 100) * 0.5 END;

  -- ---- 4. Cooperation (15%, NEW) — Class Quest contributions. Half from
  -- cumulative volume contributed (capped at 300 pts), half from how many
  -- DIFFERENT Class Quests that contribution helped push over the goal
  -- line (capped at 3) — rewards showing up for the team repeatedly, not
  -- just once.
  SELECT COALESCE(SUM(c.points_contributed), 0) INTO cq_contrib_total
  FROM class_quest_contributions c WHERE c.student_id = target_student_id;
  SELECT COUNT(DISTINCT c.quest_id) INTO cq_distinct_completed
  FROM class_quest_contributions c JOIN class_quests q ON q.id = c.quest_id
  WHERE c.student_id = target_student_id AND q.completed_at IS NOT NULL;
  cooperation_score := LEAST(cq_contrib_total / 300.0, 1) * 100 * 0.5
    + LEAST(cq_distinct_completed / 3.0, 1) * 100 * 0.5;

  -- ---- 5. Boss Battles (10%, win-rate only — no more "beat N classmates") ----
  SELECT COALESCE(sum(LEAST(w, 3)), 0), COALESCE(sum(LEAST(g, 3)), 0) INTO capped_wins, capped_games
  FROM (
    SELECT CASE WHEN student_a_id = target_student_id THEN student_b_id ELSE student_a_id END AS opp,
      count(*) FILTER (WHERE winner_id = target_student_id) AS w,
      count(*) AS g
    FROM battles
    WHERE status = 'completed' AND (student_a_id = target_student_id OR student_b_id = target_student_id)
    GROUP BY 1
  ) x;
  win_rate := CASE WHEN capped_games = 0 THEN 0 ELSE capped_wins::NUMERIC / capped_games * 100 END;
  battle_score := win_rate;

  -- ---- 6. Intelligent Practice (10%) ----
  FOR r IN SELECT domain_key FROM practice_domains WHERE active LOOP
    domain_total := domain_total + 1;
    domain_sum := domain_sum + COALESCE((les.skill_proficiency ->> r.domain_key)::INT, 0);
  END LOOP;
  practice_score := CASE WHEN domain_total = 0 THEN 0 ELSE domain_sum / domain_total END;

  -- ---- 7. Consistency (10%) ----
  streak_score := LEAST(COALESCE(eng.current_streak, 0), 60) / 60.0 * 100;
  SELECT COUNT(*) INTO daily_count FROM daily_challenge_completions WHERE student_id = target_student_id;
  daily_score := LEAST(daily_count, 60) / 60.0 * 100;
  consistency_score := streak_score * 0.5 + daily_score * 0.5;

  total := rank_progress * 0.25 + drill_score * 0.20 + quest_score * 0.10 + cooperation_score * 0.15
    + battle_score * 0.10 + practice_score * 0.10 + consistency_score * 0.10;

  RETURN jsonb_build_object(
    'eligible', eligible,
    'total', round(total, 2),
    'breakdown', jsonb_build_object(
      'rank_progress', round(rank_progress, 2),
      'drill_mastery', round(drill_score, 2),
      'quest_mode', round(quest_score, 2),
      'cooperation', round(cooperation_score, 2),
      'boss_battles', round(battle_score, 2),
      'intelligent_practice', round(practice_score, 2),
      'consistency', round(consistency_score, 2)
    )
  );
END;
$$;
GRANT EXECUTE ON FUNCTION public.championship_score(UUID) TO anon, authenticated;

-- grade_champion_standings() and finalize_school_year() need NO changes —
-- both call championship_score() internally and automatically pick up the
-- new formula.

-- ============================================================================
-- Done. Sanity check:
-- select championship_score(id) from students limit 1;
-- select eureka_trial_status(id) from students limit 1;
-- ============================================================================
