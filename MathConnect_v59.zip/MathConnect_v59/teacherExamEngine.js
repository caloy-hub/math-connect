// ============================================================================
// MathConnect — Teacher Exam Manager (Exam Feature, Core)
// Loaded AFTER teacher.js (reuses `state`, `supabase`, `escapeHtml`, `toast`,
// `showModal`, `closeModal`). Add "exams" to the tab dispatch table in
// teacher.js's renderCurrentTab(), and add a matching tab button + panel
// in teacher.html — see DEPLOY_NOTES.md.
// ============================================================================

// v53 — teacher-typed math (x^2, sqrt(x), <=, 1/2, pi …) is rendered as real
// notation via mathText.js, so what teachers review here matches what
// students see. Falls back to plain escaped text if that file is missing.
function mtx(str) { return (typeof MathText !== "undefined") ? MathText.html(str) : escapeHtml(str); }

var estate = { exams: [], activeExamId: null, questions: [], resultsExamId: null, results: [], explainedByExam: {}, questionCountByExam: {} };

async function renderTeacherExams() {
  const el = document.getElementById("tab-exams");
  el.innerHTML = `<p class="muted">Loading exams…</p>`;
  const { data, error } = await supabase.from("exams").select("*")
    .eq("section_id", state.section.id).eq("term_id", state.term ? state.term.id : null)
    .order("created_at", { ascending: false });
  if (error) { el.innerHTML = `<div class="empty">Couldn't load exams — ${escapeHtml(error.message)}. Have you run exam_schema.sql yet?</div>`; return; }
  estate.exams = data || [];

  // How many questions in each exam already have an explanation (shown as
  // "💡 12/40 explained" and used for the publish warning).
  estate.explainedByExam = {}; estate.questionCountByExam = {};
  if (estate.exams.length) {
    const qRes = await fetchAllRowsChecked(() => supabase.from("exam_questions").select("id, exam_id, explanation").in("exam_id", estate.exams.map((e) => e.id)));
    (qRes.data || []).forEach((q) => {
      estate.questionCountByExam[q.exam_id] = (estate.questionCountByExam[q.exam_id] || 0) + 1;
      if (q.explanation && q.explanation.trim()) estate.explainedByExam[q.exam_id] = (estate.explainedByExam[q.exam_id] || 0) + 1;
    });
  }

  el.innerHTML = `
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <h3 style="margin:0;">📝 Exams — ${state.term ? escapeHtml(state.term.term_label || ("Term " + state.term.term_number)) : ""}</h3>
        <button class="btn-gold" onclick="openCreateExamModal()">+ New Exam</button>
      </div>
      ${estate.exams.length === 0 ? `<div class="empty">No exams yet for this term. Create one to get started.</div>` :
        `<table>
          <thead><tr><th>Title</th><th>Format</th><th>Questions</th><th>Duration</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${estate.exams.map((e) => `
              <tr>
                <td>${mtx(e.title)}${examExplanationBadgeHtml(e)}</td>
                <td>${escapeHtml(e.question_format)}</td>
                <td>${e.total_questions}</td>
                <td>${e.duration_minutes} min</td>
                <td>${e.is_locked ? `<span style="color:var(--clay);">🔒 Locked</span>` : e.is_published ? `<span style="color:var(--forest);">✅ Published</span>` : `<span class="muted">Draft</span>`}</td>
                <td><div style="display:flex;gap:4px;flex-wrap:wrap;min-width:260px;">
                  <button class="btn-outline btn-sm" onclick="openQuestionEditor('${e.id}')">Questions</button>
                  <button class="btn-outline btn-sm" onclick="openExplanationEditor('${e.id}')">💡 Explanations</button>
                  <button class="btn-outline btn-sm" onclick="openExamResults('${e.id}')">Results</button>
                  <button class="btn-outline btn-sm" onclick="openEditExamModal('${e.id}')">✏️ Edit</button>
                  <button class="btn-outline btn-sm" onclick="toggleExamPublish('${e.id}', ${!e.is_published})">${e.is_published ? "Unpublish" : "Publish"}</button>
                  <button class="btn-outline btn-sm" onclick="toggleExamLock('${e.id}', ${!e.is_locked})">${e.is_locked ? "Unlock" : "Lock"}</button>
                  <button class="btn-outline btn-sm" title="${e.shuffle_options ? "Options are shuffled per student — click to turn off" : "Options show in the same order for everyone — click to shuffle per student"}" onclick="toggleExamShuffle('${e.id}', ${!e.shuffle_options})">${e.shuffle_options ? "🔀 Shuffle: On" : "🔀 Shuffle: Off"}</button>
                  <button class="btn-outline btn-sm" onclick="deleteExam('${e.id}')">🗑️</button>
                </div></td>
              </tr>
              ${e.max_attempts > 1 ? `<tr><td colspan="6" style="border-top:none;padding-top:0;"><span class="muted" style="font-size:.78rem;">↳ Students may retake this exam — up to ${e.max_attempts} attempt${e.max_attempts === 1 ? "" : "s"} total.</span></td></tr>` : ""}`).join("")}
          </tbody>
        </table>`}
    </div>
    <div id="examSubPanel" style="margin-top:16px;"></div>`;
}

// ---------- Explanation coverage + review-release helpers ----------
function examExplanationBadgeHtml(e) {
  const total = estate.questionCountByExam[e.id] || 0;
  if (!total) return "";
  const done = estate.explainedByExam[e.id] || 0;
  const color = done === total ? "var(--forest)" : done === 0 ? "var(--clay)" : "var(--gold-dark, #a67c00)";
  const release = e.review_release === "after_lock" ? ` · 🔒 review opens when you lock the exam` : "";
  return `<div style="font-size:.76rem;margin-top:2px;color:${color};">💡 ${done}/${total} explained${release}</div>`;
}

// Same block in the New Exam and Edit Exam dialogs.
function examReleaseFieldHtml(value) {
  const v = value === "after_lock" ? "after_lock" : "after_submit";
  return `
    <div class="field" style="border-top:1px solid var(--paper-line);padding-top:10px;margin-top:6px;">
      <label>When do students see the review (correct answers + 💡 explanations)?</label>
      <select id="ex_release">
        <option value="after_submit" ${v === "after_submit" ? "selected" : ""}>Right after they submit</option>
        <option value="after_lock" ${v === "after_lock" ? "selected" : ""}>Only after I lock the exam (best for a class-wide test)</option>
      </select>
      <div class="muted" style="margin-top:2px;">Applies when "Allow review" is on. Explanations appear only if "Show correct answers" is also on. With "after I lock", early finishers see their score but not the answers, so they can't pass them on to classmates still working — and it also avoids handing out answers before a retake.</div>
    </div>`;
}

// review_release only exists after migration-52. If it hasn't been run yet,
// retry without that one field so creating/editing an exam never breaks.
async function writeExamWithFallback(run, payload) {
  let res = await run(payload);
  if (res.error && /review_release/i.test(res.error.message || "")) {
    const rest = { ...payload }; delete rest.review_release;
    res = await run(rest);
    if (!res.error && payload.review_release === "after_lock") toast("Saved — but run migration-52 in Supabase to turn on the 'after I lock the exam' setting.");
  }
  return res;
}

// ---------- Create / settings ----------
function openCreateExamModal() {
  showModal(`
    <h3>New Exam</h3>
    <div class="field"><label>Title</label><input id="ex_title" placeholder="e.g. Term 2 Mock Exam — Algebra"></div>
    <div class="field"><label>Description (optional)</label><input id="ex_desc" placeholder="Shown to students on the exam list"></div>
    <div class="field-row">
      <div class="field"><label>Question Format</label>
        <select id="ex_format">
          <option value="mixed">Mixed (MC + True/False)</option>
          <option value="multiple_choice">Multiple Choice only</option>
          <option value="true_false">True/False only</option>
        </select>
      </div>
      <div class="field"><label>Duration (minutes)</label><input type="number" id="ex_duration" value="60"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Passing Score (%)</label><input type="number" id="ex_passing" value="75"></div>
      <div class="field"><label>Max Attempts</label><input type="number" id="ex_maxattempts" value="1"></div>
    </div>
    <div class="field-row">
      <div class="field"><label><input type="checkbox" id="ex_review" checked> Allow review after submit</label></div>
      <div class="field"><label><input type="checkbox" id="ex_showanswers" checked> Show correct answers in review</label></div>
    </div>
    <div class="field"><label><input type="checkbox" id="ex_shuffle" checked> Shuffle answer options per student</label>
      <div class="muted" style="margin-top:2px;">Each student sees the choices in a different order, so they can't just copy the letter from a neighbor. Correct scoring isn't affected.</div>
    </div>
    ${examReleaseFieldHtml('after_submit')}
    <div class="field-row" style="border-top:1px solid var(--paper-line);padding-top:10px;margin-top:6px;">
      <div class="field"><label><input type="checkbox" id="ex_fullscreen" checked> Require fullscreen while taking exam</label></div>
      <div class="field"><label>Auto-submit after this many violations</label><input type="number" id="ex_maxviolations" min="0" value="3">
        <div class="muted" style="margin-top:2px;">Tab switches, exiting fullscreen, and copy attempts each count. 0 = just log them, never auto-submit.</div>
      </div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createExam()">Create</button>
    </div>`);
}

async function createExam() {
  const title = document.getElementById("ex_title").value.trim();
  if (!title) { toast("Please enter a title."); return; }
  const payload = {
    teacher_id: state.user.id, section_id: state.section.id, term_id: state.term ? state.term.id : null,
    title, description: document.getElementById("ex_desc").value.trim() || null,
    question_format: document.getElementById("ex_format").value,
    duration_minutes: Number(document.getElementById("ex_duration").value) || 60,
    passing_score: Number(document.getElementById("ex_passing").value) || null,
    max_attempts: Number(document.getElementById("ex_maxattempts").value) || 1,
    allow_multiple_attempts: (Number(document.getElementById("ex_maxattempts").value) || 1) > 1,
    allow_review: document.getElementById("ex_review").checked,
    show_correct_answers: document.getElementById("ex_showanswers").checked,
    shuffle_options: document.getElementById("ex_shuffle").checked,
    require_fullscreen: document.getElementById("ex_fullscreen").checked,
    max_violations: Math.max(0, Number(document.getElementById("ex_maxviolations").value) || 0),
    review_release: document.getElementById("ex_release").value,
  };
  const { data, error } = await writeExamWithFallback((p) => supabase.from("exams").insert(p).select().single(), payload);
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Exam created — now add questions.");
  await renderTeacherExams();
  openQuestionEditor(data.id);
}

// ---------- Edit existing exam settings (incl. how many attempts are allowed) ----------
function openEditExamModal(examId) {
  const e = estate.exams.find((x) => x.id === examId);
  if (!e) return;
  showModal(`
    <h3>Edit Exam</h3>
    <div class="field"><label>Title</label><input id="ex_title" value="${escapeHtml(e.title)}"></div>
    <div class="field"><label>Description (optional)</label><input id="ex_desc" value="${escapeHtml(e.description || "")}" placeholder="Shown to students on the exam list"></div>
    <div class="field-row">
      <div class="field"><label>Question Format</label>
        <select id="ex_format">
          <option value="mixed" ${e.question_format === "mixed" ? "selected" : ""}>Mixed (MC + True/False)</option>
          <option value="multiple_choice" ${e.question_format === "multiple_choice" ? "selected" : ""}>Multiple Choice only</option>
          <option value="true_false" ${e.question_format === "true_false" ? "selected" : ""}>True/False only</option>
        </select>
      </div>
      <div class="field"><label>Duration (minutes)</label><input type="number" id="ex_duration" value="${e.duration_minutes}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Passing Score (%)</label><input type="number" id="ex_passing" value="${e.passing_score != null ? e.passing_score : 75}"></div>
      <div class="field"><label>Max Attempts</label><input type="number" min="1" id="ex_maxattempts" value="${e.max_attempts || 1}">
        <div class="muted" style="margin-top:2px;">How many times a student may take this exam. Set to 1 for no retakes.</div>
      </div>
    </div>
    <div class="field-row">
      <div class="field"><label><input type="checkbox" id="ex_review" ${e.allow_review ? "checked" : ""}> Allow review after submit</label></div>
      <div class="field"><label><input type="checkbox" id="ex_showanswers" ${e.show_correct_answers ? "checked" : ""}> Show correct answers in review</label></div>
    </div>
    <div class="field"><label><input type="checkbox" id="ex_shuffle" ${e.shuffle_options ? "checked" : ""}> Shuffle answer options per student</label>
      <div class="muted" style="margin-top:2px;">Each student sees the choices in a different order, so they can't just copy the letter from a neighbor. Correct scoring isn't affected.</div>
    </div>
    ${examReleaseFieldHtml(e.review_release)}
    <div class="field-row" style="border-top:1px solid var(--paper-line);padding-top:10px;margin-top:6px;">
      <div class="field"><label><input type="checkbox" id="ex_fullscreen" ${e.require_fullscreen !== false ? "checked" : ""}> Require fullscreen while taking exam</label></div>
      <div class="field"><label>Auto-submit after this many violations</label><input type="number" id="ex_maxviolations" min="0" value="${e.max_violations != null ? e.max_violations : 3}">
        <div class="muted" style="margin-top:2px;">Tab switches, exiting fullscreen, and copy attempts each count. 0 = just log them, never auto-submit.</div>
      </div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="updateExam('${examId}')">Save Changes</button>
    </div>`);
}

async function updateExam(examId) {
  const title = document.getElementById("ex_title").value.trim();
  if (!title) { toast("Please enter a title."); return; }
  const maxAttempts = Math.max(1, Number(document.getElementById("ex_maxattempts").value) || 1);
  const payload = {
    title, description: document.getElementById("ex_desc").value.trim() || null,
    question_format: document.getElementById("ex_format").value,
    duration_minutes: Number(document.getElementById("ex_duration").value) || 60,
    passing_score: Number(document.getElementById("ex_passing").value) || null,
    max_attempts: maxAttempts,
    allow_multiple_attempts: maxAttempts > 1,
    allow_review: document.getElementById("ex_review").checked,
    show_correct_answers: document.getElementById("ex_showanswers").checked,
    shuffle_options: document.getElementById("ex_shuffle").checked,
    require_fullscreen: document.getElementById("ex_fullscreen").checked,
    max_violations: Math.max(0, Number(document.getElementById("ex_maxviolations").value) || 0),
    review_release: document.getElementById("ex_release").value,
    updated_at: new Date().toISOString(),
  };
  const { error } = await writeExamWithFallback((p) => supabase.from("exams").update(p).eq("id", examId), payload);
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Exam settings updated.");
  await renderTeacherExams();
}

async function toggleExamPublish(examId, publish) {
  const exam = estate.exams.find((e) => e.id === examId);
  if (publish && (!exam || exam.total_questions === 0)) { toast("Add at least one question before publishing."); return; }
  if (publish) {
    const total = estate.questionCountByExam[examId] || 0, done = estate.explainedByExam[examId] || 0;
    if (total > 0 && done < total) {
      const msg = done === 0
        ? `None of the ${total} questions has an explanation yet, so students will only see which answers were right or wrong in their review.\n\nPublish anyway?`
        : `${total - done} of ${total} questions have no explanation yet — students won't see a "why" for those items.\n\nPublish anyway? (You can fill them in later with 💡 Explanations.)`;
      if (!confirm(msg)) return;
    }
  }
  const { error } = await supabase.from("exams").update({ is_published: publish, updated_at: new Date().toISOString() }).eq("id", examId);
  if (error) { toast("Error: " + error.message); return; }
  toast(publish ? "Exam published — students can now see it." : "Exam unpublished.");
  await renderTeacherExams();
}

async function toggleExamLock(examId, lock) {
  const { error } = await supabase.from("exams").update({ is_locked: lock, updated_at: new Date().toISOString() }).eq("id", examId);
  if (error) { toast("Error: " + error.message); return; }
  const exam = estate.exams.find((e) => e.id === examId);
  const held = exam && exam.review_release === "after_lock";
  toast(lock
    ? (held ? "Exam locked — students can no longer start it, and submitted students can now open their answer review." : "Exam locked — students can no longer start or resume it.")
    : (held ? "Exam unlocked — the answer review is hidden again until you lock it." : "Exam unlocked."));
  await renderTeacherExams();
}

async function toggleExamShuffle(examId, shuffle) {
  const { error } = await supabase.from("exams").update({ shuffle_options: shuffle, updated_at: new Date().toISOString() }).eq("id", examId);
  if (error) { toast("Error: " + error.message); return; }
  toast(shuffle ? "Shuffle turned on — new attempts will get a randomized option order." : "Shuffle turned off — everyone sees the same option order.");
  await renderTeacherExams();
}

async function deleteExam(examId) {
  if (!confirm("Delete this exam and all student attempts? This cannot be undone.")) return;
  const { error } = await supabase.from("exams").delete().eq("id", examId);
  if (error) { toast("Error: " + error.message); return; }
  toast("Exam deleted.");
  document.getElementById("examSubPanel").innerHTML = "";
  await renderTeacherExams();
}

// ---------- Question editor ----------
async function openQuestionEditor(examId) {
  estate.activeExamId = examId;
  const exam = estate.exams.find((e) => e.id === examId);
  const panel = document.getElementById("examSubPanel");
  panel.innerHTML = `<p class="muted">Loading questions…</p>`;

  const { data, error } = await supabase.from("exam_questions").select("*").eq("exam_id", examId).order("question_number");
  if (error) { panel.innerHTML = `<div class="empty">Couldn't load questions — ${escapeHtml(error.message)}</div>`; return; }
  estate.questions = data || [];

  panel.innerHTML = `
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <h3 style="margin:0;">Questions — ${mtx(exam ? exam.title : "")}</h3>
        <div>
          <button class="btn-outline btn-sm" onclick="document.getElementById('examSubPanel').innerHTML=''">Close</button>
          <button class="btn-outline btn-sm" onclick="openBulkAddModal()">📥 Bulk Add</button>
          <button class="btn-outline btn-sm" onclick="openExplanationEditor('${examId}')">💡 Explanations</button>
          <button class="btn-gold btn-sm" onclick="openQuestionFormModal(null)">+ Add Question</button>
        </div>
      </div>
      ${estate.questions.length ? (() => {
        const done = estate.questions.filter((q) => q.explanation && q.explanation.trim()).length;
        const total = estate.questions.length;
        return `<div class="muted" style="margin:-6px 0 12px;">💡 ${done} of ${total} items have an explanation${done < total ? ` — <a href="#" onclick="openExplanationEditor('${examId}', true);return false;">write the ${total - done} missing</a>` : " — every item is covered ✅"}. Students see these under each item once their exam is scored.</div>`;
      })() : ""}
      ${estate.questions.length === 0 ? `<div class="empty">No questions yet.</div>` :
        estate.questions.map((q, i) => `
          <div class="card" style="margin-bottom:10px;background:var(--paper);">
            <div style="display:flex;justify-content:space-between;gap:10px;">
              <div style="flex:1;">
                <strong>Q${q.question_number}.</strong> ${mtx(q.question_text)} <span class="muted">(${q.points} pt${q.points === 1 ? "" : "s"})</span>
                ${q.question_type === "true_false"
                  ? `<div class="muted" style="margin-top:6px;">True / False — correct: <strong>${escapeHtml(q.correct_answer)}</strong></div>`
                  : `<ul style="margin:6px 0 0 18px;">${(q.options || []).map((o, idx) => `<li${String.fromCharCode(65 + idx) === q.correct_answer ? ' style="font-weight:700;color:var(--forest);"' : ""}>${String.fromCharCode(65 + idx)}) ${mtx(o)}</li>`).join("")}</ul>`}
                ${q.explanation && q.explanation.trim()
                  ? `<div class="muted" style="margin-top:6px;white-space:pre-wrap;">💡 ${mtx(q.explanation)}</div>`
                  : `<div style="margin-top:6px;font-size:.82rem;color:var(--clay);">⚠️ No explanation yet — <a href="#" onclick='openQuestionFormModal(${JSON.stringify(q.id)});return false;'>add one</a></div>`}
              </div>
              <div style="white-space:nowrap;">
                <button class="btn-outline btn-sm" onclick='openQuestionFormModal(${JSON.stringify(q.id)})'>Edit</button>
                <button class="btn-outline btn-sm" onclick="deleteQuestion('${q.id}')">🗑️</button>
              </div>
            </div>
          </div>`).join("")}
    </div>`;
}

function openQuestionFormModal(questionId) {
  const q = questionId ? estate.questions.find((x) => x.id === questionId) : null;
  const nextNumber = q ? q.question_number : estate.questions.length + 1;
  const type = q ? q.question_type : "multiple_choice";
  const opts = q && q.options ? q.options : ["", "", "", ""];
  showModal(`
    <h3>${q ? "Edit" : "Add"} Question ${nextNumber}</h3>
    <div class="field"><label>Question Text</label><textarea id="q_text" data-mt="1" rows="3" placeholder="e.g. Simplify (x+1)/(x-2) when x^2 &lt;= 9, or  What is sqrt(144) + 2 pi?">${q ? escapeHtml(q.question_text) : ""}</textarea></div>
    ${typeof MathText !== "undefined" ? MathText.paletteHtml("mtPalQ", "q_text") : ""}
    <div class="mt-preview"><div class="mt-preview-label">👁️ What students will see</div><div id="q_preview"></div></div>
    <div class="field-row">
      <div class="field"><label>Type</label>
        <select id="q_type" onchange="toggleQuestionTypeFields()">
          <option value="multiple_choice" ${type === "multiple_choice" ? "selected" : ""}>Multiple Choice</option>
          <option value="true_false" ${type === "true_false" ? "selected" : ""}>True / False</option>
        </select>
      </div>
      <div class="field"><label>Points</label><input type="number" id="q_points" value="${q ? q.points : 1}"></div>
    </div>
    <div id="q_mcFields" style="display:${type === "multiple_choice" ? "block" : "none"};">
      ${["A", "B", "C", "D"].map((L, i) => `<div class="field"><label>Option ${L}</label><input id="q_opt${i}" data-mt="1" value="${escapeHtml(opts[i] || "")}"></div>`).join("")}
      <div class="field"><label>Correct Option</label>
        <select id="q_mcAnswer">
          ${["A", "B", "C", "D"].map((L) => `<option value="${L}" ${q && q.correct_answer === L ? "selected" : ""}>${L}</option>`).join("")}
        </select>
      </div>
    </div>
    <div id="q_tfFields" style="display:${type === "true_false" ? "block" : "none"};">
      <div class="field"><label>Correct Answer</label>
        <select id="q_tfAnswer">
          <option value="True" ${q && q.correct_answer === "True" ? "selected" : ""}>True</option>
          <option value="False" ${q && q.correct_answer === "False" ? "selected" : ""}>False</option>
        </select>
      </div>
    </div>
    <div class="field"><label>💡 Explanation — why the correct answer is correct <span class="muted">(shown to students under this item after their exam is scored)</span></label><textarea id="q_explanation" data-mt="1" rows="3" placeholder="e.g. 7 groups of 8 make 56. Choosing 54 comes from 6 x 9, a common mix-up.">${q && q.explanation ? escapeHtml(q.explanation) : ""}</textarea></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveQuestion(${q ? `'${q.id}'` : "null"}, ${nextNumber})">Save</button>
    </div>`);
  bindQuestionPreview();
}

// v53 — live "what students will see" preview under the question editor.
function updateQuestionPreview() {
  const box = document.getElementById("q_preview");
  if (!box) return;
  const val = (id) => { const el = document.getElementById(id); return el ? el.value : ""; };
  const type = val("q_type");
  const opts = ["A", "B", "C", "D"].map((L, i) => ({ L, t: val("q_opt" + i) })).filter((o) => o.t.trim());
  const expl = val("q_explanation").trim();
  box.innerHTML = `
    <div class="mt-preview-q">${val("q_text").trim() ? mtx(val("q_text")) : `<span class="muted">Type a question above…</span>`}</div>
    ${type === "true_false"
      ? ["True", "False"].map((o) => `<div class="mt-preview-opt">${o}</div>`).join("")
      : opts.map((o) => `<div class="mt-preview-opt">${o.L}) ${mtx(o.t)}</div>`).join("")}
    ${expl ? `<div class="muted" style="margin-top:8px;font-size:.85rem;">💡 ${mtx(expl)}</div>` : ""}`;
}
function bindQuestionPreview() {
  ["q_text", "q_opt0", "q_opt1", "q_opt2", "q_opt3", "q_explanation"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", updateQuestionPreview);
  });
  const t = document.getElementById("q_type");
  if (t) t.addEventListener("change", updateQuestionPreview);
  updateQuestionPreview();
}

function toggleQuestionTypeFields() {
  const isMC = document.getElementById("q_type").value === "multiple_choice";
  document.getElementById("q_mcFields").style.display = isMC ? "block" : "none";
  document.getElementById("q_tfFields").style.display = isMC ? "none" : "block";
}

async function saveQuestion(questionId, questionNumber) {
  const text = document.getElementById("q_text").value.trim();
  if (!text) { toast("Please enter the question text."); return; }
  const type = document.getElementById("q_type").value;
  const payload = {
    exam_id: estate.activeExamId, question_number: questionNumber, question_text: text, question_type: type,
    points: Number(document.getElementById("q_points").value) || 1,
    explanation: document.getElementById("q_explanation").value.trim() || null,
  };
  if (type === "multiple_choice") {
    payload.options = [0, 1, 2, 3].map((i) => document.getElementById("q_opt" + i).value.trim());
    if (payload.options.some((o) => !o)) { toast("Please fill in all four options."); return; }
    payload.correct_answer = document.getElementById("q_mcAnswer").value;
  } else {
    payload.options = null;
    payload.correct_answer = document.getElementById("q_tfAnswer").value;
  }

  const { error } = questionId
    ? await supabase.from("exam_questions").update(payload).eq("id", questionId)
    : await supabase.from("exam_questions").insert(payload);
  if (error) { toast("Error: " + error.message); return; }

  await supabase.from("exams").update({ total_questions: (await supabase.from("exam_questions").select("id", { count: "exact", head: true }).eq("exam_id", estate.activeExamId)).count || 0 }).eq("id", estate.activeExamId);

  closeModal();
  toast("Question saved.");
  await openQuestionEditor(estate.activeExamId);
}

// ---------- Explanation editor (write "why" for every item in one place) ----------
async function openExplanationEditor(examId, onlyMissing) {
  const exam = estate.exams.find((e) => e.id === examId);
  if (!exam) return;
  estate.activeExamId = examId;
  const { data, error } = await supabase.from("exam_questions").select("*").eq("exam_id", examId).order("question_number");
  if (error) { toast("Couldn't load questions: " + error.message); return; }
  estate.questions = data || [];
  if (!estate.questions.length) { toast("Add some questions first, then write their explanations."); return; }

  const answerLabel = (q) => {
    if (q.question_type === "true_false") return escapeHtml(q.correct_answer);
    const idx = q.correct_answer.charCodeAt(0) - 65;
    const text = q.options && q.options[idx] != null ? q.options[idx] : "";
    return `${escapeHtml(q.correct_answer)}) ${escapeHtml(text)}`;
  };
  showModal(`
    <style>.modal{max-width:860px !important;}</style>
    <h3 style="margin-bottom:2px;">💡 Explanations — ${escapeHtml(exam.title)}</h3>
    <p class="muted" style="margin-top:0;">Explain <em>why</em> the correct answer is correct — and, where it helps, why a tempting wrong answer is wrong. Students see this under each item after their exam is scored (subject to this exam's review settings).</p>
    <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:8px;">
      <strong id="expl_count"></strong>
      <label style="font-size:.88rem;"><input type="checkbox" id="expl_onlymissing" ${onlyMissing ? "checked" : ""} onchange="applyExplanationFilter()"> Show only items without an explanation</label>
    </div>
    <details style="margin-bottom:10px;">
      <summary style="cursor:pointer;">📋 Paste numbered explanations from your answer key</summary>
      <div class="muted" style="margin:6px 0;">One per number, e.g. <code>1. 7 x 8 = 56</code> then <code>2) Because 9 x 9 = 81</code>. A line without a number continues the previous explanation. This fills in the boxes below — nothing is saved until you press Save.</div>
      <textarea id="expl_paste" rows="5" style="width:100%;font-family:monospace;font-size:.82rem;"></textarea>
      <button class="btn-outline btn-sm" style="margin-top:6px;" onclick="applyPastedExplanations()">Fill in the boxes</button>
    </details>
    <div id="expl_list" style="max-height:52vh;overflow:auto;padding-right:4px;">
      ${estate.questions.map((q) => `
        <div class="expl-row" data-qid="${q.id}" style="padding:10px 0;border-bottom:1px solid var(--paper-line);">
          <div><strong>Q${q.question_number}.</strong> ${mtx(q.question_text.length > 170 ? q.question_text.slice(0, 170) + "…" : q.question_text)}</div>
          <div class="muted" style="font-size:.82rem;margin:2px 0 6px;">Correct answer: <strong style="color:var(--forest);">${answerLabel(q)}</strong></div>
          <textarea id="expl_${q.id}" rows="2" style="width:100%;" oninput="updateExplanationCount()" placeholder="Why is this the correct answer?">${escapeHtml(q.explanation || "")}</textarea>
        </div>`).join("")}
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:14px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveExplanations()">Save explanations</button>
    </div>`);
  updateExplanationCount();
  applyExplanationFilter();
}

function updateExplanationCount() {
  const total = estate.questions.length;
  const done = estate.questions.filter((q) => { const el = document.getElementById("expl_" + q.id); return el && el.value.trim(); }).length;
  const c = document.getElementById("expl_count");
  if (c) { c.textContent = `💡 ${done} of ${total} explained`; c.style.color = done === total ? "var(--forest)" : ""; }
}

// Hides rows that already have text. Uses the text as it was when the filter
// was applied, so a row doesn't vanish while you're still typing in it.
function applyExplanationFilter() {
  const only = document.getElementById("expl_onlymissing");
  const on = only && only.checked;
  document.querySelectorAll("#expl_list .expl-row").forEach((row) => {
    const q = estate.questions.find((x) => x.id === row.dataset.qid);
    row.style.display = on && q && q.explanation && q.explanation.trim() ? "none" : "";
  });
}

// "1. text" / "Q2) text" / "3: text" — later unnumbered lines continue the previous item.
function parseNumberedExplanations(raw) {
  const map = {}; let cur = null;
  String(raw || "").split(/\r?\n/).forEach((line) => {
    const m = line.match(/^\s*(?:q(?:uestion)?\s*)?#?(\d+)\s*[\.\):\-–]\s*(.*)$/i);
    if (m) { cur = parseInt(m[1], 10); map[cur] = m[2].trim(); }
    else if (cur != null && line.trim()) map[cur] += "\n" + line.trim();
  });
  return map;
}

function applyPastedExplanations() {
  const map = parseNumberedExplanations(document.getElementById("expl_paste").value);
  const nums = Object.keys(map).map(Number);
  if (!nums.length) { toast("Couldn't find any numbered lines — start each one with 1. or 2) etc."); return; }
  let filled = 0;
  estate.questions.forEach((q) => {
    if (map[q.question_number] == null || !map[q.question_number]) return;
    const el = document.getElementById("expl_" + q.id);
    if (el) { el.value = map[q.question_number]; filled++; }
  });
  const unmatched = nums.filter((n) => !estate.questions.some((q) => q.question_number === n)).length;
  updateExplanationCount();
  toast(`Filled ${filled} box${filled === 1 ? "" : "es"}${unmatched ? ` — ${unmatched} number${unmatched === 1 ? "" : "s"} didn't match a question` : ""}. Review, then press Save.`);
}

async function saveExplanations() {
  const changes = [];
  estate.questions.forEach((q) => {
    const el = document.getElementById("expl_" + q.id);
    if (!el) return;
    const v = el.value.trim();
    if (v !== (q.explanation || "").trim()) changes.push({ id: q.id, explanation: v || null });
  });
  if (!changes.length) { toast("No changes to save."); closeModal(); return; }
  const results = await Promise.all(changes.map((c) =>
    supabase.from("exam_questions").update({ explanation: c.explanation, updated_at: new Date().toISOString() }).eq("id", c.id)));
  const failed = results.filter((r) => r.error);
  const examId = estate.activeExamId;
  if (failed.length) toast(`Saved ${changes.length - failed.length} of ${changes.length}; ${failed.length} failed (${failed[0].error.message}). Open 💡 Explanations again to retry.`);
  else toast(`Saved ${changes.length} explanation${changes.length === 1 ? "" : "s"}.`);
  closeModal();
  await renderTeacherExams();
  await openQuestionEditor(examId);
}

// ---------- Bulk add ----------
var _bulkParsed = [];

const BULK_EXAMPLE = `Q: What is 7 x 8?
A) 54
B) 56
C) 63
D) 64
ANSWER: B
EXPLANATION: 7 groups of 8 make 56.
54 is 6 x 9 and 63 is 7 x 9 - easy to mix up.
POINTS: 1

Q: The square root of 81 is 9.
ANSWER: True
EXPLANATION: 9 x 9 = 81, so the square root of 81 is 9.

Q: Which of these is a prime number?
A) 9
B) 15
C) 17
D) 21
ANSWER: C`;

function openBulkAddModal() {
  showModal(`
    <style>.modal{max-width:760px !important;}</style>
    <h3>Bulk Add Questions</h3>
    <p class="muted" style="margin-top:-6px;">Paste several questions at once — separate each one with a blank line. <a href="#" onclick="fillBulkExample();return false;">Load an example</a></p>
    ${typeof MathText !== "undefined" ? MathText.paletteHtml("mtPalBulk", "bulk_text") : ""}
    <div class="field">
      <label>Questions</label>
      <textarea id="bulk_text" data-mt="1" rows="14" style="font-family:monospace;font-size:0.82rem;" placeholder="Q: Question text
A) Option
B) Option
C) Option
D) Option
ANSWER: B
EXPLANATION: optional - why the answer is correct (may run onto more lines)
POINTS: optional, default 1

Q: A true/false question.
ANSWER: True"></textarea>
      <div class="muted" style="margin-top:4px;">Leave out A)/B)/C)/D) for a True/False question. ANSWER: is required for every question. EXPLANATION: (also accepts RATIONALE: or SOLUTION:) and POINTS: are optional — but an explanation for every item makes the post-exam review far more useful. Keep an explanation's lines together with no blank line inside.</div>
    </div>
    <div id="bulkPreview"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-outline" onclick="previewBulkQuestions()">Preview</button>
      <button class="btn-primary" id="bulkSaveBtn" style="display:none;" onclick="saveBulkQuestions()">Add Questions</button>
    </div>`);
}

function fillBulkExample() {
  const ta = document.getElementById("bulk_text");
  if (ta) ta.value = BULK_EXAMPLE;
}

function parseBulkQuestions(raw) {
  const blocks = raw.split(/\n\s*\n+/).map((b) => b.trim()).filter(Boolean);
  const qLine = /^q(?:uestion)?\s*[:.]\s*(.+)$/i;
  const optLine = /^([A-Za-z0-9])[\.\)]\s*(.+)$/;
  const ansLine = /^(?:answer|ans|correct)\s*:\s*(.+)$/i;
  const expLine = /^(?:explanation|exp|rationale|solution)\s*:\s*(.+)$/i;
  const ptsLine = /^(?:points?|pts)\s*:\s*(\d+)/i;
  const typeLine = /^type\s*:\s*(.+)$/i;

  return blocks.map((block, i) => {
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
    let questionText = "", answerRaw = "", explanation = "", points = 1;
    const options = [];

    // `inExplanation`: once an EXPLANATION: line starts, every following line
    // (until ANSWER:/POINTS:/TYPE:) continues the explanation instead of being
    // glued onto the question text. Keep an explanation's lines together — a
    // blank line ends the question block.
    let inExplanation = false;
    lines.forEach((line) => {
      let m;
      if ((m = line.match(ansLine))) { answerRaw = m[1].trim(); inExplanation = false; return; }
      if ((m = line.match(expLine))) { explanation = m[1].trim(); inExplanation = true; return; }
      if ((m = line.match(ptsLine))) { points = parseInt(m[1], 10) || 1; inExplanation = false; return; }
      if (typeLine.test(line)) { inExplanation = false; return; } // type is inferred from options, this prefix is just ignored
      if (inExplanation) { explanation += "\n" + line; return; }
      if ((m = line.match(optLine))) { options.push({ label: m[1].toUpperCase(), text: m[2].trim() }); return; }
      if ((m = line.match(qLine))) { questionText = (questionText ? questionText + " " : "") + m[1].trim(); return; }
      questionText = (questionText ? questionText + " " : "") + line;
    });

    const errors = [];
    let question_type, correct_answer, finalOptions = null;

    if (!questionText) errors.push("Missing question text");
    if (!answerRaw) errors.push("Missing ANSWER:");

    if (options.length > 0) {
      question_type = "multiple_choice";
      if (options.length < 2) errors.push("Needs at least 2 options");
      finalOptions = options.map((o) => o.text);
      if (answerRaw) {
        const pos = options.findIndex((o) => o.label === answerRaw.toUpperCase());
        if (pos === -1) errors.push(`ANSWER "${answerRaw}" doesn't match any option letter (${options.map((o) => o.label).join(", ")})`);
        else correct_answer = String.fromCharCode(65 + pos);
      }
    } else if (answerRaw) {
      question_type = "true_false";
      const a = answerRaw.toLowerCase();
      if (a.startsWith("t")) correct_answer = "True";
      else if (a.startsWith("f")) correct_answer = "False";
      else errors.push(`ANSWER "${answerRaw}" must be True or False, or add options (A), B)…) for multiple choice`);
    }

    return { index: i, questionText, question_type, options: finalOptions, correct_answer, explanation, points, errors };
  });
}

function previewBulkQuestions() {
  const raw = document.getElementById("bulk_text").value;
  if (!raw.trim()) { toast("Paste some questions first."); return; }
  _bulkParsed = parseBulkQuestions(raw);
  const valid = _bulkParsed.filter((q) => q.errors.length === 0);
  document.getElementById("bulkPreview").innerHTML = `
    <div style="margin-top:12px;max-height:280px;overflow:auto;border:1px solid var(--paper-line);border-radius:8px;padding:10px;">
      ${_bulkParsed.map((q) => `
        <div style="padding:6px 0;border-bottom:1px solid var(--paper-line);">
          ${q.errors.length === 0
            ? `<span style="color:var(--forest);">✅</span> <strong>${mtx(q.questionText.slice(0, 90) + (q.questionText.length > 90 ? "…" : ""))}</strong> <span class="muted">(${q.question_type === "true_false" ? "T/F" : q.options.length + " options"} • answer: ${escapeHtml(q.correct_answer)})</span> ${q.explanation ? `<span title="${escapeHtml(q.explanation)}">💡</span>` : `<span class="muted" style="font-size:.75rem;">no explanation</span>`}`
            : `<span style="color:var(--clay);">❌ Question ${q.index + 1}:</span> ${q.errors.map((e) => escapeHtml(e)).join("; ")}`}
        </div>`).join("")}
    </div>
    <p class="muted" style="margin-top:8px;">${valid.length} of ${_bulkParsed.length} ready to add${_bulkParsed.length > valid.length ? " — questions with errors will be skipped" : ""}. 💡 ${valid.filter((q) => q.explanation).length} of ${valid.length} include an explanation.</p>`;
  const saveBtn = document.getElementById("bulkSaveBtn");
  saveBtn.style.display = valid.length ? "inline-block" : "none";
  saveBtn.textContent = `Add ${valid.length} Question${valid.length === 1 ? "" : "s"}`;
}

async function saveBulkQuestions() {
  const valid = _bulkParsed.filter((q) => q.errors.length === 0);
  if (!valid.length) return;
  let nextNumber = estate.questions.length + 1;
  const rows = valid.map((q) => ({
    exam_id: estate.activeExamId,
    question_number: nextNumber++,
    question_text: q.questionText,
    question_type: q.question_type,
    options: q.question_type === "multiple_choice" ? q.options : null,
    correct_answer: q.correct_answer,
    explanation: q.explanation || null,
    points: q.points || 1,
  }));
  const { error } = await supabase.from("exam_questions").insert(rows);
  if (error) { toast("Error: " + error.message); return; }
  const { count } = await supabase.from("exam_questions").select("id", { count: "exact", head: true }).eq("exam_id", estate.activeExamId);
  await supabase.from("exams").update({ total_questions: count || 0 }).eq("id", estate.activeExamId);
  closeModal();
  toast(`Added ${rows.length} question${rows.length === 1 ? "" : "s"}.`);
  await openQuestionEditor(estate.activeExamId);
}

async function deleteQuestion(questionId) {
  if (!confirm("Delete this question?")) return;
  const { error } = await supabase.from("exam_questions").delete().eq("id", questionId);
  if (error) { toast("Error: " + error.message); return; }
  const { count } = await supabase.from("exam_questions").select("id", { count: "exact", head: true }).eq("exam_id", estate.activeExamId);
  await supabase.from("exams").update({ total_questions: count || 0 }).eq("id", estate.activeExamId);
  await openQuestionEditor(estate.activeExamId);
}

// ---------- Results ----------
async function openExamResults(examId) {
  estate.resultsExamId = examId;
  const exam = estate.exams.find((e) => e.id === examId);
  const panel = document.getElementById("examSubPanel");
  panel.innerHTML = `<p class="muted">Loading results…</p>`;

  const { data, error } = await supabase.from("exam_attempts").select("*, students(first_name, last_name)")
    .eq("exam_id", examId).order("percentage_score", { ascending: false, nullsFirst: false });
  if (error) { panel.innerHTML = `<div class="empty">Couldn't load results — ${escapeHtml(error.message)}</div>`; return; }
  estate.results = data || [];

  const { data: violations } = await supabase.from("exam_violations").select("*").eq("exam_id", examId).order("occurred_at", { ascending: true });
  estate.violationsByAttempt = {};
  (violations || []).forEach((v) => { (estate.violationsByAttempt[v.attempt_id] = estate.violationsByAttempt[v.attempt_id] || []).push(v); });

  const submitted = estate.results.filter((r) => r.is_submitted);
  const avg = submitted.length ? (submitted.reduce((s, r) => s + Number(r.percentage_score || 0), 0) / submitted.length).toFixed(1) : "—";
  const passRate = submitted.length && exam && exam.passing_score
    ? Math.round((submitted.filter((r) => Number(r.percentage_score) >= exam.passing_score).length / submitted.length) * 100) + "%" : "—";
  const flaggedCount = estate.results.filter((r) => (estate.violationsByAttempt[r.id] || []).length > 0).length;

  const REASON_LABEL = { time_expired: "⏱️ Timer expired", violations: "🚩 Auto-submitted (violations)" };

  panel.innerHTML = `
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <h3 style="margin:0;">Results — ${mtx(exam ? exam.title : "")}</h3>
        <button class="btn-outline btn-sm" onclick="document.getElementById('examSubPanel').innerHTML=''">Close</button>
      </div>
      <div style="display:flex;gap:24px;margin-bottom:14px;flex-wrap:wrap;">
        <div><span class="muted">Submitted</span><br><strong>${submitted.length}</strong></div>
        <div><span class="muted">Class Average</span><br><strong>${avg}${submitted.length ? "%" : ""}</strong></div>
        <div><span class="muted">Pass Rate</span><br><strong>${passRate}</strong></div>
        <div><span class="muted">Flagged for Review</span><br><strong style="${flaggedCount ? "color:var(--clay);" : ""}">${flaggedCount}</strong></div>
      </div>
      ${estate.results.length === 0 ? `<div class="empty">No attempts yet.</div>` :
        `<table>
          <thead><tr><th>Student</th><th>Status</th><th>Score</th><th>Time Taken</th><th>Submitted</th><th>Integrity</th></tr></thead>
          <tbody>
            ${estate.results.map((r) => {
              const vlist = estate.violationsByAttempt[r.id] || [];
              return `
              <tr>
                <td>${escapeHtml(r.students ? r.students.last_name + ", " + r.students.first_name : "—")}</td>
                <td>${r.is_submitted ? "✅ Submitted" : "⏳ In progress"}${r.auto_submit_reason ? `<br><span class="muted" style="font-size:.75rem;">${REASON_LABEL[r.auto_submit_reason] || escapeHtml(r.auto_submit_reason)}</span>` : ""}</td>
                <td>${r.is_submitted ? `${r.total_score}/${r.total_points} (${r.percentage_score}%)` : "—"}</td>
                <td>${r.time_taken_seconds ? Math.round(r.time_taken_seconds / 60) + " min" : "—"}</td>
                <td>${r.submission_time ? new Date(r.submission_time).toLocaleString() : "—"}</td>
                <td>${vlist.length === 0 ? `<span class="muted">✅ Clean</span>` : `<button class="btn-outline btn-sm" style="color:var(--clay);border-color:var(--clay);" onclick="openViolationLog('${r.id}')">🚩 ${vlist.length}</button>`}</td>
              </tr>`;
            }).join("")}
          </tbody>
        </table>`}
    </div>`;
}

function openViolationLog(attemptId) {
  const vlist = (estate.violationsByAttempt && estate.violationsByAttempt[attemptId]) || [];
  const r = estate.results.find((x) => x.id === attemptId);
  const name = r && r.students ? `${r.students.last_name}, ${r.students.first_name}` : "Student";
  const TYPE_LABEL = { tab_switch: "Switched tab/app", fullscreen_exit: "Exited fullscreen", copy_attempt: "Copy/right-click attempt", devtools_attempt: "Tried to open DevTools" };
  showModal(`
    <h3>Integrity Log — ${escapeHtml(name)}</h3>
    <p class="muted">${vlist.length} violation${vlist.length === 1 ? "" : "s"} recorded during this attempt. This is a deterrent log, not proof of cheating — use your judgment.</p>
    <table>
      <thead><tr><th>Time</th><th>Event</th></tr></thead>
      <tbody>
        ${vlist.map((v) => `<tr><td>${new Date(v.occurred_at).toLocaleTimeString()}</td><td>${escapeHtml(TYPE_LABEL[v.violation_type] || v.violation_type)}</td></tr>`).join("")}
      </tbody>
    </table>
    <div style="display:flex;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Close</button>
    </div>`);
}
