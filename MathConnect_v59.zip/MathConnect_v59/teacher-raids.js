// ============================================================================
// MathConnect — Teacher view of Team Boss Raids
// Read-only. Shows how the class is using the co-op boss fights: totals,
// per-boss results, a per-student table (raids fought, victories, accuracy,
// damage) and a recent-raid log with the whole team named. A grade-wide raid
// can include students from other sections — their names still show in the
// team list (same privacy boundary as before: teachers can see who their own
// students teamed up with), but only YOUR roster is counted in the stats.
// Depends on: state (teacher.js), escapeHtml + fetchAllRowsChecked
// (supabase-client.js), TDRILL_TOPICS (teacher-drills.js).
// ============================================================================

const TRAID_LOG_LIMIT = 40;
var traidLoadErrors = [];

// Same roster as raidEngine.js (the teacher pages don't load student scripts).
const TRAID_BOSSES = {
  basic: ["👹", "Grumbo the Number Ogre"], order: ["🐉", "PEMDAS the Puzzle Dragon"], integers: ["🤖", "Negatron"],
  fractions: ["🦖", "Slice-o-saurus"], decimals: ["🦀", "Dot the Decimal Crab"], algebra: ["🐍", "Vex the Variable Viper"],
  ratio: ["🐗", "Boarus the Mix-Master"], percent: ["🐙", "Markdown the Kraken"], geometry: ["🐊", "Sir Perimeter Gator"],
  patterns: ["🦉", "Cipher the Code Owl"], statistics: ["🕷️", "Median Widow"], probability: ["🦊", "Lady Luck the Fox"],
  exponents: ["🐂", "Powerhorn the Bull"], equations: ["🦍", "Kong-Equal"], factoring: ["🗿", "The Vault Golem"],
  measurement: ["🦂", "Scorpio Scale"], coordinates: ["👻", "The Grid Wraith"], pythagoras: ["🐲", "Hypotenuse the Hydra"],
  mixed: ["👾", "Omega Mathoid — the Grand Boss"],
};
const TRAID_DIFF = { easy: "🟢 Easy", normal: "🟡 Normal", hard: "🔴 Hard" };
function tRaidBoss(topic) { return TRAID_BOSSES[topic] || ["👾", topic]; }
function tRaidStation(topic) {
  if (topic === "mixed") return "Every station";
  const t = typeof TDRILL_TOPICS !== "undefined" ? TDRILL_TOPICS.find((x) => x.key === topic) : null;
  return t ? `${t.icon} ${t.name}` : topic;
}

async function fetchClassRaidData(students) {
  traidLoadErrors = [];
  const ids = students.map((s) => s.id);
  if (!ids.length) return { mine: [], teams: {} };
  const minesRes = await fetchAllRowsChecked(() => supabase.from("boss_raid_members")
    .select("student_id, correct_count, wrong_count, damage_dealt, raid:raid_id(id, topic, difficulty, status, team_size, boss_max_hp, boss_hp, created_at, ended_at, ends_at)")
    .in("student_id", ids));
  if (minesRes.error) traidLoadErrors.push(`raid history (${minesRes.error.message})`);
  const mine = (minesRes.data || []).filter((m) => m.raid);
  // whole teams for the raids that finished — in chunks so the request URL stays short
  const raidIds = Array.from(new Set(mine.filter((m) => m.raid.status === "won" || m.raid.status === "lost").map((m) => m.raid.id)));
  const teams = {};
  for (let i = 0; i < raidIds.length; i += 40) {
    const chunk = raidIds.slice(i, i + 40);
    const res = await fetchAllRowsChecked(() => supabase.from("boss_raid_members")
      .select("raid_id, student_id, correct_count, wrong_count, damage_dealt, student:student_id(full_name)").in("raid_id", chunk));
    if (res.error) { traidLoadErrors.push(`team lists (${res.error.message})`); break; }
    (res.data || []).forEach((r) => { (teams[r.raid_id] = teams[r.raid_id] || []).push(r); });
  }
  return { mine, teams };
}

// Pure — everything the panel shows, computed from the fetched rows.
function computeRaidStats(students, mine, teams) {
  const finished = mine.filter((m) => m.raid.status === "won" || m.raid.status === "lost");
  const live = mine.filter((m) => m.raid.status === "lobby" || m.raid.status === "active");
  const perStudent = {};
  students.forEach((s) => (perStudent[s.id] = { raids: 0, wins: 0, correct: 0, wrong: 0, damage: 0, last: null }));
  finished.forEach((m) => {
    const p = perStudent[m.student_id]; if (!p) return;
    p.raids += 1; if (m.raid.status === "won") p.wins += 1;
    p.correct += m.correct_count; p.wrong += m.wrong_count; p.damage += m.damage_dealt;
    const when = m.raid.ended_at || m.raid.created_at;
    if (!p.last || when > p.last) p.last = when;
  });
  // one entry per raid (a raid with 5 of my students appears once)
  const raids = {};
  finished.forEach((m) => { raids[m.raid.id] = m.raid; });
  const raidList = Object.values(raids).sort((a, b) => String(b.ended_at || b.created_at).localeCompare(String(a.ended_at || a.created_at)));
  const perBoss = {};
  raidList.forEach((r) => {
    const b = (perBoss[r.topic] = perBoss[r.topic] || { raids: 0, wins: 0, correct: 0, total: 0 });
    b.raids += 1; if (r.status === "won") b.wins += 1;
    (teams[r.id] || []).forEach((t) => { b.correct += t.correct_count; b.total += t.correct_count + t.wrong_count; });
  });
  const wins = raidList.filter((r) => r.status === "won").length;
  const liveRaids = new Set(live.map((m) => m.raid.id)).size;
  const played = students.filter((s) => perStudent[s.id].raids > 0);
  const mostActive = played.slice().sort((a, b) => perStudent[b.id].raids - perStudent[a.id].raids)[0] || null;
  const avgTeam = raidList.length ? raidList.reduce((sum, r) => sum + (r.team_size || (teams[r.id] || []).length || 0), 0) / raidList.length : 0;
  return { perStudent, raidList, perBoss, totalRaids: raidList.length, wins, winRate: raidList.length ? Math.round((wins / raidList.length) * 100) : null, liveRaids, mostActive, participants: played.length, avgTeam };
}

function tRaidAcc(c, w) { return c + w > 0 ? Math.round((c / (c + w)) * 100) + "%" : "—"; }
function tRaidFmtDate(iso) { return iso ? new Date(iso).toLocaleDateString("en-PH", { month: "short", day: "numeric" }) : "—"; }

async function renderTeacherRaids() {
  const el = document.getElementById("tab-battles");
  if (!el) return;
  el.innerHTML = `<div class="empty">Loading Boss Raid results…</div>`;
  if (!state.section || !state.students.length) { el.innerHTML = `<div class="empty">No students in this section yet.</div>`; return; }

  const { mine, teams } = await fetchClassRaidData(state.students);
  const st = computeRaidStats(state.students, mine, teams);
  const th = `style="padding:8px;"`;

  el.innerHTML = `
    ${traidLoadErrors.length ? `<div style="border-left:4px solid var(--clay);background:var(--paper);padding:8px 12px;margin-bottom:12px;border-radius:6px;font-size:.85rem;">⚠️ Some data didn't load: ${traidLoadErrors.map((e) => escapeHtml(e)).join("; ")}. Numbers below may be incomplete rather than zero — switch tabs and back to retry.</div>` : ""}
    <div class="card" style="margin-bottom:16px;">
      <h2 style="margin:0 0 4px;">🐉 Boss Raids</h2>
      <p class="muted" style="margin:0;">Students team up (3–8 players) to defeat a station's boss before the clock runs out — every correct answer damages it, every wrong answer heals it. Read-only: students form teams themselves; nothing here needs setup. Locked stations (Admin) can't be raided.</p>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;gap:28px;flex-wrap:wrap;">
        <div><div class="muted">Raids finished</div><h3 style="margin:2px 0;">${st.totalRaids}</h3></div>
        <div><div class="muted">Victories</div><h3 style="margin:2px 0;">${st.wins}${st.winRate !== null ? ` <span class="muted" style="font-size:.85rem;">(${st.winRate}%)</span>` : ""}</h3></div>
        <div><div class="muted">Students who've raided</div><h3 style="margin:2px 0;">${st.participants}/${state.students.length}</h3></div>
        <div><div class="muted">Average team size</div><h3 style="margin:2px 0;">${st.avgTeam ? st.avgTeam.toFixed(1) : "—"}</h3></div>
        <div><div class="muted">Raids in progress now</div><h3 style="margin:2px 0;">${st.liveRaids}</h3></div>
        <div><div class="muted">Most active</div><h3 style="margin:2px 0;">${st.mostActive ? `${escapeHtml(st.mostActive.full_name)} <span class="muted" style="font-size:.85rem;">(${st.perStudent[st.mostActive.id].raids})</span>` : "—"}</h3></div>
      </div>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin:0 0 12px;">Results by boss</h3>
      ${!Object.keys(st.perBoss).length ? `<div class="empty">No finished raids yet.</div>` : `
      <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:.88rem;">
        <thead><tr style="text-align:left;border-bottom:2px solid var(--paper-line);"><th ${th}>Boss</th><th ${th}>Station</th><th ${th}>Raids</th><th ${th}>Victories</th><th ${th}>Win rate</th><th ${th}>Answer accuracy</th></tr></thead>
        <tbody>${Object.entries(st.perBoss).sort((a, b) => b[1].raids - a[1].raids).map(([topic, b]) => {
          const [emoji, name] = tRaidBoss(topic);
          return `<tr style="border-bottom:1px solid var(--paper-line);"><td ${th}>${emoji} ${escapeHtml(name)}</td><td ${th}>${escapeHtml(tRaidStation(topic))}</td><td ${th}>${b.raids}</td><td ${th}>${b.wins}</td><td ${th}>${Math.round((b.wins / b.raids) * 100)}%</td><td ${th}>${tRaidAcc(b.correct, b.total - b.correct)}</td></tr>`;
        }).join("")}</tbody>
      </table></div>`}
    </div>

    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin:0 0 12px;">Class-wide stats</h3>
      <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:.88rem;">
        <thead><tr style="text-align:left;border-bottom:2px solid var(--paper-line);"><th ${th}>Student</th><th ${th}>Raids</th><th ${th}>Victories</th><th ${th}>Correct</th><th ${th}>Wrong</th><th ${th}>Accuracy</th><th ${th}>Damage dealt</th><th ${th}>Last raid</th></tr></thead>
        <tbody>${sortedStudents(state.students).map((s) => {
          const p = st.perStudent[s.id];
          return `<tr style="border-bottom:1px solid var(--paper-line);"><td ${th}>${escapeHtml(s.full_name)}</td><td ${th}>${p.raids}</td><td ${th}>${p.wins}</td><td ${th}>${p.correct}</td><td ${th}>${p.wrong}</td><td ${th}>${tRaidAcc(p.correct, p.wrong)}</td><td ${th}>${p.damage}</td><td ${th}>${tRaidFmtDate(p.last)}</td></tr>`;
        }).join("")}</tbody>
      </table></div>
    </div>

    <div class="card">
      <h3 style="margin:0 0 12px;">Recent raids</h3>
      ${!st.raidList.length ? `<div class="empty">No raids yet.</div>` : `
      ${st.raidList.length > TRAID_LOG_LIMIT ? `<p class="muted" style="margin:0 0 8px;">Showing the ${TRAID_LOG_LIMIT} most recent of ${st.raidList.length}. The stats above count all of them.</p>` : ""}
      <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:.88rem;">
        <thead><tr style="text-align:left;border-bottom:2px solid var(--paper-line);"><th ${th}>When</th><th ${th}>Boss</th><th ${th}>Level</th><th ${th}>Team</th><th ${th}>Result</th></tr></thead>
        <tbody>${st.raidList.slice(0, TRAID_LOG_LIMIT).map((r) => {
          const [emoji, name] = tRaidBoss(r.topic);
          const team = (teams[r.id] || []).slice().sort((a, b) => b.damage_dealt - a.damage_dealt);
          const won = r.status === "won";
          const spare = won && r.ends_at && r.ended_at ? Math.max(0, Math.round((Date.parse(r.ends_at) - Date.parse(r.ended_at)) / 1000)) : null;
          return `<tr style="border-bottom:1px solid var(--paper-line);vertical-align:top;">
            <td ${th}>${tRaidFmtDate(r.ended_at || r.created_at)}</td>
            <td ${th}>${emoji} ${escapeHtml(name)}</td>
            <td ${th}>${TRAID_DIFF[r.difficulty] || r.difficulty}</td>
            <td ${th}>${team.map((t) => `${escapeHtml((t.student && t.student.full_name) || "?")} <span class="muted">(${t.damage_dealt})</span>`).join(", ") || "—"}</td>
            <td ${th} style="padding:8px;color:${won ? "var(--forest)" : "var(--clay)"};font-weight:700;">${won ? `🏆 Won${spare !== null ? ` · ${Math.floor(spare / 60)}:${String(spare % 60).padStart(2, "0")} left` : ""}` : `💀 Boss survived (${r.boss_max_hp ? Math.round((r.boss_hp / r.boss_max_hp) * 100) : "?"}% HP)`}</td>
          </tr>`;
        }).join("")}</tbody>
      </table></div>`}
    </div>`;
}
