# MathConnect v55 — 18 Intelligent Practice domains + Legendary Pet certificates

Builds on v54. **One new migration:** `migration-62-practice-domains-18-and-pet-certificates.sql`
(run after migrations 25 and 61; safe to re-run).

## 1. Intelligent Practice now matches Math Drills (12 → 18)
Six new adaptive domains, keyed like the six Drill stations added in migration-47, so both modes cover the same 18 areas:

| Domain | Easy → Expert (4 adaptive tiers) |
|---|---|
| ⚡ Exponents & Radicals | n² / n³ → exponent laws (× and ÷ same base) → square & cube roots → power of a power, zero exponent, scientific notation |
| ⚖️ Equation Scale | x + a = b → ax = b → ax ± b = c (negatives allowed) → a(x + b) = c and x on both sides |
| 🧩 Factor Vault | GCF of two numbers → factor out a GCF → difference of squares → trinomials / perfect squares |
| 🌾 Farm Measure | km/m/cm and kg/g → cm→m, g→kg, L→mL → hectares ↔ m² → fertilizer/application rates |
| 📈 Grid Navigator | distance on a grid line → slope (integer) → y-intercept of y = mx + b → slope as a reduced fraction |
| 📐 Surveyor's Post | 3-4-5 diagonal fence → missing leg (ladder) → bigger triples & both directions → non-perfect triangles (round to 0.1) |

* Same engine as before: adaptive tier by last 5 answers, 0–100 mastery bar, one retry, 8-question sessions, certificates at 8/8.
* **Smarter hints for the new domains.** `diagnosisEngine.js` accepts optional per-question `commonMistakes`, and five new
  hint types (with matching labels in the teacher's Learning Heatmap): *exponent-rule slips*, *wrong inverse operation*,
  *forgot the square root*, *unit-conversion slips*, *rise/run flipped*.
* Lists updated: `learningEngine.js` (LE_DOMAINS + generators), `teacher-learning-heatmap.js`, `admin.js` (lock/unlock card).
* Verified with a Node harness: **12,000 generated questions** (6 domains × 4 tiers × 500) — every answer round-trips through
  `checkAnswer`, no NaN/blank prompts, integers stay integers, and the "likely mistake" hints fire for the intended wrong answers.
* The six domains ship **unlocked** (same as the six matching Drill stations). Lock any of them from Admin → Intelligent Practice Domains.
* ⚠️ Heads-up: the Archimedes Trial / Grand Champion formulas (migrations 44/53) count every *active* practice domain, so
  "expert in every Intelligent Practice domain" now means 18 domains — mirroring the Trial's existing all-18-Drill-stations rule.

## 2. 🐾 Legendary Pet certificates — one per Legendary pet
* A pet reaching **Legendary** (growth_points ≥ 5000) earns its owner a **Certificate of Award · Legendary Pet**
  (teal seal). It is **one certificate per pet** — raise a second Legendary pet and you get a second certificate.
* Issued the moment the pet evolves (a "🎓 View & Print" strip appears in the evolution ceremony), **and** caught up automatically
  the next time the student opens the app — so pets that were *already* Legendary get their certificate without any replay.
* The certificate shows the student, section, pet name, Legendary form (e.g. Qinglong), growth points and adoption month,
  with the pet's own artwork as a soft watermark, plus the same date / seal / subject-teacher signature block and PDF / Print / image export.
* Shows up in 🎓 My Certificates under a new **🐾 Legendary Pets** filter, from a "🎓 Legendary Pet Certificate" button on the Legendary banner in My Pet,
  and in the teacher's Certificates tab (new chip, "Legendary Pet" type filter and a "Legendary pets" count).
* If migration-62 hasn't been run yet, the certificate is kept on the student's device and uploaded to the database on their next visit after it is.

## Files
New: `migration-62-practice-domains-18-and-pet-certificates.sql`
Changed: `learningEngine.js`, `diagnosisEngine.js`, `teacher-learning-heatmap.js`, `admin.js`, `certificateEngine.js`,
`petEngine.js`, `petEvolution.js`, `pet-ui.js`, `teacher-certificates.js`, `README.md`, `service-worker.js` (cache → v55-1)

## Deploy
1. Supabase → SQL Editor → run `migration-62-practice-domains-18-and-pet-certificates.sql`.
2. Redeploy the folder. Students may need one refresh to pick up the new cache.
