-- ============================================================================
-- MathConnect — Migration 61: Station Certificates (v53)
-- ----------------------------------------------------------------------------
-- Every successful station completion in Math Drills, Quest Mode and
-- Intelligent Practice earns the student a printable certificate (Completion /
-- Award). This table is the student's certificate shelf, so they can re-open,
-- download (PDF) and print any certificate later.
--
--   • One row per (student, source, station, level). Replaying a station you
--     already hold a certificate for keeps the BEST result — the row is only
--     updated when the new run is more accurate.
--   • The identity fields (name, section, teacher…) are snapshotted at issue
--     time so an old certificate never changes if a name/section is edited.
--   • Same security model as drill_progress / quest_progress (students are
--     anon-key requests): open read/insert/update, teacher/admin delete.
--
-- SAFE TO RE-RUN. If you have not run this yet, the app still works: it falls
-- back to keeping certificates on the student's own device until you do.
-- ============================================================================

create table if not exists station_certificates (
  id                uuid primary key default gen_random_uuid(),
  student_id        uuid not null references students(id) on delete cascade,
  source            text not null check (source in ('drills','quest','practice')),
  station_key       text not null,          -- drill topic key / quest chapter key / practice domain key
  level_key         text not null,          -- 'L4' (drill/quest level), 'T3' (practice tier), 'chapter' (whole quest chapter)
  station_name      text not null,          -- e.g. "Fractions", "The Locked Cabinet"
  level_label       text,                   -- e.g. "Level 4 of 15", "Hard"
  kind              text not null default 'completion'
                    check (kind in ('completion','excellence','perfect','chapter')),
  correct_count     integer,
  total_questions   integer,
  accuracy          integer,                -- whole percent, 0-100
  extra             jsonb not null default '{}'::jsonb,   -- printed detail lines + stat boxes
  student_name      text not null,
  section_name      text,
  grade_level       text,
  school_year       text,
  subject           text,
  teacher_name      text,
  teacher_position  text,
  cert_no           text not null unique,   -- printed on the certificate, e.g. MC-2610-DR-8F3K2A
  earned_at         timestamptz not null default now(),
  unique (student_id, source, station_key, level_key)
);

create index if not exists station_certificates_student_idx
  on station_certificates (student_id, earned_at desc);

alter table station_certificates enable row level security;

drop policy if exists "public read station_certificates" on station_certificates;
create policy "public read station_certificates" on station_certificates for select using (true);
drop policy if exists "anyone insert station_certificates" on station_certificates;
create policy "anyone insert station_certificates" on station_certificates for insert with check (true);
drop policy if exists "anyone update station_certificates" on station_certificates;
create policy "anyone update station_certificates" on station_certificates for update using (true);
drop policy if exists "teacher delete station_certificates" on station_certificates;
create policy "teacher delete station_certificates" on station_certificates for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ============================================================================
-- Done. Nothing else to configure — students will see a "🎓 My Certificates"
-- button in Math Drills, Quest Mode and Intelligent Practice.
-- ============================================================================
