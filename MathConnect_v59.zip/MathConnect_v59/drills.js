// ============================================================================
// MathConnect — Math Drill Arena
// A dynamic, level-based drill game covering: Basic Operations, Order of
// Operations, Integers, Fractions, Decimals, and Algebraic Expressions.
// Point system + streak/speed bonuses + Mystery Box surprise events +
// a top-10 leaderboard scoped to the student's own grade level.
// Depends on: supabase-client.js (supabase, escapeHtml, toast), auth.js/
// student.js (sstate: session/student/section already loaded).
// ============================================================================

const DRILL_TOPICS = [
  { key: "basic", icon: "➕", name: "Basic Operations", desc: "Addition, subtraction, multiplication, division" },
  { key: "order", icon: "🔢", name: "Order of Operations", desc: "PEMDAS / GEMDAS — sequence it right" },
  { key: "integers", icon: "➖", name: "Integers", desc: "Signed numbers (positive & negative)" },
  { key: "fractions", icon: "🍕", name: "Fractions", desc: "Add, subtract, multiply, divide" },
  { key: "decimals", icon: "💯", name: "Decimals", desc: "Add, subtract, multiply, divide" },
  { key: "algebra", icon: "🅧", name: "Algebraic Expressions", desc: "Simplify & evaluate" },
  // ---- Term 2 additions (migration-22) — each pairs a real-world theme with
  // its own mechanic twist on top of the same 15-level foundational-skill
  // ramp. Admin can lock/unlock each of these school-wide from admin.html
  // until the class is ready for it (see DRILL_STATION_LOCK_DEFAULT below). ----
  { key: "ratio", icon: "⚖️", name: "Ratio & Proportion", desc: "Farm Mix — reduce ratios & solve proportions", isNew: true },
  { key: "percent", icon: "💸", name: "Percent", desc: "Market Day — discounts, mark-ups & tax", isNew: true },
  { key: "geometry", icon: "📐", name: "Geometry", desc: "Farm Plot — perimeter, area & volume (with diagrams)", isNew: true },
  { key: "patterns", icon: "🧩", name: "Patterns & Sequences", desc: "Code Breaker — find the next term or the rule", isNew: true },
  { key: "statistics", icon: "📊", name: "Statistics", desc: "Data Detective — mean, median, mode & range", isNew: true },
  { key: "probability", icon: "🎡", name: "Probability", desc: "Harvest Gamble — chance, spinners & dice (with diagrams)", isNew: true },
  // ---- High School expansion (migration-47) — 6 foundational JHS/SHS-
  // transition stations, still on the same 15-level ramp as everything
  // above. See genExponents/genEquations/genFactoring/genMeasurement/
  // genCoordinates/genPythagoras further down. ----
  { key: "exponents", icon: "⚡", name: "Exponents & Radicals", desc: "Laws of exponents, roots, radicals & scientific notation", isNew: true },
  { key: "equations", icon: "⚖️", name: "Equation Scale", desc: "Linear equations — solve for x", isNew: true },
  { key: "factoring", icon: "🧩", name: "Factor Vault", desc: "GCF, difference of squares & quadratic factoring", isNew: true },
  { key: "measurement", icon: "🌾", name: "Farm Measure", desc: "Metric conversions & farm application rates", isNew: true },
  { key: "coordinates", icon: "📈", name: "Grid Navigator", desc: "Cartesian plane, slope & y-intercepts", isNew: true },
  { key: "pythagoras", icon: "📐", name: "Surveyor's Post", desc: "Pythagorean Theorem — farm boundary fencing", isNew: true },
];
const DRILL_MAX_LEVEL = 15; // aligned to the MathLegends 15-tier rank ceiling (rankEngine.js RANK_MAX_TIER)
const DRILL_RUN_LENGTH = 10;
const DRILL_MYSTERY_AFTER = [4, 8]; // a Mystery Box appears after the 4th and 8th question

// ============================================================================
// IN-GAME SURPRISES (migration-47) — Golden Question, Pet Assist, Fever Rush
// Combo Mode, and the Wheel of Archimedes. All purely client-side session
// mechanics layered on top of the existing question/score flow above; none
// of them touch skill_proficiency or mastery data.
// ============================================================================
const GOLDEN_QUESTION_SLOTS = [5, 8];   // candidate question numbers (1-indexed)
const GOLDEN_QUESTION_CHANCE = 0.25;    // 25% chance a candidate slot actually rolls Golden
const GOLDEN_QUESTION_MULTIPLIER = 3;
const PET_ASSIST_AFTER_SECONDS = 15;    // idle time before the pet offers help
const FEVER_STREAK_NEEDED = 3;          // consecutive sub-5s correct answers to trigger Fever
const FEVER_ANSWER_SECONDS = 5;
const FEVER_MULTIPLIER = 2;

// ============================================================================
// MATHLEGENDS OVERALL RANK now lives in rankEngine.js (RANK_TIERS,
// rankTierByLevel, renderRankBadge, awardMasteryStars) — loaded before this
// file. It's a star-driven ladder, separate from each station's 1-10 level
// below (which still purely controls question difficulty per topic).
// ============================================================================
// Stars awarded per drill run, based on accuracy on that run.
function starsForDrillRun(accuracy, leveledUp) {
  if (accuracy >= 1) return 2;                  // flawless run
  if (accuracy >= 0.8 && leveledUp) return 1;    // solid run that pushed the station level up
  return 0;
}

var dstate = { progress: null, loaded: false, locks: {}, locksLoaded: false };

// ============================================================================
// STATION LOCKS (admin-controlled, school-wide) — see migration-22.
// Locked stations are hidden behind a 🔒 card; students can't start a run,
// and their level/points still show so nothing is lost once unlocked.
// ============================================================================
async function loadStationLocks() {
  const { data } = await supabase.from("drill_station_locks").select("station_key, locked, note");
  const map = {};
  (data || []).forEach((r) => (map[r.station_key] = { locked: r.locked, note: r.note }));
  dstate.locks = map;
  dstate.locksLoaded = true;
}
function isStationLocked(topicKey) {
  const l = dstate.locks[topicKey];
  return !!(l && l.locked);
}
var dgame = null; // active-run state, created fresh by startDrillRun()

// ============================================================================
// RANDOM / MATH HELPERS
// ============================================================================
function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function pick(arr) { return arr[randInt(0, arr.length - 1)]; }
function randSignedInt(range) { return pick([1, -1]) * randInt(1, range); }
function fmtInt(n) { return n < 0 ? `(${n})` : `${n}`; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a || 1; }
function reduceFrac(f) {
  let { n, d } = f;
  if (d < 0) { n = -n; d = -d; }
  const g = gcd(n, d);
  return { n: n / g, d: d / g };
}
function fracToString(f) { return f.d === 1 ? `${f.n}` : `${f.n}/${f.d}`; }
function randFrac(maxD) { const d = randInt(2, maxD); const n = randInt(1, d - 1); return { n, d }; }
function fracGTE(a, b) { return a.n * b.d >= b.n * a.d; }
function addFracRaw(a, b) { return { n: a.n * b.d + b.n * a.d, d: a.d * b.d }; }
function subFracRaw(a, b) { return { n: a.n * b.d - b.n * a.d, d: a.d * b.d }; }
function mulFracRaw(a, b) { return { n: a.n * b.n, d: a.d * b.d }; }
function divFracRaw(a, b) { return { n: a.n * b.d, d: a.d * b.n }; }

function parseFractionAnswer(raw) {
  let s = String(raw || "").trim();
  if (!s) return null;
  let neg = false;
  if (s.startsWith("-")) { neg = true; s = s.slice(1).trim(); }
  let m;
  if ((m = /^(\d+)\s+(\d+)\/(\d+)$/.exec(s))) {
    const whole = +m[1], n = +m[2], d = +m[3];
    if (!d) return null;
    let num = whole * d + n;
    return { n: neg ? -num : num, d };
  }
  if ((m = /^(\d+)\/(\d+)$/.exec(s))) {
    const n = +m[1], d = +m[2];
    if (!d) return null;
    return { n: neg ? -n : n, d };
  }
  if ((m = /^(\d+)$/.exec(s))) {
    const n = +m[1];
    return { n: neg ? -n : n, d: 1 };
  }
  return null;
}

// ============================================================================
// QUESTION GENERATORS — one per topic, difficulty scales with `level` (1-15)
// ============================================================================
function genBasic(level) {
  const ops = level <= 3 ? ["+", "-"] : level <= 6 ? ["+", "-", "×"] : ["+", "-", "×", "÷"];
  const op = pick(ops);
  const maxRange = 9 + level * 9;
  let a, b, answer;
  if (op === "+") { a = randInt(1, maxRange); b = randInt(1, maxRange); answer = a + b; }
  else if (op === "-") { a = randInt(1, maxRange); b = randInt(1, a); answer = a - b; }
  else if (op === "×") { const maxF = 5 + level * 2; a = randInt(2, maxF); b = randInt(2, maxF); answer = a * b; }
  else { const maxF = 4 + level * 2; b = randInt(2, maxF); const q = randInt(2, maxF); a = b * q; answer = q; }
  return { prompt: `${a} ${op} ${b} = ?`, type: "integer", answer };
}

function genOrder(level) {
  if (level <= 2) {
    const a = randInt(1, 9), b = randInt(1, 9), c = randInt(1, 9);
    return { prompt: `${a} + ${b} × ${c} = ?`, type: "integer", answer: a + b * c };
  }
  if (level <= 4) {
    const a = randInt(1, 9), b = randInt(1, 9), d = randInt(2, 6), q = randInt(1, 6), c = d * q;
    return { prompt: `${a} × ${b} - ${c} ÷ ${d} = ?`, type: "integer", answer: a * b - q };
  }
  if (level <= 6) {
    const a = randInt(1, 9), b = randInt(1, 9), c = randInt(2, 9), d = randInt(1, 9);
    return { prompt: `(${a} + ${b}) × ${c} - ${d} = ?`, type: "integer", answer: (a + b) * c - d };
  }
  if (level <= 8) {
    const a = randInt(2, 9), b = randInt(4, 9), c = randInt(1, b - 1), e = randInt(2, 6), q = randInt(1, 6), d = e * q;
    return { prompt: `${a} × (${b} - ${c}) + ${d} ÷ ${e} = ?`, type: "integer", answer: a * (b - c) + q };
  }
  if (level <= 10) {
    const a = randInt(1, 9), b = randInt(1, 9), c = randInt(4, 9), d = randInt(1, c - 1), f = randInt(2, 6), q = randInt(1, 6), e = f * q;
    return { prompt: `(${a} + ${b}) × (${c} - ${d}) + ${e} ÷ ${f} = ?`, type: "integer", answer: (a + b) * (c - d) + q };
  }
  if (level <= 12) {
    const a = randInt(4, 9), b = randInt(4, 9), c = randInt(3, 9), e = randInt(2, 4), q = randInt(1, 5), inner = (a + b) * c, d = inner - e * q, f = randInt(1, 9);
    return { prompt: `((${a} + ${b}) × ${c} - ${d}) ÷ ${e} + ${f} = ?`, type: "integer", answer: q + f };
  }
  const a = randInt(3, 12), b = randInt(2, 9), c = randInt(2, 9), d = randInt(2, 9), f = randInt(2, 6), q = randInt(1, 6), e = f * q;
  return { prompt: `${a}² - (${b} + ${c}) × ${d} + ${e} ÷ ${f} = ?`, type: "integer", answer: a * a - (b + c) * d + q };
}

function genIntegers(level) {
  const range = 8 + level * 4;
  if (level <= 3) {
    const a = randSignedInt(range), b = randSignedInt(range), op = pick(["+", "-"]);
    const answer = op === "+" ? a + b : a - b;
    return { prompt: `${fmtInt(a)} ${op} ${fmtInt(b)} = ?`, type: "integer", answer };
  }
  if (level <= 6) {
    const a = randSignedInt(range), b = randSignedInt(range), c = randSignedInt(Math.round(range / 2));
    const op1 = pick(["+", "-"]), op2 = pick(["+", "-"]);
    const mid = op1 === "+" ? a + b : a - b;
    const answer = op2 === "+" ? mid + c : mid - c;
    return { prompt: `${fmtInt(a)} ${op1} ${fmtInt(b)} ${op2} ${fmtInt(c)} = ?`, type: "integer", answer };
  }
  if (level <= 8) {
    const a = randSignedInt(12), b = randSignedInt(12);
    return { prompt: `${fmtInt(a)} × ${fmtInt(b)} = ?`, type: "integer", answer: a * b };
  }
  if (level <= 10) {
    const bAbs = randInt(2, 12), b = pick([1, -1]) * bAbs, q = randSignedInt(12), a = b * q;
    return { prompt: `${fmtInt(a)} ÷ ${fmtInt(b)} = ?`, type: "integer", answer: q };
  }
  if (level <= 12) {
    const a = randSignedInt(12), b = randSignedInt(12), c = randSignedInt(10), d = randSignedInt(10);
    return { prompt: `${fmtInt(a)} × ${fmtInt(b)} + ${fmtInt(c)} × ${fmtInt(d)} = ?`, type: "integer", answer: a * b + c * d };
  }
  const bAbs = randInt(2, 9), b = pick([1, -1]) * bAbs, q = randSignedInt(12), a = b * q, c = randSignedInt(9), d = randSignedInt(9);
  return { prompt: `${fmtInt(a)} ÷ ${fmtInt(b)} + ${fmtInt(c)} × ${fmtInt(d)} = ?`, type: "integer", answer: q + c * d };
}

function genFractions(level) {
  const hint = "Enter as a fraction (e.g. 3/4), a whole number, or a mixed number (e.g. 1 1/2).";
  if (level <= 2) {
    const d = randInt(2, 6);
    let f1 = { n: randInt(1, d - 1), d }, f2 = { n: randInt(1, d - 1), d };
    const op = pick(["+", "-"]);
    if (op === "-" && !fracGTE(f1, f2)) [f1, f2] = [f2, f1];
    const raw = op === "+" ? addFracRaw(f1, f2) : subFracRaw(f1, f2);
    return { prompt: `${fracToString(f1)} ${op} ${fracToString(f2)} = ?`, type: "fraction", answer: reduceFrac(raw), hint };
  }
  if (level <= 4) {
    let f1 = randFrac(8), f2 = randFrac(8);
    const op = pick(["+", "-"]);
    if (op === "-" && !fracGTE(f1, f2)) [f1, f2] = [f2, f1];
    const raw = op === "+" ? addFracRaw(f1, f2) : subFracRaw(f1, f2);
    return { prompt: `${fracToString(f1)} ${op} ${fracToString(f2)} = ?`, type: "fraction", answer: reduceFrac(raw), hint };
  }
  if (level <= 6) {
    const f1 = randFrac(6), f2 = randFrac(6);
    return { prompt: `${fracToString(f1)} × ${fracToString(f2)} = ?`, type: "fraction", answer: reduceFrac(mulFracRaw(f1, f2)), hint };
  }
  if (level <= 8) {
    const f1 = randFrac(6), f2 = randFrac(6);
    return { prompt: `${fracToString(f1)} ÷ ${fracToString(f2)} = ?`, type: "fraction", answer: reduceFrac(divFracRaw(f1, f2)), hint };
  }
  if (level <= 10) {
    // Similar fractions (same denominator) inside the parentheses — the
    // combined-operation structure is already the harder part of this
    // problem, so the addition itself shouldn't also require finding an LCD.
    const d = randInt(2, 6);
    const f1 = { n: randInt(1, d - 1), d }, f2 = { n: randInt(1, d - 1), d };
    const f3 = randFrac(6);
    const step1 = reduceFrac(addFracRaw(f1, f2));
    const raw = mulFracRaw(step1, f3);
    return { prompt: `(${fracToString(f1)} + ${fracToString(f2)}) × ${fracToString(f3)} = ?`, type: "fraction", answer: reduceFrac(raw), hint };
  }
  if (level <= 12) {
    const f1 = randFrac(8), f2 = randFrac(8);
    const step1 = reduceFrac(divFracRaw(f1, f2));
    // f3 is generated as a fraction similar to (same denominator as) the
    // division's result, so the final "+" combines similar fractions.
    const step1d = step1.d >= 2 ? step1.d : randInt(3, 8);
    const f3 = { n: randInt(1, step1d - 1), d: step1d };
    const raw = addFracRaw(step1, f3);
    return { prompt: `(${fracToString(f1)} ÷ ${fracToString(f2)}) + ${fracToString(f3)} = ?`, type: "fraction", answer: reduceFrac(raw), hint };
  }
  // Similar fractions inside the innermost parentheses, and f4 generated
  // similar to the division step's result for the final subtraction —
  // same reasoning as the two branches above.
  const d1 = randInt(2, 6);
  const f1 = { n: randInt(1, d1 - 1), d: d1 }, f2 = { n: randInt(1, d1 - 1), d: d1 };
  const f3 = randFrac(8);
  const step1 = reduceFrac(addFracRaw(f1, f2));
  const step2 = reduceFrac(divFracRaw(step1, f3));
  const step2d = step2.d >= 2 ? step2.d : randInt(3, 8);
  const f4 = { n: randInt(1, step2d - 1), d: step2d };
  const raw = subFracRaw(step2, f4);
  return { prompt: `((${fracToString(f1)} + ${fracToString(f2)}) ÷ ${fracToString(f3)}) - ${fracToString(f4)} = ?`, type: "fraction", answer: reduceFrac(raw), hint };
}

function genDecimals(level) {
  const maxWhole = 3 + level * 2;
  const ops = level <= 3 ? ["+", "-"] : level <= 6 ? ["+", "-", "×"] : ["+", "-", "×", "÷"];
  const op = pick(ops);
  // Multiplication/division keep the randomized operands to 1 decimal place
  // regardless of level — two-decimal-place factors make the multiplication
  // itself needlessly tedious rather than testing the actual skill being
  // drilled. Addition/subtraction still scale up to 2 decimal places at
  // higher levels.
  const dp = (op === "×" || op === "÷") ? 1 : (level <= 3 ? 1 : 2);
  const scale = dp === 1 ? 10 : 100;
  const randDec = () => +(randInt(0, maxWhole) + randInt(0, scale - 1) / scale).toFixed(dp);
  let a = randDec(), b = randDec(), answer;
  if (op === "+") { answer = +(a + b).toFixed(2); }
  else if (op === "-") { if (a < b) [a, b] = [b, a]; answer = +(a - b).toFixed(2); }
  else if (op === "×") { answer = +(a * b).toFixed(2); }
  else {
    b = +(randInt(1, 9) / 10).toFixed(1) || 0.1;
    const q = +(randInt(1, maxWhole) + randInt(0, 9) / 10).toFixed(1);
    a = +(b * q).toFixed(2);
    answer = +q.toFixed(2);
  }
  return { prompt: `${a} ${op} ${b} = ?`, type: "decimal", answer, tolerance: 0.05, hint: "Round to 2 decimal places if needed." };
}

function genAlgebra(level) {
  if (level <= 2) {
    const a = randInt(2, 9), b = randInt(1, 12), xx = randInt(1, 9);
    return { prompt: `If x = ${xx}, find the value of ${a}x + ${b}.`, type: "integer", answer: a * xx + b };
  }
  if (level <= 4) {
    const a = randInt(2, 9), b = randInt(2, 9), c = randInt(1, 12), xx = randInt(1, 9);
    return { prompt: `If x = ${xx}, find the value of ${a}x + ${b}x - ${c}. (Combine like terms first!)`, type: "integer", answer: (a + b) * xx - c };
  }
  if (level <= 6) {
    const a = randInt(2, 9), b = randInt(1, 9), xx = randInt(1, 9);
    return { prompt: `If x = ${xx}, find the value of ${a}(x + ${b}).`, type: "integer", answer: a * (xx + b) };
  }
  if (level <= 8) {
    const xx = randInt(-6, 9), a = randInt(2, 6), b = randInt(1, 9);
    return { prompt: `If x = ${xx}, find the value of x² + ${a}x - ${b}.`, type: "integer", answer: xx * xx + a * xx - b };
  }
  if (level <= 10) {
    const a = randInt(2, 9), b = randInt(2, 9), c = randInt(1, 9), xx = randInt(-5, 8), yy = randInt(-5, 8);
    return { prompt: `If x = ${xx} and y = ${yy}, find the value of ${a}x + ${b}y - ${c}.`, type: "integer", answer: a * xx + b * yy - c };
  }
  if (level <= 12) {
    const a = randInt(2, 6), b = randInt(2, 9), c = randInt(1, 9), xx = randInt(-6, 8), yy = randInt(-5, 8);
    return { prompt: `If x = ${xx} and y = ${yy}, find the value of ${a}x² + ${b}y - ${c}.`, type: "integer", answer: a * xx * xx + b * yy - c };
  }
  const a = randInt(2, 5), b = randInt(2, 5), c = randInt(1, 9), xx = randInt(-5, 7), yy = randInt(-5, 7);
  return { prompt: `If x = ${xx} and y = ${yy}, find the value of ${a}x² + ${b}y² - ${c}.`, type: "integer", answer: a * xx * xx + b * yy * yy - c };
}

// ============================================================================
// TERM 2 ADDITIONS — 6 new stations, each with its own theme + mechanic twist
// on top of the same 15-level foundational-skill ramp used above.
// ============================================================================

// ---- small inline SVG helpers (Geometry + Probability stations) ----
function svgRect(w, h, unit) {
  const maxW = 200, maxH = 110;
  const scale = Math.min(maxW / w, maxH / h);
  const W = w * scale, H = h * scale;
  const x = (260 - W) / 2, y = (160 - H) / 2;
  return `<svg viewBox="0 0 260 160" xmlns="http://www.w3.org/2000/svg" style="max-width:240px;">
    <rect x="${x}" y="${y}" width="${W}" height="${H}" fill="none" stroke="var(--forest-dark)" stroke-width="3"/>
    <text x="130" y="${Math.max(14, y - 8)}" text-anchor="middle" fill="var(--forest-dark)" font-size="13">${w} ${unit}</text>
    <text x="${Math.max(14, x - 8)}" y="${y + H / 2}" text-anchor="end" fill="var(--forest-dark)" font-size="13">${h} ${unit}</text>
  </svg>`;
}
function svgTriangle(b, h, unit) {
  return `<svg viewBox="0 0 260 160" xmlns="http://www.w3.org/2000/svg" style="max-width:240px;">
    <polygon points="30,140 230,140 130,30" fill="none" stroke="var(--forest-dark)" stroke-width="3"/>
    <text x="130" y="155" text-anchor="middle" fill="var(--forest-dark)" font-size="13">${b} ${unit} base</text>
    <text x="188" y="82" text-anchor="middle" fill="var(--forest-dark)" font-size="13">${h} ${unit} height</text>
  </svg>`;
}
function svgCircle(r, unit) {
  return `<svg viewBox="0 0 260 160" xmlns="http://www.w3.org/2000/svg" style="max-width:240px;">
    <circle cx="130" cy="80" r="55" fill="none" stroke="var(--forest-dark)" stroke-width="3"/>
    <line x1="130" y1="80" x2="185" y2="80" stroke="var(--forest-dark)" stroke-width="2"/>
    <text x="158" y="72" text-anchor="middle" fill="var(--forest-dark)" font-size="13">${r} ${unit}</text>
  </svg>`;
}
function svgDie() {
  return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" style="max-width:90px;">
    <rect x="10" y="10" width="80" height="80" rx="12" fill="none" stroke="var(--forest-dark)" stroke-width="4"/>
    <circle cx="30" cy="30" r="6" fill="var(--forest-dark)"/><circle cx="70" cy="30" r="6" fill="var(--forest-dark)"/>
    <circle cx="50" cy="50" r="6" fill="var(--forest-dark)"/>
    <circle cx="30" cy="70" r="6" fill="var(--forest-dark)"/><circle cx="70" cy="70" r="6" fill="var(--forest-dark)"/>
  </svg>`;
}
function shuffleArr(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = randInt(0, i); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

// ---------------------------------------------------------------------------
// STATION 7 — Ratio & Proportion  ("⚖️ Farm Mix")
// Twist: every question is a scaled ratio/proportion word problem instead of
// a bare "a:b = c:d" — students solve real mixing/pricing scenarios.
// ---------------------------------------------------------------------------
const RATIO_ITEMS = [["fertilizer", "water"], ["chicken feed", "water"], ["cement", "sand"], ["red corn seeds", "yellow corn seeds"], ["vinegar", "sugar"], ["day-old chicks", "hens"]];
function genRatio(level) {
  const hint = "Ratios reduce like fractions — enter as a fraction in lowest terms (e.g. 3/4) unless asked for a whole number.";
  const [itemA, itemB] = pick(RATIO_ITEMS);
  if (level <= 2) {
    const n = randInt(1, 6), d = randInt(n + 1, 9), scale = randInt(2, 5);
    return { prompt: `A farmer mixes ${itemA} to ${itemB} at ${n * scale} : ${d * scale}. Write this ratio in lowest terms.`, type: "fraction", answer: reduceFrac({ n, d }), hint };
  }
  if (level <= 4) {
    const n = randInt(2, 9), d = randInt(2, 9), scale = randInt(2, 6);
    return { prompt: `${n} : ${d} = ${n * scale} : x — solve for x.`, type: "integer", answer: d * scale };
  }
  if (level <= 6) {
    const partA = randInt(2, 9), partB = randInt(2, 9), scale = randInt(2, 8);
    return { prompt: `A mix uses ${partA} parts ${itemA} for every ${partB} parts ${itemB}. If you use ${partA * scale} L of ${itemA}, how many L of ${itemB} are needed?`, type: "integer", answer: partB * scale };
  }
  if (level <= 8) {
    const partA = randInt(2, 9), partB = randInt(2, 9), scale = randInt(2, 9);
    return { prompt: `${itemA} and ${itemB} are mixed ${partA}:${partB}. A batch has ${(partA + partB) * scale} L total. How many L of ${itemA} is that?`, type: "integer", answer: partA * scale };
  }
  if (level <= 10) {
    const price = randInt(4, 45), units = randInt(2, 15);
    return { prompt: `${itemA} costs ₱${price} per kg. At that same rate, how much for ${units} kg (₱)?`, type: "integer", answer: price * units };
  }
  if (level <= 12) {
    const n = randInt(1, 5), d = randInt(n + 1, 9), scale = randInt(2, 8);
    return { prompt: `${itemA} : ${itemB} = ${n} : ${d}. If there are ${n * scale} units of ${itemA}, how many units in total (${itemA} + ${itemB})?`, type: "integer", answer: n * scale + d * scale };
  }
  const a = randInt(2, 6), b = randInt(2, 6), c = randInt(2, 6), scale = randInt(2, 6);
  return { prompt: `A 3-way mix of ${itemA}, ${itemB}, and water is ${a}:${b}:${c}. The total mixture is ${(a + b + c) * scale} L. How many L of ${itemA}?`, type: "integer", answer: a * scale };
}

// ---------------------------------------------------------------------------
// STATION 8 — Percent  ("💸 Market Day")
// Twist: every question is a peso market scenario (discounts, mark-ups,
// tax, or working backwards from a sale price) instead of a bare "x% of y".
// ---------------------------------------------------------------------------
const MARKET_ITEMS = ["a sack of rice", "a tray of eggs", "vegetables", "chicken feed", "fertilizer", "seedlings"];
function genPercent(level) {
  const item = pick(MARKET_ITEMS);
  if (level <= 2) {
    const base = randInt(5, 20) * 20, pct = pick([10, 20, 25, 50]); // base is a multiple of 20 so every pct divides evenly
    return { prompt: `${pct}% of ₱${base} = ?`, type: "integer", answer: (base * pct) / 100 };
  }
  if (level <= 4) {
    const price = randInt(10, 50) * 10, pct = pick([5, 10, 15, 20, 25]);
    return { prompt: `${item.charAt(0).toUpperCase() + item.slice(1)} originally ₱${price} is on sale at ${pct}% off. What's the sale price (₱)?`, type: "integer", answer: price - Math.round(price * pct / 100) };
  }
  if (level <= 6) {
    const price = randInt(10, 50) * 10, pct = pick([5, 10, 15, 20, 25, 30]);
    return { prompt: `${item.charAt(0).toUpperCase() + item.slice(1)} costing ₱${price} is marked up ${pct}% for resale. What's the new price (₱)?`, type: "integer", answer: price + Math.round(price * pct / 100) };
  }
  if (level <= 8) {
    const pct = pick([10, 20, 25, 50]), k = 100 / pct, m = randInt(3, 25);
    const original = m * k, final = original - m;
    return { prompt: `After a ${pct}% discount, ${item} now costs ₱${final}. What was the original price (₱)?`, type: "integer", answer: original };
  }
  if (level <= 10) {
    const pct = pick([10, 20, 25, 50]), k = 100 / pct, m = randInt(3, 20);
    const original = m * k, newPrice = original + m;
    return { prompt: `The price of ${item} rose from ₱${original} to ₱${newPrice}. What percent increase is that?`, type: "integer", answer: pct };
  }
  if (level <= 12) {
    const price = +(randInt(50, 400) + randInt(0, 9) / 10).toFixed(1), pct = pick([5, 12, 15, 18]);
    return { prompt: `${item.charAt(0).toUpperCase() + item.slice(1)} costs ₱${price}. With a ${pct}% tax added, what's the total price (₱)?`, type: "decimal", answer: +(price * (1 + pct / 100)).toFixed(2), tolerance: 0.05, hint: "Round to 2 decimal places." };
  }
  const price = randInt(10, 50) * 10, discPct = pick([10, 20, 25]), taxPct = pick([5, 12]);
  const afterDisc = price * (1 - discPct / 100);
  return { prompt: `${item.charAt(0).toUpperCase() + item.slice(1)} costs ₱${price}. It's ${discPct}% off, then ${taxPct}% tax is added on the discounted price. What's the final total (₱)?`, type: "decimal", answer: +(afterDisc * (1 + taxPct / 100)).toFixed(2), tolerance: 0.1, hint: "Round to 2 decimal places." };
}

// ---------------------------------------------------------------------------
// STATION 9 — Geometry  ("📐 Farm Plot")
// Twist: each question renders a small labeled diagram (rectangle, triangle,
// or circle) alongside the prompt — students read real dimensions off it.
// ---------------------------------------------------------------------------
function genGeometry(level) {
  if (level <= 2) {
    const w = randInt(3, 12), h = randInt(3, 12);
    return { prompt: `A rectangular farm plot is shown below. Find its perimeter (m).`, type: "integer", answer: 2 * (w + h), svg: svgRect(w, h, "m") };
  }
  if (level <= 4) {
    const w = randInt(3, 15), h = randInt(3, 15);
    return { prompt: `A rectangular farm plot is shown below. Find its area (m²).`, type: "integer", answer: w * h, svg: svgRect(w, h, "m") };
  }
  if (level <= 6) {
    const s = randInt(3, 20);
    return { prompt: `A square seedbed is shown below. Find its area (m²).`, type: "integer", answer: s * s, svg: svgRect(s, s, "m") };
  }
  if (level <= 8) {
    const b = randInt(4, 20), hh = pick([2, 4, 6, 8, 10, 12, 14, 16, 18, 20]);
    return { prompt: `A triangular plot is shown below. Find its area (m²).`, type: "integer", answer: (b * hh) / 2, svg: svgTriangle(b, hh, "m") };
  }
  if (level <= 10) {
    const r = randInt(3, 15);
    return { prompt: `A circular fish pond is shown below. Find its area (m²), using π ≈ 3.14.`, type: "decimal", answer: +(3.14 * r * r).toFixed(2), tolerance: 0.5, hint: "Use π ≈ 3.14. Round to 2 decimals.", svg: svgCircle(r, "m") };
  }
  if (level <= 12) {
    const l = randInt(2, 10), w = randInt(2, 10), h = randInt(2, 10);
    return { prompt: `A water tank is ${l} m long, ${w} m wide, and ${h} m tall. Find its volume (m³).`, type: "integer", answer: l * w * h, svg: svgRect(l, w, "m") };
  }
  const w = randInt(5, 25), h = randInt(5, 25), pricePerMeter = randInt(30, 120);
  return { prompt: `Fencing costs ₱${pricePerMeter} per meter. How much to fence the plot shown below (₱)?`, type: "integer", answer: 2 * (w + h) * pricePerMeter, svg: svgRect(w, h, "m") };
}

// ---------------------------------------------------------------------------
// STATION 10 — Patterns & Sequences  ("🧩 Code Breaker")
// Twist: not every question asks "what's next" — some ask for the missing
// middle term, or for the rule (common difference) itself.
// ---------------------------------------------------------------------------
function genPatterns(level) {
  if (level <= 2) {
    const start = randInt(1, 20), d = randInt(2, 9);
    return { prompt: `Find the next number: ${start}, ${start + d}, ${start + 2 * d}, ${start + 3 * d}, ?`, type: "integer", answer: start + 4 * d };
  }
  if (level <= 4) {
    const start = randInt(1, 20), d = randInt(2, 12);
    return { prompt: `Find the missing number: ${start}, ${start + d}, ?, ${start + 3 * d}, ${start + 4 * d}`, type: "integer", answer: start + 2 * d };
  }
  if (level <= 6) {
    const start = randInt(1, 5), r = randInt(2, 4);
    return { prompt: `Find the next number: ${start}, ${start * r}, ${start * r * r}, ${start * r * r * r}, ?`, type: "integer", answer: start * r * r * r * r };
  }
  if (level <= 8) {
    const d = randInt(2, 12), start = randInt(1, 15);
    return { prompt: `${start}, ${start + d}, ${start + 2 * d}, ${start + 3 * d}, ... — what number is being added each time (the common difference)?`, type: "integer", answer: d };
  }
  if (level <= 10) {
    const a = randInt(2, 8), b = randInt(2, 8), start = randInt(1, 10);
    const t1 = start + a, t2 = t1 - b, t3 = t2 + a;
    return { prompt: `Find the next number (pattern: +${a}, −${b}, repeat): ${start}, ${t1}, ${t2}, ${t3}, ?`, type: "integer", answer: t3 - b };
  }
  if (level <= 12) {
    const start = randInt(1, 4), r = randInt(2, 3);
    return { prompt: `Find the missing number: ${start}, ?, ${start * r * r}, ${start * r * r * r}`, type: "integer", answer: start * r };
  }
  const start = randInt(1, 5), d0 = randInt(1, 4), d1 = randInt(2, 5);
  const d2 = d1 + d0, d3 = d2 + d0, d4 = d3 + d0;
  const t1 = start + d1, t2 = t1 + d2, t3 = t2 + d3;
  return { prompt: `Find the next number (the gaps grow each time): ${start}, ${t1}, ${t2}, ${t3}, ?`, type: "integer", answer: t3 + d4 };
}

// ---------------------------------------------------------------------------
// STATION 11 — Statistics  ("📊 Data Detective")
// Twist: every question hands over a small real dataset (harvest, sales,
// scores) and asks for mean, median, mode, or range from it.
// ---------------------------------------------------------------------------
function genStatistics(level) {
  if (level <= 2) {
    const base = randInt(5, 20), vals = [base - 2, base - 1, base + 1, base + 2];
    return { prompt: `Weekly harvest (kg): ${vals.join(", ")}. Find the mean.`, type: "integer", answer: base };
  }
  if (level <= 4) {
    const vals = Array.from({ length: 5 }, () => randInt(1, 50)).sort((a, b) => a - b);
    return { prompt: `Quiz scores: ${vals.join(", ")}. Find the median.`, type: "integer", answer: vals[2] };
  }
  if (level <= 6) {
    const modeVal = randInt(1, 20), others = [randInt(1, 20), randInt(1, 20), randInt(1, 20)];
    const vals = shuffleArr([modeVal, modeVal, modeVal, ...others]);
    return { prompt: `Eggs laid per hen this week: ${vals.join(", ")}. Find the mode.`, type: "integer", answer: modeVal };
  }
  if (level <= 8) {
    const vals = Array.from({ length: 6 }, () => randInt(1, 100));
    return { prompt: `Daily sales (₱): ${vals.join(", ")}. Find the range.`, type: "integer", answer: Math.max(...vals) - Math.min(...vals) };
  }
  if (level <= 10) {
    const vals = Array.from({ length: 5 }, () => randInt(1, 40));
    const mean = vals.reduce((a, b) => a + b, 0) / 5;
    return { prompt: `Rainfall this week (mm): ${vals.join(", ")}. Find the mean.`, type: "decimal", answer: +mean.toFixed(2), tolerance: 0.05, hint: "Round to 2 decimal places." };
  }
  if (level <= 12) {
    const vals = Array.from({ length: 6 }, () => randInt(1, 60)).sort((a, b) => a - b);
    const median = (vals[2] + vals[3]) / 2;
    return { prompt: `Weights of piglets (kg): ${vals.join(", ")}. Find the median.`, type: "decimal", answer: +median.toFixed(2), tolerance: 0.05, hint: "Round to 2 decimal places." };
  }
  const vals = Array.from({ length: 4 }, () => randInt(1, 40));
  const mean1 = vals.reduce((a, b) => a + b, 0) / 4;
  const newVal = randInt(1, 40);
  const newMean = (vals.reduce((a, b) => a + b, 0) + newVal) / 5;
  return { prompt: `Test scores: ${vals.join(", ")} (mean = ${mean1.toFixed(2)}). A new score of ${newVal} is added. What's the new mean?`, type: "decimal", answer: +newMean.toFixed(2), tolerance: 0.05, hint: "Round to 2 decimal places." };
}

// ---------------------------------------------------------------------------
// STATION 12 — Probability  ("🎡 Harvest Gamble")
// Twist: a small die/spinner diagram accompanies chance questions; answers
// are entered as reduced fractions, reusing the same fraction engine as
// the Fractions station.
// ---------------------------------------------------------------------------
const PROB_COLORS = [["red", "blue"], ["brown", "white"], ["orange", "green"], ["yellow", "black"]];
function genProbability(level) {
  const hint = "Enter as a reduced fraction (e.g. 1/6), or a whole number if asked for a count.";
  if (level <= 2) {
    const target = randInt(1, 6);
    return { prompt: `You roll a fair 6-sided die. What's the probability of rolling a ${target}?`, type: "fraction", answer: reduceFrac({ n: 1, d: 6 }), hint, svg: svgDie() };
  }
  if (level <= 4) {
    const [c1, c2] = pick(PROB_COLORS), n1 = randInt(2, 8), n2 = randInt(2, 8);
    return { prompt: `A basket has ${n1} ${c1} eggs and ${n2} ${c2} eggs. What's the probability of picking a ${c1} egg at random?`, type: "fraction", answer: reduceFrac({ n: n1, d: n1 + n2 }), hint };
  }
  if (level <= 6) {
    return { prompt: `You flip a coin and roll a die. What's the probability of getting Heads AND a 6?`, type: "fraction", answer: reduceFrac({ n: 1, d: 12 }), hint };
  }
  if (level <= 8) {
    const [c1, c2] = pick(PROB_COLORS), n1 = randInt(3, 6), n2 = randInt(3, 6), total = n1 + n2;
    return { prompt: `A pouch has ${n1} ${c1} seeds and ${n2} ${c2} seeds. You draw two seeds without putting the first back. What's the probability BOTH are ${c1}?`, type: "fraction", answer: reduceFrac({ n: n1 * (n1 - 1), d: total * (total - 1) }), hint };
  }
  if (level <= 10) {
    const target = randInt(1, 6);
    return { prompt: `You roll a fair die. What's the probability of NOT rolling a ${target}?`, type: "fraction", answer: reduceFrac({ n: 5, d: 6 }), hint, svg: svgDie() };
  }
  if (level <= 12) {
    const a = randInt(1, 3), rest = [4, 5, 6].filter((x) => x !== a), b = pick(rest);
    return { prompt: `You roll a fair die. What's the probability of rolling a ${a} OR a ${b}?`, type: "fraction", answer: reduceFrac({ n: 2, d: 6 }), hint, svg: svgDie() };
  }
  const [c1] = pick(PROB_COLORS), n1 = randInt(1, 5), n2 = randInt(1, 5), total = n1 + n2, seedsPlanted = total * randInt(4, 12);
  return { prompt: `Out of every ${total} seeds planted, ${n1} are expected to sprout. If you plant ${seedsPlanted} seeds, how many should sprout?`, type: "integer", answer: (seedsPlanted * n1) / total };
}

// ---------------------------------------------------------------------------
// STATION 13 — Exponents & Radicals  ("⚡ Exponents & Radicals")
// Laws of exponents, then roots and radicals — the two are one topic, since a
// root is just a fractional exponent (√x = x^(1/2)). Every answer is a whole
// number, so the station uses the plain integer keypad.
//   1–2   powers                     9   square roots
//   3–4   product rule              10   cube roots (+ larger square roots)
//   5–6   quotient rule             11   zero & negative exponents
//   7–8   power of a power          12   rational exponents  a^(m/n)
//   13    simplifying radicals      14   adding / subtracting like radicals
//   15    scientific notation
// (The station key stays "exponents" — it is stored in student progress,
// leaderboards and Boss Raids — so only the display name changed.)
// ---------------------------------------------------------------------------
function genExponents(level) {
  if (level <= 2) {
    const b = randInt(2, 6), e = randInt(2, 3);
    return { prompt: `${b}^${e} = ?`, type: "integer", answer: Math.pow(b, e) };
  }
  if (level <= 4) {
    const b = randInt(2, 5), e1 = randInt(1, 4), e2 = randInt(1, 4);
    return { prompt: `${b}^${e1} × ${b}^${e2} = ${b}^?`, type: "integer", answer: e1 + e2 };
  }
  if (level <= 6) {
    const b = randInt(2, 6), e2 = randInt(1, 3), e1 = e2 + randInt(1, 3);
    return { prompt: `${b}^${e1} ÷ ${b}^${e2} = ${b}^?`, type: "integer", answer: e1 - e2 };
  }
  if (level <= 8) {
    const b = randInt(2, 5), e = randInt(2, 3), p = randInt(2, 3);
    return { prompt: `(${b}^${e})^${p} = ${b}^?`, type: "integer", answer: e * p };
  }
  if (level === 9) {
    const n = randInt(2, 15);
    return { prompt: `Find the square root: √${n * n} = ?`, type: "integer", answer: n };
  }
  if (level === 10) {
    // mostly cube roots (³√ is used instead of ∛ because ∛ is missing from some phone fonts)
    if (Math.random() < 0.75) {
      const n = randInt(2, 8);
      return { prompt: `Find the cube root: ³√${n * n * n} = ?`, type: "integer", answer: n, hint: "Which number multiplied by itself three times gives this?" };
    }
    const n = randInt(13, 20);
    return { prompt: `Find the square root: √${n * n} = ?`, type: "integer", answer: n };
  }
  if (level === 11) {
    // zero and negative exponents — every variant has a different, non-constant answer
    const kind = pick(["neg", "neg", "mixed", "zero"]);
    if (kind === "neg") {
      const b = randInt(2, 5), k = randInt(2, 3);
      return { prompt: `${b}^-${k} = 1/?`, type: "integer", answer: Math.pow(b, k), hint: "A negative exponent flips the base: a^-n = 1/aⁿ" };
    }
    if (kind === "mixed") {
      const b = randInt(2, 6), e2 = randInt(1, 3), e1 = e2 + randInt(1, 4);
      return { prompt: `${b}^${e1} × ${b}^-${e2} = ${b}^?`, type: "integer", answer: e1 - e2, hint: "Add the exponents (a negative one subtracts)." };
    }
    const a = randInt(2, 9), b = randInt(2, 5), e = randInt(2, 3);
    return { prompt: `${a}^0 + ${b}^${e} = ?`, type: "integer", answer: 1 + Math.pow(b, e), hint: "Anything (except 0) to the power 0 equals 1." };
  }
  if (level === 12) {
    // rational exponents: a^(m/n) = (ⁿ√a)^m
    const kind = pick(["half", "third", "threeHalves", "twoThirds"]);
    if (kind === "half") { const n = randInt(2, 12); return { prompt: `${n * n}^(1/2) = ?`, type: "integer", answer: n, hint: "An exponent of 1/2 means square root; 1/3 means cube root." }; }
    if (kind === "third") { const n = randInt(2, 6); return { prompt: `${n ** 3}^(1/3) = ?`, type: "integer", answer: n, hint: "An exponent of 1/2 means square root; 1/3 means cube root." }; }
    if (kind === "threeHalves") { const n = randInt(2, 5); return { prompt: `${n * n}^(3/2) = ?`, type: "integer", answer: n ** 3, hint: "a^(m/n): take the n-th root first, then raise to the power m." }; }
    const n = randInt(2, 5);
    return { prompt: `${n ** 3}^(2/3) = ?`, type: "integer", answer: n * n, hint: "a^(m/n): take the n-th root first, then raise to the power m." };
  }
  if (level === 13) {
    // simplify a radical: √(a²·b) = a√b, b square-free — ask for the number in front
    const b = pick([2, 3, 5, 6, 7]), a = randInt(2, 7);
    return { prompt: `Simplify √${a * a * b} = ?√${b}. What number goes in front of the radical?`, type: "integer", answer: a, hint: "Pull out the biggest perfect square, e.g. √40 = √4 × √10 = 2√10." };  // example radicand 40 can never be asked here (a²·b with b in {2,3,5,6,7}), so the hint never gives the answer away
  }
  if (level === 14) {
    // add / subtract like radicals: simplify each, then combine the coefficients
    const b = pick([2, 3, 5]);
    if (Math.random() < 0.7) {
      let p = randInt(1, 5), q = randInt(1, 5);
      while (q === p) q = randInt(1, 5);
      return { prompt: `√${p * p * b} + √${q * q * b} = ?√${b}`, type: "integer", answer: p + q, hint: "Simplify each radical first, then add the numbers in front." };
    }
    const p = randInt(2, 6), q = randInt(1, p - 1);
    return { prompt: `√${p * p * b} − √${q * q * b} = ?√${b}`, type: "integer", answer: p - q, hint: "Simplify each radical first, then subtract the numbers in front." };
  }
  // level 15 — scientific notation: student reads the coefficient off a value written as A × 10^n.
  const coeff = +(randInt(10, 99) / 10).toFixed(1);
  const exp = randInt(2, 6);
  const value = coeff * Math.pow(10, exp);
  return { prompt: `Write in scientific notation, then give just the exponent: ${value.toLocaleString("en-US")} = ${coeff} × 10^?`, type: "integer", answer: exp };
}

// ---------------------------------------------------------------------------
// STATION 14 — Equation Scale  ("⚖️ Equation Scale")
// Linear equations in 1 variable, 2-step solving, distributive property.
// ---------------------------------------------------------------------------
function genEquations(level) {
  if (level <= 2) {
    const x = randInt(1, 15), b = randInt(1, 20);
    return { prompt: `x + ${b} = ${x + b}. Solve for x.`, type: "integer", answer: x };
  }
  if (level <= 4) {
    const x = randInt(1, 12), a = randInt(2, 9);
    return { prompt: `${a}x = ${a * x}. Solve for x.`, type: "integer", answer: x };
  }
  if (level <= 6) {
    const x = randInt(-10, 12), a = randInt(2, 8), b = randInt(1, 20);
    return { prompt: `${a}x + ${b} = ${a * x + b}. Solve for x.`, type: "integer", answer: x };
  }
  if (level <= 8) {
    const x = randInt(-10, 12), a = randInt(2, 8), b = randInt(1, 15);
    return { prompt: `${a}x - ${b} = ${a * x - b}. Solve for x.`, type: "integer", answer: x };
  }
  if (level <= 10) {
    // a(x + c) = result — distributive property
    const x = randInt(-8, 10), a = randInt(2, 6), c = randInt(1, 9);
    const result = a * (x + c);
    return { prompt: `${a}(x + ${c}) = ${result}. Solve for x.`, type: "integer", answer: x };
  }
  if (level <= 12) {
    const x = randInt(-8, 10), a = randInt(2, 6), b = randInt(1, 9), c = randInt(2, 5);
    const rhs = a * x + b + c * x;
    return { prompt: `${a}x + ${b} + ${c}x = ${rhs}. Solve for x.`, type: "integer", answer: x };
  }
  // Variable on both sides
  const x = randInt(-9, 9), a = randInt(3, 9), c = randInt(1, a - 1), b = randInt(1, 15), d = randInt(1, 15);
  const lhs = a * x + b, computedD = lhs - c * x;
  return { prompt: `${a}x + ${b} = ${c}x + ${computedD}. Solve for x.`, type: "integer", answer: x };
}

// ---------------------------------------------------------------------------
// STATION 15 — Factor Vault  ("🧩 Factor Vault")
// GCF, Difference of Two Squares, Perfect Square Trinomials, Quadratic
// Factoring. Answers are the "other factor" or a specific root, kept as a
// single integer/decimal so it still fits the numeric keypad.
// ---------------------------------------------------------------------------
function genFactoring(level) {
  if (level <= 2) {
    // GCF of two numbers
    const g = randInt(2, 9), a = g * randInt(2, 6), b = g * randInt(2, 6);
    return { prompt: `Find the GCF of ${a} and ${b}.`, type: "integer", answer: gcd(a, b) };
  }
  if (level <= 4) {
    // GCF of a monomial expression a·x + a·y -> factor out the GCF, answer is that GCF
    const g = randInt(2, 9), c1 = randInt(2, 8), c2 = randInt(2, 8);
    return { prompt: `Factor out the GCF from ${g * c1}x + ${g * c2}y = GCF(${c1}x + ${c2}y). What is the GCF?`, type: "integer", answer: g };
  }
  if (level <= 6) {
    // Difference of two squares: x^2 - n^2 = (x-n)(x+n); give n
    const n = randInt(2, 15);
    return { prompt: `x² - ${n * n} factors as (x - ?)(x + ${n}). What number goes in the blank?`, type: "integer", answer: n };
  }
  if (level <= 8) {
    // Perfect square trinomial: x^2 + 2nx + n^2 = (x+n)^2; give n
    const n = randInt(2, 12);
    return { prompt: `x² + ${2 * n}x + ${n * n} = (x + ?)². What number goes in the blank?`, type: "integer", answer: n };
  }
  if (level <= 10) {
    // Quadratic factoring x^2 + bx + c = (x+p)(x+q), both roots positive-friendly; ask for the larger root
    const p = randInt(1, 9), q = randInt(1, 9), b = p + q, c = p * q;
    return { prompt: `x² + ${b}x + ${c} = (x + ${p})(x + ?). What goes in the blank?`, type: "integer", answer: q };
  }
  if (level <= 12) {
    // Quadratic with a negative root: x^2 + bx - c = (x+p)(x-q)
    const p = randInt(1, 9), q = randInt(1, 9), b = p - q, c = p * q;
    return { prompt: `x² ${b >= 0 ? "+ " + b : "- " + Math.abs(b)}x - ${c} = (x + ${p})(x - ?). What goes in the blank?`, type: "integer", answer: q };
  }
  // Solve a factorable quadratic for the positive root: x^2 - bx + c = 0
  const p = randInt(2, 10), q = randInt(2, 10), b = p + q, c = p * q;
  return { prompt: `x² - ${b}x + ${c} = 0 has two positive roots. What is the LARGER root?`, type: "integer", answer: Math.max(p, q) };
}

// ---------------------------------------------------------------------------
// STATION 16 — Farm Measure  ("🌾 Farm Measure")
// Metric conversions (length, mass, volume), hectare/acreage land area, and
// farm application rates.
// ---------------------------------------------------------------------------
function genMeasurement(level) {
  if (level <= 2) {
    const m = randInt(2, 50);
    return { prompt: `${m} meters = ? centimeters`, type: "integer", answer: m * 100 };
  }
  if (level <= 4) {
    const kg = randInt(2, 40);
    return { prompt: `${kg} kilograms = ? grams`, type: "integer", answer: kg * 1000 };
  }
  if (level <= 6) {
    const l = randInt(2, 60);
    return { prompt: `${l} liters = ? milliliters`, type: "integer", answer: l * 1000 };
  }
  if (level <= 8) {
    const cm = randInt(2, 40) * 100; // guarantee a whole-meter result
    return { prompt: `${cm} centimeters = ? meters`, type: "integer", answer: cm / 100 };
  }
  if (level <= 10) {
    // Hectares — 1 hectare = 10,000 m²
    const ha = randInt(1, 12);
    return { prompt: `A farm plot covers ${ha} hectares. How many square meters is that? (1 hectare = 10,000 m²)`, type: "integer", answer: ha * 10000 };
  }
  if (level <= 12) {
    // Reverse: given m², find hectares (decimal)
    const ha = +(randInt(5, 90) / 10).toFixed(1);
    const sqm = ha * 10000;
    return { prompt: `A field measures ${sqm.toLocaleString("en-US")} m². How many hectares is that?`, type: "decimal", answer: ha, tolerance: 0.05 };
  }
  // Farm application rate: fertilizer per hectare
  const ratePerHa = randInt(20, 80), ha = randInt(2, 15);
  return { prompt: `Fertilizer is applied at ${ratePerHa} kg per hectare. How many kg are needed for ${ha} hectares?`, type: "integer", answer: ratePerHa * ha };
}

// ---------------------------------------------------------------------------
// STATION 17 — Grid Navigator  ("📈 Grid Navigator")
// Cartesian plane, coordinates, slope formula, y-intercepts.
// ---------------------------------------------------------------------------
function genCoordinates(level) {
  if (level <= 2) {
    const x1 = randInt(-8, 8), y1 = randInt(-8, 8);
    return { prompt: `A point is at (${x1}, ${y1}). What is its x-coordinate?`, type: "integer", answer: x1 };
  }
  if (level <= 4) {
    const x1 = randInt(1, 9), y1 = randInt(1, 9), dx = randInt(1, 6);
    return { prompt: `Starting at (${x1}, ${y1}), move ${dx} units right. What is the new x-coordinate?`, type: "integer", answer: x1 + dx };
  }
  if (level <= 6) {
    // Horizontal or vertical slope-free distance along an axis
    const x1 = randInt(-10, 10), x2 = x1 + randInt(2, 12), y = randInt(-5, 5);
    return { prompt: `Find the distance between (${x1}, ${y}) and (${x2}, ${y}).`, type: "integer", answer: Math.abs(x2 - x1) };
  }
  if (level <= 8) {
    // Slope with whole-number result
    const m = randInt(-5, 5) || 2, x1 = randInt(-6, 4), y1 = randInt(-6, 6);
    const dx = randInt(1, 4), x2 = x1 + dx, y2 = y1 + m * dx;
    return { prompt: `Find the slope of the line through (${x1}, ${y1}) and (${x2}, ${y2}).`, type: "integer", answer: m };
  }
  if (level <= 10) {
    // Slope as a reduced fraction
    const x1 = randInt(-6, 4), y1 = randInt(-6, 6), dx = randInt(2, 6), dy = randInt(-8, 8) || 3;
    const x2 = x1 + dx, y2 = y1 + dy;
    return { prompt: `Find the slope of the line through (${x1}, ${y1}) and (${x2}, ${y2}). m = (y₂-y₁)/(x₂-x₁)`, type: "fraction", answer: reduceFrac({ n: dy, d: dx }), hint: "Enter as a fraction in lowest terms (e.g. -3/2) or a whole number." };
  }
  if (level <= 12) {
    // y-intercept from slope-intercept form given m and a point
    const m = randInt(-6, 6) || 2, x1 = randInt(1, 9), b = randInt(-10, 10);
    const y1 = m * x1 + b;
    return { prompt: `A line has slope ${m} and passes through (${x1}, ${y1}). What is its y-intercept (b)?`, type: "integer", answer: b };
  }
  // Given the equation y = mx + b, find y for a given x
  const m = randInt(-6, 6) || 3, b = randInt(-10, 10), x = randInt(-8, 8);
  return { prompt: `For the line y = ${m}x ${b >= 0 ? "+ " + b : "- " + Math.abs(b)}, find y when x = ${x}.`, type: "integer", answer: m * x + b };
}

// ---------------------------------------------------------------------------
// STATION 18 — Surveyor's Post  ("📐 Surveyor's Post")
// Pythagorean Theorem, hypotenuse/leg solving, farm boundary fencing.
// ---------------------------------------------------------------------------
const PYTHAG_TRIPLES = [[3, 4, 5], [6, 8, 10], [5, 12, 13], [9, 12, 15], [8, 15, 17], [7, 24, 25], [12, 16, 20], [10, 24, 26], [9, 40, 41], [20, 21, 29]];
function genPythagoras(level) {
  if (level <= 2) {
    const [a, b, c] = pick(PYTHAG_TRIPLES);
    return { prompt: `A right triangle has legs ${a} m and ${b} m. Find the hypotenuse (m).`, type: "integer", answer: c, svg: svgTriangle(a, b, "m") };
  }
  if (level <= 4) {
    const [a, b, c] = pick(PYTHAG_TRIPLES);
    return { prompt: `A right triangle has one leg ${a} m and hypotenuse ${c} m. Find the other leg (m).`, type: "integer", answer: b };
  }
  if (level <= 6) {
    const [a, b, c] = pick(PYTHAG_TRIPLES);
    const scale = randInt(2, 5);
    return { prompt: `A right triangle has legs ${a * scale} m and ${b * scale} m. Find the hypotenuse (m).`, type: "integer", answer: c * scale };
  }
  if (level <= 8) {
    // Farm boundary fencing: rectangular field, find the diagonal
    const [a, b, c] = pick(PYTHAG_TRIPLES);
    return { prompt: `A rectangular farm boundary is ${a} m by ${b} m. A diagonal fence is built corner to corner. How long is it (m)?`, type: "integer", answer: c, svg: svgRect(a, b, "m") };
  }
  if (level <= 10) {
    // Non-Pythagorean-triple: decimal answer
    const a = randInt(3, 15), b = randInt(3, 15);
    const c = Math.sqrt(a * a + b * b);
    return { prompt: `A right triangle has legs ${a} m and ${b} m. Find the hypotenuse (m), rounded to 2 decimals.`, type: "decimal", answer: +c.toFixed(2), tolerance: 0.05, hint: "Round to 2 decimal places." };
  }
  if (level <= 12) {
    // Ladder/pole word problem
    const [a, b, c] = pick(PYTHAG_TRIPLES);
    const scale = randInt(2, 4);
    return { prompt: `A ${c * scale}-m irrigation pipe runs diagonally across a field, covering ${a * scale} m of one side. How many meters does it cover along the other side?`, type: "integer", answer: b * scale };
  }
  // Perimeter of a right-triangle plot (fence around all three sides)
  const [a, b, c] = pick(PYTHAG_TRIPLES);
  const scale = randInt(2, 4);
  return { prompt: `A right-triangle plot has legs ${a * scale} m and ${b * scale} m. What is the perimeter of the plot (m), including the hypotenuse boundary?`, type: "integer", answer: (a + b + c) * scale };
}

const DRILL_GENERATORS = {
  basic: genBasic, order: genOrder, integers: genIntegers, fractions: genFractions, decimals: genDecimals, algebra: genAlgebra,
  ratio: genRatio, percent: genPercent, geometry: genGeometry, patterns: genPatterns, statistics: genStatistics, probability: genProbability,
  exponents: genExponents, equations: genEquations, factoring: genFactoring, measurement: genMeasurement, coordinates: genCoordinates, pythagoras: genPythagoras,
};
function generateDrillQuestion(topic, level) { return DRILL_GENERATORS[topic](level); }

function checkDrillAnswer(q, raw) {
  const s = String(raw == null ? "" : raw).trim();
  if (!s) return false;
  if (q.type === "integer") { if (!/^-?\d+$/.test(s)) return false; return parseInt(s, 10) === q.answer; }
  if (q.type === "decimal") { if (!/^-?\d+(\.\d+)?$/.test(s)) return false; return Math.abs(parseFloat(s) - q.answer) <= (q.tolerance || 0.05); }
  if (q.type === "fraction") { const f = parseFractionAnswer(s); if (!f) return false; const r = reduceFrac(f); return r.n === q.answer.n && r.d === q.answer.d; }
  return false;
}
function fmtDrillAnswer(q) {
  if (q.type === "fraction") return fracToString(q.answer);
  return String(q.answer);
}

// ============================================================================
// MYSTERY BOX
// ============================================================================
// Enhanced drops (migration-47): on top of the original bonus/jackpot/
// bokya/empty outcomes, a Mystery Box can now also drop a free pet snack
// (Green Points), a coin bonus (real, persistent Coins), or a rare
// gemstone shard — each carries its own session `amount` (added to the
// run's score, same as before) PLUS a `grant` side-effect applied
// immediately in openMysteryBox() below.
function pickMysteryOutcome(level) {
  // v49: the old "😬 BOKYA!" outcome (25% — it TOOK points away) is gone.
  // Every box is now a gain or, rarely, a shrug: trying a box never costs a
  // student anything, so opening one is always a small moment of hope.
  const roll = Math.random() * 100;
  if (roll < 40) return { type: "bonus", label: "✨ BONUS!", amount: randInt(15, 30) + level * 3 };
  if (roll < 52) return { type: "jackpot", label: "💰 JACKPOT!", amount: randInt(40, 60) + level * 5 };
  if (roll < 72) return { type: "snack", label: "🍎 Free Snack for your pet!", amount: 5, grant: { kind: "snack", foodKey: pick(["math_snack", "number_nuggets", "geometry_gelato"]) } };
  if (roll < 90) return { type: "coinbonus", label: "🪙 Coin Bonus!", amount: 5, grant: { kind: "coins", amount: randInt(10, 25) } };
  if (roll < 96) return { type: "gemshard", label: "💎 Gemstone Shard!", amount: 10, grant: { kind: "gemstone", amount: 1 } };
  return { type: "empty", label: "📦 Walang laman... empty box!", amount: 0 };
}
const MYSTERY_BOX_ICONS = { jackpot: "💰", empty: "📦", snack: "🍎", coinbonus: "🪙", gemshard: "💎", bonus: "✨" };

// ============================================================================
// PROGRESS LOAD / SAVE
// ============================================================================
function defaultTopicLevels() {
  const o = {}; DRILL_TOPICS.forEach((t) => (o[t.key] = 1)); return o;
}
function defaultTopicPoints() {
  const o = {}; DRILL_TOPICS.forEach((t) => (o[t.key] = 0)); return o;
}
async function loadDrillProgress() {
  const { data } = await supabase.from("drill_progress").select("*").eq("student_id", sstate.student.id).maybeSingle();
  if (data) {
    // Back-compat: rows created before migration-14/20 won't have topic_points
    // or mastery_tier/mastery_stars yet.
    dstate.progress = {
      ...data,
      topic_points: data.topic_points || defaultTopicPoints(),
      mastery_tier: data.mastery_tier || 1,
      mastery_stars: data.mastery_stars || 0,
    };
  } else {
    const fresh = { student_id: sstate.student.id, total_points: 0, games_played: 0, best_streak: 0, topic_levels: defaultTopicLevels(), topic_points: defaultTopicPoints(), mastery_tier: 1, mastery_stars: 0 };
    const { data: inserted } = await supabase.from("drill_progress").insert(fresh).select().maybeSingle();
    dstate.progress = inserted || { ...fresh, id: null };
  }
  dstate.loaded = true;
}
function drillSleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function drillNewId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => { const r = (Math.random() * 16) | 0; return (c === "x" ? r : (r & 0x3) | 0x8).toString(16); });
}

// v46 — RELIABLE SAVING. Both writes below used to ignore their result, so a
// dropped connection or a hiccup on the school wifi silently lost a run: the
// student saw their score on screen, but the teacher's dashboard never got it.
async function saveDrillProgress() {
  const p = dstate.progress;
  const payload = {
    student_id: sstate.student.id,
    total_points: p.total_points, games_played: p.games_played, best_streak: p.best_streak,
    topic_levels: p.topic_levels, topic_points: p.topic_points, updated_at: new Date().toISOString(),
  };
  // upsert (not update): if the student's progress row somehow doesn't exist
  // yet, an update would "succeed" while changing nothing. student_id is unique,
  // and only the columns listed here are touched on conflict.
  let { error } = await supabase.from("drill_progress").upsert(payload, { onConflict: "student_id" });
  if (error) { await drillSleep(800); ({ error } = await supabase.from("drill_progress").upsert(payload, { onConflict: "student_id" })); }
  if (error) {
    console.warn("saveDrillProgress failed:", error.message);
    toast("⚠️ Couldn't save your progress — check your connection. It will save with your next run.");
  }
}

// Run history goes through a small retry queue. Each run gets a client-made id,
// so retrying can never double-count it (a repeat insert is a harmless
// duplicate-key error, treated as "already saved").
const DRILL_PENDING_KEY = "mc_pending_drill_attempts_v1";
function drillPendingLoad() { try { return JSON.parse(localStorage.getItem(DRILL_PENDING_KEY) || "[]"); } catch (e) { return []; } }
function drillPendingSave(list) { try { localStorage.setItem(DRILL_PENDING_KEY, JSON.stringify(list.slice(-100))); } catch (e) { /* storage full/blocked — nothing more we can do */ } }
async function insertDrillAttemptRow(row) {
  const { error } = await supabase.from("drill_attempts").insert(row);
  if (!error) return true;
  if (error.code === "23505" || /duplicate key/i.test(error.message || "")) return true; // an earlier try did land
  console.warn("drill_attempts insert failed:", error.message);
  return false;
}
async function flushPendingDrillAttempts() {
  const list = drillPendingLoad();
  if (!list.length) return;
  const stillPending = [];
  for (const row of list) { if (!(await insertDrillAttemptRow(row))) stillPending.push(row); }
  drillPendingSave(stillPending);
}
async function logDrillAttempt(topic, level, correctCount, pointsEarned, bonusPoints, penaltyPoints, leveledUp) {
  const row = {
    id: drillNewId(), played_at: new Date().toISOString(),
    student_id: sstate.student.id, topic, level, correct_count: correctCount, total_questions: DRILL_RUN_LENGTH,
    points_earned: pointsEarned, bonus_points: bonusPoints, penalty_points: penaltyPoints, leveled_up: leveledUp,
  };
  let saved = await insertDrillAttemptRow(row);
  if (!saved) { await drillSleep(800); saved = await insertDrillAttemptRow(row); }
  if (saved) {
    flushPendingDrillAttempts(); // opportunistically clear anything an earlier bad connection left behind
  } else {
    drillPendingSave(drillPendingLoad().concat(row));
    toast("⚠️ Couldn't save this run's history yet — it will retry automatically.");
  }
  // Class Quest — best-effort, non-blocking. Only net-positive points count
  // toward the shared class goal (a bad run shouldn't set the class back).
  // The RPC itself checks topic match if the active quest targets one
  // specific station (e.g. "Ratio & Proportion only") — a mismatched
  // station is silently ignored here rather than shown as an error, since
  // most drill runs happen with no active quest at all.
  if (pointsEarned > 0) {
    supabase.rpc("contribute_to_class_quest", { p_student_id: sstate.student.id, p_points: pointsEarned, p_topic: topic }).then(({ data }) => {
      if (data && data.ok && data.just_completed) {
        toast(`🎉 Class Quest complete! "${data.quest.title}" — ${data.quest.reward_text || "ask your teacher what's next!"}`);
      }
    }).catch(() => {});
  }
}

// ============================================================================
// HUB (the "🎮 Math Drills" tab)
// ============================================================================
async function fetchStudentStationStats(studentId, progress) {
  // v46: page through every run (a bare select() caps at ~1,000 rows), and
  // treat a raised level / banked points as proof a station was played even if
  // its run log is missing — this must agree with what the teacher's dashboard shows.
  const { data } = await fetchAllRowsChecked(() => supabase.from("drill_attempts").select("topic, correct_count, total_questions").eq("student_id", studentId));
  const byTopic = {};
  DRILL_TOPICS.forEach((t) => (byTopic[t.key] = { attempts: 0, correct: 0, total: 0, played: false }));
  (data || []).forEach((r) => {
    if (!byTopic[r.topic]) return;
    byTopic[r.topic].attempts += 1;
    byTopic[r.topic].correct += r.correct_count || 0;
    byTopic[r.topic].total += r.total_questions || 0;
  });
  DRILL_TOPICS.forEach((t) => {
    const lvl = (progress && progress.topic_levels && progress.topic_levels[t.key]) || 1;
    const pts = (progress && progress.topic_points && progress.topic_points[t.key]) || 0;
    byTopic[t.key].played = byTopic[t.key].attempts > 0 || lvl > 1 || pts > 0;
  });
  return byTopic;
}

// ============================================================================
// CLASS QUEST — one shared XP bar the whole section fills together. Every
// net-positive drill run contributes automatically (see logDrillAttempt).
// Deliberately shows only the shared total and "your contribution" — no
// per-classmate ranking, to keep it cooperative rather than competitive.
// ============================================================================
async function renderClassQuestWidget() {
  const { data: quest } = await supabase.rpc("get_active_class_quest", { p_section_id: sstate.section.id });
  if (!quest) return "";
  const { data: myContribution } = await supabase.rpc("get_my_quest_contribution", { p_quest_id: quest.id, p_student_id: sstate.student.id });
  const myPts = myContribution || 0;
  const pct = Math.min(100, Math.round((quest.current_points / quest.goal_points) * 100));
  const done = !!quest.completed_at;
  const targetMeta = quest.target_topic ? DRILL_TOPICS.find((t) => t.key === quest.target_topic) : null;
  return `
    <div class="card" style="margin-bottom:16px;border:2px solid var(--sage);background:${done ? "var(--gold-light)" : "transparent"};">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
        <div><div class="muted">🌱 Class Quest</div><h3 style="margin:2px 0;">${escapeHtml(quest.title)}</h3></div>
        ${done ? `<span style="font-weight:700;color:var(--forest-dark);">🎉 Complete!</span>` : ""}
      </div>
      ${quest.description ? `<p class="muted" style="margin:4px 0 10px;">${escapeHtml(quest.description)}</p>` : ""}
      ${targetMeta ? `<p style="margin:4px 0 10px;font-weight:600;color:var(--forest-dark);">${targetMeta.icon} Only ${escapeHtml(targetMeta.name)} points count toward this quest — practice that station to help your class!</p>` : `<p class="muted" style="margin:4px 0 10px;">Any drill station counts toward this quest.</p>`}
      <div style="background:var(--sage-light);border-radius:8px;height:16px;overflow:hidden;">
        <div style="background:${done ? "var(--gold)" : "var(--forest)"};height:100%;width:${pct}%;transition:width .4s;"></div>
      </div>
      <div class="muted" style="margin-top:6px;font-size:.82rem;">
        ${quest.current_points} / ${quest.goal_points} pts (${pct}%) — your class is in this together${myPts > 0 ? ` · you've contributed ${myPts} pts` : ""}
      </div>
      ${quest.reward_text ? `<div class="muted" style="margin-top:4px;font-size:.82rem;">🎁 Reward: ${escapeHtml(quest.reward_text)}</div>` : ""}
    </div>`;
}

async function renderDrillsHub() {
  const el = document.getElementById("tab-drills");
  el.innerHTML = `<div class="empty">Loading your drill progress…</div>`;
  if (!dstate.loaded) await loadDrillProgress();
  if (!dstate.locksLoaded) await loadStationLocks();
  const p = dstate.progress;
  flushPendingDrillAttempts(); // send any run history a bad connection held back earlier
  const stationStats = await fetchStudentStationStats(sstate.student.id, p);
  const attemptedCount = DRILL_TOPICS.filter((t) => stationStats[t.key].played).length;
  const leftStations = DRILL_TOPICS.filter((t) => !stationStats[t.key].played);
  const overallTier = rankTierByLevel(p.mastery_tier);

  el.innerHTML = `
    ${await renderClassQuestWidget()}
    ${await myWeekCardHtml(0)}
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <div>
          <div class="muted">🏅 MathLegends Rank</div>
          <h2 style="margin:4px 0;">${renderRankBadge(overallTier, { withStars: true, stars: p.mastery_stars })}</h2>
        </div>
        <div style="text-align:right;">
          <div class="muted">Total Drill Points</div>
          <h3 style="margin:2px 0;color:var(--gold);">🏆 ${p.total_points}</h3>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button class="btn-outline" onclick="renderDrillLeaderboardView()">📊 View Leaderboards</button>
          ${typeof certShelfButtonHtml === "function" ? certShelfButtonHtml("drills") : ""}
        </div>
      </div>
      <div class="muted" style="margin-top:10px;">
        ${p.games_played} game${p.games_played === 1 ? "" : "s"} played · Best streak 🔥 ${p.best_streak} ·
        Stations attempted: ${attemptedCount}/${DRILL_TOPICS.length}
        ${leftStations.length ? ` · Not started yet: ${leftStations.map((t) => `${t.icon} ${t.name}`).join(", ")}` : " · All stations started 🎉"}
      </div>
    </div>
    <div class="drill-grid">
      ${DRILL_TOPICS.map((t) => {
        const lvl = p.topic_levels[t.key] || 1;
        const st = stationStats[t.key];
        const acc = st.total > 0 ? Math.round((st.correct / st.total) * 100) : null;
        const locked = isStationLocked(t.key);
        if (locked) {
          const note = (dstate.locks[t.key] && dstate.locks[t.key].note) || "Locked by your admin — check back soon!";
          return `
          <div class="drill-card" style="opacity:.6;">
            <div class="icon">🔒</div>
            <h3 style="margin-top:8px;">${t.icon} ${t.name}</h3>
            <p class="muted" style="font-size:.82rem;min-height:2.4em;">${escapeHtml(note)}</p>
            <button class="btn-outline" style="width:100%;margin-top:6px;" disabled>🔒 Locked</button>
          </div>`;
        }
        return `
        <div class="drill-card">
          <div class="icon">${t.icon}</div>
          <h3 style="margin-top:8px;">${t.name}${t.isNew ? ` <span class="muted" style="font-size:.7rem;">NEW</span>` : ""}</h3>
          <p class="muted" style="font-size:.82rem;min-height:2.4em;">${t.desc}</p>
          <div class="drill-level-badge">Level ${lvl} / ${DRILL_MAX_LEVEL} &nbsp;·&nbsp; ${p.topic_points[t.key] || 0} pts</div>
          <div class="muted" style="font-size:.76rem;margin-top:6px;">
            ${st.attempts > 0 ? `${st.attempts} run${st.attempts === 1 ? "" : "s"} · ${acc}% accuracy` : st.played ? "Played · run history not saved" : "Not attempted yet"}
          </div>
          <div class="field" style="margin-top:10px;text-align:left;">
            <label>Play at level</label>
            <select id="drill_level_${t.key}">
              ${Array.from({ length: lvl }, (_, i) => i + 1).map((n) => `<option value="${n}" ${n === lvl ? "selected" : ""}>Level ${n}${n === lvl ? " (current)" : ""}</option>`).join("")}
            </select>
          </div>
          <button class="btn-primary" style="width:100%;margin-top:6px;" onclick="startDrillRun('${t.key}', +document.getElementById('drill_level_${t.key}').value)">▶ Play</button>
        </div>`;
      }).join("")}
    </div>
    <p class="muted" style="margin-top:16px;">Score 7/10 or better at your current level to break through to the next level. Keep an eye out for 🎁 Mystery Boxes along the way — each one is a little surprise! Your MathLegends Rank climbs from stars earned in Drills, the Daily Challenge, and Boss Battles.</p>`;
}

// ============================================================================
// GAMEPLAY
// ============================================================================
function startDrillRun(topic, level) {
  if (sstate.readOnly) { toast("⏸️ Your account is in read-only mode — drills are paused. See your teacher."); return; }
  if (isStationLocked(topic)) { toast("🔒 This station is locked by your admin right now."); return; }
  const topicMeta = DRILL_TOPICS.find((t) => t.key === topic);
  const sequence = [];
  for (let i = 1; i <= DRILL_RUN_LENGTH; i++) {
    const q = generateDrillQuestion(topic, level);
    // ✨ Golden Question — only questions #5/#8 are candidates, and each
    // candidate still only has a 25% chance of actually rolling Golden.
    if (GOLDEN_QUESTION_SLOTS.includes(i) && Math.random() < GOLDEN_QUESTION_CHANCE) q.isGolden = true;
    sequence.push({ kind: "question", q });
    if (DRILL_MYSTERY_AFTER.includes(i)) sequence.push({ kind: "mystery" });
  }
  dgame = {
    topic, level, topicMeta, sequence, idx: 0,
    score: 0, correct: 0, wrong: 0, streak: 0, bestStreakSession: 0,
    bonusPoints: 0, penaltyPoints: 0, timerId: null, timeLeft: 0, timeTotal: 0, answered: false,
    timeFrozen: false,
    // 🔥 Fever Rush Combo — counts consecutive correct answers solved in
    // under FEVER_ANSWER_SECONDS; feverActive turns on at FEVER_STREAK_NEEDED
    // and applies FEVER_MULTIPLIER to points until a slow/wrong answer resets it.
    feverStreak: 0, feverActive: false,
    // 🐾 Pet Assist — offered once per question after PET_ASSIST_AFTER_SECONDS
    // of inactivity; petAssistTimerId is separate from the main countdown
    // timer so it can be cleared independently.
    petAssistTimerId: null, petAssistOffered: false, petAssistUsed: false,
  };
  if (typeof showPetCheerBubble === "function") showPetCheerBubble();
  renderDrillGameScreen();
}

// Extended 40% (was Math.max(8, 20 - level)) so students with slower/spotty
// connections have more real breathing room per question.
function drillTimeForLevel(level) { return Math.round(Math.max(8, 20 - level) * 1.4); }

function renderDrillGameScreen() {
  const root = document.getElementById("modalRoot");
  const step = dgame.sequence[dgame.idx];
  const answeredCount = dgame.correct + dgame.wrong;

  const dots = dgame.sequence.map((s, i) => {
    if (s.kind === "mystery") return `<div class="drill-mystery-icon" title="Mystery Box"></div>`;
    let cls = "drill-dot";
    if (i < dgame.idx) cls += s._result === "correct" ? " done-correct" : s._result === "wrong" ? " done-wrong" : s._result === "skipped" ? " done-skipped" : "";
    if (i === dgame.idx) cls += " current";
    return `<div class="${cls}"></div>`;
  }).join("");

  root.innerHTML = `
    <div class="drill-overlay ${dgame.feverActive ? "drill-fever-active" : ""}">
      <div class="drill-top-row">
        <div>${dgame.topicMeta.icon} <strong>${dgame.topicMeta.name}</strong> · Level ${dgame.level}</div>
        <div>Score: <strong style="color:${dgame.score < 0 ? "#FF8A75" : "var(--gold-light)"};">${dgame.score}</strong> &nbsp;|&nbsp; Streak: 🔥 ${dgame.streak}
          ${dgame.feverActive ? ` &nbsp;|&nbsp; <span class="drill-fever-badge">🔥 FEVER x${FEVER_MULTIPLIER}</span>` : ""}
        </div>
        <button class="btn-outline" style="border-color:var(--gold-light);color:var(--gold-light);" onclick="quitDrillRun()">✕ Quit</button>
      </div>
      <div class="drill-progress-dots">${dots}</div>
      <div id="drillStage"></div>
    </div>`;

  if (step.kind === "mystery") renderMysteryStage();
  else renderQuestionStage(step.q);
}

function renderQuestionStage(q) {
  dgame.answered = false;
  dgame.timeTotal = drillTimeForLevel(dgame.level);
  dgame.timeLeft = dgame.timeTotal;
  dgame.questionStartedAt = Date.now();
  dgame.petAssistOffered = false;
  dgame.petAssistUsed = false;
  const stage = document.getElementById("drillStage");
  stage.innerHTML = `
    <div class="drill-timerbar-track"><div id="drillTimerFill" class="drill-timerbar-fill" style="width:100%;"></div></div>
    <div class="drill-question-card ${q.isGolden ? "drill-card-golden" : ""}">
      ${q.isGolden ? `<div class="drill-golden-banner">✨ GOLDEN QUESTION — 3× points! ✨</div>` : ""}
      ${q.svg ? `<div style="display:flex;justify-content:center;margin-bottom:10px;">${q.svg}</div>` : ""}
      <div class="drill-question-text">${escapeHtml(q.prompt)}</div>
      ${q.hint ? `<p class="muted" style="margin-top:8px;font-size:.78rem;">${escapeHtml(q.hint)}</p>` : ""}
      <input id="drillAnswerInput" class="drill-answer-input" placeholder="${q.type === "fraction" ? "e.g. 3/4" : "your answer"}" autocomplete="off" />
      <div style="margin-top:16px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
        <button class="btn-primary" onclick="submitDrillAnswer()">Submit</button>
        ${typeof estate !== "undefined" && estate.loaded && estate.data && estate.data.skip_passes > 0
          ? `<button class="btn-outline" onclick="skipDrillQuestion()">⏭️ Skip (${estate.data.skip_passes} left)</button>` : ""}
        ${typeof ownedCount === "function" && ownedCount("time_freeze") > 0
          ? `<button class="btn-outline btn-sm" onclick="useTimeFreezeOnDrill()">⏱️ Time Freeze (${ownedCount("time_freeze")})</button>` : ""}
        ${typeof ownedCount === "function" && ownedCount("genius_pass") > 0
          ? `<button class="btn-outline btn-sm" onclick="useGeniusPassOnDrill()">💡 Genius Pass (${ownedCount("genius_pass")})</button>` : ""}
      </div>
      <div id="drillPetAssist"></div>
      <div id="drillFeedback" class="drill-feedback"></div>
    </div>`;
  const input = document.getElementById("drillAnswerInput");
  if (input) { input.focus(); input.addEventListener("keydown", (e) => { if (e.key === "Enter") submitDrillAnswer(); }); }
  attachNumericKeypad("drillAnswerInput", { type: q.type });

  clearInterval(dgame.timerId);
  dgame.timerId = setInterval(() => {
    if (dgame.timeFrozen) return; // Time Freeze power-up: countdown paused, bar just holds
    dgame.timeLeft -= 0.1;
    const pct = Math.max(0, (dgame.timeLeft / dgame.timeTotal) * 100);
    const fill = document.getElementById("drillTimerFill");
    if (fill) {
      fill.style.width = pct + "%";
      fill.style.background = pct < 25 ? "var(--clay)" : pct < 55 ? "#F4C95D" : "var(--gold)";
    }
    if (dgame.timeLeft <= 0) { clearInterval(dgame.timerId); if (!dgame.answered) submitDrillAnswer(true); }
  }, 100);

  // 🐾 Pet Assist lifeline — if the student is still on this question after
  // PET_ASSIST_AFTER_SECONDS, the pet offers 2 plausible-but-wrong choices
  // alongside the correct one (a "50/50"-style pick, since only 1 wrong
  // option is left standing next to the right answer).
  clearTimeout(dgame.petAssistTimerId);
  if (dgame.timeTotal > PET_ASSIST_AFTER_SECONDS + 2) {
    dgame.petAssistTimerId = setTimeout(() => offerPetAssist(q), PET_ASSIST_AFTER_SECONDS * 1000);
  }
}

function offerPetAssist(q) {
  if (dgame.answered || dgame.petAssistOffered) return;
  dgame.petAssistOffered = true;
  const wrap = document.getElementById("drillPetAssist");
  if (!wrap) return;
  const correctText = fmtDrillAnswer(q);
  const wrongText = plausibleWrongAnswer(q);
  const choices = shuffleArr([correctText, wrongText]);
  wrap.innerHTML = `
    <div class="drill-pet-assist-bubble">
      🐾 <strong>Stuck? I narrowed it down for you!</strong>
      <div style="display:flex;gap:8px;justify-content:center;margin-top:8px;flex-wrap:wrap;">
        ${choices.map((c) => `<button class="btn-outline btn-sm" onclick="choosePetAssistAnswer('${escapeHtml(String(c)).replace(/'/g, "\\'")}')">${escapeHtml(String(c))}</button>`).join("")}
      </div>
    </div>`;
}

/** Builds one plausible-but-wrong distractor near the correct answer, matching the question's answer type. */
function plausibleWrongAnswer(q) {
  if (q.type === "fraction") {
    const off = pick([1, -1]);
    return fracToString(reduceFrac({ n: q.answer.n + off, d: q.answer.d }));
  }
  const delta = pick([-1, 1]) * randInt(1, Math.max(2, Math.round(Math.abs(q.answer) * 0.15) || 2));
  const wrong = q.type === "decimal" ? +(q.answer + delta * 0.1).toFixed(2) : Math.round(q.answer + delta);
  return wrong === q.answer ? wrong + 1 : wrong;
}

function choosePetAssistAnswer(text) {
  if (dgame.answered) return;
  dgame.petAssistUsed = true;
  const input = document.getElementById("drillAnswerInput");
  if (input) input.value = text;
  const wrap = document.getElementById("drillPetAssist");
  if (wrap) wrap.innerHTML = "";
}

/** Spends 1 Genius Pass (shop relic) — same 50/50-style narrowing as Pet Assist, available on demand instead of waiting out the idle timer. */
async function useGeniusPassOnDrill() {
  if (dgame.answered || dgame.petAssistOffered) return;
  const row = await activateShopItem("genius_pass");
  if (!row || !row.success) return;
  clearTimeout(dgame.petAssistTimerId);
  offerPetAssist(dgame.sequence[dgame.idx].q);
}

/** Spends 1 Time Freeze and pauses the countdown for 5 real seconds. */
async function useTimeFreezeOnDrill() {
  if (dgame.answered || dgame.timeFrozen) return;
  const row = await activateShopItem("time_freeze");
  if (!row || !row.success) return;
  dgame.timeFrozen = true;
  const fill = document.getElementById("drillTimerFill");
  if (fill) fill.style.filter = "grayscale(1)";
  toast("⏱️ Time Freeze! 5 seconds off the clock.");
  setTimeout(() => {
    dgame.timeFrozen = false;
    const f = document.getElementById("drillTimerFill");
    if (f) f.style.filter = "";
  }, 5000);
}

/** Spends one Skip Question pass (from a 7-day streak Power-Up) to skip the current question with no penalty. */
async function skipDrillQuestion() {
  if (dgame.answered) return;
  const spent = await consumeSkipPass();
  if (!spent) { toast("No Skip passes left."); return; }
  dgame.answered = true;
  clearInterval(dgame.timerId);
  clearTimeout(dgame.petAssistTimerId);
  dgame.sequence[dgame.idx]._result = "skipped";
  const feedback = document.getElementById("drillFeedback");
  if (feedback) { feedback.className = "drill-feedback"; feedback.innerHTML = "⏭️ Skipped — no penalty!"; }
  const input = document.getElementById("drillAnswerInput");
  if (input) input.disabled = true;
  setTimeout(() => advanceDrillSequence(), 1200);
}

function submitDrillAnswer(timedOut) {
  if (dgame.answered) return;
  dgame.answered = true;
  clearInterval(dgame.timerId);
  clearTimeout(dgame.petAssistTimerId);
  const q = dgame.sequence[dgame.idx].q;
  const input = document.getElementById("drillAnswerInput");
  const raw = timedOut ? "" : (input ? input.value : "");
  const isCorrect = !timedOut && checkDrillAnswer(q, raw);
  const basePoints = dgame.level * 10;
  const feedback = document.getElementById("drillFeedback");
  const answerSeconds = (Date.now() - (dgame.questionStartedAt || Date.now())) / 1000;

  if (isCorrect) {
    dgame.streak++;
    dgame.bestStreakSession = Math.max(dgame.bestStreakSession, dgame.streak);
    const speedBonus = dgame.timeLeft / dgame.timeTotal > 0.5 ? Math.round(basePoints * 0.2) : 0;
    const streakBonus = dgame.streak > 0 && dgame.streak % 3 === 0 ? 15 : 0;
    let gained = basePoints + speedBonus + streakBonus;

    // ✨ Golden Question — 3x on top of everything else earned this question.
    let goldenBonus = 0;
    if (q.isGolden) {
      goldenBonus = gained * (GOLDEN_QUESTION_MULTIPLIER - 1);
      gained += goldenBonus;
    }

    // 🔥 Fever Rush Combo — 3 consecutive sub-5s correct answers doubles
    // points for as long as the streak of fast answers keeps going.
    if (!timedOut && answerSeconds < FEVER_ANSWER_SECONDS) {
      dgame.feverStreak++;
      if (dgame.feverStreak >= FEVER_STREAK_NEEDED) dgame.feverActive = true;
    } else {
      dgame.feverStreak = 0;
      dgame.feverActive = false;
    }
    let feverBonus = 0;
    if (dgame.feverActive) {
      feverBonus = gained * (FEVER_MULTIPLIER - 1);
      gained += feverBonus;
    }

    const doubleXpOn = typeof isDoubleXpActive === "function" && isDoubleXpActive();
    if (doubleXpOn) gained = typeof applyDoubleXp === "function" ? applyDoubleXp(gained) : gained * 2;
    dgame.score += gained;
    dgame.bonusPoints += speedBonus + streakBonus + goldenBonus + feverBonus;
    dgame.correct++;
    dgame.sequence[dgame.idx]._result = "correct";
    let msg = `✅ Correct! +${gained} pts`;
    if (speedBonus) msg += ` <span style="color:var(--gold);">(⚡ +${speedBonus} speed)</span>`;
    if (streakBonus) msg += ` <span style="color:var(--clay);">(🔥 +${streakBonus} streak x${dgame.streak})</span>`;
    if (q.isGolden) msg += ` <span style="color:#B8790E;">(✨ +${goldenBonus} GOLDEN x${GOLDEN_QUESTION_MULTIPLIER})</span>`;
    if (dgame.feverActive) msg += ` <span style="color:#E07856;">(🔥 +${feverBonus} FEVER x${FEVER_MULTIPLIER})</span>`;
    if (doubleXpOn) msg += ` <span style="color:var(--gold);">(⚡×2 Double XP)</span>`;
    feedback.className = "drill-feedback correct";
    feedback.innerHTML = msg;
    if (typeof awardAnswerCoins === "function") {
      awardAnswerCoins(true, 1).then((coins) => { if (coins) feedback.innerHTML += ` &nbsp;·&nbsp; 🪙 +${coins}`; });
    }
    // Green Points for the Math Pet — 1 per correct drill answer, same
    // "playing anywhere earns it" spirit as coins, just a separate currency.
    if (typeof awardGreenPoints === "function") {
      awardGreenPoints(1).then(() => { feedback.innerHTML += ` &nbsp;·&nbsp; 💚 +1`; });
    }
    if (typeof triggerPetEvent === "function") {
      triggerPetEvent(q.isGolden ? "GOLDEN_CORRECT" : "QUESTION_CORRECT");
      if (streakBonus) triggerPetEvent("STREAK_INCREASE", { streak: dgame.streak });
    }
    if (q.isGolden && typeof playGoldenBurst === "function") playGoldenBurst();
  } else {
    dgame.feverStreak = 0;
    dgame.feverActive = false;
    // 🛡️ Streak Shield (shop relic) — protects the current streak from
    // exactly 1 miss, then is consumed. Still costs points, just not the streak.
    const shieldSpared = !!(typeof shopEffects !== "undefined" && shopEffects.streakShieldArmed);
    const penalty = Math.max(5, Math.round(basePoints * 0.4));
    dgame.score -= penalty;
    dgame.penaltyPoints += penalty;
    dgame.wrong++;
    if (shieldSpared) { shopEffects.streakShieldArmed = false; } else { dgame.streak = 0; }
    dgame.sequence[dgame.idx]._result = "wrong";
    feedback.className = "drill-feedback wrong";
    feedback.innerHTML = `${timedOut ? "⏰ Time's up!" : "❌ Not quite."} Correct answer: <strong>${fmtDrillAnswer(q)}</strong> (${penalty} pts)`;
    if (shieldSpared) feedback.innerHTML += ` <span style="color:var(--sage);">(🛡️ Streak Shield protected your streak!)</span>`;
    if (typeof triggerPetEvent === "function") triggerPetEvent("QUESTION_WRONG");
  }
  if (input) input.disabled = true;
  const assistWrap = document.getElementById("drillPetAssist");
  if (assistWrap) assistWrap.innerHTML = "";
  setTimeout(() => advanceDrillSequence(), 1500);
}

function renderMysteryStage() {
  const stage = document.getElementById("drillStage");
  stage.innerHTML = `
    <div class="drill-mysterybox-wrap">
      <div class="muted" style="margin-bottom:10px;">🎁 A Mystery Box appeared!</div>
      <div id="drillMysteryBox" class="drill-mysterybox" onclick="openMysteryBox()">🎁</div>
      <p class="muted" style="margin-top:14px;">Tap the box to open it — what surprise is inside?</p>
      <div id="drillMysteryResult" class="drill-mystery-result"></div>
    </div>`;
}
async function openMysteryBox() {
  const box = document.getElementById("drillMysteryBox");
  if (box.classList.contains("opened")) return;
  box.classList.add("opened");
  const outcome = pickMysteryOutcome(dgame.level);
  box.textContent = MYSTERY_BOX_ICONS[outcome.type] || "✨";
  dgame.score += outcome.amount;
  if (outcome.amount > 0) dgame.bonusPoints += outcome.amount; else dgame.penaltyPoints += -outcome.amount;
  const resultEl = document.getElementById("drillMysteryResult");
  resultEl.style.color = outcome.amount > 0 ? "#4CAF7D" : outcome.amount < 0 ? "#FF8A75" : "var(--gold-light)";
  resultEl.textContent = `${outcome.label} ${outcome.amount >= 0 ? "+" : ""}${outcome.amount} pts`;

  // Apply any persistent side-grant (a free pet Snack / real Coins / a Gemstone).
  if (outcome.grant) {
    const g = outcome.grant;
    let suffix = "";
    if (g.kind === "snack") {
      const pet = typeof activePet === "function" ? activePet() : null;
      if (pet) {
        const { data } = await supabase.rpc("grant_pet_food", { target_student_id: sstate.student.id, target_pet_id: pet.id, target_food_key: g.foodKey, amount: 1 });
        if (data) pet.food_inventory = data;
        suffix = `${PET_FOOD_META[g.foodKey]?.icon || "🍎"} +1 ${g.foodKey.replace(/_/g, " ")}`;
      } else if (typeof awardGreenPoints === "function") {
        // No pet adopted yet — fall back to Green Points so the reward isn't wasted.
        await awardGreenPoints(8, false);
        suffix = "💚 +8 (no pet yet — banked as Green Points)";
      }
    } else if (g.kind === "coins" && typeof awardCoins === "function") {
      await awardCoins(g.amount);
      suffix = `🪙 +${g.amount}`;
    } else if (g.kind === "gemstone") {
      const { data } = await supabase.rpc("award_gemstone", { target_student_id: sstate.student.id, amount: g.amount });
      if (typeof estate !== "undefined" && estate.loaded) estate.data.gemstones = data != null ? data : (estate.data.gemstones || 0) + g.amount;
      suffix = `💎 +${g.amount}`;
    }
    if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
    if (suffix) resultEl.innerHTML += ` &nbsp;·&nbsp; ${suffix}`;
  }
  setTimeout(() => advanceDrillSequence(), 1600);
}

function advanceDrillSequence() {
  dgame.idx++;
  if (dgame.idx >= dgame.sequence.length) finishDrillRun();
  else renderDrillGameScreen();
}

function quitDrillRun() {
  clearInterval(dgame.timerId);
  clearTimeout(dgame.petAssistTimerId);
  document.getElementById("modalRoot").innerHTML = "";
  dgame = null;
}

// ============================================================================
// ✨ Golden particle burst — a gold-tinted variant of shopEngine.js's
// playConfettiBurst(), fired on a correct Golden Question answer.
// ============================================================================
function playGoldenBurst() {
  const colors = ["#F59E0B", "#FDE68A", "#FCD34D", "#FFFFFF"];
  const layer = document.createElement("div");
  layer.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999;overflow:hidden;";
  for (let i = 0; i < 50; i++) {
    const bit = document.createElement("div");
    const left = Math.random() * 100;
    const delay = Math.random() * 0.25;
    const duration = 1 + Math.random() * 0.6;
    const color = colors[i % colors.length];
    bit.style.cssText = `position:absolute;top:-10px;left:${left}vw;width:9px;height:9px;background:${color};
      opacity:.95;border-radius:50%;box-shadow:0 0 6px ${color};transform:rotate(${Math.random() * 360}deg);
      animation:shopConfettiFall ${duration}s ease-in ${delay}s forwards;`;
    layer.appendChild(bit);
  }
  document.body.appendChild(layer);
  setTimeout(() => layer.remove(), 2000);
}

// ============================================================================
// 🎡 WHEEL OF ARCHIMEDES — a perfect 10/10 run unlocks one spin of a prize
// wheel: coins, Green Points, a Skip Pass, or (rarely) a Gemstone.
// ============================================================================
const ARCHIMEDES_PRIZES = [
  { label: "🪙 30 Coins", type: "coins", amount: 30, weight: 30 },
  { label: "🪙 75 Coins — JACKPOT!", type: "coins", amount: 75, weight: 10 },
  { label: "💚 20 Green Points", type: "green", amount: 20, weight: 30 },
  { label: "⏭️ +1 Skip Pass", type: "skip", amount: 1, weight: 20 },
  { label: "💎 1 Gemstone — RARE!", type: "gemstone", amount: 1, weight: 10 },
];
function pickArchimedesPrize() {
  const total = ARCHIMEDES_PRIZES.reduce((s, p) => s + p.weight, 0);
  let roll = Math.random() * total;
  for (const p of ARCHIMEDES_PRIZES) { if (roll < p.weight) return p; roll -= p.weight; }
  return ARCHIMEDES_PRIZES[0];
}
function openArchimedesWheel(returnTopic, returnLevel) {
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-question-card" style="max-width:420px;">
        <h2>🎡 Wheel of Archimedes</h2>
        <p class="muted">Perfect 10/10! Tap the wheel for a jackpot spin.</p>
        <div id="archimedesWheel" class="wheel-modal" onclick="spinArchimedesWheel()">🎡</div>
        <p class="muted" style="margin-top:10px;">Tap to spin!</p>
        <div id="archimedesResult" class="drill-mystery-result"></div>
        <div style="margin-top:16px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <button class="btn-primary" onclick="startDrillRun('${returnTopic}', ${returnLevel})">▶ Play Again</button>
          <button class="btn-outline" onclick="closeDrillGameToHub()">Back to Drills</button>
        </div>
      </div>
    </div>`;
}
async function spinArchimedesWheel() {
  const wheel = document.getElementById("archimedesWheel");
  if (!wheel || wheel.classList.contains("spun")) return;
  wheel.classList.add("spun");
  wheel.style.animation = "spinWheel 1.8s cubic-bezier(.17,.67,.32,1.32) forwards";
  const prize = pickArchimedesPrize();
  setTimeout(async () => {
    const resultEl = document.getElementById("archimedesResult");
    if (resultEl) resultEl.textContent = `🎉 You won: ${prize.label}!`;
    if (prize.type === "coins" && typeof awardCoins === "function") await awardCoins(prize.amount);
    if (prize.type === "green" && typeof awardGreenPoints === "function") await awardGreenPoints(prize.amount, false);
    if (prize.type === "skip" && typeof estate !== "undefined" && estate.loaded) {
      estate.data.skip_passes = (estate.data.skip_passes || 0) + prize.amount;
      if (typeof saveEngagement === "function") await saveEngagement();
    }
    if (prize.type === "gemstone") {
      const { data } = await supabase.rpc("award_gemstone", { target_student_id: sstate.student.id, amount: prize.amount });
      if (typeof estate !== "undefined" && estate.loaded) estate.data.gemstones = data != null ? data : (estate.data.gemstones || 0) + prize.amount;
    }
    if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  }, 1700);
}

async function finishDrillRun() {
  clearInterval(dgame.timerId);
  clearTimeout(dgame.petAssistTimerId);
  const accuracy = dgame.correct / DRILL_RUN_LENGTH;
  const p = dstate.progress;
  const currentUnlocked = p.topic_levels[dgame.topic] || 1;
  let leveledUp = false;
  if (accuracy >= 0.7 && dgame.level === currentUnlocked && dgame.level < DRILL_MAX_LEVEL) {
    p.topic_levels = { ...p.topic_levels, [dgame.topic]: dgame.level + 1 };
    leveledUp = true;
  }
  p.total_points = Math.max(0, p.total_points + dgame.score);
  const prevStationPts = (p.topic_points && p.topic_points[dgame.topic]) || 0;
  p.topic_points = { ...(p.topic_points || defaultTopicPoints()), [dgame.topic]: Math.max(0, prevStationPts + dgame.score) };
  p.games_played += 1;
  p.best_streak = Math.max(p.best_streak, dgame.bestStreakSession);

  await saveDrillProgress();
  await logDrillAttempt(dgame.topic, dgame.level, dgame.correct, dgame.score, dgame.bonusPoints, dgame.penaltyPoints, leveledUp);
  if (typeof recordDailyActivity === "function") { await recordDailyActivity(); await renderTopbarStreakBadge(); }
  if (typeof markDailyActivity === "function") await markDailyActivity("drills");

  // ---- MathLegends stars: earned from THIS run's accuracy, independent of
  // which station it was — feeds the single overall rank. ----
  const starsEarned = starsForDrillRun(accuracy, leveledUp);
  let rankResult = null;
  if (starsEarned > 0) {
    rankResult = await awardMasteryStars(sstate.student.id, starsEarned);
    p.mastery_tier = rankResult.newTier;
    p.mastery_stars = rankResult.newStars;
  }

  if (typeof triggerPetEvent === "function") {
    if (leveledUp) triggerPetEvent("LEVEL_UP");
    if (rankResult && rankResult.promoted) triggerPetEvent("RANK_UP");
  }

  // v58 — certificates are per STATION, not per run: earned once levels 1..DRILL_MAX_LEVEL are all cleared
  // with >= 80% overall accuracy (best run per level). Only a run that cleared its level can change that.
  let certRec = null, certSum = null;
  if (typeof certCheckDrillStation === "function" && accuracy >= 0.7) {
    const chk = await certCheckDrillStation(dgame);
    certRec = chk.rec; certSum = chk.sum;
  }

  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-question-card" style="max-width:520px;">
        ${leveledUp ? `<div class="drill-levelup-banner">🎉 Breakthrough! ${dgame.topicMeta.name} rises to Level ${dgame.level + 1}!</div>` : ""}
        ${rankResult && rankResult.promoted ? `<div class="drill-levelup-banner">🏅 Rank Up! You're now ${renderRankBadge(rankResult.tierObj)}!</div>` : ""}
        <h2>${dgame.topicMeta.icon} Run Complete!</h2>
        <div class="drill-stat-row">
          <div class="drill-stat"><div class="num">${dgame.correct}/${DRILL_RUN_LENGTH}</div><div class="muted">Correct</div></div>
          <div class="drill-stat"><div class="num" style="color:${dgame.score < 0 ? "var(--clay)" : "var(--gold)"};">${dgame.score >= 0 ? "+" : ""}${dgame.score}</div><div class="muted">Points</div></div>
          <div class="drill-stat"><div class="num">🔥 ${dgame.bestStreakSession}</div><div class="muted">Best Streak</div></div>
        </div>
        <p class="muted">Bonus points earned: +${dgame.bonusPoints} &nbsp;·&nbsp; Penalty points: -${dgame.penaltyPoints}</p>
        <p class="muted">🏆 New total: ${p.total_points} points${starsEarned > 0 ? ` &nbsp;·&nbsp; ⭐ +${starsEarned} MathLegends star${starsEarned === 1 ? "" : "s"}` : ""}</p>
        ${certEarnedBannerHtml(certRec)}
        ${certRec ? "" : certStationProgressHtml(certSum, dgame.topicMeta.name)}
        ${dgame.correct === DRILL_RUN_LENGTH ? `<button class="btn-gold" style="margin-top:10px;" onclick="openArchimedesWheel('${dgame.topic}', ${leveledUp ? dgame.level + 1 : dgame.level})">🎡 Spin the Wheel of Archimedes!</button>` : ""}
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
          <button class="btn-primary" onclick="startDrillRun('${dgame.topic}', ${leveledUp ? dgame.level + 1 : dgame.level})">▶ Play Again</button>
          <button class="btn-outline" onclick="closeDrillGameToHub()">Back to Drills</button>
          <button class="btn-outline" onclick="renderDrillLeaderboardView()">📊 Leaderboard</button>
        </div>
      </div>
    </div>`;
  dgame = null;
}
function closeDrillGameToHub() {
  document.getElementById("modalRoot").innerHTML = "";
  renderDrillsHub();
}

// ============================================================================
// MY WEEK — a personal, growth-only summary (never a negative number)
// ============================================================================
function myWeekLines(d) {
  const lines = [];
  if (!d || d.error) return lines;
  const name = (code) => { const t = DRILL_TOPICS.find((x) => x.key === code); return t ? `${t.icon} ${t.name}` : code; };
  if (d.acc_gain != null && d.acc_gain > 0) lines.push({ icon: "📈", text: `Your accuracy is <strong>+${Math.round(d.acc_gain)} points</strong> above your usual (${Math.round(d.base_accuracy)}% → ${Math.round(d.accuracy)}%). That is real growth.` });
  else if (d.base_kind !== "none" && d.answers >= 20) lines.push({ icon: "🌿", text: `Your usual accuracy is about ${Math.round(d.base_accuracy)}%. New topics can feel harder before they click — every session is building your skill, so keep going.` });
  else if (d.base_kind === "none" && d.answers > 0) lines.push({ icon: "🌱", text: "Answer about 20 questions and we'll learn your usual pace — then you'll see exactly how much you grow." });
  if (d.level_ups > 0) lines.push({ icon: "🪜", text: `You climbed <strong>${d.level_ups} level${d.level_ups === 1 ? "" : "s"}</strong>!` });
  if (d.prev_answers > 0 && d.answers > d.prev_answers) lines.push({ icon: "🔥", text: `That's <strong>${d.answers - d.prev_answers} more questions</strong> than the week before.` });
  else if (d.prev_days_active > 0 && d.days_active > d.prev_days_active) lines.push({ icon: "📅", text: `You practiced on more days than the week before.` });
  if (d.best_station) lines.push({ icon: "⭐", text: `Strongest station: <strong>${escapeHtml(name(d.best_station.topic))}</strong> (${Math.round(d.best_station.accuracy)}% on ${d.best_station.answers} questions).` });
  if (d.tag === "new") lines.push({ icon: "🎉", text: "Welcome to your first week of drills — you're on your way!" });
  if (d.tag === "comeback") lines.push({ icon: "🔁", text: "Welcome back! Coming back is the hardest part, and you did it." });
  return lines;
}

async function myWeekCardHtml(weeksAgo) {
  const { data: d } = await supabase.rpc("my_week_progress", { p_student_id: sstate.student.id, p_weeks_ago: weeksAgo || 0 });
  if (!d || d.error) return "";
  const range = `${new Date(d.week_start + "T00:00:00").toLocaleDateString("en-PH", { month: "short", day: "numeric" })} – ${new Date(d.week_end + "T00:00:00").toLocaleDateString("en-PH", { month: "short", day: "numeric" })}`;
  const lines = myWeekLines(d);
  const chip = (icon, val, label) => `<div style="text-align:center;min-width:72px;"><div style="font-size:1.25rem;font-weight:700;">${icon} ${val}</div><div class="muted" style="font-size:.72rem;">${label}</div></div>`;
  const empty = d.answers === 0;
  return `
    <div class="card" style="margin-bottom:16px;" id="myWeekCard">
      <div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:6px;">
        <h3 style="margin:0;">📈 ${weeksAgo ? "Last week" : "My week"}</h3>
        <span class="muted" style="font-size:.78rem;">${range}${weeksAgo ? "" : " · so far"} · <a href="#" onclick="showMyWeek(${weeksAgo ? 0 : 1});return false;">${weeksAgo ? "this week" : "last week"}</a></span>
      </div>
      ${empty ? `
        <p class="muted" style="margin:8px 0 0;">${weeksAgo ? "No drills that week." : "A fresh week! Even one short run starts your progress — there's no pressure, and every question you answer counts."}</p>`
      : `
        <div style="display:flex;gap:14px;flex-wrap:wrap;margin:10px 0;">
          ${chip("❓", d.answers, "questions")}${chip("🎯", d.accuracy != null ? Math.round(d.accuracy) + "%" : "—", "accuracy")}${chip("📅", d.days_active, d.days_active === 1 ? "day" : "days")}${d.level_ups ? chip("🪜", d.level_ups, "level-ups") : ""}${d.progress_pts ? chip("🌟", d.progress_pts, "progress pts") : ""}
        </div>
        ${lines.map((l) => `<div style="font-size:.88rem;margin:4px 0;">${l.icon} ${l.text}</div>`).join("")}
        ${d.rank ? `<div style="font-size:.88rem;margin:4px 0;">🏅 You're <strong>#${d.rank}</strong> on the Most Improved board${d.ranked_total ? ` (of ${d.ranked_total} improving)` : ""}.</div>` : ""}`}
      <div style="margin-top:10px;"><button class="btn-outline btn-sm" onclick="dlbState.activeTab='growth';dlbState.weeksAgo=0;renderDrillLeaderboardView()">🌟 See Most Improved</button></div>
    </div>`;
}

async function showMyWeek(weeksAgo) {
  const el = document.getElementById("myWeekCard");
  if (!el) return;
  el.outerHTML = await myWeekCardHtml(weeksAgo);
}

// ============================================================================
// LEADERBOARDS (top 10 within the student's own grade level)
// Scoped PER STATION by default — fair to every student, since a Fractions
// leaderboard only ranks Fractions points, not whoever farmed points
// somewhere else. An "Overall" tab is kept for reference (lifetime points
// across every station combined, same as before this update).
// ============================================================================
var dlbState = { activeTab: "basic", myVisibility: null, weeksAgo: 0 }; // "basic" | "order" | ... | "overall" | "growth"

async function fetchStationLeaderboard(topic) {
  const gradeLevel = sstate.section.grade_level;
  const { data: top10, error } = await supabase.rpc("station_leaderboard", { target_grade_level: gradeLevel, target_topic: topic, result_limit: 10 });
  const { data: rankRows } = await supabase.rpc("student_station_rank", { target_student_id: sstate.student.id, target_topic: topic });
  const rankInfo = rankRows && rankRows[0] ? rankRows[0] : null;
  return {
    top10: error ? [] : top10 || [],
    myRank: rankInfo ? rankInfo.rnk : null,
    myPoints: rankInfo ? rankInfo.topic_points : 0,
  };
}
async function fetchOverallLeaderboard() {
  const gradeLevel = sstate.section.grade_level;
  const { data: top10, error } = await supabase.rpc("grade_level_drill_leaderboard", { target_grade_level: gradeLevel, result_limit: 10 });
  const { data: rankRows } = await supabase.rpc("student_drill_rank", { target_student_id: sstate.student.id });
  const rankInfo = rankRows && rankRows[0] ? rankRows[0] : null;
  return {
    top10: error ? [] : top10 || [],
    myRank: rankInfo ? rankInfo.rnk : null,
    myPoints: rankInfo ? rankInfo.total_points : 0,
  };
}
// "🌱 Most Improved" — resets every 7 days on points EARNED that week only,
// so a rough lifetime total never permanently locks a student out of
// appearing near the top. Deliberately kept separate from the lifetime
// boards above.
// v49 — "Most Improved" now measures growth against a student's OWN usual
// (accuracy gained + levels climbed), not who played the most. See
// migration-56-weekly-improvement.sql for the exact rules.
async function fetchImprovementBoard() {
  const weeksAgo = dlbState.weeksAgo || 0;
  const [{ data: rows, error }, { data: me }] = await Promise.all([
    supabase.rpc("weekly_improvement_board", { p_student_id: sstate.student.id, p_weeks_ago: weeksAgo, p_limit: 10 }),
    supabase.rpc("my_week_progress", { p_student_id: sstate.student.id, p_weeks_ago: weeksAgo }),
  ]);
  const all = error ? [] : (rows || []);
  return { ranked: all.filter((r) => r.kind === "ranked"), welcome: all.filter((r) => r.kind === "welcome"), me: me || null, failed: !!error };
}

async function loadMyLeaderboardVisibility() {
  const { data } = await supabase.from("student_preferences").select("show_on_leaderboard").eq("student_id", sstate.student.id).maybeSingle();
  dlbState.myVisibility = data ? data.show_on_leaderboard : true;
}
async function toggleLeaderboardVisibility(checked) {
  dlbState.myVisibility = checked;
  await supabase.from("student_preferences").upsert({ student_id: sstate.student.id, show_on_leaderboard: checked, updated_at: new Date().toISOString() });
  toast(checked ? "You're visible on leaderboards again." : "You're hidden from leaderboards now — your own progress still counts, just not shown to classmates.");
  renderDrillLeaderboardView();
}

function drillLeaderboardTabsHtml() {
  const tabs = [{ key: "growth", label: "🌱 Most Improved" }, ...DRILL_TOPICS.map((t) => ({ key: t.key, label: `${isStationLocked(t.key) ? "🔒 " : ""}${t.icon} ${t.name}` })), { key: "overall", label: "🏆 Overall (all stations)" }];
  return `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;">
    ${tabs.map((t) => `<button class="btn-outline" style="padding:6px 12px;font-size:.8rem;${dlbState.activeTab === t.key ? "background:var(--gold-light);border-color:var(--gold);color:var(--forest-dark);" : "border-color:rgba(255,255,255,.4);color:var(--white);"}" onclick="setDrillLeaderboardTab('${t.key}')">${t.label}</button>`).join("")}
  </div>`;
}
function setDrillLeaderboardTab(key) { dlbState.activeTab = key; renderDrillLeaderboardView(); }

function improvementRowsHtml(g) {
  const medals = ["🥇", "🥈", "🥉"];
  if (g.failed) return `<p class="muted">The Most Improved list couldn't load right now — please try again in a moment.</p>`;
  const ranked = g.ranked.length === 0
    ? `<p class="muted">Nobody has grown enough yet this week to be listed — you could be the first! Every question counts.</p>`
    : g.ranked.map((r, i) => `
      <div class="leaderboard-row ${r.is_me ? "me" : ""} ${i < 3 ? "rank-" + (i + 1) : ""}">
        <div class="leaderboard-rank">${i < 3 ? medals[i] : i + 1}</div>
        <div style="flex:1;">
          <strong>${escapeHtml(r.full_name)}</strong>${r.tag === "comeback" ? " 🔁" : r.tag === "new" ? " 🌱" : ""}
          <div class="muted" style="font-size:.78rem;">${escapeHtml(r.section_name)}</div>
          <div style="font-size:.78rem;margin-top:2px;display:flex;gap:10px;flex-wrap:wrap;">
            ${r.acc_gain != null && r.acc_gain > 0 ? `<span>📈 accuracy +${Math.round(r.acc_gain)} pts (${Math.round(r.base_accuracy)}% → ${Math.round(r.accuracy)}%)</span>` : ""}
            ${r.level_ups > 0 ? `<span>🪜 +${r.level_ups} level${r.level_ups === 1 ? "" : "s"}</span>` : ""}
            <span>📅 ${r.days_active} day${r.days_active === 1 ? "" : "s"}</span>
          </div>
        </div>
        <div style="font-weight:700;color:var(--gold);white-space:nowrap;">🌟 ${r.progress_pts}</div>
      </div>`).join("");
  const me = g.me;
  const meLine = me && me.rank == null && me.visible !== false
    ? (me.answers > 0 ? `<hr class="divider"><p class="muted" style="text-align:center;margin:6px 0;">Your week so far: ${me.answers} questions${me.acc_gain > 0 ? ` · accuracy +${Math.round(me.acc_gain)} pts` : ""}. Keep going — you're building toward the list! 🌱</p>` : "")
    : "";
  const welcome = g.welcome.length ? `
    <hr class="divider">
    <div style="font-size:.85rem;"><strong>🌱 New starters &amp; 🔁 comebacks this week</strong> <span class="muted">(not ranked — just celebrated!)</span></div>
    <div style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;">${g.welcome.map((r) => `<span class="badge" style="background:var(--gold-light);color:var(--forest-dark);">${r.tag === "comeback" ? "🔁" : "🌱"} ${escapeHtml(r.full_name)}</span>`).join("")}</div>` : "";
  return ranked + meLine + welcome;
}

async function renderDrillLeaderboardView() {
  const root = document.getElementById("modalRoot");
  root.innerHTML = `<div class="drill-overlay">${drillLeaderboardTabsHtml()}<div class="empty" style="color:var(--white);">Loading leaderboard…</div></div>`;
  if (dlbState.myVisibility === null) await loadMyLeaderboardVisibility();
  const isOverall = dlbState.activeTab === "overall";
  const isGrowth = dlbState.activeTab === "growth";
  const growth = isGrowth ? await fetchImprovementBoard() : null;
  const { top10, myRank, myPoints } = isGrowth ? { top10: [], myRank: null, myPoints: 0 } : isOverall ? await fetchOverallLeaderboard() : await fetchStationLeaderboard(dlbState.activeTab);
  const topicMeta = isOverall || isGrowth ? null : DRILL_TOPICS.find((t) => t.key === dlbState.activeTab);
  const medals = ["🥇", "🥈", "🥉"];
  const heading = isOverall ? "Overall" : isGrowth ? "🌱 Most Improved" : `${topicMeta.icon} ${topicMeta.name}`;
  const subtitle = isOverall ? "Lifetime points across all stations combined — kept for reference."
    : isGrowth ? "Ranked by how much you've GROWN compared with your own usual — not by who plays the most. 🌟 Progress points = 1 for every accuracy point above your usual (up to 30) + 5 for every level you climb."
    : "Ranked by points earned in this station only, so every station gets its own fair champions.";
  const weekToggle = isGrowth ? `
    <div style="display:flex;gap:6px;justify-content:center;margin-bottom:10px;">
      ${[[0, "This week"], [1, "Last week"]].map(([n, label]) => `<button class="btn-outline" style="padding:4px 12px;font-size:.8rem;${(dlbState.weeksAgo || 0) === n ? "background:var(--gold-light);border-color:var(--gold);color:var(--forest-dark);" : "border-color:var(--gold-light);color:var(--gold-light);"}" onclick="dlbState.weeksAgo=${n};renderDrillLeaderboardView()">${label}</button>`).join("")}
    </div>` : "";
  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-top-row">
        <div><strong>📊 ${isGrowth ? "" : "Top 10 — "}${heading} · ${escapeHtml(sstate.section.grade_level)}</strong></div>
        <button class="btn-outline" style="border-color:var(--gold-light);color:var(--gold-light);" onclick="closeDrillLeaderboard()">✕ Close</button>
      </div>
      ${drillLeaderboardTabsHtml()}
      <p class="muted" style="color:var(--gold-light);max-width:600px;margin:0 auto 10px;">${subtitle}</p>
      ${weekToggle}
      <label style="display:inline-flex;align-items:center;gap:6px;color:var(--white);font-size:.8rem;margin-bottom:10px;cursor:pointer;">
        <input type="checkbox" ${dlbState.myVisibility ? "checked" : ""} onchange="toggleLeaderboardVisibility(this.checked)">
        Show me on leaderboards
      </label>
      <div class="drill-question-card" style="max-width:600px;text-align:left;">
        ${isGrowth ? improvementRowsHtml(growth) : top10.length === 0 ? `<p class="muted">No scores yet for ${escapeHtml(sstate.section.grade_level)} in this category — be the first!</p>` : top10.map((r, i) => `
          <div class="leaderboard-row ${r.student_id === sstate.student.id ? "me" : ""} ${i < 3 ? "rank-" + (i + 1) : ""}">
            <div class="leaderboard-rank">${i < 3 ? medals[i] : i + 1}</div>
            <div style="flex:1;">
              <strong>${escapeHtml(r.full_name)}</strong>
              <div class="muted" style="font-size:.78rem;">${escapeHtml(r.section_name)}</div>
            </div>
            <div style="font-weight:700;color:var(--gold);">${isOverall ? r.total_points : r.topic_points} pts</div>
          </div>`).join("")}
        ${!isGrowth && myRank && myRank > 10 ? `
          <hr class="divider">
          <div class="leaderboard-row me">
            <div class="leaderboard-rank">${myRank}</div>
            <div style="flex:1;"><strong>You</strong></div>
            <div style="font-weight:700;color:var(--gold);">${myPoints} pts</div>
          </div>` : dlbState.myVisibility === false ? `
          <hr class="divider">
          <p class="muted" style="text-align:center;">You're hidden from this board right now (see the checkbox above). Your own progress still counts.</p>` : ""}
      </div>
    </div>`;
}
function closeDrillLeaderboard() {
  document.getElementById("modalRoot").innerHTML = "";
  renderDrillsHub();
}
