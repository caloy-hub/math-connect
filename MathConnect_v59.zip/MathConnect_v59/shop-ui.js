// ============================================================================
// MathConnect — Shop tab UI
// Renders the coin balance, the tabbed shop catalog (Boosters & Relics /
// Pet Treats & Superfoods / Pet Accessories / Titles — migration-47), and
// the inventory panel (owned consumables + activate buttons). All logic
// lives in shopEngine.js — this file only renders state and reacts to
// clicks. Pet food/care items themselves come straight from the
// pet_food_items / pet_care_items tables via pet-ui.js's
// renderShopPetSections(), so any row added there (e.g. by
// migration-47-shop-expansion.sql) shows up here with zero code changes.
// Depends on: shopEngine.js, streakEngine.js (estate), pet-ui.js
// (renderShopPetSections), escapeHtml/toast (supabase-client.js).
// ============================================================================

var shopUiState = { activeTab: "boosters" }; // "boosters" | "treats" | "accessories" | "titles"

const SHOP_TABS = [
  { key: "boosters", label: "⚡ Boosters & Relics" },
  { key: "treats", label: "🍕 Pet Treats & Superfoods" },
  { key: "accessories", label: "👒 Pet Accessories" },
  { key: "titles", label: "🏷️ Titles" },
];

// Item ids that live under the Titles tab instead of Boosters & Relics.
const TITLE_ITEM_IDS = ["profile_title", "mathematician_name"];

async function renderShopTab() {
  const el = document.getElementById("tab-shop");
  el.innerHTML = `<div class="empty">Loading the shop…</div>`;
  if (!estate.loaded) await loadEngagement();
  if (!shopState.loaded) await loadShopItems();

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
      <div>
        <h2 style="margin:0 0 4px;">🛒 Power-Up Shop</h2>
        <p class="muted" style="margin:0;">Earn coins by answering drill questions correctly — 🪙2 on your first try, 🪙1 on a corrected retry.</p>
      </div>
      <div style="text-align:right;">
        <div class="muted">Your Balance</div>
        <h3 style="margin:2px 0;color:var(--gold);">🪙 ${estate.data.coins || 0}</h3>
        <div class="muted" style="font-size:.78rem;">💚 ${estate.data.green_points || 0} Green Points</div>
      </div>
    </div>

    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px;">
      ${SHOP_TABS.map((t) => `<button class="btn-outline" style="padding:6px 12px;font-size:.85rem;${shopUiState.activeTab === t.key ? "background:var(--gold-light);border-color:var(--gold);color:var(--forest-dark);" : ""}" onclick="setShopTab('${t.key}')">${t.label}</button>`).join("")}
    </div>

    <div id="shopTab-boosters" style="${shopUiState.activeTab === "boosters" ? "" : "display:none;"}">
      <div id="shopInventoryPanel"></div>
      <div class="card">
        <h3 style="margin:0 0 12px;">Boosters &amp; Relics</h3>
        <div class="shop-grid" id="shopItemGrid"></div>
      </div>
    </div>

    <div id="shopTab-treats" style="${shopUiState.activeTab === "treats" ? "" : "display:none;"}">
      <div id="shopAdoptPetWrap"></div>
      <div id="shopPetFoodWrap"></div>
    </div>

    <div id="shopTab-accessories" style="${shopUiState.activeTab === "accessories" ? "" : "display:none;"}">
      <div id="shopPetAccessoryWrap"></div>
      <div id="shopPetCareWrap"></div>
    </div>

    <div id="shopTab-titles" style="${shopUiState.activeTab === "titles" ? "" : "display:none;"}">
      <div class="card">
        <h3 style="margin:0 0 12px;">🏷️ Titles</h3>
        <div id="shopTitleChipsWrap"></div>
        <div class="shop-grid" id="shopTitleItemGrid"></div>
      </div>
    </div>`;

  renderInventoryPanel();
  renderShopItemGrid();
  renderTitleTab();
  if (typeof renderShopPetSections === "function") renderShopPetSections();
}

function setShopTab(key) {
  shopUiState.activeTab = key;
  SHOP_TABS.forEach((t) => {
    const el = document.getElementById(`shopTab-${t.key}`);
    if (el) el.style.display = t.key === key ? "" : "none";
  });
}

function renderShopItemGrid() {
  const grid = document.getElementById("shopItemGrid");
  if (!grid) return;
  const items = shopState.items.filter((it) => !TITLE_ITEM_IDS.includes(it.id));
  if (!items.length) { grid.innerHTML = `<div class="empty">The shop is empty right now — check back later.</div>`; return; }

  grid.innerHTML = items.map((item) => {
    const meta = SHOP_ITEM_META[item.id] || { icon: "✨" };
    const affordable = (estate.data.coins || 0) >= item.cost;
    const owned = ownedCount(item.id);
    return `
      <div class="shop-item-card">
        <div class="shop-item-icon">${meta.icon}</div>
        <h4 style="margin:8px 0 2px;">${escapeHtml(item.name)}</h4>
        <p class="muted" style="font-size:.8rem;min-height:34px;">${escapeHtml(item.description)}</p>
        ${owned > 0 ? `<div class="muted" style="font-size:.75rem;margin-bottom:6px;">You own: ${owned}</div>` : ""}
        <button class="btn-gold" style="width:100%;" ${affordable ? "" : "disabled"} onclick="handleShopPurchase('${item.id}')">
          ${affordable ? `Buy — 🪙 ${item.cost}` : `🪙 ${item.cost} (need more)`}
        </button>
      </div>`;
  }).join("");
}

// ---------- 🏷️ Titles tab (migration-47) — its own purchase grid + chips, split out of the general item grid/inventory above ----------
function renderTitleTab() {
  const chipsWrap = document.getElementById("shopTitleChipsWrap");
  const grid = document.getElementById("shopTitleItemGrid");
  if (chipsWrap) {
    chipsWrap.innerHTML = `
      ${ownedCount("profile_title") > 0 ? renderTitleChips() : ""}
      ${ownedCount("mathematician_name") > 0 ? renderMathematicianChips() : ""}
      ${ownedCount("profile_title") === 0 && ownedCount("mathematician_name") === 0 ? `<p class="muted">Buy a Profile Title or a Mathematician's Name below to unlock your first flair.</p>` : ""}`;
  }
  if (grid) {
    const items = shopState.items.filter((it) => TITLE_ITEM_IDS.includes(it.id));
    grid.innerHTML = items.map((item) => {
      const meta = SHOP_ITEM_META[item.id] || { icon: "🏷️" };
      const affordable = (estate.data.coins || 0) >= item.cost;
      const nextName = item.id === "mathematician_name" ? nextMathematicianName() : null;
      const soldOut = item.id === "mathematician_name" && !nextName;
      return `
        <div class="shop-item-card">
          <div class="shop-item-icon">${meta.icon}</div>
          <h4 style="margin:8px 0 2px;">${escapeHtml(item.name)}</h4>
          <p class="muted" style="font-size:.8rem;min-height:34px;">${escapeHtml(item.description)}</p>
          ${nextName ? `<div class="muted" style="font-size:.75rem;margin-bottom:6px;">Next unlock: <strong>${escapeHtml(nextName)}</strong></div>` : ""}
          ${soldOut ? `<div class="muted" style="font-size:.78rem;margin-bottom:6px;">🏆 All mathematicians unlocked!</div>` :
          `<button class="btn-gold" style="width:100%;" ${affordable ? "" : "disabled"} onclick="handleShopPurchase('${item.id}')">
            ${affordable ? `Buy — 🪙 ${item.cost}` : `🪙 ${item.cost} (need more)`}
          </button>`}
        </div>`;
    }).join("");
  }
}

function renderInventoryPanel() {
  const el = document.getElementById("shopInventoryPanel");
  if (!el) return;
  const owned = shopState.items.filter((it) => !TITLE_ITEM_IDS.includes(it.id) && ownedCount(it.id) > 0);
  const doubleXpActive = isDoubleXpActive();
  const coinMagnetActive = typeof isCoinMagnetActive === "function" && isCoinMagnetActive();

  if (!owned.length && !doubleXpActive && !coinMagnetActive) {
    el.innerHTML = "";
    return;
  }

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin:0 0 12px;">🎒 My Inventory</h3>
      ${doubleXpActive ? `
        <div style="padding:10px 14px;background:var(--gold-light);border-radius:8px;margin-bottom:12px;">
          ⚡ <strong>Double XP is active!</strong> Skill points are doubled until
          ${new Date(estate.data.double_xp_expires_at).toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" })}.
        </div>` : ""}
      ${coinMagnetActive ? `
        <div style="padding:10px 14px;background:var(--gold-light);border-radius:8px;margin-bottom:12px;">
          🧲 <strong>Coin Magnet is active!</strong> Coins are doubled until
          ${new Date(estate.data.coin_magnet_expires_at).toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" })}.
        </div>` : ""}
      <div style="display:flex;flex-wrap:wrap;gap:10px;">
        ${owned.map((item) => {
          const meta = SHOP_ITEM_META[item.id] || { icon: "✨" };
          const count = ownedCount(item.id);
          const isDoubleXpAndActive = item.id === "double_xp" && doubleXpActive;
          const isCoinMagnetAndActive = item.id === "coin_magnet" && coinMagnetActive;
          const isStreakShieldArmed = item.id === "streak_shield" && typeof shopEffects !== "undefined" && shopEffects.streakShieldArmed;
          const disabled = isDoubleXpAndActive || isCoinMagnetAndActive || isStreakShieldArmed;
          const label = isDoubleXpAndActive || isCoinMagnetAndActive ? "Active" : isStreakShieldArmed ? "Armed" : "Activate";
          return `
            <div style="border:1px solid var(--paper-line);border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px;">
              <span style="font-size:1.3rem;">${meta.icon}</span>
              <div>
                <div style="font-weight:600;font-size:.88rem;">${escapeHtml(item.name)} <span class="muted">×${count}</span></div>
                <div class="muted" style="font-size:.72rem;">${escapeHtml(meta.short || "")}</div>
              </div>
              <button class="btn-outline btn-sm" ${disabled ? "disabled" : ""} onclick="handleShopActivate('${item.id}')">
                ${label}
              </button>
            </div>`;
        }).join("")}
      </div>
    </div>`;
}

function renderTitleChips() {
  const titles = unlockedTitles();
  const active = estate.data.active_title;
  return `
    <div style="margin-bottom:12px;">
      <div class="muted" style="font-size:.78rem;margin-bottom:6px;">🏷️ Your titles — tap to display next to your name:</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;">
        ${titles.map((title) => `
          <button class="btn-outline btn-sm" style="${title === active ? "background:var(--gold-light);border-color:var(--gold);" : ""}"
            onclick="handleSetActiveTitle('${escapeHtml(title)}')">
            ${title === active ? "✓ " : ""}${escapeHtml(title)}
          </button>`).join("")}
      </div>
    </div>`;
}

function renderMathematicianChips() {
  const names = unlockedMathematicianNames();
  const active = estate.data.active_title;
  const bio = (key) => (typeof MATH_BIOS !== "undefined" && MATH_BIOS[key]) || null;
  return `
    <div style="margin-bottom:12px;">
      <div class="muted" style="font-size:.78rem;margin-bottom:6px;">🧮 Your mathematician names — tap to display next to your name:</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;">
        ${names.map((name) => {
          const b = bio(name);
          return `
          <button class="btn-outline btn-sm" title="${b ? escapeHtml(b.period) : ""}" style="${name === active ? "background:var(--gold-light);border-color:var(--gold);" : ""}"
            onclick="handleSetActiveTitle('${escapeHtml(name)}')">
            ${name === active ? "✓ " : ""}${escapeHtml(name)}
          </button>`;
        }).join("")}
      </div>
    </div>`;
}

async function handleShopPurchase(itemId) {
  const row = await purchaseShopItem(itemId);
  if (row && row.success) { renderInventoryPanel(); renderShopItemGrid(); renderTitleTab(); }
}

async function handleShopActivate(itemId) {
  const row = await activateShopItem(itemId);
  if (row && row.success) { renderInventoryPanel(); renderShopItemGrid(); }
}

async function handleSetActiveTitle(title) {
  const ok = await setActiveTitle(title);
  if (ok) { renderTitleTab(); if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge(); }
}
