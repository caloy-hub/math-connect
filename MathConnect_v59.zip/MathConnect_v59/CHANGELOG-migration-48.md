# MathConnect — Migration 48 Changelog
## School-wide Term Toggle, Editable/Deletable Teacher Accounts, Admin Overview Reorganized

## 1. One switch to change the term for every class (migration-48-global-term-control.sql, admin.js, admin.html, teacher.js)
**Problem:** each section already had its own Term 1/2/3 rows with an
`is_active` flag, but nothing ever flipped that flag after a class's terms
were first created — Term 1 stayed "active" forever no matter what time of
year it actually was, section by section, with no whole-school switch.

**Fix:**
- New `school_settings` table — one row, `current_term_number`, the
  school's single source of truth for "what term is it right now."
  Publicly readable, admin-only to write.
- New `admin_set_current_term(target_term_number)` RPC (admin-only,
  re-checks `is_admin()` itself) that atomically: backfills Term 1/2/3
  rows for any section that doesn't have them yet (a class no teacher has
  opened before), flips `is_active` to match on **every** section's terms,
  and records the new current term.
- New **🗓️ School Term** tab in Admin Overview: a click-to-switch Term
  1 → 2 → 3 tracker (reuses the app's existing `.termline` component, the
  same one students see on their own dashboard). Confirms before switching,
  toasts on success, logs to the Audit Log as `term_change`.
- `teacher.js`'s `ensureTerms()` — when a brand-new section gets its Term
  rows created for the first time, it now asks `school_settings` which
  term is current instead of hard-coding Term 1, so a class created
  mid-Term-2/3 starts in step with the rest of the school.
- Existing per-screen "look back at Term 1/2/3's data" dropdowns (Admin's
  All Classes filter, Teacher's `#termSelect`, Student's term picker) are
  untouched — this only changes which term counts as *current*, not
  anyone's ability to browse past terms.

**Run `migration-48-global-term-control.sql` once in the Supabase SQL
Editor before deploying this drop.**

## 2. Teacher accounts: edit name/school/position, safer delete (admin.js, admin.html)
- Teacher Accounts table: **Name**, **School**, and **Position** are now
  inline-editable text fields (same click-to-edit pattern already used for
  the "Joined" date), saved through `updateAccountField()` — no new RLS
  needed, admin already had UPDATE rights on `teachers` since migration-19.
- Deleting a teacher now warns specifically that it cascades to delete
  every section/class they own, plus that class's students, terms,
  assessments, scores, and attendance (this cascade already existed at the
  database level via `on delete cascade`; the confirmation dialog just
  didn't say so before).
- Renaming a teacher immediately refreshes the All Classes table too, so
  the name shown there doesn't go stale until the next full reload.
- Sign-in email is still shown read-only (it lives in Supabase Auth, not
  the `teachers` table — changing it needs the `service_role` key this
  app deliberately never ships to the browser, same limitation already
  documented for password resets in migration-41).

## 3. Admin Overview reorganized into tabs — no more long scrolling (admin.html, admin.js)
Admin Overview used to be one long stacked page: stats → All Classes table
→ Drill Station locks → Practice Domain locks → Championship → Audit Log →
Teacher Accounts → Student Accounts, all on screen at once. It's now a
sidebar/tab layout (same pattern as Teacher Dashboard), so only one section
is visible at a time:

- 🏠 **Overview** — the 3 stat cards + a one-line summary of the current
  school term.
- 🗓️ **School Term** — the new global term toggle (see #1).
- 🔒 **Content Locks** — Drill Station locks + Practice Domain locks.
- 📊 **All Classes** — the General Average / Proficiency / Attendance /
  Examinations table, unchanged.
- 🏆 **Championship** — MathLegends Grand Champion standings + Hall of Fame.
- 👩‍🏫 **Teacher Accounts** / 🧑‍🎓 **Student Accounts** — unchanged content,
  own tab each.
- 📋 **Audit Log** — Logins / Admin Actions, unchanged content.

On mobile, a hamburger button opens the same drawer pattern already used
on Teacher Dashboard, plus a quick 4-item tabbar for the most-used
sections. Every panel's underlying data still loads once on page load
(`initAdmin()`); the tabs only control which one is visible, so switching
tabs is instant with no extra network round-trip.

## Verification performed
- `node --check` syntax check on `admin.js` and `teacher.js` — both pass.
- Manual review of `admin.html` — `<div>` open/close tags balance (81/81),
  and every `onclick="…"` handler referenced in the HTML has a matching
  function defined in `admin.js`/`auth.js`.
- The new SQL was written to mirror the exact security-definer +
  `is_admin()` pattern already used by `admin_reset_teacher_password()`
  (migration-41) and `finalize_school_year()` (migration-24), but **has
  not been run against a live Supabase project** — please run it in a
  staging environment first and click through the new School Term tab
  before deploying to production.

## Not automated
- Manual click-through of the new tab navigation, the term-switch
  confirmation flow, and the inline teacher-edit fields in an actual
  browser — please verify these once live, since they weren't scriptable
  in this environment.
