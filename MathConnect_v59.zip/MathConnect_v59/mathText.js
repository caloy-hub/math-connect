// ============================================================================
// MathConnect — MathText (v53)
// Renders the way teachers naturally TYPE math into the way students expect to
// READ it, so symbols never hurt comprehension of an exam question.
//
//   x^2  →  x²      sqrt(x+1) →  √ with a proper overbar     <=  →  ≤
//   1/2  →  stacked fraction   (a+1)/(b-2) →  stacked        pi  →  π
//   H_2O →  H₂O     30^o → 30°      +-  →  ±      \frac{a}{b}, \sqrt[3]{x}
//
// EQUATIONS & FORMULAS (v53.1): whole formulas display properly, e.g.
//   x = (-b +- sqrt(b^2 - 4ac))/(2a)      quadratic formula, stacked
//   m = (y_2 - y_1)/(x_2 - x_1)           slope        d = m/v, x/2, 3x/4   variable fractions
//   sum_(i=1)^n i = (n(n+1))/2            ∑ with limits above/below   lim_(x->0), int_0^1
//   3 x 4 = 12                            "x" between numbers shows as ×
//   $$ x^2 + 5x + 6 = 0 $$                display equation, centred on its own line
//
// Also understands a useful subset of LaTeX (\frac \sqrt \pi \theta \leq \neq
// \times \div \angle \triangle …, and $…$ delimiters), and passes any symbol
// typed or pasted directly (∠ △ ≤ ≥ π √ ² ³ ½ …) straight through untouched.
//
// SAFETY: every character is HTML-escaped BEFORE it is emitted; the only markup
// this file ever produces is its own fixed set of <span>/<sup>/<sub> tags.
// Loaded on student.html + teacher.html (no dependencies).
// ============================================================================
(function (global) {
  "use strict";

  const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  const esc = (t) => String(t).replace(/[&<>"']/g, (m) => ESC[m]);

  // \command → symbol
  const CMD = {
    // Greek
    alpha: "α", beta: "β", gamma: "γ", delta: "δ", epsilon: "ε", zeta: "ζ", eta: "η", theta: "θ", lambda: "λ",
    mu: "μ", nu: "ν", xi: "ξ", pi: "π", rho: "ρ", sigma: "σ", tau: "τ", phi: "φ", chi: "χ", psi: "ψ", omega: "ω",
    Gamma: "Γ", Delta: "Δ", Theta: "Θ", Lambda: "Λ", Pi: "Π", Sigma: "Σ", Phi: "Φ", Psi: "Ψ", Omega: "Ω",
    // operators & relations
    times: "×", div: "÷", cdot: "·", pm: "±", mp: "∓", leq: "≤", le: "≤", geq: "≥", ge: "≥", neq: "≠", ne: "≠",
    approx: "≈", equiv: "≡", sim: "∼", cong: "≅", propto: "∝", infty: "∞", degree: "°", circ: "°",
    // geometry
    angle: "∠", triangle: "△", perp: "⊥", parallel: "∥", square: "□",
    // sets & logic
    in: "∈", notin: "∉", subset: "⊂", subseteq: "⊆", cup: "∪", cap: "∩", emptyset: "∅", varnothing: "∅",
    forall: "∀", exists: "∃", neg: "¬", land: "∧", lor: "∨", therefore: "∴", because: "∵",
    mathbb_N: "ℕ", mathbb_Z: "ℤ", mathbb_Q: "ℚ", mathbb_R: "ℝ",
    // arrows
    to: "→", rightarrow: "→", leftarrow: "←", Rightarrow: "⇒", Leftrightarrow: "⇔", leftrightarrow: "↔",
    // misc
    sum: "∑", prod: "∏", int: "∫", partial: "∂", nabla: "∇", ldots: "…", dots: "…", cdots: "⋯", prime: "′", percent: "%",
  };

  // Plain-word forms (whole word, lowercase only): "2 pi r", "sin theta"
  const WORD = {
    pi: "π", theta: "θ", alpha: "α", beta: "β", gamma: "γ", delta: "δ", lambda: "λ", sigma: "σ", omega: "ω", phi: "φ",
    infinity: "∞",
  };

  const isAlnum = (c) => !!c && /[A-Za-z0-9]/.test(c);
  const isLetter = (c) => !!c && /[A-Za-z]/.test(c);
  const isDigit = (c) => !!c && /[0-9]/.test(c);

  // Balanced group starting at s[i] === open. Returns { inner, end } or null.
  function group(s, i, open, close) {
    let d = 0;
    for (let j = i; j < s.length; j++) {
      const c = s[j];
      if (c === "\\") { j++; continue; }
      if (c === open) d++;
      else if (c === close) { d--; if (d === 0) return { inner: s.slice(i + 1, j), end: j + 1 }; }
    }
    return null;
  }

  const fracHtml = (a, b) => `<span class="mt-frac"><span class="mt-num">${a}</span><span class="mt-den">${b}</span></span>`;
  const radHtml = (body, idx) =>
    `<span class="mt-rad">${idx ? `<sup class="mt-rad-idx">${idx}</sup>` : ""}<span class="mt-rad-sign">√</span><span class="mt-rad-body">${body}</span></span>`;

  // Reads a ^ or _ argument starting at s[i]. Returns { html, raw, end } or null.
  function readScript(s, i, isSup, depth) {
    const c = s[i];
    if (c === "{") {
      const g = group(s, i, "{", "}");
      if (g) return { html: render(g.inner, depth + 1), raw: g.inner.trim(), end: g.end };
    }
    if (c === "(") {
      const g = group(s, i, "(", ")");
      if (g && g.inner.trim()) return { html: render(g.inner, depth + 1), raw: g.inner.trim(), end: g.end };
    }
    if (c === "\\") {
      const m = /^\\([A-Za-z]+)/.exec(s.slice(i));
      if (m && CMD[m[1]]) return { html: esc(CMD[m[1]]), raw: "\\" + m[1], end: i + m[0].length };
    }
    const rest = s.slice(i, i + 24);
    // sign + digits (x^-1, 10^-3, x^2, 2^10) — but for subscripts don't take a sign
    let m = (isSup ? /^[+\-−]?\d+(?:\.\d+)?/ : /^\d+/).exec(rest);
    if (m) return { html: esc(m[0].replace("-", "−")), raw: m[0], end: i + m[0].length };
    // single letter (x^n, a_n) — but not the start of a longer word (avoids snake_case, x^abc)
    m = /^[+\-−]?[A-Za-z]/.exec(rest);
    if (m && !isLetter(rest[m[0].length])) return { html: esc(m[0].replace("-", "−")), raw: m[0], end: i + m[0].length };
    return null;
  }

  // ---- variable fractions: x/2, 3x/4, d/t, 1/(x+1), (a+b)/c, m/(n) ----
  const TOK = String.raw`(?:\d+(?:\.\d+)?[A-Za-z]?|[A-Za-z])(?:\^-?\d+)?`;
  const RE_TF = new RegExp("^(" + TOK + ")\\/(" + TOK + ")(?![A-Za-z0-9\\/]|\\.\\d)");
  const RE_TF_PAREN_DEN = new RegExp("^(" + TOK + ")\\/\\(");
  const RE_PAREN_NUM_TOKEN = new RegExp("^\\/(" + TOK + ")(?![A-Za-z0-9\\/]|\\.\\d)");
  const OPERAND_PREV = "=(+-*×<>≤≥≠±,;:[{";

  function prevNonSpace(s, i) { let j = i - 1; while (j >= 0 && s[j] === " ") j--; return j >= 0 ? s[j] : ""; }

  function tokenFrac(s, i, depth) {
    const prev = s[i - 1];
    if (prev && /[A-Za-z0-9.\/_^)]/.test(prev)) return null; // must start at a token boundary
    const rest = s.slice(i);
    let m = RE_TF.exec(rest);
    let kind = null;
    if (m && /[A-Za-z]/.test(m[1] + m[2])) kind = "tok";
    else { m = RE_TF_PAREN_DEN.exec(rest); if (m) kind = "paren"; }
    if (!kind) return null;
    const pureLetters = !/\d/.test(m[1] + (kind === "tok" ? m[2] : ""));
    const pv = prevNonSpace(s, i);
    if (pureLetters) { if (pv && !OPERAND_PREV.includes(pv)) return null; }            // "d = m/v" yes, "coffee w/o", "20 m/s" no
    else if (s[i - 1] === " " && /\d/.test(pv)) return null;                            // "5 m/2" style unit context
    if (kind === "tok") return { html: fracHtml(render(m[1], depth + 1), render(m[2], depth + 1)), end: i + m[0].length };
    const gs = i + m[0].length - 1, g = group(s, gs, "(", ")");
    if (g && g.inner.trim()) return { html: fracHtml(render(m[1], depth + 1), render(g.inner, depth + 1)), end: g.end };
    return null;
  }

  // ---- ∑ ∏ lim with limits stacked above/below ----
  function bigOp(sym, s, j, depth) {
    let sub = null, sup = null, k = j;
    for (let n = 0; n < 2; n++) {
      if (s[k] === "_" && sub === null) { const sc = readScript(s, k + 1, false, depth); if (!sc) break; sub = sc.html; k = sc.end; }
      else if (s[k] === "^" && sup === null) { const sc = readScript(s, k + 1, true, depth); if (!sc) break; sup = sc.html; k = sc.end; }
      else break;
    }
    if (sub === null && sup === null) return null;
    return { end: k, html: `<span class="mt-bigop">${sup !== null ? `<span class="mt-bigop-top">${sup}</span>` : ""}<span class="mt-bigop-sym${sym === "lim" ? " mt-bigop-lim" : ""}">${sym}</span>${sub !== null ? `<span class="mt-bigop-bot">${sub}</span>` : ""}</span>` };
  }

  function render(s, depth) {
    depth = depth || 0;
    if (depth > 6) return esc(s);
    let out = "";
    let i = 0;
    const n = s.length;

    while (i < n) {
      const c = s[i];

      // ---------------- backslash commands ----------------
      if (c === "\\") {
        const nx = s[i + 1];
        if (nx === undefined) { i++; continue; }
        if (nx === "\\") { out += "\n"; i += 2; continue; }
        if (!isLetter(nx)) {
          if (" ,;:!".includes(nx)) { out += nx === " " || nx === ";" || nx === ":" ? " " : ""; i += 2; continue; }
          if ("()[]".includes(nx)) { i += 2; continue; } // \( \) \[ \] delimiters
          out += esc(nx); i += 2; continue;              // \{ \} \% \$ \_ \^ …
        }
        const m = /^\\([A-Za-z]+)/.exec(s.slice(i));
        const name = m[1];
        let j = i + m[0].length;

        if (name === "frac" || name === "dfrac" || name === "tfrac") {
          while (s[j] === " ") j++;
          const g1 = s[j] === "{" ? group(s, j, "{", "}") : null;
          if (g1) {
            let k = g1.end; while (s[k] === " ") k++;
            const g2 = s[k] === "{" ? group(s, k, "{", "}") : null;
            if (g2) { out += fracHtml(render(g1.inner, depth + 1), render(g2.inner, depth + 1)); i = g2.end; continue; }
          }
          i = j; continue;
        }
        if (name === "sqrt") {
          let idx = "";
          if (s[j] === "[") { const g = group(s, j, "[", "]"); if (g) { idx = esc(g.inner); j = g.end; } }
          while (s[j] === " ") j++;
          if (s[j] === "{") {
            const g = group(s, j, "{", "}");
            if (g) { out += radHtml(render(g.inner, depth + 1), idx); i = g.end; continue; }
          }
          const t = /^(\d+(?:\.\d+)?|[A-Za-z])/.exec(s.slice(j));
          if (t) { out += radHtml(esc(t[1]), idx); i = j + t[1].length; continue; }
          out += "√"; i = j; continue;
        }
        if (name === "text" || name === "mathrm" || name === "textbf" || name === "mathbf" || name === "textit" || name === "mathit") {
          if (s[j] === "{") {
            const g = group(s, j, "{", "}");
            if (g) {
              const inner = esc(g.inner);
              out += /bf$/.test(name) ? `<b>${inner}</b>` : /it$/.test(name) ? `<i>${inner}</i>` : inner;
              i = g.end; continue;
            }
          }
        }
        if (name === "overline" || name === "bar" || name === "overrightarrow" || name === "vec") {
          if (s[j] === "{") {
            const g = group(s, j, "{", "}");
            if (g) {
              const cls = name === "overline" || name === "bar" ? "mt-over" : "mt-vec";
              out += `<span class="${cls}">${render(g.inner, depth + 1)}</span>`; i = g.end; continue;
            }
          }
        }
        if (name === "quad" || name === "qquad") { out += name === "quad" ? "  " : "    "; i = j; continue; }
        if (name === "left" || name === "right") {
          if (s[j] === ".") j++;
          i = j; continue;
        }
        if (name === "mathbb" && s[j] === "{") {
          const g = group(s, j, "{", "}");
          if (g) { const k = "mathbb_" + g.inner.trim(); out += esc(CMD[k] || g.inner); i = g.end; continue; }
        }
        if ((name === "sum" || name === "prod" || name === "lim") && (s[j] === "_" || s[j] === "^")) {
          const b = bigOp(name === "lim" ? "lim" : CMD[name], s, j, depth);
          if (b) { out += b.html; i = b.end; continue; }
        }
        if (CMD[name]) { out += esc(CMD[name]); i = j; continue; }
        out += esc(name); i = j; continue; // unknown command (e.g. \lim, \sin): show its name rather than nothing
      }

      // ---------------- superscript / subscript ----------------
      if (c === "^" && i > 0) {
        const sc = readScript(s, i + 1, true, depth);
        if (sc) {
          if (sc.raw === "o" || sc.raw === "\\circ" || sc.raw === "°") out += "°";
          else out += `<sup class="mt-sup">${sc.html}</sup>`;
          i = sc.end; continue;
        }
      }
      if (c === "_" && i > 0 && (isAlnum(s[i - 1]) || ")}]∫∑∏".includes(s[i - 1]))) {
        const sc = readScript(s, i + 1, false, depth);
        if (sc) { out += `<sub class="mt-sub">${sc.html}</sub>`; i = sc.end; continue; }
      }

      // ---------------- words: sqrt( ), cbrt( ), pi, theta, 30 deg ----------------
      if (isLetter(c)) {
        let j = i; while (j < n && isLetter(s[j])) j++;
        const word = s.slice(i, j);

        if (word.length === 1) {
          const tf = tokenFrac(s, i, depth);
          if (tf) { out += tf.html; i = tf.end; continue; }
          // "3 x 4" (a lone x between numbers, with spaces) is multiplication
          if (word === "x" && s[i - 1] === " " && s[j] === " " && /[\d)]/.test(prevNonSpace(s, i)) && /^\s+[\d(]/.test(s.slice(j))) { out += "×"; i = j; continue; }
        }
        if ((word === "sum" || word === "prod" || word === "lim") && (s[j] === "_" || s[j] === "^")) {
          const b = bigOp(word === "lim" ? "lim" : word === "sum" ? "∑" : "∏", s, j, depth);
          if (b) { out += b.html; i = b.end; continue; }
        }
        if (word === "int" && (s[j] === "_" || s[j] === "^")) { out += "∫"; i = j; continue; }

        if ((word === "sqrt" || word === "cbrt") && !isLetter(s[i - 1])) {
          const idx = word === "cbrt" ? "3" : "";
          if (s[j] === "(") {
            const g = group(s, j, "(", ")");
            if (g) { out += radHtml(render(g.inner, depth + 1), idx); i = g.end; continue; }
          }
          if (s[j] === "{") {
            const g = group(s, j, "{", "}");
            if (g) { out += radHtml(render(g.inner, depth + 1), idx); i = g.end; continue; }
          }
          const t = /^\s?(\d+(?:\.\d+)?|[A-Za-z])(?![A-Za-z])/.exec(s.slice(j));
          if (t) { out += radHtml(esc(t[1]), idx); i = j + t[0].length; continue; }
          out += idx === "3" ? "∛" : "√"; i = j; continue;
        }
        if (word === "deg" && (isDigit(s[i - 1]) || (s[i - 1] === " " && isDigit(s[i - 2])))) {
          out = out.replace(/ $/, ""); out += "°"; i = j; continue;
        }
        if (WORD[word]) { out += WORD[word]; i = j; continue; }
        out += esc(word); i = j; continue;
      }

      // ---------------- numbers: stacked numeric fractions ----------------
      if (isDigit(c)) {
        const prev = s[i - 1];
        if (!isDigit(prev) && prev !== "." && prev !== "/") {
          const tf = tokenFrac(s, i, depth);
          if (tf) { out += tf.html; i = tf.end; continue; }
          const fm = /^(\d+)\/(\d+)(?![\d\/]|\.\d)/.exec(s.slice(i));
          if (fm) { out += fracHtml(esc(fm[1]), esc(fm[2])); i += fm[0].length; continue; }
        }
        const nm = /^\d+(?:[.,]\d+)*/.exec(s.slice(i));
        out += esc(nm[0]); i += nm[0].length; continue;
      }

      // ---------------- (expr)/(expr) → stacked fraction ----------------
      if (c === "(" && !isAlnum(s[i - 1])) { // not a function call like sin(x)/x or f(x)/2
        const g1 = group(s, i, "(", ")");
        if (g1 && s[g1.end] === "/" && s[g1.end + 1] === "(") {
          const g2 = group(s, g1.end + 1, "(", ")");
          if (g2 && g1.inner.trim() && g2.inner.trim()) {
            out += fracHtml(render(g1.inner, depth + 1), render(g2.inner, depth + 1)); i = g2.end; continue;
          }
        } else if (g1 && g1.inner.trim() && s[g1.end] === "/") {
          const tm = RE_PAREN_NUM_TOKEN.exec(s.slice(g1.end));
          if (tm) { out += fracHtml(render(g1.inner, depth + 1), render(tm[1], depth + 1)); i = g1.end + tm[0].length; continue; }
        }
      }

      // ---------------- multi-character operators ----------------
      const two = s.substr(i, 2), three = s.substr(i, 3);
      if (three === "<=>") { out += "⇔"; i += 3; continue; }
      if (three === "<->") { out += "↔"; i += 3; continue; }
      if (three === "=/=") { out += "≠"; i += 3; continue; }
      if (three === "+/-") { out += "±"; i += 3; continue; }
      if (three === "...") { out += "…"; i += 3; continue; }
      if (two === "<=") { out += "≤"; i += 2; continue; }
      if (two === ">=") { out += "≥"; i += 2; continue; }
      if (two === "!=") { out += "≠"; i += 2; continue; }
      if (two === "+-") { out += "±"; i += 2; continue; }
      if (two === "~=") { out += "≈"; i += 2; continue; }
      if (two === "->") { out += "→"; i += 2; continue; }
      if (two === "=>") { out += "⇒"; i += 2; continue; }

      // "3*4" / "a * b" → ×  (only between operands, so a leading "*Note" is left alone)
      if (c === "*" && s[i + 1] !== "*") {
        const before = s.slice(0, i).replace(/\s+$/, "").slice(-1);
        const after = s.slice(i + 1).replace(/^\s+/, "").charAt(0);
        if (/[A-Za-z0-9)\]}.]/.test(before) && /[A-Za-z0-9(\[{.\-+√π]/.test(after)) { out += "×"; i++; continue; }
      }

      out += esc(c); i++;
    }
    return out;
  }

  // "$x^2$" → "x^2" (only when the content looks like math, so "$5 and $10" prices are untouched)
  function stripDollars(s) {
    return s.replace(/\$([^$\n]*[\\^_{}][^$\n]*)\$/g, "$1");
  }

  /** Safe HTML for a piece of teacher-typed math text. */
  function html(str) {
    if (str === null || str === undefined || str === "") return "";
    const src = String(str);
    // $$ … $$ and \[ … \] are display equations: centred on their own line, slightly larger.
    const re = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]/g;
    let out = "", last = 0, m;
    while ((m = re.exec(src))) {
      out += render(stripDollars(src.slice(last, m.index).replace(/\n$/, "")));
      out += `<span class="mt-display">${render((m[1] !== undefined ? m[1] : m[2]).trim())}</span>`;
      last = m.index + m[0].length;
      if (src[last] === "\n") last++;
    }
    out += render(stripDollars(src.slice(last)));
    return `<span class="mt">${out}</span>`;
  }

  // ==========================================================================
  // Symbol palette (teacher editor) — inserts real Unicode characters, so the
  // symbols also survive copy/paste, exports and any screen that does not run
  // this renderer.
  // ==========================================================================
  const PALETTE = [
    { key: "basic", label: "Basic", items: ["×", "÷", "±", "∓", "·", "°", "%", "‰", "(", ")", "[", "]", "{", "}", "|"] },
    { key: "rel", label: "Compare", items: ["≤", "≥", "≠", "≈", "≡", "∼", "∝", "<", ">", "⇒", "⇔", "→", "←", "↔"] },
    { key: "pow", label: "Powers & roots", items: ["²", "³", "⁴", "ⁿ", "⁻¹", "⁻²", "₀", "₁", "₂", "₃", "ₙ", "√", "∛", "∜", "½", "⅓", "⅔", "¼", "¾", "⅕", "⅛", "⅜", "⅝", "⅞"] },
    { key: "greek", label: "Greek", items: ["π", "θ", "α", "β", "γ", "δ", "Δ", "ε", "λ", "μ", "σ", "Σ", "φ", "ω", "Ω", "ρ", "τ"] },
    { key: "geo", label: "Geometry", items: ["∠", "△", "⊥", "∥", "≅", "∼", "°", "′", "″", "□", "○", "∴", "∵"] },
    { key: "sets", label: "Sets & logic", items: ["∈", "∉", "⊂", "⊆", "∪", "∩", "∅", "∞", "ℕ", "ℤ", "ℚ", "ℝ", "∀", "∃", "¬", "∧", "∨"] },
    { key: "calc", label: "Calculus", items: ["∑", "∏", "∫", "∂", "∇", "…", "⋯", "lim"] },
    // Ready-made equations & formulas — inserted as easy-to-edit text, shown as proper notation.
    { key: "formula", label: "Formulas", formulas: [
      { label: "Quadratic formula", text: "x = (-b +- sqrt(b^2 - 4ac))/(2a)" },
      { label: "Pythagorean theorem", text: "a^2 + b^2 = c^2" },
      { label: "Slope", text: "m = (y_2 - y_1)/(x_2 - x_1)" },
      { label: "Distance", text: "d = sqrt((x_2 - x_1)^2 + (y_2 - y_1)^2)" },
      { label: "Midpoint", text: "M = ((x_1 + x_2)/2, (y_1 + y_2)/2)" },
      { label: "Slope-intercept", text: "y = mx + b" },
      { label: "Circle area", text: "A = pi r^2" },
      { label: "Circumference", text: "C = 2 pi r" },
      { label: "Triangle area", text: "A = 1/2 bh" },
      { label: "Sphere volume", text: "V = 4/3 pi r^3" },
      { label: "Arithmetic sequence", text: "a_n = a_1 + (n - 1)d" },
      { label: "Geometric sequence", text: "a_n = a_1 r^(n-1)" },
      { label: "Compound interest", text: "A = P(1 + r/n)^(nt)" },
      { label: "Mean", text: "mean = (x_1 + x_2 + ... + x_n)/n" },
      { label: "Sum of 1…n", text: "sum_(i=1)^n i = (n(n+1))/2" },
      { label: "Difference of squares", text: "a^2 - b^2 = (a + b)(a - b)" },
      { label: "Square of a binomial", text: "(a + b)^2 = a^2 + 2ab + b^2" },
      { label: "Speed", text: "v = d/t" },
      { label: "Own-line equation", text: "$$x^2 + 5x + 6 = 0$$" },
    ] },
  ];

  let lastField = null;
  document.addEventListener("focusin", (e) => {
    const t = e.target;
    if (t && (t.tagName === "TEXTAREA" || t.tagName === "INPUT") && t.dataset && t.dataset.mt) lastField = t;
  });

  function insertAt(el, text, selStart, selEnd) {
    if (!el) return;
    const start = el.selectionStart != null ? el.selectionStart : el.value.length;
    const end = el.selectionEnd != null ? el.selectionEnd : start;
    el.value = el.value.slice(0, start) + text + el.value.slice(end);
    const a = start + (selStart != null ? selStart : text.length);
    const b = start + (selEnd != null ? selEnd : (selStart != null ? selStart : text.length));
    el.focus();
    try { el.setSelectionRange(a, b); } catch (e) { /* input types without selection support */ }
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function targetField(defaultId) {
    const a = document.activeElement;
    if (a && (a.tagName === "TEXTAREA" || a.tagName === "INPUT") && a.dataset && a.dataset.mt) return a;
    if (lastField && document.body.contains(lastField)) return lastField;
    return document.getElementById(defaultId);
  }

  function pickFormula(defaultId, idx) {
    const g = PALETTE.find((x) => x.key === "formula");
    if (g && g.formulas[idx]) insertAt(targetField(defaultId), g.formulas[idx].text);
  }

  function pick(defaultId, text) {
    if (text === "FRAC") return insertAt(targetField(defaultId), "(a)/(b)", 1, 2);
    if (text === "lim") return insertAt(targetField(defaultId), "lim ");
    insertAt(targetField(defaultId), text);
  }

  function showGroup(paletteId, key) {
    const root = document.getElementById(paletteId);
    if (!root) return;
    root.querySelectorAll(".mt-tab").forEach((b) => b.classList.toggle("active", b.dataset.key === key));
    root.querySelectorAll(".mt-group").forEach((g) => { g.style.display = g.dataset.key === key ? "flex" : "none"; });
  }

  /** Markup for a compact tabbed symbol palette. `defaultId` = the field to insert into when none has focus. */
  function paletteHtml(paletteId, defaultId) {
    const tabs = PALETTE.map((g, i) =>
      `<button type="button" class="mt-tab${i === 0 ? " active" : ""}" data-key="${g.key}" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" onclick="MathText.showGroup('${paletteId}','${g.key}')">${esc(g.label)}</button>`).join("");
    const groups = PALETTE.map((g, i) =>
      `<div class="mt-group" data-key="${g.key}" style="display:${i === 0 ? "flex" : "none"};">${
        g.formulas ? g.formulas.map((f, n) => `<button type="button" class="mt-formula" title="${esc(f.text)}" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" onclick="MathText.pickFormula('${defaultId}',${n})"><span class="mt-formula-label">${esc(f.label)}</span><span class="mt-formula-view">${html(f.text)}</span></button>`).join("") :
        (g.key === "pow" ? `<button type="button" class="mt-sym mt-sym-wide" title="Insert a stacked fraction — replace a and b" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" onclick="MathText.pick('${defaultId}','FRAC')">a⁄b</button>` : "") +
        (g.items || []).map((s) => `<button type="button" class="mt-sym" title="Insert ${esc(s)}" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" onclick="MathText.pick('${defaultId}','${s.replace(/'/g, "\\'")}')">${esc(s)}</button>`).join("")
      }</div>`).join("");
    return `<div class="mt-palette" id="${paletteId}"><div class="mt-tabs">${tabs}</div>${groups}
      <div class="mt-tip">Or just type it: <code>x^2</code> → x², <code>sqrt(x+1)</code> → √, <code>&lt;=</code> → ≤, <code>1/2</code>, <code>x/2</code>, <code>(a+b)/(c-d)</code> → stacked fractions, <code>pi</code> → π, <code>30^o</code> → 30°, <code>H_2O</code> → H₂O, <code>sum_(i=1)^n</code> → ∑ with limits, <code>$$…$$</code> → equation on its own line</div></div>`;
  }

  global.MathText = { pickFormula, html, render: (s) => render(stripDollars(String(s == null ? "" : s))), paletteHtml, pick, showGroup, insertAt, PALETTE };
})(typeof window !== "undefined" ? window : globalThis);
