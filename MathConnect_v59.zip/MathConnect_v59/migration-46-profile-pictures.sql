-- ============================================================================
-- MathConnect — migration 46: Profile Pictures (teachers & students)
--
-- Storage footprint is kept small in THREE layers, not just one:
--   1. Client-side (avatarUpload.js) resizes every photo down to a small
--      square and re-compresses it as JPEG, iterating quality down until
--      it's under ~45KB, BEFORE it's ever uploaded — a 20MB phone photo and
--      a 200KB one both end up the same tiny size. This is the main
--      defense, because it works regardless of what the person picks.
--   2. The bucket itself has a hard file_size_limit as a backstop, in case
--      a modified client ever tries to skip the compression step.
--   3. Every person gets exactly ONE fixed storage path for their avatar
--      (upload always overwrites, never adds a new file) — so total
--      storage use is capped at (number of people) × (~45KB), not
--      unbounded by how many times someone changes their picture.
--
-- Run this once in Supabase Dashboard → SQL Editor.
-- ============================================================================

ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE public.student_preferences ADD COLUMN IF NOT EXISTS avatar_url TEXT;

-- ----------------------------------------------------------------------------
-- Storage bucket. 45KB is the design target after client compression; 300KB
-- is a generous hard ceiling so a slightly-larger-than-expected compressed
-- image is never rejected right at the finish line.
-- ----------------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('avatars', 'avatars', TRUE, 307200, ARRAY['image/jpeg', 'image/png', 'image/webp'])
ON CONFLICT (id) DO UPDATE SET public = TRUE, file_size_limit = 307200, allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp'];

-- Anyone can view avatars (they're profile pictures shown throughout the
-- app — public bucket downloads don't strictly need this policy to work,
-- but it's included so listing/authenticated-URL access behaves the same).
DROP POLICY IF EXISTS "public read avatars" ON storage.objects;
CREATE POLICY "public read avatars" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');

-- A teacher may only write to their OWN folder: avatars/teacher_<their-uuid>/...
DROP POLICY IF EXISTS "teacher manage own avatar" ON storage.objects;
CREATE POLICY "teacher manage own avatar" ON storage.objects FOR ALL
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = 'teacher_' || auth.uid()::text)
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = 'teacher_' || auth.uid()::text);

-- Students (anon sessions, same trust model as every other student write in
-- this app — e.g. drill_progress) may upload/update their own
-- avatars/student_<id>/... folder. They intentionally do NOT get DELETE —
-- "remove my picture" just clears the DB pointer (see below); the small
-- leftover file is simply overwritten next time they upload one.
DROP POLICY IF EXISTS "students upload own avatar" ON storage.objects;
CREATE POLICY "students upload own avatar" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] LIKE 'student\_%');
DROP POLICY IF EXISTS "students update own avatar" ON storage.objects;
CREATE POLICY "students update own avatar" ON storage.objects FOR UPDATE
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] LIKE 'student\_%')
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] LIKE 'student\_%');

-- Any signed-in staff member (teacher or admin) can overwrite or delete a
-- STUDENT's avatar — this is the moderation escape hatch: since students
-- can upload arbitrary photos, a teacher needs to be able to remove an
-- inappropriate one without waiting on anyone else.
DROP POLICY IF EXISTS "staff moderate student avatars" ON storage.objects;
CREATE POLICY "staff moderate student avatars" ON storage.objects FOR ALL
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] LIKE 'student\_%' AND auth.uid() IS NOT NULL)
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] LIKE 'student\_%' AND auth.uid() IS NOT NULL);

-- ============================================================================
-- Done. Sanity check:
-- select id, public, file_size_limit from storage.buckets where id = 'avatars';
-- ============================================================================
