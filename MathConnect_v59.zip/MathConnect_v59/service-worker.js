// ============================================================================
// MathConnect — Service Worker
// ----------------------------------------------------------------------------
// Caches the app SHELL (html/css/js/icons) so the dashboards can load and the
// UI can render while offline or on a flaky connection. It deliberately does
// NOT cache anything from the Supabase API or its own live data — grades,
// attendance, scores, etc. always come from the network so nobody is ever
// looking at stale numbers without knowing it. Bump CACHE_VERSION whenever
// you ship new app files so old clients pick up the update.
// ============================================================================
const CACHE_VERSION = "mathconnect-v59-1";
const OFFLINE_URL = "offline.html";

const APP_SHELL = [
  "./",
  "index.html",
  "login.html",
  "teacher.html",
  "student.html",
  "admin.html",
  "report-card.html",
  "offline.html",
  "style.css",
  "manifest.json",
  "config.js",
  "supabase-client.js",
  "auth.js",
  "grading.js",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-512-maskable.png",
  "icons/apple-touch-icon.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

function isApiOrData(url) {
  // Never cache Supabase (REST/Auth/Realtime) traffic or any non-GET request —
  // grades, attendance, and scores must always be live.
  return url.hostname.endsWith("supabase.co") || url.hostname.endsWith("supabase.in");
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return; // never intercept writes
  const url = new URL(req.url);
  if (isApiOrData(url)) return; // let Supabase calls go straight to network

  // Navigations (loading a page directly): network-first, falling back to
  // the cached shell page, then the offline page, so switching between
  // index/teacher/student/admin still works without a connection.
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).then((res) => {
        const resClone = res.clone(); // clone immediately, before res is consumed
        caches.open(CACHE_VERSION).then((cache) => cache.put(req, resClone));
        return res;
      }).catch(() =>
        caches.match(req).then((cached) => cached || caches.match(OFFLINE_URL))
      )
    );
    return;
  }

  // Static assets (css/js/icons/CDN libraries): stale-while-revalidate —
  // serve the cached copy instantly if present, and refresh the cache in
  // the background for next time.
  event.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req).then((res) => {
        if (res && res.status === 200) {
          const resClone = res.clone(); // clone immediately, before res is consumed
          caches.open(CACHE_VERSION).then((cache) => cache.put(req, resClone));
        }
        return res;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
