-- ============================================================================
-- MathConnect — migration 52
-- Exam review upgrade: per-item explanations + teacher-controlled release
--
-- Run this once in Supabase Dashboard → SQL Editor, AFTER exam_schema.sql,
-- migration-28-exam-bulk-and-shuffle.sql and migration-42-exam-integrity-
-- and-proficiency-rollup.sql. Safe to re-run.
--
-- What it adds
--   1. exams.review_release ('after_submit' | 'after_lock')
--        after_submit — a student sees their review (correct answers +
--                       explanations) the moment they submit. This is the
--                       existing behaviour and stays the DEFAULT, so nothing
--                       changes for exams you already have.
--                       after_lock  — the review is held back until the teacher
--                       LOCKS the exam. Meant for a class-wide test: early
--                       finishers can't pass answers to classmates who are
--                       still working. Enforced here in the database, not in
--                       the browser, so a student can't get around it.
--   2. submit_exam_attempt() is rebuilt (same signature as migration 42) so
--      that it
--        • withholds the review while it is being held, and says so via
--          'review_pending' so the student sees a clear message instead of
--          an empty screen;
--        • includes question_type and points with every reviewed item so the
--          review screen can lay out True/False vs. multiple-choice items
--          correctly.
--      Grading logic is copied unchanged from migration 42.
--
-- No change is needed for the explanations themselves: exam_questions.
-- explanation has existed since exam_schema.sql.
-- ============================================================================

ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS review_release TEXT NOT NULL DEFAULT 'after_submit';

ALTER TABLE public.exams DROP CONSTRAINT IF EXISTS exams_review_release_check;
ALTER TABLE public.exams
  ADD CONSTRAINT exams_review_release_check CHECK (review_release IN ('after_submit', 'after_lock'));

-- IMPORTANT: exam_schema.sql / migration-28 created submit_exam_attempt(UUID)
-- (one argument). Migration 42 then added submit_exam_attempt(UUID, TEXT) as a
-- SECOND function next to it instead of replacing it, so the old one has been
-- sitting there all along. Left in place it would (a) still hand back the full
-- review on request, which would let a student walk around the release setting
-- below by calling it directly, and (b) make a call with only p_attempt_id
-- ambiguous. The two-argument version below has a default for p_reason, so
-- dropping the old one loses nothing — every existing call keeps working.
DROP FUNCTION IF EXISTS public.submit_exam_attempt(UUID);

CREATE OR REPLACE FUNCTION public.submit_exam_attempt(p_attempt_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_attempt exam_attempts%ROWTYPE;
  v_exam exams%ROWTYPE;
  v_total_score INTEGER := 0;
  v_total_points INTEGER := 0;
  v_review JSONB;
  v_review_open BOOLEAN;
BEGIN
  SELECT * INTO v_attempt FROM exam_attempts WHERE id = p_attempt_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'attempt_not_found'); END IF;
  SELECT * INTO v_exam FROM exams WHERE id = v_attempt.exam_id;

  IF v_attempt.is_submitted THEN
    NULL; -- idempotent: fall through and just return the existing result below
  ELSE
    UPDATE exam_responses r
    SET is_correct = (
      lower(trim(public._exam_effective_answer(v_attempt.shuffle_map, r.question_id, r.student_answer))) = lower(trim(q.correct_answer))
    )
    FROM exam_questions q
    WHERE r.question_id = q.id AND r.attempt_id = p_attempt_id;

    SELECT COALESCE(SUM(q.points), 0), COALESCE(SUM(CASE WHEN r.is_correct THEN q.points ELSE 0 END), 0)
      INTO v_total_points, v_total_score
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;

    UPDATE exam_attempts SET
      is_submitted = TRUE,
      submission_time = NOW(),
      total_score = v_total_score,
      total_points = v_total_points,
      percentage_score = CASE WHEN v_total_points > 0 THEN ROUND((v_total_score::NUMERIC / v_total_points) * 100, 2) ELSE 0 END,
      time_taken_seconds = GREATEST(0, EXTRACT(EPOCH FROM (LEAST(NOW(), v_attempt.expected_end_time) - v_attempt.start_time))::INTEGER),
      auto_submit_reason = p_reason,
      updated_at = NOW()
    WHERE id = p_attempt_id
    RETURNING * INTO v_attempt;
  END IF;

  -- The review (correct answers + explanations) is open when the teacher allows
  -- review AND either releases it on submit or has since locked the exam.
  v_review_open := COALESCE(v_exam.allow_review, FALSE)
    AND (COALESCE(v_exam.review_release, 'after_submit') = 'after_submit' OR COALESCE(v_exam.is_locked, FALSE));

  IF v_review_open THEN
    SELECT jsonb_agg(jsonb_build_object(
      'question_number', q.question_number, 'question_text', q.question_text,
      'question_type', q.question_type, 'points', q.points,
      'options', public._exam_shuffled_options(q.options, v_attempt.shuffle_map, q.id),
      'student_answer', r.student_answer, 'is_correct', r.is_correct,
      'correct_answer', CASE WHEN v_exam.show_correct_answers
        THEN public._exam_original_to_shuffled_answer(v_attempt.shuffle_map, q.id, q.correct_answer) ELSE NULL END,
      'explanation', CASE WHEN v_exam.show_correct_answers THEN q.explanation ELSE NULL END
    ) ORDER BY q.question_number)
    INTO v_review
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;
  END IF;

  RETURN jsonb_build_object(
    'attempt', to_jsonb(v_attempt),
    'review', v_review,
    'review_pending', COALESCE(v_exam.allow_review, FALSE) AND NOT v_review_open
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_exam_attempt(UUID, TEXT) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- Done. Sanity check:
--   select title, allow_review, show_correct_answers, review_release, is_locked from exams;
-- ----------------------------------------------------------------------------
