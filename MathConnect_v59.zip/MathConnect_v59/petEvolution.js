// ============================================================================
// MathConnect — Pet Evolution Ceremony (MATHCONNECT 2.0 Phase 3)
//
// growth_points only changes in ONE place client-side — feedPetWithGreenPoints()
// in petEngine.js (its only assignment is `pet.growth_points = row.new_growth_points`;
// food/care items restore hunger/effects but never move growth_points). So the
// single choke point for "did this pet just cross an evolution threshold?" is
// right after that call, in pet-ui.js's handleFeedGreenPoints() — nothing else
// needs instrumenting, and nothing here duplicates petEngine.js's growth logic.
//
// This file owns ONLY the ceremony. It reads stage/visual info from
// petEngine.js (petGrowthStage, petDisplayForm, petVisualHtml, PET_STAGE_BADGE)
// exactly like every other pet UI file already does.
// ============================================================================

// Short flavor line for what changed at each stage — purely cosmetic copy,
// no gameplay effect, same spirit as PET_GROWTH_STAGES' own "purely a
// display layer" comment in petEngine.js.
const PET_EVOLUTION_UNLOCK_COPY = {
  Growing: "Your pet is bigger and a little bolder!",
  Juvenile: "Your pet is growing fast — new confidence, new energy!",
  Thriving: "Your pet is thriving — full size, full of life!",
  Radiant: "✨ A golden glow has awakened around your pet!",
  Ascendant: "🌠 Your pet's glow burns brighter than ever!",
  Champion: "🏆 Your pet radiates Champion energy!",
  Legendary: "👑 Your pet has undergone a full mythical transformation!",
};

/**
 * Call right after a growth-points feed succeeds, passing the stage BEFORE
 * and the stage AFTER the feed (see handleFeedGreenPoints() in pet-ui.js).
 * No-ops quietly if the stage didn't actually change — growth points only
 * ever go up, so a stage difference always means "leveled up," never down.
 */
function maybePlayPetEvolutionCeremony(pet, oldStage, newStage) {
  if (!pet || !oldStage || !newStage || oldStage.label === newStage.label) return false;
  playPetEvolutionCeremony(pet, oldStage, newStage);
  return true;
}

function playPetEvolutionCeremony(pet, oldStage, newStage) {
  const root = document.getElementById("modalRoot");
  if (!root) return; // resilience — never throws even if the shared modal mount is missing
  const reducedMotion = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  const oldForm = petDisplayForm(pet.pet_type_key, oldStage.label);
  const newForm = petDisplayForm(pet.pet_type_key, newStage.label);
  const idleClass = (typeof PET_STATE_CLASS !== "undefined" && PET_STATE_CLASS[PET_STATE.IDLE]) || "pet-anim-idle";
  const celebrateClass = (typeof PET_STATE_CLASS !== "undefined" && PET_STATE_CLASS[PET_STATE.CELEBRATE]) || "pet-anim-idle";
  const badge = (typeof PET_STAGE_BADGE !== "undefined" && PET_STAGE_BADGE[newStage.label]) || "🌱";
  const unlockLine = PET_EVOLUTION_UNLOCK_COPY[newStage.label] || "Your pet grew stronger!";

  root.innerHTML = `
    <div class="evo-backdrop">
      <div class="evo-stage">
        ${reducedMotion ? "" : petEvolutionParticlesHtml(14)}
        <div class="evo-pet-wrap" id="evoPetWrap">${petVisualHtml(oldForm, idleClass, oldStage.glow, 3.2 * Math.max(oldStage.scale, 0.75))}</div>
        <div class="evo-title" id="evoTitle" style="opacity:0;">${badge} ${escapeHtml(newStage.label.toUpperCase())}!</div>
      </div>
      <div class="evo-panel" id="evoPanel" style="opacity:0;">
        <p class="evo-evolved-line">Your pet has evolved!</p>
        <div class="evo-stage-row">
          <span class="evo-stage-old">${escapeHtml(oldStage.label)}</span>
          <span class="evo-arrow">→</span>
          <span class="evo-stage-new">${escapeHtml(newStage.label)}</span>
        </div>
        <p class="muted" style="margin:8px 0;">${escapeHtml(unlockLine)}</p>
        <p class="muted" style="font-size:.8rem;">🌱 ${pet.growth_points} growth points</p>
        <div id="evoCertSlot"></div>
        <button class="btn-primary" style="margin-top:10px;" onclick="closePetEvolutionCeremony()">Continue</button>
      </div>
    </div>`;

  // v55 — a pet reaching Legendary earns a certificate (one per pet); show it right in the ceremony.
  if (newStage.label === "Legendary" && typeof certSyncLegendaryPets === "function") {
    // The database normally issues it the instant the pet crosses the line; the sync is the safety net, then we show THIS pet's certificate.
    certSyncLegendaryPets({ silent: true })
      .then(() => certFindPetCertificate(pet.id))
      .then((rec) => {
        const slot = document.getElementById("evoCertSlot");
        if (slot && rec && typeof certEarnedBannerHtml === "function") slot.innerHTML = certEarnedBannerHtml(rec);
      }).catch(() => {});
  }

  const petWrap = document.getElementById("evoPetWrap");
  const titleEl = document.getElementById("evoTitle");
  const panelEl = document.getElementById("evoPanel");

  // Short auto-playing sequence: old form holds briefly ("growth energy
  // building"), then swaps to the new form + title reveal, then the detail
  // panel — reduced-motion collapses this to near-instant, no held beats.
  const swapDelay = reducedMotion ? 150 : 900;
  const revealDelay = reducedMotion ? 250 : 1500;

  setTimeout(() => {
    if (petWrap) petWrap.innerHTML = petVisualHtml(newForm, celebrateClass, newStage.glow, 3.6 * Math.max(newStage.scale, 0.75));
    if (titleEl) {
      titleEl.style.opacity = "1";
      if (!reducedMotion) titleEl.classList.add("evo-title-pop");
    }
  }, swapDelay);

  setTimeout(() => { if (panelEl) panelEl.style.opacity = "1"; }, revealDelay);
}

function closePetEvolutionCeremony() {
  const root = document.getElementById("modalRoot");
  if (root) root.innerHTML = "";
}

function petEvolutionParticlesHtml(count) {
  let html = "";
  for (let i = 0; i < count; i++) {
    const left = Math.round(Math.random() * 100);
    const delay = (Math.random() * 0.7).toFixed(2);
    const size = (0.7 + Math.random() * 0.9).toFixed(2);
    html += `<span class="evo-particle" style="left:${left}%;animation-delay:${delay}s;font-size:${size}rem;">✨</span>`;
  }
  return html;
}
