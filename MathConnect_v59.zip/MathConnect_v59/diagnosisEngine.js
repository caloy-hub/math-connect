// ============================================================================
// MathConnect — Error Diagnosis Engine
// Given the question the student was asked and the wrong answer they typed,
// figures out WHICH common mistake it looks like and returns a short,
// encouraging, specific hint. Never scolds — always names the fix.
//
// questionData shape expected (all optional except `answer`):
//   {
//     domain,            // "basic" | "order" | "integers" | "fractions" | "decimals" | "algebra"
//     type,              // "integer" | "decimal" | "fraction"
//     answer,            // correct answer: number, or {n,d} for fractions
//     operands: { a, b, op }  // the two operands + operator, when known —
//                              // unlocks the carry-over / borrow / sign checks
//   }
// ============================================================================

const LE_MISTAKE_LIBRARY = {
  off_by_one: "So close — you're off by just 1. Double-check your last count or your final digit.",
  digit_transposition: "Careful — the digits look swapped (like 27 vs 72). Re-read the number you wrote.",
  sign_error: "Watch the sign! With negative numbers, check whether the result should be positive or negative.",
  carry_over: "Looks like a carrying step got missed when adding — remember to carry the 1 into the next column.",
  borrow_error: "Looks like a borrowing step got missed when subtracting — check the column you borrowed from.",
  operator_confusion: "This one might have used the wrong operation — re-read the symbol between the numbers.",
  decimal_point_shift: "The digits are right, but the decimal point looks shifted. Recount the decimal places.",
  fraction_denominator: "With fractions, you need a common denominator before adding or subtracting — check that step.",
  order_of_operations: "Remember PEMDAS/GEMDAS — multiplication and division happen before addition and subtraction.",
  rounding_slip: "You're very close — this looks like a small rounding slip. Recheck your last decimal place.",
  // ---- v55: high-school domains (Exponents, Equations, Factoring, Farm Measure, Grid Navigator, Surveyor's Post) ----
  exponent_multiplied: "Careful with exponents — an exponent means repeated multiplication of the base (and the exponent rules add, subtract or multiply the powers). Re-check which rule applies.",
  inverse_operation: "It looks like a step was done in the wrong direction — to undo + use −, to undo × use ÷, and do the same to both sides.",
  forgot_square_root: "You're close — that looks like the squared value. Don't forget the last step: take the square root!",
  unit_conversion: "Check your conversion factor — count the zeros between the two units (×1,000 for km→m and kg→g, ×100 for m→cm, 10,000 m² per hectare) and whether you should multiply or divide.",
  rise_run_flip: "Slope is rise over run — the change in y goes on TOP. It looks like the fraction got flipped.",
  generic: "Not quite — take another look at each step and try again. You've got this!",
};

function num(v) {
  const n = typeof v === "number" ? v : parseFloat(v);
  return Number.isFinite(n) ? n : null;
}

function digitsOf(n) {
  return String(Math.abs(Math.round(n))).split("").map(Number);
}

function isTransposition(correct, given) {
  if (correct === given) return false;
  const c = digitsOf(correct), g = digitsOf(given);
  if (c.length !== g.length || c.length < 2) return false;
  const sortedC = [...c].sort().join("");
  const sortedG = [...g].sort().join("");
  return sortedC === sortedG; // same digits, different order -> classic transposition
}

/**
 * diagnoseMistake(questionData, userAnswer)
 * Returns { mistakeType, message } — mistakeType is one of LE_MISTAKE_LIBRARY's
 * keys (used for the teacher heatmap), message is the student-facing hint.
 */
function diagnoseMistake(questionData, userAnswer) {
  const type = questionData.type || "integer";

  // ---- Question-specific likely mistakes (v55): a generator may attach
  // `commonMistakes: [{ type, value }]` — a wrong answer students commonly
  // give and which LE_MISTAKE_LIBRARY key explains it. Checked first because
  // it is far more specific than the generic numeric patterns below. ----
  if (Array.isArray(questionData.commonMistakes)) {
    for (const cm of questionData.commonMistakes) {
      const msg = LE_MISTAKE_LIBRARY[cm.type];
      if (!msg) continue;
      if (type === "fraction") {
        const g = parseFractionForDiagnosis(userAnswer);
        if (!g || !cm.value || typeof cm.value !== "object" || g.d === 0) continue;
        if (g.n * cm.value.d === cm.value.n * g.d) return { mistakeType: cm.type, message: msg };
      } else {
        const g = num(userAnswer), v = num(cm.value);
        if (g !== null && v !== null && Math.abs(g - v) < 0.06 && Math.abs(g - num(questionData.answer)) >= 0.06) return { mistakeType: cm.type, message: msg };
      }
    }
  }

  // ---- Fractions get their own path: denominator mismatch is the #1 real-world error ----
  if (type === "fraction" && questionData.answer && typeof questionData.answer === "object") {
    const parsed = parseFractionForDiagnosis(userAnswer);
    if (!parsed) return { mistakeType: "generic", message: LE_MISTAKE_LIBRARY.generic };
    const correct = questionData.answer;
    if (parsed.d !== correct.d && (questionData.operands ? ["+", "-"].includes(questionData.operands.op) : true)) {
      return { mistakeType: "fraction_denominator", message: LE_MISTAKE_LIBRARY.fraction_denominator };
    }
    return { mistakeType: "generic", message: LE_MISTAKE_LIBRARY.generic };
  }

  const correct = num(questionData.answer);
  const given = num(userAnswer);
  if (correct === null || given === null) return { mistakeType: "generic", message: LE_MISTAKE_LIBRARY.generic };

  // ---- Decimals: shifted decimal point / rounding ----
  if (type === "decimal") {
    if (Math.abs(given * 10 - correct) < 0.01 || Math.abs(given / 10 - correct) < 0.01) {
      return { mistakeType: "decimal_point_shift", message: LE_MISTAKE_LIBRARY.decimal_point_shift };
    }
    if (Math.abs(given - correct) <= 0.15) {
      return { mistakeType: "rounding_slip", message: LE_MISTAKE_LIBRARY.rounding_slip };
    }
  }

  // ---- Off-by-one (very common on counting-heavy questions) ----
  if (Math.abs(given - correct) === 1) {
    return { mistakeType: "off_by_one", message: LE_MISTAKE_LIBRARY.off_by_one };
  }

  // ---- Sign flip (integers domain) ----
  if (given === -correct && correct !== 0) {
    return { mistakeType: "sign_error", message: LE_MISTAKE_LIBRARY.sign_error };
  }

  // ---- Digit transposition (e.g. wrote 27 instead of 72) ----
  if (isTransposition(correct, given)) {
    return { mistakeType: "digit_transposition", message: LE_MISTAKE_LIBRARY.digit_transposition };
  }

  // ---- Operand-aware checks, when the caller supplies them ----
  const ops = questionData.operands;
  if (ops && num(ops.a) !== null && num(ops.b) !== null) {
    const a = num(ops.a), b = num(ops.b);

    // Operator confusion: does the given answer match a DIFFERENT operation on the same operands?
    const altResults = {
      "+": a + b, "-": a - b, "×": a * b, "*": a * b, "÷": b !== 0 ? a / b : null, "/": b !== 0 ? a / b : null,
    };
    for (const [altOp, altVal] of Object.entries(altResults)) {
      if (altOp === ops.op || altVal === null) continue;
      if (Math.abs(altVal - given) < 0.01) {
        return { mistakeType: "operator_confusion", message: LE_MISTAKE_LIBRARY.operator_confusion };
      }
    }

    // Carry-over: addition where every individual column sum was right but the
    // carried digit into the next column was dropped -> given is off from the
    // correct answer by a positive multiple of 10 (a missed "carry the 1").
    const addDiff = correct - given;
    if (ops.op === "+" && addDiff > 0 && addDiff % 10 === 0 && addDiff <= 90 && (a % 10) + (b % 10) >= 10) {
      return { mistakeType: "carry_over", message: LE_MISTAKE_LIBRARY.carry_over };
    }
    // Borrow error: subtraction, same signature in the opposite direction.
    const subDiff = given - correct;
    if (ops.op === "-" && subDiff > 0 && subDiff % 10 === 0 && subDiff <= 90 && (a % 10) < (b % 10)) {
      return { mistakeType: "borrow_error", message: LE_MISTAKE_LIBRARY.borrow_error };
    }
  }

  // ---- Order of Operations domain: wrong answer usually means left-to-right was used instead of PEMDAS ----
  if (questionData.domain === "order") {
    return { mistakeType: "order_of_operations", message: LE_MISTAKE_LIBRARY.order_of_operations };
  }

  return { mistakeType: "generic", message: LE_MISTAKE_LIBRARY.generic };
}

// Minimal local fraction parser so this file has no dependency on drills.js.
function parseFractionForDiagnosis(raw) {
  const s = String(raw == null ? "" : raw).trim();
  let m;
  if ((m = /^-?(\d+)\/(\d+)$/.exec(s))) return { n: +m[1] * (s.startsWith("-") ? -1 : 1), d: +m[2] };
  if ((m = /^-?(\d+)$/.exec(s))) return { n: +m[1] * (s.startsWith("-") ? -1 : 1), d: 1 };
  return null;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { LE_MISTAKE_LIBRARY, diagnoseMistake };
}
