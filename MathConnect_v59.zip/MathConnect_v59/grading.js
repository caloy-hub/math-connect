// ============================================================================
// DepEd Order No. 015, s. 2026 — Grade computation (Table 9, Grades 4-10)
// ----------------------------------------------------------------------------
// Component weights depend on the subject group:
//   Core subjects (English, Filipino, Math, Science, AP, GMRC/Values Ed):
//     WW 20%   |   PT 50%   |   EX 30%
//   EPP/TLE, MAPEH (Music, Arts, PE, Health):
//     WW 20%   |   PT 60%   |   EX 20%
//   SLS Numeracy Intervention (Success Learning Stations program):
//     WW 35%   |   PT 35%   |   EX 30%  — uses its own adjusted transmutation
//     table (floor 50 / cap 90), not the standard one below.
//   Custom (e.g. Senior High subjects, which have their own subject-specific
//   weights): whatever the teacher sets on the section.
// Within EX (same split for every subject group): ST1 30% | ST2 30% | TE 40%
// ----------------------------------------------------------------------------
// IMPORTANT: The "adjusted transmutation table" below is an approximation
// (piecewise-linear: IG 70 -> TG 75, IG 100 -> TG 100, floor of 60) built from
// publicly reported summaries of DO 015 s.2026. Please verify the exact
// official table with your school head / Division office before using these
// numbers on official report cards. You can edit the transmute() function
// below if your school issues a different official table.
// ============================================================================

var WEIGHT_PRESETS = {
  core: { WW: 0.20, PT: 0.50, EX: 0.30, label: "Core Subjects (English, Filipino, Math, Science, AP, GMRC) — WW 20 / PT 50 / EX 30" },
  mapeh_tle: { WW: 0.20, PT: 0.60, EX: 0.20, label: "EPP/TLE, MAPEH — WW 20 / PT 60 / EX 20" },
  sls_numeracy: { WW: 0.35, PT: 0.35, EX: 0.30, label: "SLS Numeracy Intervention — WW 35 / PT 35 / EX 30 (adjusted transmutation, floor 50 / cap 90)" },
};
var EX_SUBWEIGHTS = { ST1: 0.30, ST2: 0.30, TE: 0.40 };

// Returns the {WW, PT, EX, transmute} that apply to a given section, based on
// its weight_preset ('core' | 'mapeh_tle' | 'sls_numeracy' | 'custom'). The
// transmute function travels with the weights so computeTermGrade always
// uses the right transmutation table without needing extra parameters.
function getSectionWeights(section) {
  if (!section) return { ...WEIGHT_PRESETS.core, transmute };
  if (section.weight_preset === "mapeh_tle") return { ...WEIGHT_PRESETS.mapeh_tle, transmute };
  if (section.weight_preset === "sls_numeracy") return { ...WEIGHT_PRESETS.sls_numeracy, transmute: transmuteSLS };
  if (section.weight_preset === "custom") {
    const ww = Number(section.custom_ww) || 0;
    const pt = Number(section.custom_pt) || 0;
    const ex = Number(section.custom_ex) || 0;
    // Normalize in case a teacher's custom entries don't sum to exactly 100.
    const sum = ww + pt + ex;
    if (sum > 0) return { WW: ww / sum, PT: pt / sum, EX: ex / sum, transmute };
  }
  return { ...WEIGHT_PRESETS.core, transmute };
}

// Short human-readable name of a section's active preset — single source of
// truth so every screen (Assessments, Grade Summary, exports) always agrees.
function weightPresetLabel(section) {
  if (!section) return "Core Subjects preset";
  if (section.weight_preset === "mapeh_tle") return "EPP/TLE, MAPEH preset";
  if (section.weight_preset === "sls_numeracy") return "SLS Numeracy Intervention preset";
  if (section.weight_preset === "custom") return "custom weights";
  return "Core Subjects preset";
}

// Full "WW xx% · PT xx% · EX xx% (preset name)" sentence fragment, used
// wherever the current section's weights need to be displayed.
function weightsSummaryText(section) {
  const w = getSectionWeights(section);
  return `WW ${Math.round(w.WW * 100)}% · PT ${Math.round(w.PT * 100)}% · EX ${Math.round(w.EX * 100)}% (${weightPresetLabel(section)})`;
}

// percentageScore = (sum of raw scores / sum of highest possible scores) * 100
function percentageScore(items) {
  const totalRaw = items.reduce((s, i) => s + (Number(i.raw_score) || 0), 0);
  const totalHigh = items.reduce((s, i) => s + (Number(i.highest_possible_score) || 0), 0);
  if (totalHigh === 0) return null;
  return (totalRaw / totalHigh) * 100;
}

// Computes WW, PT, EX percentage scores + weighted Initial Grade for one student
// Given one entry from a scoresByAssessment map, returns the numeric value
// to use in calculations, or null if this item should be excluded entirely.
//   - no entry / blank raw_score        -> null (not yet graded — excluded)
//   - status 'excused'                  -> null (excused — excluded)
//   - status 'unexcused'                -> 0 (counts against the average)
//   - status 'scored' (or legacy plain number) -> the actual raw_score
function scoreForCalc(entry) {
  if (entry === undefined || entry === null || entry === "") return null;
  if (typeof entry === "number" || typeof entry === "string") {
    const n = Number(entry);
    return isNaN(n) ? null : n; // backward-compat: plain-number maps
  }
  if (entry.status === "excused") return null;
  if (entry.status === "unexcused") return 0;
  if (entry.raw_score === undefined || entry.raw_score === null || entry.raw_score === "") return null;
  return Number(entry.raw_score);
}

// assessments: all assessment rows for the term (with .component, .ex_subtype, .highest_possible_score)
// scoresByAssessment: map assessment_id -> {raw_score, status} (for this student)
// weights: {WW, PT, EX} fractions (e.g. from getSectionWeights(section)) — defaults to Core Subjects
// bonus: optional end-of-term bonus points (see migration-36-term-bonus-points.sql) added directly
//   on top of the transmuted Term Grade, capped at 100. Defaults to 0 so every existing call site
//   that doesn't pass it behaves exactly as before.
function computeTermGrade(assessments, scoresByAssessment, weights, bonus) {
  weights = weights || { ...WEIGHT_PRESETS.core, transmute };
  bonus = Number(bonus) || 0;
  const withScores = (list) =>
    list
      .map((a) => ({ a, val: scoreForCalc(scoresByAssessment[a.id]) }))
      .filter((x) => x.val !== null)
      .map((x) => ({ raw_score: x.val, highest_possible_score: x.a.highest_possible_score }));

  const wwItems = withScores(assessments.filter((a) => a.component === "WW"));
  const ptItems = withScores(assessments.filter((a) => a.component === "PT"));

  const st1Items = withScores(assessments.filter((a) => a.component === "EX" && a.ex_subtype === "ST1"));
  const st2Items = withScores(assessments.filter((a) => a.component === "EX" && a.ex_subtype === "ST2"));
  const teItems = withScores(assessments.filter((a) => a.component === "EX" && a.ex_subtype === "TE"));

  const wwPS = percentageScore(wwItems);
  const ptPS = percentageScore(ptItems);
  const st1PS = percentageScore(st1Items);
  const st2PS = percentageScore(st2Items);
  const tePS = percentageScore(teItems);

  // Examinations combined percentage score (only counts sub-parts that have data)
  let exParts = [];
  if (st1PS !== null) exParts.push([st1PS, EX_SUBWEIGHTS.ST1]);
  if (st2PS !== null) exParts.push([st2PS, EX_SUBWEIGHTS.ST2]);
  if (tePS !== null) exParts.push([tePS, EX_SUBWEIGHTS.TE]);
  const exWeightSum = exParts.reduce((s, [, w]) => s + w, 0);
  const exPS = exParts.length ? exParts.reduce((s, [ps, w]) => s + ps * w, 0) / exWeightSum : null;

  const wwWS = wwPS !== null ? wwPS * weights.WW : 0;
  const ptWS = ptPS !== null ? ptPS * weights.PT : 0;
  const exWS = exPS !== null ? exPS * weights.EX : 0;

  const hasAnyData = wwPS !== null || ptPS !== null || exPS !== null;
  const initialGrade = hasAnyData ? wwWS + ptWS + exWS : null;
  const transmuteFn = weights.transmute || transmute;
  const baseTermGrade = initialGrade !== null ? transmuteFn(initialGrade) : null;
  // Bonus only applies once the student has an actual term grade to add it
  // to — a bonus with no underlying grade would misleadingly imply the
  // student was graded this term when they weren't.
  const termGrade = baseTermGrade !== null ? Math.min(100, baseTermGrade + bonus) : null;

  return {
    wwPS, ptPS, exPS, st1PS, st2PS, tePS,
    wwWS, ptWS, exWS,
    initialGrade: initialGrade !== null ? round2(initialGrade) : null,
    baseTermGrade,
    bonus,
    termGrade,
  };
}

// Adjusted transmutation approximation for SY 2026-2027 (see note above)
function transmute(ig) {
  if (ig === null || ig === undefined || isNaN(ig)) return null;
  let tg;
  if (ig >= 100) tg = 100;
  else if (ig >= 70) {
    // 70 -> 75, 100 -> 100 (linear)
    tg = 75 + ((ig - 70) / 30) * 25;
  } else {
    // below 70 -> scaled down to a floor of 60
    tg = 60 + (ig / 70) * 15;
  }
  return Math.round(Math.max(60, Math.min(100, tg)));
}

// SLS Numeracy Intervention transmutation — from the school-provided
// "SLS Numeracy Transmutation Table" (Success Learning Stations program).
// Formula: Transmuted Grade = 50 + (Initial Grade / 100) x 40, rounded to
// the nearest whole number. This shifts the standard 60-100 scale down to a
// 50-100 floor/90 cap range for this remediation program specifically.
// Verified against the source table: IG 0 -> 50, IG 50 -> 70, IG 100 -> 90.
function transmuteSLS(ig) {
  if (ig === null || ig === undefined || isNaN(ig)) return null;
  const tg = 50 + (ig / 100) * 40;
  return Math.round(Math.max(50, Math.min(90, tg)));
}

function round2(n) { return Math.round(n * 100) / 100; }

function gradeDescriptor(tg) {
  if (tg === null) return { label: "No data yet", color: "#647266" };
  if (tg >= 90) return { label: "Outstanding", color: "var(--forest-dark)" };
  if (tg >= 85) return { label: "Very Satisfactory", color: "#2F8FD1" };
  if (tg >= 80) return { label: "Satisfactory", color: "#1FA6A0" };
  if (tg >= 75) return { label: "Fairly Satisfactory", color: "#8B93A1" };
  return { label: "Did Not Meet Expectations", color: "#E8632E" };
}

// ----------------------------------------------------------------------------
// Written Works performance risk indicator — an early-warning color code
// based on a student's Written Works percentage score (wwPS) for the term.
// Thresholds are a reasonable default (Green at/above DepEd's 75% passing
// mark); adjust the cutoffs below if your school prefers different bands.
// ----------------------------------------------------------------------------
function wwPerformanceCategory(wwPS) {
  if (wwPS === null || wwPS === undefined) return { label: "No Data", color: "#647266", bg: "#E7E9ED" };
  if (wwPS >= 75) return { label: "Stable / Passing", color: "#1E7A34", bg: "#DEF2E3" };
  if (wwPS >= 70) return { label: "Mild Attention", color: "#8A6D00", bg: "#FBF0C9" };
  if (wwPS >= 60) return { label: "Average / Needs Attention", color: "#B15C00", bg: "#FCE3C7" };
  return { label: "Danger", color: "#B3261E", bg: "#FBDAD7" };
}

// Final grade = average of the 3 term grades (rounded to whole number)
function computeFinalGrade(termGrades) {
  const valid = termGrades.filter((g) => g !== null && g !== undefined);
  if (!valid.length) return null;
  return Math.round(valid.reduce((s, g) => s + g, 0) / valid.length);
}
