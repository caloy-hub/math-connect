-- ============================================================================
-- Migration 49 — Fix account-delete foreign key bugs
-- Run this once in Supabase → SQL Editor (SQL Editor → New query → paste →
-- Run). Safe to run any time — it only relaxes what happens to a handful of
-- reference columns when a student/teacher is deleted; it does not delete
-- or move any data by itself.
--
-- ROOT CAUSE:
-- Seven columns across three earlier migrations reference students(id) or
-- teachers(id) with no ON DELETE action, which defaults to NO ACTION in
-- Postgres — meaning Postgres outright REJECTS the delete (a real foreign
-- key violation, not a permissions issue) if the account being deleted is
-- referenced by any of these:
--   - battles.winner_id                        (student ever won a Boss Battle)
--   - tournaments.champion_id                   (student ever won a tournament)
--   - tournament_matches.participant_a_id       (student ever joined a match)
--   - tournament_matches.participant_b_id       (student ever joined a match)
--   - tournament_matches.winner_id              (student ever won a match)
--   - learners.created_by                       (teacher ever added/edited a
--                                                 shared directory entry)
--   - term_bonus_points.awarded_by              (teacher ever awarded bonus
--                                                 points to a student)
-- This is on top of (not a replacement for) migration-19-admin-account-
-- controls.sql, which is what grants the admin panel permission to delete
-- teacher/student rows in the first place — run that one too if you haven't.
--
-- FIX: re-create each constraint as ON DELETE SET NULL instead of the
-- default NO ACTION. The battle/tournament/bonus-points ROW itself is kept
-- (so bracket history, other students' matches, and past scores are not
-- disturbed) — only the reference to the now-deleted account is cleared.
-- ============================================================================

alter table battles drop constraint if exists battles_winner_id_fkey;
alter table battles
  add constraint battles_winner_id_fkey
  foreign key (winner_id) references students(id) on delete set null;

alter table tournaments drop constraint if exists tournaments_champion_id_fkey;
alter table tournaments
  add constraint tournaments_champion_id_fkey
  foreign key (champion_id) references students(id) on delete set null;

alter table tournament_matches drop constraint if exists tournament_matches_participant_a_id_fkey;
alter table tournament_matches
  add constraint tournament_matches_participant_a_id_fkey
  foreign key (participant_a_id) references students(id) on delete set null;

alter table tournament_matches drop constraint if exists tournament_matches_participant_b_id_fkey;
alter table tournament_matches
  add constraint tournament_matches_participant_b_id_fkey
  foreign key (participant_b_id) references students(id) on delete set null;

alter table tournament_matches drop constraint if exists tournament_matches_winner_id_fkey;
alter table tournament_matches
  add constraint tournament_matches_winner_id_fkey
  foreign key (winner_id) references students(id) on delete set null;

alter table learners drop constraint if exists learners_created_by_fkey;
alter table learners
  add constraint learners_created_by_fkey
  foreign key (created_by) references teachers(id) on delete set null;

alter table term_bonus_points drop constraint if exists term_bonus_points_awarded_by_fkey;
alter table term_bonus_points
  add constraint term_bonus_points_awarded_by_fkey
  foreign key (awarded_by) references teachers(id) on delete set null;

-- ============================================================================
-- Done. Deleting a teacher or student account from the admin panel will no
-- longer be rejected because of these seven columns. (If a delete still
-- fails after this, the admin panel's error toast now shows the exact
-- Postgres error message — check the constraint name it names and let's
-- track down that one too; there could in principle be a similar gap in a
-- future feature's migration.)
-- ============================================================================
