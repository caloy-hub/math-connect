// ============================================================================
// MathConnect — Teacher Dashboard Logic
// ============================================================================

var state = {
  user: null,
  teacher: null,
  sections: [],
  section: null,
  terms: [],
  term: null,
  students: [],          // students ENROLLED in the selected term — every tab in the dashboard reads this
  allStudents: [],       // every student in the section, whatever their term status (Roster / edit / delete use this)
  removals: {},          // term_id -> { student_id -> student_term_status row }  (migration-63)
  removedStudents: [],   // students removed from the SELECTED term
  removalReady: true,    // false until migration-63 has been run on this project
  assessments: [],
  crSubTab: "assessments",
  activeAssessmentId: null,
  _statusById: null, // cache for the 📋 Status tab — cleared by loadStudents()
};

initSupabase();
init();

// Profile picture (migration-46 + avatarUpload.js) — click the avatar chip
// in the top header to change it.
function changeTeacherAvatar() {
  if (!state.teacher) return;
  pickAndUploadAvatar("teacher", state.teacher.id, async (url) => {
    const { error } = await supabase.from("teachers").update({ avatar_url: url }).eq("id", state.teacher.id);
    if (error) throw error;
    state.teacher.avatar_url = url;
    renderAvatarInto(document.getElementById("teacherAvatarImg"), url, "👩‍🏫");
  });
}

async function init() {
  const user = await requireTeacher();
  if (!user) return;
  state.user = user;

  const { data: teacher } = await supabase.from("teachers").select("*").eq("id", user.id).maybeSingle();
  state.teacher = teacher;
  document.getElementById("teacherNameLabel").textContent = teacher ? teacher.full_name : user.email;
  renderAvatarInto(document.getElementById("teacherAvatarImg"), teacher && teacher.avatar_url, "👩‍🏫");

  if (user.readOnly) {
    const banner = document.createElement("div");
    banner.className = "card";
    banner.style.cssText = "margin-bottom:16px;border-left:4px solid var(--clay);";
    banner.innerHTML = `<strong>⏸️ Read-only mode</strong> — an administrator has paused new activity on this account. You can view everything, but saving, adding, or deleting will be rejected by the server.`;
    document.querySelector("main")?.prepend(banner) || document.body.prepend(banner);
  }

  await loadSections();
}

async function loadSections() {
  const { data, error } = await supabase.from("sections").select("*").eq("teacher_id", state.user.id).order("created_at");
  state.sections = data || [];
  await seedSectionSignatures();

  const sel = document.getElementById("sectionSelect");
  sel.innerHTML = state.sections.map((s) => `<option value="${s.id}">${escapeHtml(s.section_name)} (${escapeHtml(s.grade_level)})</option>`).join("");

  if (state.sections.length === 0) {
    document.getElementById("noSectionState").style.display = "block";
    document.getElementById("mainApp").style.display = "none";
    document.getElementById("classCodeBox").innerHTML = "";
    return;
  }
  document.getElementById("noSectionState").style.display = "none";
  document.getElementById("mainApp").style.display = "block";

  const keep = state.section && state.sections.find((s) => s.id === state.section.id);
  sel.value = keep ? state.section.id : state.sections[0].id;
  await onSectionChange();
}

async function onSectionChange() {
  const id = document.getElementById("sectionSelect").value;
  state.section = state.sections.find((s) => s.id === id);
  document.getElementById("classCodeBox").innerHTML = `
    <span class="muted">Class code for students:</span>
    <span class="class-code-display">${escapeHtml(state.section.class_code)}</span>`;
  wheelStudents = null;
  lastGeneratedGroups = null;
  applySubjectTabRestriction();
  await ensureTerms();
}

// ----------------------------------------------------------------------------
// SUBJECT-BASED TAB RESTRICTION
// Non-Math sections (any subject other than "Mathematics" / "General
// Mathematics") only get the core class-management tabs. All of the
// Math-specific gamified/assessment tabs (Status, Other Concerns, Math
// Drills, Quest Mode, Boss Battles, Learning Heatmap, Exams) are hidden.
// ----------------------------------------------------------------------------
const MATH_ONLY_TABS = ["status", "concerns", "drills", "quest", "certificates", "battles", "learning"];
// "literacy" is deliberately ALWAYS allowed (not Math-only) — see migration-59.
const ALWAYS_ALLOWED_TABS = ["dashboard", "roster", "classrecord", "attendance", "lessons", "blended", "groups", "exams", "literacy", "settings"];

function isMathSubject(subject) {
  const s = (subject || "Mathematics").trim().toLowerCase();
  // Contains-match, not exact-match: catches "Mathematics", "General Mathematics",
  // "Mathematics Intervention", "Math 7", "Remedial Math", etc. — any subject
  // name that mentions math gets the Math-only feature set.
  return s.indexOf("math") !== -1;
}

function applySubjectTabRestriction() {
  const mathSubject = isMathSubject(state.section && state.section.subject);
  MATH_ONLY_TABS.forEach((tab) => {
    document.querySelectorAll(`.tab[data-tab="${tab}"]`).forEach((tabBtn) => {
      tabBtn.style.display = mathSubject ? "" : "none";
    });
  });
  // If the tab currently open just got hidden, fall back to the Dashboard tab.
  if (!mathSubject && MATH_ONLY_TABS.includes(window._currentTab)) {
    switchTab("dashboard");
  }
}

async function ensureTerms() {
  let { data: terms } = await supabase.from("terms").select("*").eq("section_id", state.section.id).order("term_number");
  if (!terms || terms.length === 0) {
    // New section, never had its Term rows created yet — match whichever
    // term the admin has set as the school-wide current term (Admin
    // Overview's "🗓️ School Term" control, migration-48) instead of always
    // defaulting to Term 1, so a class created mid-Term-2/3 starts in step
    // with the rest of the school rather than admin having to fix it later.
    let activeTermNumber = 1;
    try {
      const { data: settings } = await supabase.from("school_settings").select("current_term_number").eq("id", "global").maybeSingle();
      if (settings && settings.current_term_number) activeTermNumber = settings.current_term_number;
    } catch (e) { /* school_settings not installed yet on older deployments — default to Term 1 */ }
    const rows = [1, 2, 3].map((n) => ({
      section_id: state.section.id, term_number: n, term_name: `Term ${n}`,
      school_year: state.section.school_year, is_active: n === activeTermNumber,
    }));
    const { data: inserted } = await supabase.from("terms").insert(rows).select();
    terms = inserted;
  }
  state.terms = terms || [];
  const sel = document.getElementById("termSelect");
  sel.innerHTML = state.terms.map((t) => `<option value="${t.id}">${escapeHtml(t.term_name)}${t.is_active ? " (active)" : ""}</option>`).join("");
  const active = state.terms.find((t) => t.is_active) || state.terms[0];
  sel.value = active.id;
  await onTermChange();
}

async function onTermChange() {
  const id = document.getElementById("termSelect").value;
  state.term = state.terms.find((t) => t.id === id);
  await loadStudents();
  await loadAssessments();
  renderCurrentTab();
}

async function loadStudents() {
  const { data } = await supabase.from("students").select("*").eq("section_id", state.section.id);
  state.allStudents = sortedStudents(data || []);
  await loadTermRemovals();
  applyTermEnrollment();
  state._statusById = null; // force the 📋 Status tab to refetch on next view
}

// ----------------------------------------------------------------------------
// PER-TERM ENROLLMENT (migration-63)
// A student can be removed from Term N (and optionally later terms) without
// touching earlier terms: nothing is deleted, the student simply stops showing
// up in that term's class record, attendance, lessons, etc. No row in
// student_term_status = enrolled, so existing data needs no backfill.
// state.students is always "who is enrolled in the term on screen", which is
// why Class Record / Attendance / Status / every other tab respects this with
// no further changes.
// ----------------------------------------------------------------------------
async function loadTermRemovals() {
  state.removals = {};
  state.removalReady = true;
  const termIds = (state.terms || []).map((t) => t.id);
  if (!termIds.length) return;
  const { data, error } = await supabase.from("student_term_status").select("*").in("term_id", termIds);
  if (error) { state.removalReady = false; return; } // migration-63 not run yet: everyone stays enrolled
  (data || []).forEach((r) => { (state.removals[r.term_id] = state.removals[r.term_id] || {})[r.student_id] = r; });
}
function isRemovedInTerm(studentId, termId) {
  return !!(state.removals[termId] && state.removals[termId][studentId]);
}
function applyTermEnrollment() {
  const tid = state.term && state.term.id;
  state.students = state.allStudents.filter((s) => !isRemovedInTerm(s.id, tid));
  state.removedStudents = state.allStudents.filter((s) => isRemovedInTerm(s.id, tid));
}
function studentAny(id) { return state.allStudents.find((x) => x.id === id) || null; }
function termsBefore() { return (state.terms || []).filter((t) => t.term_number < state.term.term_number).sort((a, b) => a.term_number - b.term_number); }
function termsAfter() { return (state.terms || []).filter((t) => t.term_number > state.term.term_number).sort((a, b) => a.term_number - b.term_number); }
function termListText(list) {
  const n = list.map((t) => t.term_name);
  return n.length <= 1 ? (n[0] || "") : n.slice(0, -1).join(", ") + " and " + n[n.length - 1];
}

async function loadAssessments() {
  const { data } = await supabase.from("assessments").select("*").eq("term_id", state.term.id).order("date_given");
  state.assessments = data || [];
}

function toggleTeacherDrawer() {
  const drawer = document.getElementById("teacherDrawer");
  const overlay = document.getElementById("teacherDrawerOverlay");
  const isOpen = drawer && drawer.classList.contains("open");
  if (isOpen) {
    closeTeacherDrawer();
  } else {
    if (drawer) drawer.classList.add("open");
    if (overlay) overlay.classList.add("open");
    document.body.classList.add("drawer-open");
  }
}

function closeTeacherDrawer() {
  const drawer = document.getElementById("teacherDrawer");
  const overlay = document.getElementById("teacherDrawerOverlay");
  if (drawer) drawer.classList.remove("open");
  if (overlay) overlay.classList.remove("open");
  document.body.classList.remove("drawer-open");
}

function switchTab(tab) {
  closeTeacherDrawer();
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === tab));
  document.querySelectorAll(".mobile-teacher-drawer .drawer-item").forEach((it) => {
    const isThisTab = it.getAttribute("onclick") && it.getAttribute("onclick").includes(`'${tab}'`);
    it.classList.toggle("active", !!isThisTab);
  });
  document.querySelectorAll(".tabpanel").forEach((p) => (p.style.display = "none"));
  const targetPanel = document.getElementById("tab-" + tab);
  if (targetPanel) targetPanel.style.display = "block";
  window._currentTab = tab;
  renderCurrentTab();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderCurrentTab() {
  const tab = window._currentTab || "dashboard";
  ({ dashboard: renderTeacherDashboard, roster: renderRoster, status: renderTeacherStatus, classrecord: renderClassRecord, attendance: renderAttendance,
     lessons: renderLessons, blended: renderBlended, concerns: renderConcerns, groups: renderGroups, drills: renderTeacherDrills,
     quest: renderTeacherQuest, certificates: renderTeacherCertificates, learning: renderTeacherLearningHeatmap, battles: renderTeacherRaids, shoutouts: renderTeacherShoutouts,
     exams: renderTeacherExams, literacy: renderTeacherLiteracyPanel, settings: renderClassSettings }[tab] || renderTeacherDashboard)();
}

// ============================================================================
// DASHBOARD — welcome banner, at-a-glance stats, class progress, upcoming
// ============================================================================
async function renderTeacherDashboard() {
  const el = document.getElementById("tab-dashboard");
  if (!el) return;
  el.innerHTML = `<div class="empty">Loading your dashboard…</div>`;

  const students = state.students || [];
  const totalStudents = students.length;
  const today = new Date().toISOString().slice(0, 10);

  // Attendance: today's rate for this section (falls back gracefully if none logged yet).
  // NOTE: the real table is "attendance" with an "attendance_date" column (see attendance.js
  // logic / supabase-schema.sql) — this used to point at a nonexistent "attendance_records"
  // table with a "date" column, so the query always silently failed and this card was stuck
  // on "—" even once attendance had been taken.
  let presentToday = 0, attendanceLoggedToday = 0;
  try {
    const { data: att } = await supabase.from("attendance").select("status")
      .eq("section_id", state.section.id).eq("attendance_date", today);
    if (att) {
      attendanceLoggedToday = att.length;
      presentToday = att.filter((a) => a.status === "present" || a.status === "late").length;
    }
  } catch (e) { /* attendance table/columns may differ across deployments — fail quiet */ }

  // Class record average (+ its DepEd proficiency descriptor), computed the same way as the
  // Class Record tab: per-student weighted WW/PT/EX term grade, then averaged across the class.
  // NOTE: this used to select("score, max_score") from "scores", but that table has no such
  // columns (it's "raw_score" + "status", with the max coming from assessments.
  // highest_possible_score) — so the query errored, was swallowed by the catch below, and
  // Class Average was stuck on "—" even with scores encoded.
  let classAvg = null, classDescriptor = gradeDescriptor(null);
  try {
    const assessmentIds = (state.assessments || []).map((a) => a.id);
    const { data: scores } = assessmentIds.length
      ? await supabase.from("scores").select("*").in("assessment_id", assessmentIds)
      : { data: [] };
    const scoresByStudent = {};
    (scores || []).forEach((s) => {
      scoresByStudent[s.student_id] = scoresByStudent[s.student_id] || {};
      scoresByStudent[s.student_id][s.assessment_id] = s;
    });
    // Term-end bonus points (migration-36) for the currently selected term,
    // so this card stays consistent with Grade Summary's Term Grade column.
    const { data: bonusRows } = state.term
      ? await supabase.from("term_bonus_points").select("student_id, points").eq("term_id", state.term.id)
      : { data: [] };
    const bonusByStudent = {};
    (bonusRows || []).forEach((b) => { bonusByStudent[b.student_id] = Number(b.points); });
    const weights = getSectionWeights(state.section);
    const termGrades = students
      .map((s) => computeTermGrade(state.assessments || [], scoresByStudent[s.id] || {}, weights, bonusByStudent[s.id] || 0).termGrade)
      .filter((g) => g !== null);
    if (termGrades.length) {
      classAvg = round2(termGrades.reduce((a, b) => a + b, 0) / termGrades.length);
      classDescriptor = gradeDescriptor(classAvg);
    }
  } catch (e) { /* scores table may differ across deployments — fail quiet */ }

  // Proficiency level per section — a quick roll-up (average, DepEd descriptor, attendance
  // today) for every section this teacher runs, not just the one currently selected.
  let sectionsOverview = [];
  try {
    const sectionIds = (state.sections || []).map((s) => s.id);
    if (sectionIds.length) {
      const [{ data: allTerms }, { data: allStudents }, { data: todayAtt }] = await Promise.all([
        supabase.from("terms").select("*").in("section_id", sectionIds),
        supabase.from("students").select("id, section_id").in("section_id", sectionIds),
        supabase.from("attendance").select("section_id, status").in("section_id", sectionIds).eq("attendance_date", today),
      ]);
      const activeTermBySection = {};
      (allTerms || []).forEach((t) => {
        if (t.is_active || !activeTermBySection[t.section_id]) activeTermBySection[t.section_id] = t;
      });
      const termIds = Object.values(activeTermBySection).map((t) => t.id);
      const { data: allAssessments } = termIds.length
        ? await supabase.from("assessments").select("*").in("term_id", termIds)
        : { data: [] };
      const assessmentsByTerm = {};
      (allAssessments || []).forEach((a) => { (assessmentsByTerm[a.term_id] = assessmentsByTerm[a.term_id] || []).push(a); });
      const assessmentIds2 = (allAssessments || []).map((a) => a.id);
      const { data: allScores } = assessmentIds2.length
        ? await supabase.from("scores").select("*").in("assessment_id", assessmentIds2)
        : { data: [] };
      const scoresByAssessment = {};
      (allScores || []).forEach((sc) => {
        scoresByAssessment[sc.assessment_id] = scoresByAssessment[sc.assessment_id] || {};
        scoresByAssessment[sc.assessment_id][sc.student_id] = sc;
      });
      // Students removed from a section's ACTIVE term (migration-63) are not counted in that section's dashboard figures.
      let removedNow = new Set();
      if (termIds.length) {
        const { data: rm, error: rmErr } = await supabase.from("student_term_status").select("student_id, term_id").in("term_id", termIds);
        if (!rmErr) removedNow = new Set((rm || []).map((r) => r.term_id + "|" + r.student_id));
      }
      const studentsBySection = {};
      (allStudents || []).forEach((s) => {
        const at = activeTermBySection[s.section_id];
        if (at && removedNow.has(at.id + "|" + s.id)) return;
        (studentsBySection[s.section_id] = studentsBySection[s.section_id] || []).push(s);
      });
      const attBySection = {};
      (todayAtt || []).forEach((a) => { (attBySection[a.section_id] = attBySection[a.section_id] || []).push(a); });
      // Term-end bonus points across every active term represented above.
      const { data: allBonus } = termIds.length
        ? await supabase.from("term_bonus_points").select("student_id, term_id, points").in("term_id", termIds)
        : { data: [] };
      const bonusByTermStudent = {};
      (allBonus || []).forEach((b) => {
        bonusByTermStudent[b.term_id] = bonusByTermStudent[b.term_id] || {};
        bonusByTermStudent[b.term_id][b.student_id] = Number(b.points);
      });

      sectionsOverview = (state.sections || []).map((section) => {
        // The currently-open section's average was already computed above (from
        // state.assessments/state.students, which is what the rest of this
        // dashboard session is working off of) — reuse that exact number here
        // instead of recomputing it a second time from a fresh, independent
        // query. Two separate pipelines computing "the same" average can drift
        // apart (e.g. a score edited between the two fetches, or simply the
        // normal delay between this async roll-up and the card above finishing),
        // which is why this row and the Class Average card used to disagree.
        if (section.id === state.section.id) {
          return {
            section, studentCount: totalStudents, average: classAvg, descriptor: classDescriptor,
            attendanceLogged: attendanceLoggedToday, attendancePresent: presentToday,
          };
        }
        const term = activeTermBySection[section.id];
        const sectionAssessments = term ? (assessmentsByTerm[term.id] || []) : [];
        const sectionBonus = term ? (bonusByTermStudent[term.id] || {}) : {};
        const weights = getSectionWeights(section);
        const sectionStudents = studentsBySection[section.id] || [];
        const grades = sectionStudents.map((s) => {
          const byAssessment = {};
          sectionAssessments.forEach((a) => {
            const byStudent = scoresByAssessment[a.id];
            if (byStudent && byStudent[s.id] !== undefined) byAssessment[a.id] = byStudent[s.id];
          });
          return computeTermGrade(sectionAssessments, byAssessment, weights, sectionBonus[s.id] || 0).termGrade;
        }).filter((g) => g !== null);
        const avg = grades.length ? round2(grades.reduce((a, b) => a + b, 0) / grades.length) : null;
        const attRecords = attBySection[section.id] || [];
        const attPresent = attRecords.filter((a) => a.status === "present" || a.status === "late").length;
        return {
          section, studentCount: sectionStudents.length, average: avg, descriptor: gradeDescriptor(avg),
          attendanceLogged: attRecords.length, attendancePresent: attPresent,
        };
      });
    }
  } catch (e) { /* fail quiet — this roll-up is a nice-to-have, not core dashboard function */ }

  const upcomingLessons = (await supabase.from("lessons").select("*").eq("term_id", state.term?.id || "").order("week_number", { ascending: false }).limit(1)).data || [];
  const currentLesson = upcomingLessons[0];

  const teacherFirst = (state.teacher && state.teacher.full_name ? state.teacher.full_name.split(" ")[0] : "Teacher");
  // Latest certificates + Legendary pets (teacher-certificates.js) — shows nothing for non-Math sections or if unavailable.
  const certCardHtml = typeof tcertDashboardCardHtml === "function" ? await tcertDashboardCardHtml() : "";

  el.innerHTML = `
    <div class="hero-banner">
      <h1>Welcome back, ${escapeHtml(teacherFirst)}! 👋</h1>
      <p class="quote">"Teaching is the one profession that creates all other professions."
        <span class="who">— Unknown</span>
      </p>
      <button class="btn-hero" onclick="switchTab('roster')">Go to Roster →</button>
    </div>

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-icon green">👥</div>
        <div><div class="stat-value">${totalStudents}</div><div class="stat-label">Students</div><div class="stat-sub">${escapeHtml(state.section.section_name)}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon gold">📊</div>
        <div><div class="stat-value">${classAvg !== null ? classAvg.toFixed(2) : "—"}</div><div class="stat-label">Class Average</div><div class="stat-sub">${classDescriptor ? `<span style="color:${classDescriptor.color};font-weight:600;">${classDescriptor.label}</span>` : "This term"}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon orange">🗓️</div>
        <div><div class="stat-value">${attendanceLoggedToday ? Math.round((presentToday / attendanceLoggedToday) * 100) + "%" : "—"}</div><div class="stat-label">Present Today</div><div class="stat-sub">${attendanceLoggedToday ? `${presentToday}/${attendanceLoggedToday} logged` : "Not logged yet"}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon sky">📚</div>
        <div><div class="stat-value">${(state.sections || []).length}</div><div class="stat-label">Sections</div><div class="stat-sub">Active this term</div></div>
      </div>
    </div>

    <div class="dash-grid">
      <div class="card">
        <div class="section-title-row"><h3 style="margin:0;">📘 This Week's Lesson</h3>
          <span class="link-btn" onclick="switchTab('lessons')">Manage →</span>
        </div>
        ${currentLesson ? `
          <h4 style="margin:8px 0 4px;">${escapeHtml(currentLesson.title)}</h4>
          <p class="muted">Week ${currentLesson.week_number}</p>
          <p>${escapeHtml(currentLesson.objectives || "")}</p>
        ` : `<p class="muted">You haven't posted this week's lesson yet.</p><button class="btn-primary" style="margin-top:8px;" onclick="switchTab('lessons')">+ Post a Lesson</button>`}
      </div>

      <div class="card">
        <div class="section-title-row"><h3 style="margin:0;">🎓 Quick Actions</h3></div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <button class="btn-outline" style="text-align:left;" onclick="switchTab('attendance')">🗓️ Take today's attendance</button>
          <button class="btn-outline" style="text-align:left;" onclick="switchTab('classrecord')">📊 Update the class record</button>
          <button class="btn-outline" style="text-align:left;" onclick="switchTab('concerns')">📝 Log a student concern</button>
          <button class="btn-outline" style="text-align:left;" onclick="switchTab('groups')">🎲 Build groups for today</button>
        </div>
      </div>
    </div>

    ${certCardHtml}

    <div class="card">
      <div class="section-title-row"><h3 style="margin:0;">👥 Roster Snapshot</h3>
        <span class="link-btn" onclick="switchTab('roster')">View All →</span>
      </div>
      ${totalStudents ? `
        <p class="muted">You have ${totalStudents} student${totalStudents === 1 ? "" : "s"} enrolled in ${escapeHtml(state.section.section_name)}. Head to the Roster tab to manage accounts, or Class Record to post scores.</p>
      ` : `<p class="muted">No students have joined this section yet. Share your class code to get started.</p>`}
    </div>

    ${sectionsOverview.length ? `
    <div class="card">
      <div class="section-title-row"><h3 style="margin:0;">📚 Proficiency Level per Section</h3></div>
      <div style="overflow-x:auto;">
      <table>
        <thead><tr><th>Section</th><th>Students</th><th>Average</th><th>Proficiency Level</th><th>Present Today</th></tr></thead>
        <tbody>
          ${sectionsOverview.map((r) => `
            <tr>
              <td>${escapeHtml(r.section.section_name)}${state.section && r.section.id === state.section.id ? ` <span class="muted">(current)</span>` : ""}</td>
              <td class="num">${r.studentCount}</td>
              <td class="num" style="font-weight:700;">${r.average !== null ? r.average.toFixed(2) : "—"}</td>
              <td><span style="color:${r.descriptor.color};font-weight:600;">${r.average !== null ? r.descriptor.label : "No grades yet"}</span></td>
              <td class="num">${r.attendanceLogged ? Math.round((r.attendancePresent / r.attendanceLogged) * 100) + "%" : "Not logged yet"}</td>
            </tr>`).join("")}
        </tbody>
      </table>
      </div>
    </div>` : ""}`;
}

// ---------- Modal helpers ----------
function showModal(html) {
  document.getElementById("modalRoot").innerHTML = `<div class="modal-backdrop" onclick="if(event.target===this) closeModal()"><div class="modal">${html}</div></div>`;
}
function closeModal() { document.getElementById("modalRoot").innerHTML = ""; }

// ============================================================================
// NEW SECTION
// ============================================================================
function openNewSectionModal() {
  showModal(`
    <h3>New Section</h3>
    <div class="field"><label>Section Name</label><input id="ns_name" placeholder="e.g. Grade 8 - Rizal"></div>
    <div class="field-row">
      <div class="field"><label>Grade Level</label><input id="ns_grade" placeholder="e.g. Grade 8"></div>
      <div class="field"><label>Subject</label><input id="ns_subject" placeholder="e.g. Mathematics" value="Mathematics"></div>
    </div>
    <div class="field">
      <label>Grading Weights (DepEd DO 015, s. 2026)</label>
      <select id="ns_weight_preset" onchange="toggleCustomWeights('ns')">
        <option value="core">Core Subjects — English, Filipino, Math, Science, AP, GMRC (WW 20 / PT 50 / EX 30)</option>
        <option value="mapeh_tle">EPP/TLE, MAPEH (WW 20 / PT 60 / EX 20)</option>
        <option value="sls_numeracy">SLS Numeracy Intervention (WW 35 / PT 35 / EX 30, adjusted transmutation floor 50 / cap 90)</option>
        <option value="custom">Custom (e.g. Senior High subjects)</option>
      </select>
    </div>
    <div class="field-row" id="ns_customFields" style="display:none;">
      <div class="field"><label>WW %</label><input type="number" id="ns_ww" value="20"></div>
      <div class="field"><label>PT %</label><input type="number" id="ns_pt" value="50"></div>
      <div class="field"><label>EX %</label><input type="number" id="ns_ex" value="30"></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createSection()">Create</button>
    </div>`);
}
function toggleCustomWeights(prefix) {
  const preset = document.getElementById(prefix + "_weight_preset").value;
  document.getElementById(prefix + "_customFields").style.display = preset === "custom" ? "flex" : "none";
}
async function createSection() {
  const name = document.getElementById("ns_name").value.trim();
  const grade = document.getElementById("ns_grade").value.trim();
  const subject = document.getElementById("ns_subject").value.trim() || "Mathematics";
  const weight_preset = document.getElementById("ns_weight_preset").value;
  const custom_ww = weight_preset === "custom" ? Number(document.getElementById("ns_ww").value) || 0 : null;
  const custom_pt = weight_preset === "custom" ? Number(document.getElementById("ns_pt").value) || 0 : null;
  const custom_ex = weight_preset === "custom" ? Number(document.getElementById("ns_ex").value) || 0 : null;
  if (!name || !grade) { toast("Please fill in section name and grade level."); return; }
  if (weight_preset === "custom" && Math.round((custom_ww + custom_pt + custom_ex) * 100) / 100 !== 100) {
    toast("Custom WW + PT + EX must add up to 100%."); return;
  }
  const code = genClassCode(grade, name);
  const { error } = await supabase.from("sections").insert({
    teacher_id: state.user.id, section_name: name, grade_level: grade, subject, class_code: code,
    weight_preset, custom_ww, custom_pt, custom_ex,
  });
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Section created!");
  await loadSections();
}

// ============================================================================
// CLASS SETTINGS — everything about the currently-selected section in one
// place: section info, grading weights, the Subject Teacher signature used
// on the printed report card, class code, and the danger zone.
// ============================================================================
function renderClassSettings() {
  const el = document.getElementById("tab-settings");
  if (!el || !state.section) return;
  const s = state.section;
  const defaultTeacherName = s.subject_teacher_name || (state.teacher && state.teacher.full_name) || "";
  const defaultTeacherPosition = (s.subject_teacher_position || (state.teacher && state.teacher.position) || "").trim();

  el.innerHTML = `
    <div class="card">
      <h3 style="margin-top:0;">Section Info</h3>
      <p class="muted">Grade Level, Subject, and School Year must be typed exactly the same way across sections for them to share Blended Learning posts and Exams with each other. The class code students use to log in won't change.</p>
      <div class="field"><label>Section Name</label><input id="cs_name" value="${escapeHtml(s.section_name)}"></div>
      <div class="field-row">
        <div class="field"><label>Grade Level</label><input id="cs_grade" value="${escapeHtml(s.grade_level)}"></div>
        <div class="field"><label>Subject</label><input id="cs_subject" value="${escapeHtml(s.subject || "Mathematics")}"></div>
      </div>
      <div class="field"><label>School Year</label><input id="cs_year" value="${escapeHtml(s.school_year || "")}"></div>
      <div class="field"><label>Class Code (students use this to log in)</label><input value="${escapeHtml(s.class_code)}" disabled></div>
      <div class="cs-save-row"><span id="cs_status_info" class="cs-status" role="status" aria-live="polite"></span>
        <button class="btn-primary" id="cs_btn_info" onclick="saveSectionInfo()">Save Section Info</button>
      </div>
    </div>

    <div class="card" style="margin-top:20px;">
      <h3 style="margin-top:0;">Grading Weights</h3>
      <p class="muted">Changing this recalculates all grades in this section immediately using the new weights — raw scores themselves aren't changed.</p>
      <div class="field">
        <label>Grading Weights (DepEd DO 015, s. 2026)</label>
        <select id="cs_weight_preset" onchange="toggleCustomWeights('cs')">
          <option value="core" ${s.weight_preset === "core" ? "selected" : ""}>Core Subjects — English, Filipino, Math, Science, AP, GMRC (WW 20 / PT 50 / EX 30)</option>
          <option value="mapeh_tle" ${s.weight_preset === "mapeh_tle" ? "selected" : ""}>EPP/TLE, MAPEH (WW 20 / PT 60 / EX 20)</option>
          <option value="sls_numeracy" ${s.weight_preset === "sls_numeracy" ? "selected" : ""}>SLS Numeracy Intervention (WW 35 / PT 35 / EX 30, adjusted transmutation floor 50 / cap 90)</option>
          <option value="custom" ${s.weight_preset === "custom" ? "selected" : ""}>Custom (e.g. Senior High subjects)</option>
        </select>
      </div>
      <div class="field-row" id="cs_customFields" style="display:${s.weight_preset === "custom" ? "flex" : "none"};">
        <div class="field"><label>WW %</label><input type="number" id="cs_ww" value="${s.custom_ww ?? 20}"></div>
        <div class="field"><label>PT %</label><input type="number" id="cs_pt" value="${s.custom_pt ?? 50}"></div>
        <div class="field"><label>EX %</label><input type="number" id="cs_ex" value="${s.custom_ex ?? 30}"></div>
      </div>
      <div class="cs-save-row"><span id="cs_status_weights" class="cs-status" role="status" aria-live="polite"></span>
        <button class="btn-primary" id="cs_btn_weights" onclick="saveGradingWeights()">Save Grading Weights</button>
      </div>
    </div>

    <div class="card" style="margin-top:20px;">
      <h3 style="margin-top:0;">Subject Teacher (Report Card Signature)</h3>
      <p class="muted">Automatically placed on every report card generated for THIS section. Defaults to your account's name and position — change it here if you'd like this subject's report cards to print differently (e.g. a co-teacher, or a different title).</p>
      <div class="field-row">
        <div class="field"><label>Teacher's Full Name</label><input id="cs_teacher_name" value="${escapeHtml(defaultTeacherName)}" placeholder="Teacher's full name"></div>
        <div class="field"><label>Position</label>
          <select id="cs_teacher_position">${teacherPositionOptionsHtml(defaultTeacherPosition)}</select></div>
      </div>
      <div class="cs-save-row"><span id="cs_status_teacher" class="cs-status" role="status" aria-live="polite"></span>
        <button class="btn-primary" id="cs_btn_teacher" onclick="saveSubjectTeacher()">Save Subject Teacher</button>
      </div>
    </div>

    <div class="card" style="margin-top:20px;border-left:4px solid var(--clay);">
      <h3 style="margin-top:0;color:var(--clay);">Danger Zone</h3>
      <p class="muted">Permanently deletes this section and everything in it — every student, grade, attendance record, lesson, task, blended learning material, submission, and note. This cannot be undone.</p>
      <button class="btn-danger" onclick="openDeleteSectionModal()">Delete This Section</button>
    </div>`;
}

// ----------------------------------------------------------------------------
// Positions offered in Class Settings (DepEd teaching positions). A position already saved on the
// section that isn't in this list (e.g. an old "Subject Teacher") is kept and shown as "(current)".
// ----------------------------------------------------------------------------
const TEACHER_POSITIONS_T = ["Teacher I", "Teacher II", "Teacher III", "Teacher IV", "Teacher V", "Teacher VI", "Teacher VII"];
const TEACHER_POSITIONS_MT = ["Master Teacher I", "Master Teacher II", "Master Teacher III", "Master Teacher IV", "Master Teacher V"];
function teacherPositionOptionsHtml(current) {
  const cur = (current || "").trim();
  const known = TEACHER_POSITIONS_T.includes(cur) || TEACHER_POSITIONS_MT.includes(cur);
  const opt = (p) => `<option value="${escapeHtml(p)}" ${p === cur ? "selected" : ""}>${escapeHtml(p)}</option>`;
  return (!cur ? `<option value="" selected disabled>Select position…</option>` : "")
    + (cur && !known ? `<option value="${escapeHtml(cur)}" selected>${escapeHtml(cur)} (current)</option>` : "")
    + `<optgroup label="Teacher">${TEACHER_POSITIONS_T.map(opt).join("")}</optgroup>`
    + `<optgroup label="Master Teacher">${TEACHER_POSITIONS_MT.map(opt).join("")}</optgroup>`;
}

function sectionSaveErrorText(error) {
  const m = (error && error.message) || "", code = (error && error.code) || "";
  if (code === "ZERO_ROWS") return m;
  if (code === "PGRST204" || /schema cache|could not find the .* column|column .* does not exist/i.test(m))
    return "the database is missing a column this needs — run migration-64-auto-legendary-certificates-and-settings-fix.sql in Supabase, then try again.";
  if (/row-level security|permission denied|jwt|read-only|paused/i.test(m))
    return "your account can't save right now (it may be paused/read-only, or your login expired — sign in again).";
  return m || "please try again.";
}
function setSettingsStatus(id, ok, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.color = ok ? "var(--forest)" : "var(--clay)";
  el.textContent = msg;
}

/**
 * The one save path for every Class Settings card. It (1) disables the button while saving so a double-click can't
 * race, (2) asks the database to return the row it changed and REFUSES to say "saved" if nothing changed (an update
 * that matches 0 rows — RLS, paused account, expired login — used to look like success), and (3) leaves a visible
 * ✅/❌ message next to the button instead of only a 3-second toast.
 */
async function saveSectionFields(fields, opts) {
  const btn = document.getElementById(opts.btnId);
  if (btn && btn.disabled) return false;
  const label = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "Saving…"; }
  setSettingsStatus(opts.statusId, true, "");
  try {
    const { data, error } = await supabase.from("sections").update(fields).eq("id", state.section.id).select("id");
    if (error) throw error;
    if (!data || data.length !== 1) { const z = new Error("nothing was saved — your account may be read-only, or your login expired. Sign in again and retry."); z.code = "ZERO_ROWS"; throw z; }
    Object.assign(state.section, fields);
    setSettingsStatus(opts.statusId, true, "✅ Saved " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
    toast(opts.okText);
    return true;
  } catch (e) {
    console.warn("Class Settings save failed:", e);
    const msg = sectionSaveErrorText(e);
    setSettingsStatus(opts.statusId, false, "❌ Couldn't save — " + msg);
    toast("Couldn't save: " + msg);
    return false;
  } finally {
    const b = document.getElementById(opts.btnId);
    if (b) { b.disabled = false; b.textContent = label; }
  }
}

async function saveSectionInfo() {
  const section_name = document.getElementById("cs_name").value.trim();
  const grade_level = document.getElementById("cs_grade").value.trim();
  const subject = document.getElementById("cs_subject").value.trim() || "Mathematics";
  const school_year = document.getElementById("cs_year").value.trim();
  if (!section_name || !grade_level || !school_year) { setSettingsStatus("cs_status_info", false, "❌ Please fill in section name, grade level, and school year."); return; }
  const ok = await saveSectionFields({ section_name, grade_level, subject, school_year }, { btnId: "cs_btn_info", statusId: "cs_status_info", okText: "Section info updated!" });
  if (!ok) return;
  // Reflect the new name in the section picker and re-apply the Math-only tab rules (the subject may have changed).
  const sel = document.getElementById("sectionSelect");
  const opt = sel && Array.from(sel.options).find((o) => o.value === state.section.id);
  if (opt) opt.textContent = `${section_name} (${grade_level})`;
  applySubjectTabRestriction();
}

async function saveGradingWeights() {
  const weight_preset = document.getElementById("cs_weight_preset").value;
  const custom_ww = weight_preset === "custom" ? Number(document.getElementById("cs_ww").value) || 0 : null;
  const custom_pt = weight_preset === "custom" ? Number(document.getElementById("cs_pt").value) || 0 : null;
  const custom_ex = weight_preset === "custom" ? Number(document.getElementById("cs_ex").value) || 0 : null;
  if (weight_preset === "custom" && Math.round((custom_ww + custom_pt + custom_ex) * 100) / 100 !== 100) {
    setSettingsStatus("cs_status_weights", false, "❌ Custom WW + PT + EX must add up to 100%."); return;
  }
  await saveSectionFields({ weight_preset, custom_ww, custom_pt, custom_ex }, { btnId: "cs_btn_weights", statusId: "cs_status_weights", okText: "Grading weights updated!" });
}

async function saveSubjectTeacher() {
  const subject_teacher_name = document.getElementById("cs_teacher_name").value.trim();
  const subject_teacher_position = (document.getElementById("cs_teacher_position").value || "").trim();
  if (!subject_teacher_name) { setSettingsStatus("cs_status_teacher", false, "❌ Please enter the subject teacher's name."); return; }
  if (!subject_teacher_position) { setSettingsStatus("cs_status_teacher", false, "❌ Please choose a position from the list."); return; }
  await saveSectionFields({ subject_teacher_name, subject_teacher_position }, { btnId: "cs_btn_teacher", statusId: "cs_status_teacher", okText: "Subject teacher saved — it will appear on this section's report cards and certificates." });
}

/** Sections that never had a subject teacher saved get the teacher's own name/position, so report cards and certificates never print a blank signature. */
async function seedSectionSignatures() {
  try {
    const t = state.teacher;
    if (!t || !t.full_name) return;
    const todo = (state.sections || []).filter((x) => "subject_teacher_name" in x && !(x.subject_teacher_name || "").trim());
    await Promise.all(todo.map(async (x) => {
      const fields = { subject_teacher_name: t.full_name };
      const pos = (x.subject_teacher_position || t.position || "").trim();
      if (pos) fields.subject_teacher_position = pos;
      const { data, error } = await supabase.from("sections").update(fields).eq("id", x.id).select("id");
      if (!error && data && data.length === 1) Object.assign(x, fields);
    }));
  } catch (e) { /* best-effort only */ }
}

function openDeleteSectionModal() {
  if (!state.section) { toast("Select a section first."); return; }
  showModal(`
    <h3 style="color:var(--clay);">⚠ Delete "${escapeHtml(state.section.section_name)}"</h3>
    <p>This permanently deletes this section and <strong>everything in it</strong> — every student, grade, attendance record, lesson, task, blended learning material, submission, and note. This cannot be undone.</p>
    <p>To confirm, type the section name exactly: <strong>${escapeHtml(state.section.section_name)}</strong></p>
    <div class="field"><input id="del_confirm_text" placeholder="Type the section name"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-danger" onclick="confirmDeleteSection()">Delete Permanently</button>
    </div>`);
}
async function confirmDeleteSection() {
  const typed = document.getElementById("del_confirm_text").value.trim();
  if (typed !== state.section.section_name) { toast("The name you typed doesn't match — nothing was deleted."); return; }
  const { error } = await supabase.from("sections").delete().eq("id", state.section.id);
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Section deleted.");
  state.section = null;
  await loadSections();
}

// ============================================================================
// ROSTER
// ============================================================================
function displayName(s) {
  if (s.last_name) {
    return `${s.last_name}, ${s.first_name || ""}${s.middle_name ? " " + s.middle_name : ""}`.trim();
  }
  return s.full_name;
}
function surnameSortKey(s) {
  return ((s.last_name || s.full_name || "") + " " + (s.first_name || "")).toLowerCase();
}
function sortedStudents(list) {
  return [...list].sort((a, b) => surnameSortKey(a).localeCompare(surnameSortKey(b)));
}
// Shared grouping used by Roster, Class Record, and Attendance so all three
// stay consistent: Male first, then Female, then Not specified — each
// alphabetical by surname.
function studentGroups(list) {
  return [
    ["Male", sortedStudents(list.filter((s) => s.sex === "Male"))],
    ["Female", sortedStudents(list.filter((s) => s.sex === "Female"))],
    ["Not specified", sortedStudents(list.filter((s) => s.sex !== "Female" && s.sex !== "Male"))],
  ].filter(([, l]) => l.length > 0);
}

function renderRoster() {
  const el = document.getElementById("tab-roster");
  const groups = studentGroups(state.students);

  el.innerHTML = `
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <h3 style="margin:0;">Class Roster — ${state.students.length} student(s) <span class="muted" style="font-weight:400;font-size:.85rem;">in ${escapeHtml(state.term.term_name)}${state.removedStudents.length ? ` · ${state.removedStudents.length} removed` : ""}</span></h3>
        <div style="display:flex;gap:8px;">
          <button class="btn-outline" onclick="openBatchEnrollModal()">📥 Batch Enroll</button>
          <button class="btn-gold" onclick="openAddStudentModal()">+ Add Student</button>
        </div>
      </div>
      ${state.students.length === 0 ? `<div class="empty">${state.allStudents.length ? `Every student has been removed from ${escapeHtml(state.term.term_name)}. Restore them below.` : "No students yet. Add your first student to this section."}</div>` :
        groups.map(([label, list]) => `
          <h4 style="margin-top:18px;">${label} <span class="muted" style="font-weight:400;">(${list.length}, alphabetical by surname)</span></h4>
          <table>
            <thead><tr><th>#</th><th>Surname, First Name</th><th>LRN</th><th>Login Code</th><th></th></tr></thead>
            <tbody>
              ${sortedStudents(list).map((s, i) => {
                return `
                <tr>
                  <td class="num">${i + 1}</td>
                  <td><strong>${escapeHtml(displayName(s))}</strong></td>
                  <td class="num">${escapeHtml(s.lrn || "—")}</td>
                  <td class="mono" style="font-weight:600;color:var(--forest);">${escapeHtml(s.login_code || "—")}</td>
                  <td style="display:flex;gap:6px;flex-wrap:wrap;">
                    <button class="btn-outline btn-sm" onclick="openStudentProfile('${s.id}')">View</button>
                    <button class="btn-outline btn-sm" onclick="openEditStudentModal('${s.id}')">Edit</button>
                    <button class="btn-outline btn-sm" onclick="regenerateLoginCode('${s.id}')">New Code</button>
                    ${state.removalReady ? `<button class="btn-outline btn-sm" title="Take out of ${escapeHtml(state.term.term_name)} only — earlier terms stay untouched" onclick="openRemoveFromTermModal('${s.id}')">Remove from term</button>` : ""}
                    <button class="btn-danger btn-sm" title="Deletes the student and ALL their records in every term" onclick="quickDeleteStudent('${s.id}')">Delete…</button>
                  </td>
                </tr>`;
              }).join("")}
            </tbody>
          </table>`).join("")}
      <p class="muted" style="margin-top:12px;font-size:.78rem;">Login counts, points, coins, streaks, ranks and every other status signal now live in one place — see the 📋 Status tab.</p>
    </div>
    ${termRemovedPanelHtml()}`;
}

async function regenerateLoginCode(id) {
  const s = studentAny(id);
  if (!confirm(`Generate a new login code for ${displayName(s)}? Their old code (${s.login_code || "none"}) will stop working immediately.`)) return;
  const newCode = genLoginCode();
  const { error } = await supabase.from("students").update({ login_code: newCode }).eq("id", id);
  if (error) { toast("Error: " + error.message); return; }
  toast(`New login code: ${newCode}`);
  await loadStudents();
  renderRoster();
}

async function quickDeleteStudent(id) {
  if (!confirm("PERMANENTLY delete this student from the whole section?\n\nThis erases their scores, attendance and other records in EVERY term and cannot be undone.\n\nTo take them out of just this term (keeping earlier terms untouched), cancel and use “Remove from term” instead.")) return;
  await supabase.from("students").delete().eq("id", id);
  toast("Student removed.");
  await loadStudents();
  renderRoster();
}

function openAddStudentModal() {
  showModal(`
    <h3>Add Student</h3>
    <div class="field">
      <label>Search existing students (shared across all teachers at your school)</label>
      <input id="as_search" placeholder="Start typing a name…" oninput="searchLearners(this.value)">
    </div>
    <div id="as_searchResults" style="margin-bottom:10px;"></div>
    <hr class="divider">
    <p class="muted" style="margin-top:-6px;margin-bottom:10px;">Not found? Add a new student — they'll also be saved to the shared directory so other teachers can find them too.</p>
    <div class="field"><label>Last Name (Surname)</label><input id="as_last" placeholder="Dela Cruz"></div>
    <div class="field-row">
      <div class="field"><label>First Name</label><input id="as_first" placeholder="Juan"></div>
      <div class="field"><label>Middle Name (optional)</label><input id="as_middle" placeholder="Santos"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>LRN (optional)</label><input id="as_lrn" placeholder="123456789012"></div>
      <div class="field"><label>Sex</label>
        <select id="as_sex"><option value="">—</option><option value="Male">Male</option><option value="Female">Female</option></select>
      </div>
    </div>
    <p class="muted">Tip: a login code will be generated automatically — you'll find it in the Roster to share with this student.</p>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createStudent()">Add as New Student</button>
    </div>`);
}

var _learnerSearchTimeout = null;
function searchLearners(query) {
  clearTimeout(_learnerSearchTimeout);
  const box = document.getElementById("as_searchResults");
  if (!query || query.trim().length < 2) { box.innerHTML = ""; return; }
  box.innerHTML = `<p class="muted">Searching…</p>`;
  _learnerSearchTimeout = setTimeout(async () => {
    const { data, error } = await supabase.from("learners").select("*").ilike("full_name", `%${query.trim()}%`).limit(8);
    if (error) { box.innerHTML = `<p class="muted">Search unavailable — you may need to run migration-3-multi-teacher.sql.</p>`; return; }
    const existingIds = new Set(state.allStudents.map((s) => s.learner_id).filter(Boolean));
    const results = (data || []).filter((l) => !existingIds.has(l.id));
    box.innerHTML = results.length === 0 ? `<p class="muted">No matches yet — add as a new student below.</p>` :
      results.map((l) => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border:1px solid var(--paper-line);border-radius:8px;margin-bottom:6px;">
          <span>${escapeHtml(l.last_name)}, ${escapeHtml(l.first_name)}${l.middle_name ? " " + escapeHtml(l.middle_name) : ""} <span class="muted">${l.grade_level ? "· " + escapeHtml(l.grade_level) : ""}</span></span>
          <button class="btn-primary btn-sm" onclick="addExistingLearner('${l.id}')">+ Add to this class</button>
        </div>`).join("");
  }, 350);
}

async function addExistingLearner(learnerId) {
  const { data: l, error: fetchErr } = await supabase.from("learners").select("*").eq("id", learnerId).maybeSingle();
  if (fetchErr || !l) { toast("Couldn't load that student — try again."); return; }
  const { error } = await supabase.from("students").insert({
    section_id: state.section.id, learner_id: l.id,
    full_name: l.full_name, last_name: l.last_name, first_name: l.first_name, middle_name: l.middle_name,
    lrn: l.lrn, sex: l.sex, login_code: genLoginCode(),
  });
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast(`${l.first_name} added to this class!`);
  await loadStudents();
  renderRoster();
}

async function createStudent() {
  const last_name = document.getElementById("as_last").value.trim();
  const first_name = document.getElementById("as_first").value.trim();
  const middle_name = document.getElementById("as_middle").value.trim();
  const lrn = document.getElementById("as_lrn").value.trim();
  const sex = document.getElementById("as_sex").value;
  if (!last_name || !first_name) { toast("Please enter at least a first and last name."); return; }
  const full_name = `${first_name}${middle_name ? " " + middle_name : ""} ${last_name}`.trim();

  // Register in the shared school-wide directory too, so other teachers can find and reuse this student.
  const { data: learner, error: learnerErr } = await supabase.from("learners").insert({
    last_name, first_name, middle_name, full_name, lrn, sex, grade_level: state.section.grade_level, created_by: state.user.id,
  }).select().maybeSingle();
  if (learnerErr) { toast("Note: couldn't add to shared directory (" + learnerErr.message + "), adding to your class only."); }

  const { error } = await supabase.from("students").insert({
    section_id: state.section.id, learner_id: learner ? learner.id : null, full_name, last_name, first_name, middle_name, lrn, sex,
    login_code: genLoginCode(),
  });
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Student added! Check Roster for their login code.");
  await loadStudents();
  renderRoster();
}

// ============================================================================
// BATCH ENROLL — add many students to this section at once by pasting a
// list, one student per line. Each new student is also registered in the
// shared school-wide `learners` directory, same as adding one at a time.
// ============================================================================
function openBatchEnrollModal() {
  showModal(`
    <h3>Batch Enroll Students</h3>
    <p class="muted">Paste one student per line, in this order: <strong>Last Name, First Name, Middle Name, Sex, LRN</strong>.
    Only Last Name and First Name are required — leave the rest blank if you don't have them, just keep the commas out or trailing.
    Sex accepts <strong>M</strong>/<strong>Male</strong> or <strong>F</strong>/<strong>Female</strong>.</p>
    <div class="field">
      <textarea id="be_text" rows="10" placeholder="Dela Cruz, Juan, Santos, M, 123456789012
Reyes, Maria,, F
Santos, Pedro"></textarea>
    </div>
    <div style="text-align:right;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="previewBatchEnroll()">Preview</button>
    </div>
    <div id="be_preview" style="margin-top:14px;"></div>`);
}

function parseBatchEnrollLine(line) {
  const parts = line.split(",").map((p) => p.trim());
  const [last_name = "", first_name = "", middle_name = "", sexRaw = "", lrn = ""] = parts;
  let sex = "";
  const sUp = sexRaw.toUpperCase();
  if (sUp === "M" || sUp === "MALE") sex = "Male";
  else if (sUp === "F" || sUp === "FEMALE") sex = "Female";
  return {
    last_name, first_name, middle_name, sex, lrn,
    valid: !!(last_name && first_name),
    raw: line,
  };
}

let BATCH_ENROLL_ROWS = [];
function previewBatchEnroll() {
  const text = document.getElementById("be_text").value;
  BATCH_ENROLL_ROWS = text.split("\n").map((l) => l.trim()).filter(Boolean).map(parseBatchEnrollLine);
  const validCount = BATCH_ENROLL_ROWS.filter((r) => r.valid).length;
  const invalidCount = BATCH_ENROLL_ROWS.length - validCount;

  document.getElementById("be_preview").innerHTML = BATCH_ENROLL_ROWS.length === 0 ?
    `<p class="muted">Nothing to preview yet — paste at least one line above.</p>` : `
    <table>
      <thead><tr><th></th><th>Surname, First Name</th><th>Middle</th><th>Sex</th><th>LRN</th></tr></thead>
      <tbody>
        ${BATCH_ENROLL_ROWS.map((r) => `
          <tr>
            <td>${r.valid ? "✅" : "⚠️"}</td>
            <td>${r.valid ? `<strong>${escapeHtml(r.last_name)}, ${escapeHtml(r.first_name)}</strong>` : `<span class="muted">${escapeHtml(r.raw)} — needs at least Last Name and First Name</span>`}</td>
            <td>${escapeHtml(r.middle_name || "—")}</td>
            <td>${escapeHtml(r.sex || "—")}</td>
            <td>${escapeHtml(r.lrn || "—")}</td>
          </tr>`).join("")}
      </tbody>
    </table>
    <p class="muted" style="margin-top:8px;">${validCount} ready to enroll${invalidCount ? `, ${invalidCount} skipped (missing name)` : ""}.</p>
    <div style="text-align:right;margin-top:10px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" ${validCount === 0 ? "disabled" : ""} onclick="confirmBatchEnroll(event)">Enroll ${validCount} Student${validCount === 1 ? "" : "s"}</button>
    </div>`;
}

async function confirmBatchEnroll(evt) {
  const rows = BATCH_ENROLL_ROWS.filter((r) => r.valid);
  if (rows.length === 0) return;
  const btn = evt && evt.target;
  if (btn) { btn.disabled = true; btn.textContent = "Enrolling…"; }

  let successCount = 0;
  const failures = [];
  for (const r of rows) {
    const full_name = `${r.first_name}${r.middle_name ? " " + r.middle_name : ""} ${r.last_name}`.trim();
    const { data: learner, error: learnerErr } = await supabase.from("learners").insert({
      last_name: r.last_name, first_name: r.first_name, middle_name: r.middle_name,
      full_name, lrn: r.lrn, sex: r.sex, grade_level: state.section.grade_level, created_by: state.user.id,
    }).select().maybeSingle();
    if (learnerErr) console.warn("Batch enroll: couldn't add to shared directory —", learnerErr.message);

    const { error } = await supabase.from("students").insert({
      section_id: state.section.id, learner_id: learner ? learner.id : null,
      full_name, last_name: r.last_name, first_name: r.first_name, middle_name: r.middle_name,
      lrn: r.lrn, sex: r.sex, login_code: genLoginCode(),
    });
    if (error) failures.push(`${r.last_name}, ${r.first_name}: ${error.message}`);
    else successCount++;
  }

  closeModal();
  if (failures.length === 0) {
    toast(`${successCount} student(s) enrolled! Check Roster for their login codes.`);
  } else {
    toast(`${successCount} enrolled, ${failures.length} failed — see console for details.`);
    console.error("Batch enroll failures:\n" + failures.join("\n"));
  }
  await loadStudents();
  renderRoster();
}


async function openEditStudentModal(studentId) {
  const s = studentAny(studentId);
  const { data: pref } = await supabase.from("student_preferences").select("avatar_url").eq("student_id", studentId).maybeSingle();
  const avatarUrl = pref ? pref.avatar_url : null;
  showModal(`
    <h3>Edit Student</h3>
    <div class="field"><label>Last Name (Surname)</label><input id="es_last" value="${escapeHtml(s.last_name || "")}"></div>
    <div class="field-row">
      <div class="field"><label>First Name</label><input id="es_first" value="${escapeHtml(s.first_name || "")}"></div>
      <div class="field"><label>Middle Name (optional)</label><input id="es_middle" value="${escapeHtml(s.middle_name || "")}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>LRN (optional)</label><input id="es_lrn" value="${escapeHtml(s.lrn || "")}"></div>
      <div class="field"><label>Sex</label>
        <select id="es_sex">
          <option value="" ${!s.sex ? "selected" : ""}>—</option>
          <option value="Male" ${s.sex === "Male" ? "selected" : ""}>Male</option>
          <option value="Female" ${s.sex === "Female" ? "selected" : ""}>Female</option>
        </select>
      </div>
    </div>
    <p class="muted">Changing the name here updates the roster display and sorting only — students log in with their login code, not their name.</p>
    <div class="field" style="border-top:1px solid var(--paper-line);padding-top:10px;">
      <label>Profile Picture</label>
      <div style="display:flex;align-items:center;gap:10px;">
        ${avatarUrl
          ? `<img src="${avatarUrl}" alt="Profile picture" style="width:48px;height:48px;border-radius:50%;object-fit:cover;">`
          : `<span class="muted">No photo uploaded.</span>`}
        ${avatarUrl ? `<button class="btn-outline btn-sm" style="color:var(--clay);border-color:var(--clay);" onclick="removeStudentAvatar('${studentId}')">🗑️ Remove Photo</button>` : ""}
      </div>
      <div class="muted" style="margin-top:2px;">Students upload their own picture from their dashboard. Remove it here if it's ever inappropriate.</div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveStudentEdit('${s.id}')">Save</button>
    </div>`);
}
async function removeStudentAvatar(studentId) {
  if (!confirm("Remove this student's profile picture?")) return;
  await supabase.storage.from("avatars").remove([`student_${studentId}/avatar.jpg`]);
  const { error } = await supabase.from("student_preferences").update({ avatar_url: null }).eq("student_id", studentId);
  if (error) { toast("Error removing photo: " + error.message); return; }
  toast("Photo removed.");
  openEditStudentModal(studentId);
}
async function saveStudentEdit(id) {
  const last_name = document.getElementById("es_last").value.trim();
  const first_name = document.getElementById("es_first").value.trim();
  const middle_name = document.getElementById("es_middle").value.trim();
  const lrn = document.getElementById("es_lrn").value.trim();
  const sex = document.getElementById("es_sex").value;
  if (!last_name || !first_name) { toast("Please enter at least a first and last name."); return; }
  const full_name = `${first_name}${middle_name ? " " + middle_name : ""} ${last_name}`.trim();
  const { error } = await supabase.from("students").update({ last_name, first_name, middle_name, lrn, sex, full_name }).eq("id", id);
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Student updated!");
  await loadStudents();
  renderRoster();
}

// Roster "categories" quick-view: jumps into the relevant tab pre-filtered to one student
function openStudentProfile(studentId) {
  const s = studentAny(studentId);
  showModal(`
    <h3>${escapeHtml(displayName(s))}</h3>
    <p class="muted">${escapeHtml(s.lrn || "No LRN on file")}</p>
    <div class="grid" style="grid-template-columns:1fr 1fr;">
      <button class="btn-outline" onclick="closeModal();switchTab('status');">📋 Status</button>
      <button class="btn-outline" onclick="closeModal();switchTab('classrecord');">📊 Class Record</button>
      <button class="btn-outline" onclick="closeModal();switchTab('attendance');">🗓️ Attendance</button>
      <button class="btn-outline" onclick="closeModal();switchTab('lessons');">📘 Lesson &amp; Task</button>
      <button class="btn-outline" onclick="closeModal();openConcernModal('${s.id}');">📝 Other Concerns</button>
    </div>
    <div style="margin-top:16px;text-align:right;">
      ${state.removalReady && !isRemovedInTerm(s.id, state.term.id) ? `<button class="btn-outline btn-sm" onclick="closeModal();openRemoveFromTermModal('${s.id}')">Remove from ${escapeHtml(state.term.term_name)}</button>` : ""}
      <button class="btn-danger btn-sm" onclick="deleteStudent('${s.id}')">Delete permanently</button>
    </div>`);
}
async function deleteStudent(id) {
  if (!confirm("PERMANENTLY delete this student from the whole section?\n\nThis erases their records in EVERY term and cannot be undone.\n\nTo take them out of just this term (keeping earlier terms untouched), cancel and use “Remove from term” instead.")) return;
  await supabase.from("students").delete().eq("id", id);
  closeModal();
  toast("Student removed.");
  await loadStudents();
  renderRoster();
}


// ============================================================================
// REMOVE / RESTORE A STUDENT FOR A TERM  (migration-63)
// Non-destructive and one-directional: removing from Term N only ever affects
// Term N (+ later terms if chosen). Earlier terms are never touched — that is
// enforced in the database functions, not just here.
// ============================================================================
const TERM_REMOVAL_REASONS = [
  "Transferred to another school", "Transferred to another section", "Dropped out / stopped attending", "Enrolled in error", "Other",
];

function removalMigrationHint() {
  return state.removalReady ? "" : `<div style="border-left:4px solid var(--clay);background:var(--paper);padding:8px 12px;margin:10px 0;border-radius:6px;font-size:.85rem;">⚠️ Run <code>migration-63-student-term-removal.sql</code> in Supabase first — until then students can't be removed per term.</div>`;
}

function termRemovedRowsHtml(withRestore) {
  return state.removedStudents.map((s) => {
    const r = (state.removals[state.term.id] || {})[s.id] || {};
    const when = r.removed_at ? new Date(r.removed_at).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" }) : "";
    return `<tr>
      <td><strong>${escapeHtml(displayName(s))}</strong>
        <div class="muted" style="font-size:.74rem;">${escapeHtml([r.reason, when].filter(Boolean).join(" · "))}${r.note ? " — " + escapeHtml(r.note) : ""}</div></td>
      <td style="text-align:right;white-space:nowrap;">${withRestore ? `<button class="btn-outline btn-sm" onclick="openRestoreToTermModal('${s.id}', '${withRestore}')">↩ Restore</button>` : ""}</td>
    </tr>`;
  }).join("");
}

/** "Removed from Term N" card shown under the Roster. */
function termRemovedPanelHtml() {
  if (!state.removedStudents.length) return "";
  return `
    <details class="card" style="margin-top:16px;" open>
      <summary style="cursor:pointer;font-weight:700;">${state.removedStudents.length} removed from ${escapeHtml(state.term.term_name)}</summary>
      <p class="muted" style="margin:8px 0;font-size:.82rem;">They don't appear in ${escapeHtml(state.term.term_name)}'s class record, attendance or lists. ${termsBefore().length ? escapeHtml(termListText(termsBefore())) + " still shows them exactly as before. " : ""}Nothing was deleted — restore anyone below.</p>
      <table><tbody>${termRemovedRowsHtml("roster")}</tbody></table>
    </details>`;
}

function tsmActiveRowsHtml(filter) {
  const q = (filter || "").trim().toLowerCase();
  const list = sortedStudents(state.students).filter((s) => !q || displayName(s).toLowerCase().includes(q) || (s.lrn || "").includes(q));
  if (!list.length) return `<tr><td class="muted">${state.students.length ? "No students match." : "No students are enrolled in this term."}</td></tr>`;
  return list.map((s) => `<tr>
    <td>${escapeHtml(displayName(s))}<div class="muted" style="font-size:.72rem;">${escapeHtml(s.lrn || "")}</div></td>
    <td style="text-align:right;white-space:nowrap;"><button class="btn-outline btn-sm" ${state.removalReady ? "" : "disabled"} onclick="openRemoveFromTermModal('${s.id}', 'manage')">Remove</button></td>
  </tr>`).join("");
}
function tsmFilter(v) { const el = document.getElementById("tsmActiveBody"); if (el) el.innerHTML = tsmActiveRowsHtml(v); }

/** Class Record → "Manage students this term". */
function openTermStudentsModal() {
  const t = state.term;
  showModal(`
    <h3 style="margin-top:0;">👥 Students in ${escapeHtml(t.term_name)}</h3>
    <p class="muted" style="margin-top:-6px;font-size:.84rem;">Removing a student here only affects <strong>${escapeHtml(t.term_name)}</strong>${termsAfter().length ? " (and later terms, if you choose)" : ""}. ${termsBefore().length ? escapeHtml(termListText(termsBefore())) + " — scores, attendance, grades and report cards — are never touched. " : ""}Nothing is deleted, and you can restore anyone at any time.</p>
    ${removalMigrationHint()}
    <input id="tsmSearch" placeholder="Search by name or LRN…" oninput="tsmFilter(this.value)" style="margin:6px 0 8px;">
    <div style="max-height:44vh;overflow:auto;border:1px solid var(--paper-line);border-radius:8px;padding:2px 8px;">
      <table><tbody id="tsmActiveBody">${tsmActiveRowsHtml("")}</tbody></table>
    </div>
    ${state.removedStudents.length ? `
      <h4 style="margin:14px 0 6px;">Removed from ${escapeHtml(t.term_name)} (${state.removedStudents.length})</h4>
      <div style="max-height:26vh;overflow:auto;border:1px solid var(--paper-line);border-radius:8px;padding:2px 8px;">
        <table><tbody>${termRemovedRowsHtml("manage")}</tbody></table>
      </div>` : ""}
    <div style="text-align:right;margin-top:14px;"><button class="btn-outline" onclick="closeModal()">Close</button></div>`);
}

function openRemoveFromTermModal(studentId, from) {
  const s = studentAny(studentId);
  if (!s) return;
  if (!state.removalReady) { toast("Run migration-63-student-term-removal.sql first."); return; }
  const t = state.term, later = termsAfter(), earlier = termsBefore();
  const radio = (val, checked, html) => `<label style="display:flex;gap:8px;align-items:flex-start;font-weight:400;margin:4px 0;cursor:pointer;"><input type="radio" name="rm_scope" value="${val}" ${checked ? "checked" : ""} style="width:auto;margin-top:3px;"><span>${html}</span></label>`;
  showModal(`
    <h3 style="margin-top:0;">Remove ${escapeHtml(displayName(s))} from ${escapeHtml(t.term_name)}?</h3>
    <div class="field"><label>Reason</label>
      <select id="rm_reason">${TERM_REMOVAL_REASONS.map((r) => `<option>${escapeHtml(r)}</option>`).join("")}</select></div>
    <div class="field"><label>Note (optional)</label><input id="rm_note" maxlength="200" placeholder="e.g. Moved to another school in October"></div>
    ${later.length ? `<div class="field"><label>Apply to</label>
      ${radio("later", true, `${escapeHtml(t.term_name)} <strong>and ${escapeHtml(termListText(later))}</strong> <span class="muted">— the student has left the class</span>`)}
      ${radio("one", false, `${escapeHtml(t.term_name)} only`)}
    </div>` : ""}
    <div style="background:#EAF6EE;border:1px solid #BFE0CB;border-radius:8px;padding:9px 12px;font-size:.84rem;margin-top:6px;">
      ✅ ${earlier.length ? `<strong>${escapeHtml(termListText(earlier))}</strong> stays exactly as it is — scores, attendance, grades and report card.` : "Nothing is deleted."} You can restore ${escapeHtml(s.first_name || "the student")} any time.
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:14px;">
      <button class="btn-outline" onclick="${from === "manage" ? "openTermStudentsModal()" : "closeModal()"}">Cancel</button>
      <button class="btn-danger" onclick="confirmRemoveFromTerm('${s.id}', '${from || ""}')">Remove from ${escapeHtml(t.term_name)}</button>
    </div>`);
}

function termRemovalErrorText(error) {
  const m = (error && error.message) || "";
  if (/does not exist|schema cache|PGRST202|42883/i.test(m + (error.code || ""))) return "Run migration-63-student-term-removal.sql in Supabase first.";
  return m || "please try again.";
}

async function afterEnrollmentChange(from) {
  wheelStudents = null; lastGeneratedGroups = null;
  await loadStudents();
  renderCurrentTab();
  if (from === "manage") openTermStudentsModal(); else closeModal();
}

async function confirmRemoveFromTerm(studentId, from) {
  const s = studentAny(studentId), t = state.term;
  const scopeEl = document.querySelector('input[name="rm_scope"]:checked');
  const applyLater = termsAfter().length > 0 && (!scopeEl || scopeEl.value === "later");
  const reason = document.getElementById("rm_reason").value;
  const note = document.getElementById("rm_note").value.trim();
  const { data, error } = await supabase.rpc("remove_student_from_term", {
    target_student_id: studentId, target_term_id: t.id, apply_to_later: applyLater, removal_reason: reason, removal_note: note || null,
  });
  if (error) { toast("Couldn't remove: " + termRemovalErrorText(error)); return; }
  const scopeText = applyLater ? `${t.term_name} and ${termListText(termsAfter())}` : t.term_name;
  toast(`${displayName(s)} removed from ${scopeText}.${termsBefore().length ? " Earlier terms are untouched." : ""}`);
  await afterEnrollmentChange(from);
}

function openRestoreToTermModal(studentId, from) {
  const s = studentAny(studentId);
  if (!s) return;
  const t = state.term, later = termsAfter().filter((x) => isRemovedInTerm(studentId, x.id));
  const radio = (val, checked, html) => `<label style="display:flex;gap:8px;align-items:flex-start;font-weight:400;margin:4px 0;cursor:pointer;"><input type="radio" name="rs_scope" value="${val}" ${checked ? "checked" : ""} style="width:auto;margin-top:3px;"><span>${html}</span></label>`;
  showModal(`
    <h3 style="margin-top:0;">Restore ${escapeHtml(displayName(s))} to ${escapeHtml(t.term_name)}?</h3>
    <p class="muted" style="font-size:.86rem;">Their ${escapeHtml(t.term_name)} scores and attendance were kept, so they reappear in the class record right away.</p>
    ${later.length ? `<div class="field"><label>Apply to</label>
      ${radio("later", true, `${escapeHtml(t.term_name)} <strong>and ${escapeHtml(termListText(later))}</strong>`)}
      ${radio("one", false, `${escapeHtml(t.term_name)} only`)}
    </div>` : ""}
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:14px;">
      <button class="btn-outline" onclick="${from === "manage" ? "openTermStudentsModal()" : "closeModal()"}">Cancel</button>
      <button class="btn-primary" onclick="confirmRestoreToTerm('${s.id}', '${from || ""}')">Restore to ${escapeHtml(t.term_name)}</button>
    </div>`);
}

async function confirmRestoreToTerm(studentId, from) {
  const s = studentAny(studentId), t = state.term;
  const scopeEl = document.querySelector('input[name="rs_scope"]:checked');
  const applyLater = !!scopeEl && scopeEl.value === "later";
  const { error } = await supabase.rpc("restore_student_to_term", { target_student_id: studentId, target_term_id: t.id, apply_to_later: applyLater });
  if (error) { toast("Couldn't restore: " + termRemovalErrorText(error)); return; }
  toast(`${displayName(s)} restored to ${t.term_name}${applyLater ? " and later terms" : ""}.`);
  await afterEnrollmentChange(from);
}

// ============================================================================
// CLASS RECORD  (Assessments / Enter Scores / Grade Summary)
// ============================================================================
function renderClassRecord() {
  const el = document.getElementById("tab-classrecord");
  el.innerHTML = `
    <div class="card">
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:14px;padding:10px 12px;border:1px solid var(--paper-line);border-radius:10px;background:var(--paper);">
        <div style="font-size:.9rem;"><strong>${escapeHtml(state.term.term_name)}</strong> · ${state.students.length} enrolled${state.removedStudents.length ? ` · <span style="color:var(--clay);font-weight:600;">${state.removedStudents.length} removed</span>` : ""}</div>
        <button class="btn-outline btn-sm" onclick="openTermStudentsModal()" title="Remove or restore students for ${escapeHtml(state.term.term_name)} without touching earlier terms">👥 Manage students this term</button>
      </div>
      <div class="tabs" style="margin-bottom:16px;">
        <div class="tab ${state.crSubTab === "assessments" ? "active" : ""}" onclick="setCrSubTab('assessments')">Assessments</div>
        <div class="tab ${state.crSubTab === "scores" ? "active" : ""}" onclick="setCrSubTab('scores')">Enter Scores</div>
        <div class="tab ${state.crSubTab === "matrix" ? "active" : ""}" onclick="setCrSubTab('matrix')">Full Record</div>
        <div class="tab ${state.crSubTab === "summary" ? "active" : ""}" onclick="setCrSubTab('summary')">Grade Summary</div>
        <div class="tab ${state.crSubTab === "final" ? "active" : ""}" onclick="setCrSubTab('final')">Final Grades</div>
      </div>
      <div id="crContent"></div>
    </div>`;
  renderCrContent();
}
function setCrSubTab(t) { state.crSubTab = t; renderClassRecord(); }

function renderCrContent() {
  if (state.crSubTab === "assessments") return renderCrAssessments();
  if (state.crSubTab === "scores") return renderCrScores();
  if (state.crSubTab === "matrix") return renderCrMatrix();
  if (state.crSubTab === "final") return renderCrFinal();
  return renderCrSummary();
}

function componentLabel(a) {
  if (a.component === "EX") return `EX · ${a.ex_subtype}`;
  return a.component;
}

async function renderCrAssessments() {
  const el = document.getElementById("crContent");
  el.innerHTML = `<p class="muted">Loading assessments…</p>`;

  const assessmentIds = state.assessments.map((a) => a.id);
  const { data: allScores } = assessmentIds.length
    ? await supabase.from("scores").select("*").in("assessment_id", assessmentIds)
    : { data: [] };
  const scoresByAssessment = {};
  (allScores || []).forEach((s) => {
    (scoresByAssessment[s.assessment_id] = scoresByAssessment[s.assessment_id] || []).push(s);
  });
  function mpsFor(a) {
    const list = (scoresByAssessment[a.id] || []).map((s) => scoreForCalc(s)).filter((v) => v !== null);
    if (list.length === 0) return null;
    const sum = list.reduce((x, y) => x + y, 0);
    return (sum / (list.length * a.highest_possible_score)) * 100;
  }

  const groups = { WW: [], PT: [], EX: [] };
  state.assessments.forEach((a) => groups[a.component].push(a));
  const weightLabel = { WW: "20%", PT: "50%", EX: "30% (ST1 30 / ST2 30 / TE 40)" };
  el.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;">
      <p class="muted">DepEd DO 015 s.2026 weights in use for this section: ${weightsSummaryText(state.section)}</p>
      <button class="btn-gold" onclick="openNewAssessmentModal()">+ Add Assessment</button>
    </div>
    ${["WW", "PT", "EX"].map((comp) => `
      <h4 style="margin-top:20px;">${comp === "WW" ? "Written Works" : comp === "PT" ? "Performance Tasks" : "Examinations"}
        <span class="muted" style="font-weight:400;">(${weightLabel[comp]})</span></h4>
      ${groups[comp].length === 0 ? `<p class="muted">None added yet.</p>` : `
      <table>
        <thead><tr><th>Title</th><th>Type</th><th>Highest Score</th><th>Date</th><th>MPS</th><th></th></tr></thead>
        <tbody>
          ${groups[comp].map((a) => {
            const mps = mpsFor(a);
            const scored = (scoresByAssessment[a.id] || []).map((s) => scoreForCalc(s)).filter((v) => v !== null).length;
            return `
            <tr>
              <td><strong>${escapeHtml(a.title)}</strong>${a.pt_instructions ? `<br><span class="muted">${escapeHtml(a.pt_instructions).slice(0, 60)}${a.pt_instructions.length > 60 ? "…" : ""}</span>` : ""}</td>
              <td><span class="badge badge-${a.component.toLowerCase()}">${componentLabel(a)}</span></td>
              <td class="num">${a.highest_possible_score}</td>
              <td>${fmtDate(a.date_given)}</td>
              <td class="num">${mps !== null ? mps.toFixed(1) + "%" : "—"} <span class="muted" style="font-size:.72rem;">(n=${scored})</span></td>
              <td style="display:flex;gap:6px;">
                <button class="btn-outline btn-sm" onclick="openEditAssessmentModal('${a.id}')">Edit</button>
                <button class="btn-outline btn-sm" onclick="deleteAssessment('${a.id}')">Delete</button>
              </td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>`}
    `).join("")}
    <p class="muted" style="margin-top:10px;">MPS = Mean Percentage Score, the class average for that item (sum of scores ÷ (number of students scored × highest possible score) × 100).</p>
  `;
}

function openNewAssessmentModal() {
  showModal(`
    <h3>Add Assessment</h3>
    <div class="field"><label>Component</label>
      <select id="na_component" onchange="toggleExSubtype()">
        <option value="WW">Written Work</option>
        <option value="PT">Performance Task</option>
        <option value="EX">Examination</option>
      </select>
    </div>
    <div class="field" id="na_subtypeField" style="display:none;">
      <label>Examination Type</label>
      <select id="na_subtype"><option value="ST1">Summative Test 1</option><option value="ST2">Summative Test 2</option><option value="TE">Term Examination</option></select>
    </div>
    <div class="field"><label>Title</label><input id="na_title" placeholder="e.g. Quiz 1: Linear Equations"></div>
    <div class="field-row">
      <div class="field"><label>Highest Possible Score</label><input type="number" id="na_high" value="100"></div>
      <div class="field"><label>Date Given</label><input type="date" id="na_date"></div>
    </div>
    <div class="field" id="na_ptFields" style="display:none;">
      <label>Instructions / Rubric (for Performance Tasks)</label>
      <textarea id="na_instructions" rows="3" placeholder="Task instructions students will see..."></textarea>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createAssessment()">Add</button>
    </div>`);
  document.getElementById("na_component").addEventListener("change", toggleExSubtype);
  toggleExSubtype();
}
function toggleExSubtype() {
  const comp = document.getElementById("na_component").value;
  document.getElementById("na_subtypeField").style.display = comp === "EX" ? "block" : "none";
  document.getElementById("na_ptFields").style.display = comp === "PT" ? "block" : "none";
}
async function createAssessment() {
  const component = document.getElementById("na_component").value;
  const ex_subtype = component === "EX" ? document.getElementById("na_subtype").value : null;
  const title = document.getElementById("na_title").value.trim();
  const highest = Number(document.getElementById("na_high").value) || 100;
  const date_given = document.getElementById("na_date").value || null;
  const pt_instructions = component === "PT" ? document.getElementById("na_instructions").value.trim() : null;
  if (!title) { toast("Please enter a title."); return; }
  const { error } = await supabase.from("assessments").insert({
    section_id: state.section.id, term_id: state.term.id, component, ex_subtype, title,
    highest_possible_score: highest, date_given, pt_instructions,
  });
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Assessment added!");
  await loadAssessments();
  renderClassRecord();
}

function openEditAssessmentModal(id) {
  const a = state.assessments.find((x) => x.id === id);
  if (!a) return;
  showModal(`
    <h3>Edit Assessment</h3>
    <div class="field"><label>Component</label>
      <select id="ea_component" onchange="toggleEditExSubtype()">
        <option value="WW" ${a.component === "WW" ? "selected" : ""}>Written Work</option>
        <option value="PT" ${a.component === "PT" ? "selected" : ""}>Performance Task</option>
        <option value="EX" ${a.component === "EX" ? "selected" : ""}>Examination</option>
      </select>
    </div>
    <div class="field" id="ea_subtypeField" style="display:${a.component === "EX" ? "block" : "none"};">
      <label>Examination Type</label>
      <select id="ea_subtype">
        <option value="ST1" ${a.ex_subtype === "ST1" ? "selected" : ""}>Summative Test 1</option>
        <option value="ST2" ${a.ex_subtype === "ST2" ? "selected" : ""}>Summative Test 2</option>
        <option value="TE" ${a.ex_subtype === "TE" ? "selected" : ""}>Term Examination</option>
      </select>
    </div>
    <div class="field"><label>Title</label><input id="ea_title" value="${escapeHtml(a.title)}"></div>
    <div class="field-row">
      <div class="field"><label>Highest Possible Score</label><input type="number" id="ea_high" value="${a.highest_possible_score}"></div>
      <div class="field"><label>Date Given</label><input type="date" id="ea_date" value="${a.date_given || ""}"></div>
    </div>
    <div class="field" id="ea_ptFields" style="display:${a.component === "PT" ? "block" : "none"};">
      <label>Instructions / Rubric (for Performance Tasks)</label>
      <textarea id="ea_instructions" rows="3">${escapeHtml(a.pt_instructions || "")}</textarea>
    </div>
    <p class="muted">Note: changing the Highest Possible Score recalculates every existing score's percentage automatically — raw scores themselves aren't changed.</p>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveAssessmentEdit('${a.id}')">Save</button>
    </div>`);
  document.getElementById("ea_component").addEventListener("change", toggleEditExSubtype);
}
function toggleEditExSubtype() {
  const comp = document.getElementById("ea_component").value;
  document.getElementById("ea_subtypeField").style.display = comp === "EX" ? "block" : "none";
  document.getElementById("ea_ptFields").style.display = comp === "PT" ? "block" : "none";
}
async function saveAssessmentEdit(id) {
  const component = document.getElementById("ea_component").value;
  const ex_subtype = component === "EX" ? document.getElementById("ea_subtype").value : null;
  const title = document.getElementById("ea_title").value.trim();
  const highest_possible_score = Number(document.getElementById("ea_high").value) || 100;
  const date_given = document.getElementById("ea_date").value || null;
  const pt_instructions = component === "PT" ? document.getElementById("ea_instructions").value.trim() : null;
  if (!title) { toast("Please enter a title."); return; }
  const { error } = await supabase.from("assessments").update({
    component, ex_subtype, title, highest_possible_score, date_given, pt_instructions,
  }).eq("id", id);
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Assessment updated!");
  await loadAssessments();
  renderClassRecord();
}

async function deleteAssessment(id) {
  if (!confirm("Delete this assessment and all its scores?")) return;
  await supabase.from("assessments").delete().eq("id", id);
  toast("Deleted.");
  await loadAssessments();
  renderClassRecord();
}

function renderCrScores() {
  const el = document.getElementById("crContent");
  if (state.assessments.length === 0) {
    el.innerHTML = `<div class="empty">Add an assessment first, then come back here to enter scores.</div>`;
    return;
  }
  if (!state.activeAssessmentId) state.activeAssessmentId = state.assessments[0].id;
  el.innerHTML = `
    <div class="field" style="max-width:420px;">
      <label>Select Assessment</label>
      <select id="scoreAssessmentSelect" onchange="state.activeAssessmentId=this.value;renderCrScores();">
        ${state.assessments.map((a) => `<option value="${a.id}" ${a.id === state.activeAssessmentId ? "selected" : ""}>${escapeHtml(a.title)} (${componentLabel(a)}, /${a.highest_possible_score})</option>`).join("")}
      </select>
    </div>
    <div id="scoreGrid" style="margin-top:16px;"></div>`;
  loadAndRenderScoreGrid();
}
async function loadAndRenderScoreGrid() {
  const assessment = state.assessments.find((a) => a.id === state.activeAssessmentId);
  const { data: scores } = await supabase.from("scores").select("*").eq("assessment_id", assessment.id);
  const byStudent = {};
  (scores || []).forEach((s) => (byStudent[s.student_id] = s));
  const grid = document.getElementById("scoreGrid");
  if (state.students.length === 0) { grid.innerHTML = `<p class="muted">No students in roster yet.</p>`; return; }
  const groups = studentGroups(state.students);
  grid.innerHTML = groups.map(([label, list]) => `
    <h4 style="margin-top:16px;">${label}</h4>
    <table>
      <thead><tr><th>Student</th><th>Score (out of ${assessment.highest_possible_score})</th><th>Status</th></tr></thead>
      <tbody>
        ${list.map((s) => {
          const entry = byStudent[s.id];
          const status = entry ? entry.status : "scored";
          const isExcused = status === "excused";
          const isUnexcused = status === "unexcused";
          return `
          <tr>
            <td>${escapeHtml(displayName(s))}</td>
            <td>
              ${isExcused
                ? `<span class="badge" style="background:var(--sage-light);color:var(--ink-soft);">Excused</span>`
                : isUnexcused
                  ? `<span class="badge badge-absent_unexcused">Unexcused (0)</span>`
                  : `<input class="score-input" type="number" min="0" max="${assessment.highest_possible_score}"
                      value="${entry && entry.raw_score !== null && entry.raw_score !== undefined ? entry.raw_score : ""}"
                      onblur="saveScore('${assessment.id}','${s.id}',this.value)">`}
            </td>
            <td style="display:flex;gap:4px;flex-wrap:wrap;">
              <button class="btn-outline btn-sm ${isExcused ? "btn-primary" : ""}" onclick="setScoreStatus('${assessment.id}','${s.id}','excused')">Excused</button>
              <button class="btn-outline btn-sm ${isUnexcused ? "btn-primary" : ""}" onclick="setScoreStatus('${assessment.id}','${s.id}','unexcused')">Unexcused</button>
              ${(isExcused || isUnexcused) ? `<button class="btn-outline btn-sm" onclick="clearScoreStatus('${assessment.id}','${s.id}')">Clear</button>` : ""}
            </td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>`).join("");
}
async function saveScore(assessmentId, studentId, value) {
  if (value === "") return;
  const { error } = await supabase.from("scores").upsert(
    { assessment_id: assessmentId, student_id: studentId, raw_score: Number(value), status: "scored", updated_at: new Date().toISOString() },
    { onConflict: "assessment_id,student_id" }
  );
  if (error) toast("Error saving score: " + error.message);
  else toast("Score saved.");
}
async function setScoreStatus(assessmentId, studentId, status) {
  const { error } = await supabase.from("scores").upsert(
    { assessment_id: assessmentId, student_id: studentId, raw_score: null, status, updated_at: new Date().toISOString() },
    { onConflict: "assessment_id,student_id" }
  );
  if (error) { toast("Error: " + error.message); return; }
  toast(status === "excused" ? "Marked excused — excluded from averages." : "Marked unexcused — counts as zero.");
  loadAndRenderScoreGrid();
}
async function clearScoreStatus(assessmentId, studentId) {
  const { error } = await supabase.from("scores").delete().eq("assessment_id", assessmentId).eq("student_id", studentId);
  if (error) { toast("Error: " + error.message); return; }
  toast("Cleared — back to not yet graded.");
  loadAndRenderScoreGrid();
}

async function renderCrMatrix() {
  const el = document.getElementById("crContent");
  el.innerHTML = `<p class="muted">Loading full class record…</p>`;

  if (state.assessments.length === 0) {
    el.innerHTML = `<div class="empty">Add assessments first (Assessments tab), then come back here to see the full picture.</div>`;
    return;
  }

  const assessmentIds = state.assessments.map((a) => a.id);
  const { data: allScores } = await supabase.from("scores").select("*").in("assessment_id", assessmentIds);
  const scoresByStudent = {};
  (allScores || []).forEach((s) => {
    scoresByStudent[s.student_id] = scoresByStudent[s.student_id] || {};
    scoresByStudent[s.student_id][s.assessment_id] = s;
  });

  const weights = getSectionWeights(state.section);
  const wwList = state.assessments.filter((a) => a.component === "WW");
  const ptList = state.assessments.filter((a) => a.component === "PT");
  const exList = state.assessments.filter((a) => a.component === "EX");
  const groups = [
    ["Written Works", wwList],
    ["Performance Tasks", ptList],
    ["Examinations", exList],
  ].filter(([, list]) => list.length > 0);

  const shortLabel = (a, i) => {
    const prefix = a.component === "EX" && a.ex_subtype ? a.ex_subtype : a.component;
    return `${prefix}${i + 1}`;
  };

  const studentGroupsList = studentGroups(state.students);

  el.innerHTML = `
    <p class="muted">Every assessment score for every student in ${escapeHtml(state.term.term_name)} — hover a column header for the full title. Blank/highlighted cells mean the item hasn't been scored yet.</p>
    <div style="overflow-x:auto;margin-top:10px;">
    <table style="min-width:100%;">
      <thead>
        <tr>
          <th rowspan="2" style="vertical-align:bottom;">Student</th>
          ${groups.map(([label, list]) => `<th colspan="${list.length}" style="text-align:center;">${label}</th>`).join("")}
          <th rowspan="2" style="vertical-align:bottom;">WW%</th>
          <th rowspan="2" style="vertical-align:bottom;">PT%</th>
          <th rowspan="2" style="vertical-align:bottom;">EX%</th>
          <th rowspan="2" style="vertical-align:bottom;">Initial<br>Grade</th>
          <th rowspan="2" style="vertical-align:bottom;">Term<br>Grade</th>
        </tr>
        <tr>
          ${groups.map(([, list]) => list.map((a, i) => `<th class="num" title="${escapeHtml(a.title)} (out of ${a.highest_possible_score})" style="cursor:help;">${shortLabel(a, i)}</th>`).join("")).join("")}
        </tr>
      </thead>
      <tbody>
        ${studentGroupsList.map(([genderLabel, list]) => `
          <tr><td colspan="${1 + state.assessments.length + 5}" style="background:var(--paper);font-weight:600;font-size:.75rem;text-transform:uppercase;color:var(--ink-soft);">${genderLabel}</td></tr>
          ${list.map((s) => {
            const byAssessment = scoresByStudent[s.id] || {};
            const g = computeTermGrade(state.assessments, byAssessment, weights);
            const d = gradeDescriptor(g.termGrade);
            return `<tr>
              <td>${escapeHtml(displayName(s))}</td>
              ${groups.map(([, glist]) => glist.map((a) => {
                const entry = byAssessment[a.id];
                const status = entry ? entry.status : null;
                if (status === "excused") return `<td class="num" style="text-align:center;background:var(--sage-light);color:var(--ink-soft);font-weight:600;" title="Excused — excluded from average">EXC</td>`;
                if (status === "unexcused") return `<td class="num" style="text-align:center;background:var(--clay-light);color:var(--clay);font-weight:700;" title="Unexcused — counts as zero">0*</td>`;
                const hasScore = entry && entry.raw_score !== undefined && entry.raw_score !== null && entry.raw_score !== "";
                return `<td class="num" style="text-align:center;${hasScore ? "" : "background:var(--clay-light);color:var(--clay);font-weight:600;"}">${hasScore ? entry.raw_score : "—"}</td>`;
              }).join("")).join("")}
              <td class="num">${g.wwPS !== null ? g.wwPS.toFixed(0) : "—"}</td>
              <td class="num">${g.ptPS !== null ? g.ptPS.toFixed(0) : "—"}</td>
              <td class="num">${g.exPS !== null ? g.exPS.toFixed(0) : "—"}</td>
              <td class="num">${g.initialGrade !== null ? g.initialGrade : "—"}</td>
              <td class="num" style="font-weight:700;color:${d.color};">${g.termGrade !== null ? g.termGrade : "—"}</td>
            </tr>`;
          }).join("")}
        `).join("")}
      </tbody>
    </table>
    </div>
    <p class="muted" style="margin-top:10px;">Coral cells with a dash mark a missing score for that specific item — hover any column header to see which assessment it is. <strong>EXC</strong> = excused (excluded from the average). <strong>0*</strong> = unexcused (counted as zero).</p>`;
}

async function renderCrSummary() {
  const el = document.getElementById("crContent");
  el.innerHTML = `<p class="muted">Loading grade summary…</p>`;
  const { data: allScores } = await supabase
    .from("scores").select("*").in("assessment_id", state.assessments.map((a) => a.id).length ? state.assessments.map((a) => a.id) : ["00000000-0000-0000-0000-000000000000"]);
  const scoresByStudent = {};
  (allScores || []).forEach((s) => {
    scoresByStudent[s.student_id] = scoresByStudent[s.student_id] || {};
    scoresByStudent[s.student_id][s.assessment_id] = s;
  });

  // Term-end bonus points (migration-36) — a per-student, per-CURRENT-term
  // addition on top of the transmuted Term Grade, capped at 100. Not the
  // cumulative Final Grade (see the Final Grades sub-tab for that).
  const { data: bonusRows } = state.term
    ? await supabase.from("term_bonus_points").select("*").eq("term_id", state.term.id)
    : { data: [] };
  const bonusByStudent = {};
  (bonusRows || []).forEach((b) => { bonusByStudent[b.student_id] = b; });

  const groups = studentGroups(state.students);
  const weights = getSectionWeights(state.section);
  el.innerHTML = `
    <p class="muted">Weights in use for this section: ${weightsSummaryText(state.section)}</p>
    <p class="muted">🌟 Bonus points are added directly to a student's <strong>Term Grade for ${state.term ? escapeHtml(state.term.term_name) : "this term"}</strong> at the end of the term — they don't touch the WW/PT/EX averages, and they carry into the cumulative Final Grade automatically since Final Grade is just the average of each term's grade.</p>
    ${groups.map(([label, list]) => `
      <h4 style="margin-top:16px;">${label}</h4>
      <table>
        <thead><tr><th>Student</th><th>WW %</th><th>WW Status</th><th>PT %</th><th>EX %</th><th>Initial Grade</th><th>Bonus</th><th>Term Grade</th><th>Descriptor</th><th></th></tr></thead>
        <tbody>
          ${list.map((s) => {
            const bonusRow = bonusByStudent[s.id];
            const bonus = bonusRow ? Number(bonusRow.points) : 0;
            const g = computeTermGrade(state.assessments, scoresByStudent[s.id] || {}, weights, bonus);
            const d = gradeDescriptor(g.termGrade);
            const wc = wwPerformanceCategory(g.wwPS);
            return `<tr>
              <td>${escapeHtml(displayName(s))}</td>
              <td class="num">${g.wwPS !== null ? g.wwPS.toFixed(1) : "—"}</td>
              <td><span class="badge" style="background:${wc.bg};color:${wc.color};">${wc.label}</span></td>
              <td class="num">${g.ptPS !== null ? g.ptPS.toFixed(1) : "—"}</td>
              <td class="num">${g.exPS !== null ? g.exPS.toFixed(1) : "—"}</td>
              <td class="num">${g.initialGrade !== null ? g.initialGrade : "—"}</td>
              <td class="num" title="${bonusRow && bonusRow.reason ? escapeHtml(bonusRow.reason) : ""}">${bonus > 0 ? "+" + bonus : "—"}</td>
              <td class="num" style="font-weight:700;">${g.termGrade !== null ? g.termGrade : "—"}</td>
              <td><span style="color:${d.color};font-weight:600;">${d.label}</span></td>
              <td><button class="btn-outline btn-sm" onclick="openBonusPointsModal('${s.id}','${escapeHtml(displayName(s)).replace(/'/g, "\\'")}')">${bonus > 0 ? "✏️ Edit" : "＋ Points"}</button></td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>`).join("")}
    <p class="muted" style="margin-top:12px;">Term Grade uses the adjusted transmutation table (SY 2026–2027) per DepEd Order No. 015, s. 2026 — please verify against your Division's official table before finalizing report cards.</p>
    <p class="muted">WW Status is an early-warning indicator based on Written Works performance this term: <span style="color:#1E7A34;">🟢 Stable/Passing (≥75%)</span> · <span style="color:#8A6D00;">🟡 Mild Attention (70–74%)</span> · <span style="color:#B15C00;">🟠 Average/Needs Attention (60–69%)</span> · <span style="color:#B3261E;">🔴 Danger (below 60%)</span>.</p>
    <div id="crProficiencyRollup"></div>`;
  renderProficiencyRollup();
}

// ============================================================================
// 📊 Proficiency Level rollup (migration-42) — counts of students per DepEd
// proficiency descriptor, combined across EVERY section school-wide that
// shares this section's grade level + subject (not just the current class).
// Pulled via get_proficiency_breakdown(), a SECURITY DEFINER RPC that bypasses
// per-teacher RLS to gather the raw rows needed — but only counts, computed
// with the SAME computeTermGrade()/gradeDescriptor() used everywhere else in
// the app, are ever rendered. No other section's student names are exposed.
// ============================================================================
const PROFICIENCY_LEVELS = [
  { label: "Outstanding", color: "var(--forest-dark)" },
  { label: "Very Satisfactory", color: "#2F8FD1" },
  { label: "Satisfactory", color: "#1FA6A0" },
  { label: "Fairly Satisfactory", color: "#8B93A1" },
  { label: "Did Not Meet Expectations", color: "#E8632E" },
];

async function renderProficiencyRollup() {
  const el = document.getElementById("crProficiencyRollup");
  if (!el) return;
  if (!state.section || !state.term) { el.innerHTML = ""; return; }
  el.innerHTML = `<div class="card" style="margin-top:16px;"><p class="muted">Loading combined proficiency levels…</p></div>`;

  const { data, error } = await supabase.rpc("get_proficiency_breakdown", {
    p_grade_level: state.section.grade_level, p_subject: state.section.subject, p_term_number: state.term.term_number,
  });
  if (error || !data || data.error) { el.innerHTML = ""; return; }

  const sectionsById = {};
  (data.sections || []).forEach((s) => { sectionsById[s.id] = s; });
  const assessmentsBySection = {};
  (data.assessments || []).forEach((a) => { (assessmentsBySection[a.section_id] = assessmentsBySection[a.section_id] || []).push(a); });
  const scoresByStudent = {};
  (data.scores || []).forEach((sc) => { (scoresByStudent[sc.student_id] = scoresByStudent[sc.student_id] || {})[sc.assessment_id] = sc; });
  const bonusByStudent = {};
  (data.bonus || []).forEach((b) => { bonusByStudent[b.student_id] = b; });

  const counts = {}; PROFICIENCY_LEVELS.forEach((l) => { counts[l.label] = 0; });
  let ungraded = 0;

  (data.students || []).forEach((st) => {
    const section = sectionsById[st.section_id];
    const weights = getSectionWeights(section);
    const bonusRow = bonusByStudent[st.id];
    const bonus = bonusRow ? Number(bonusRow.points) : 0;
    const g = computeTermGrade(assessmentsBySection[st.section_id] || [], scoresByStudent[st.id] || {}, weights, bonus);
    if (g.termGrade === null) { ungraded++; return; }
    const d = gradeDescriptor(g.termGrade);
    if (counts[d.label] !== undefined) counts[d.label]++;
  });

  const totalGraded = PROFICIENCY_LEVELS.reduce((s, l) => s + counts[l.label], 0);
  const totalStudents = (data.students || []).length;
  const sectionCount = (data.sections || []).length;

  el.innerHTML = `
    <div class="card" style="margin-top:16px;">
      <h4 style="margin-top:0;">📊 Proficiency Level — All ${escapeHtml(state.section.grade_level)} ${escapeHtml(state.section.subject)} Sections</h4>
      <p class="muted">Combined across ${sectionCount} section${sectionCount === 1 ? "" : "s"} (${totalStudents} student${totalStudents === 1 ? "" : "s"} total) for ${escapeHtml(state.term.term_name)}.</p>
      <table>
        <thead><tr><th>Proficiency Level</th><th>Students</th><th>% of Graded</th></tr></thead>
        <tbody>
          ${PROFICIENCY_LEVELS.map((l) => {
            const pct = totalGraded ? Math.round((counts[l.label] / totalGraded) * 100) : 0;
            return `<tr>
              <td><span style="color:${l.color};font-weight:600;">${l.label}</span></td>
              <td class="num">${counts[l.label]}</td>
              <td class="num">${totalGraded ? pct + "%" : "—"}</td>
            </tr>`;
          }).join("")}
          ${ungraded > 0 ? `<tr><td class="muted">No data yet</td><td class="num">${ungraded}</td><td class="num">—</td></tr>` : ""}
        </tbody>
      </table>
    </div>`;
}

// ============================================================================
// 🌟 Term-end bonus points (migration-36-term-bonus-points.sql)
// One row per (student, term); saving again for the same term overwrites
// the previous value. Applies directly to that term's Term Grade, capped at
// 100 — NOT to the cumulative Final Grade average across Term 1-3.
// ============================================================================
function openBonusPointsModal(studentId, studentName) {
  if (!state.term) { toast("Select a term first."); return; }
  showModal(`
    <h3>🌟 Add Bonus Points — ${escapeHtml(studentName)}</h3>
    <p class="muted">Applies directly to this student's <strong>${escapeHtml(state.term.term_name)}</strong> grade only (not the cumulative Final Grade). Use for students who met all conditions for extra credit at the end of the term.</p>
    <div class="field"><label>Points to add (0–20)</label><input type="number" id="bp_points" min="0" max="20" step="0.5" placeholder="e.g. 3"></div>
    <div class="field"><label>Reason (optional, kept for your records)</label><textarea id="bp_reason" rows="2" placeholder="e.g. Perfect attendance + top drill performer this term"></textarea></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveBonusPoints('${studentId}')">Save</button>
    </div>`);
  // Pre-fill if this student already has bonus points recorded for the current term.
  supabase.from("term_bonus_points").select("*").eq("term_id", state.term.id).eq("student_id", studentId).maybeSingle()
    .then(({ data }) => {
      if (data) {
        document.getElementById("bp_points").value = data.points;
        document.getElementById("bp_reason").value = data.reason || "";
      }
    });
}
async function saveBonusPoints(studentId) {
  const points = Number(document.getElementById("bp_points").value);
  const reason = document.getElementById("bp_reason").value.trim();
  if (isNaN(points) || points < 0 || points > 20) { toast("Enter a number between 0 and 20."); return; }
  const { error } = await supabase.from("term_bonus_points").upsert(
    { student_id: studentId, term_id: state.term.id, points, reason: reason || null, awarded_by: state.teacher?.id || null, awarded_at: new Date().toISOString() },
    { onConflict: "student_id,term_id" }
  );
  if (error) { toast("Error: " + error.message); return; }
  closeModal();
  toast("Bonus points saved!");
  renderCrContent();
}

// ============================================================================
// 📈 Final Grades — Term 1 / 2 / 3 term grades side-by-side (each already
// including that term's bonus points, if any), plus the cumulative Final
// Grade = average of whichever terms the student has a grade in. This is
// the on-screen equivalent of what used to only be visible in the Excel
// export's "Final Grades" sheet, and matches admin.js's "General Average
// (Final)" figure for this section.
// ============================================================================
async function renderCrFinal() {
  const el = document.getElementById("crContent");
  el.innerHTML = `<p class="muted">Loading final grades…</p>`;
  const weights = getSectionWeights(state.section);
  const terms = [...(state.terms || [])].sort((a, b) => a.term_number - b.term_number);

  const perTermData = {};
  for (const term of terms) {
    const [{ data: assessments }, { data: bonusRows }] = await Promise.all([
      supabase.from("assessments").select("*").eq("term_id", term.id),
      supabase.from("term_bonus_points").select("*").eq("term_id", term.id),
    ]);
    const assessmentIds = (assessments || []).map((a) => a.id);
    const { data: scores } = assessmentIds.length
      ? await supabase.from("scores").select("*").in("assessment_id", assessmentIds)
      : { data: [] };
    const scoresByStudent = {};
    (scores || []).forEach((sc) => {
      scoresByStudent[sc.student_id] = scoresByStudent[sc.student_id] || {};
      scoresByStudent[sc.student_id][sc.assessment_id] = sc;
    });
    const bonusByStudent = {};
    (bonusRows || []).forEach((b) => { bonusByStudent[b.student_id] = Number(b.points); });
    perTermData[term.term_number] = { term, assessments: assessments || [], scoresByStudent, bonusByStudent };
  }

  const groups = studentGroups(state.students);
  el.innerHTML = `
    <p class="muted">Final Grade = average of each term's Term Grade (bonus points already included per term, per DepEd Order No. 015, s. 2026). A term with no grades yet is simply excluded from the average, not counted as zero. A term a student was <em>removed</em> from shows “Removed” and is left out too — their other terms are unchanged.</p>
    ${groups.map(([label, list]) => `
      <h4 style="margin-top:16px;">${label}</h4>
      <table>
        <thead><tr><th>Student</th>${terms.map((t) => `<th>${escapeHtml(t.term_name)}</th>`).join("")}<th>Final Grade</th><th>Descriptor</th></tr></thead>
        <tbody>
          ${list.map((s) => {
            const removedTerms = terms.filter((t) => isRemovedInTerm(s.id, t.id));
            const termGrades = terms.map((t) => {
              if (isRemovedInTerm(s.id, t.id)) return null; // removed that term: not counted, not shown
              const d = perTermData[t.term_number];
              const bonus = d.bonusByStudent[s.id] || 0;
              return computeTermGrade(d.assessments, d.scoresByStudent[s.id] || {}, weights, bonus).termGrade;
            });
            const final = computeFinalGrade(termGrades);
            const fd = gradeDescriptor(final);
            return `<tr>
              <td>${escapeHtml(displayName(s))}</td>
              ${termGrades.map((g, i) => isRemovedInTerm(s.id, terms[i].id) ? `<td class="num muted" title="Removed from ${escapeHtml(terms[i].term_name)}">Removed</td>` : `<td class="num">${g !== null ? g : "—"}</td>`).join("")}
              <td class="num" style="font-weight:700;">${final !== null ? final : "—"}${removedTerms.length && final !== null ? `<div class="muted" style="font-weight:400;font-size:.68rem;">partial — removed ${escapeHtml(termListText(removedTerms))}</div>` : ""}</td>
              <td><span style="color:${fd.color};font-weight:600;">${final !== null ? fd.label : "No grades yet"}</span></td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>`).join("")}`;
}

// ============================================================================
// ATTENDANCE
// ============================================================================
function renderAttendance() {
  const el = document.getElementById("tab-attendance");
  const today = new Date().toISOString().slice(0, 10);
  state.attSubTab = state.attSubTab || "entry";
  el.innerHTML = `
    <div class="card">
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">
        <button class="btn-sm ${state.attSubTab === "entry" ? "btn-primary" : "btn-outline"}" onclick="switchAttSubTab('entry')">🗓️ Take Attendance</button>
        <button class="btn-sm ${state.attSubTab === "summary" ? "btn-primary" : "btn-outline"}" onclick="switchAttSubTab('summary')">📊 Summary</button>
        <button class="btn-sm ${state.attSubTab === "log" ? "btn-primary" : "btn-outline"}" onclick="switchAttSubTab('log')">📋 Full Log (Per-Day Records)</button>
      </div>

      <div id="attEntrySection" style="display:${state.attSubTab === "entry" ? "block" : "none"};">
        <div style="display:flex;gap:14px;align-items:end;flex-wrap:wrap;">
          <div class="field" style="max-width:220px;">
            <label>Date</label>
            <input type="date" id="attDate" value="${today}" onchange="loadAttendanceForDate()">
          </div>
          <button class="btn-outline" onclick="markAll('present')">Mark all Present</button>
        </div>
        <div id="attGrid" style="margin-top:16px;"></div>
      </div>

      <div id="attSummarySection" style="display:${state.attSubTab === "summary" ? "block" : "none"};">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
          <h4 style="margin:0;">Attendance Summary (${escapeHtml(state.term.term_name)}: ${fmtDate(termDateRange(state.term, state.section.school_year).start)} – ${fmtDate(termDateRange(state.term, state.section.school_year).end)})</h4>
          <button class="btn-outline btn-sm" onclick="openEditTermDatesModal()">📅 Edit Term Dates</button>
        </div>
        <p class="muted" style="font-size:.78rem;margin-top:4px;">${state.term.start_date && state.term.end_date ? "Using the dates set for this term." : "No exact dates set for this term yet — using an estimated 1/3 slice of the school year. Set exact dates for an accurate summary."}</p>
        <div id="attSummary"></div>
      </div>

      <div id="attLogSection" style="display:${state.attSubTab === "log" ? "block" : "none"};">
        <h4 style="margin-top:0;">Full Attendance Log</h4>
        <p class="muted">Every attendance record for this section, one row per student per day. Use this to trace back and fix a mistake — change the status right in the row, or delete the row entirely if it shouldn't exist.</p>
        <div style="display:flex;gap:14px;align-items:end;flex-wrap:wrap;margin-bottom:12px;">
          <div class="field" style="max-width:180px;"><label>From</label><input type="date" id="attLogFrom" value="${state.term && state.term.start_date ? state.term.start_date : ""}" onchange="loadAttendanceLog()"></div>
          <div class="field" style="max-width:180px;"><label>To</label><input type="date" id="attLogTo" value="" onchange="loadAttendanceLog()"></div>
          <div class="field" style="min-width:200px;">
            <label>Student</label>
            <select id="attLogStudent" onchange="loadAttendanceLog()">
              <option value="">All students</option>
              ${state.students.map((s) => `<option value="${s.id}">${escapeHtml(displayName(s))}</option>`).join("")}
            </select>
          </div>
          <button class="btn-outline" onclick="document.getElementById('attLogFrom').value='';document.getElementById('attLogTo').value='';document.getElementById('attLogStudent').value='';loadAttendanceLog();">Clear Filters</button>
        </div>
        <div id="attLogTable"></div>
      </div>
    </div>`;
  loadAttendanceForDate();
  loadAttendanceSummary();
  if (state.attSubTab === "log") loadAttendanceLog();
}
function switchAttSubTab(tab) {
  state.attSubTab = tab;
  renderAttendance();
}

// AUDIT FIX (2026-09): terms.start_date/end_date existed in the schema but
// nothing in the app ever wrote to them, which was the root cause of the
// "days present" mismatch between the Teacher's per-term view and the
// Student's account. This modal is the first place they can actually be set.
function openEditTermDatesModal() {
  showModal(`
    <h3>Edit Term Dates — ${escapeHtml(state.section.section_name)}</h3>
    <p class="muted" style="margin-top:-6px;">Setting exact start/end dates makes every "this term" attendance figure (here and in the student's own account) precise instead of an estimate.</p>
    ${state.terms.map((t) => `
      <div class="field-row" style="align-items:end;">
        <div class="field"><label>${escapeHtml(t.term_name)} — Start</label><input type="date" id="td_start_${t.id}" value="${t.start_date || ""}"></div>
        <div class="field"><label>${escapeHtml(t.term_name)} — End</label><input type="date" id="td_end_${t.id}" value="${t.end_date || ""}"></div>
      </div>`).join("")}
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveTermDates()">Save</button>
    </div>`);
}
async function saveTermDates() {
  for (const t of state.terms) {
    const start_date = document.getElementById(`td_start_${t.id}`).value || null;
    const end_date = document.getElementById(`td_end_${t.id}`).value || null;
    if (start_date !== (t.start_date || null) || end_date !== (t.end_date || null)) {
      const { error } = await supabase.from("terms").update({ start_date, end_date }).eq("id", t.id);
      if (error) { toast("Error saving " + t.term_name + ": " + error.message); return; }
      t.start_date = start_date; t.end_date = end_date;
      if (state.term.id === t.id) state.term = t;
    }
  }
  closeModal();
  toast("Term dates saved.");
  renderAttendance();
}
async function loadAttendanceForDate() {
  const date = document.getElementById("attDate").value;
  const { data } = await supabase.from("attendance").select("*").eq("section_id", state.section.id).eq("attendance_date", date);
  const byStudent = {};
  (data || []).forEach((a) => (byStudent[a.student_id] = a.status));
  const statuses = [
    ["present", "Present"], ["late", "Late"],
    ["absent_excused", "Absent (Excused)"], ["absent_unexcused", "Absent (Unexcused)"],
  ];
  const groups = studentGroups(state.students);
  document.getElementById("attGrid").innerHTML = state.students.length === 0 ? `<p class="muted">No students in roster.</p>` :
    groups.map(([label, list]) => `
      <h4 style="margin-top:16px;">${label}</h4>
      <table>
        <thead><tr><th>Student</th><th>Status</th></tr></thead>
        <tbody>
          ${list.map((s) => `
            <tr>
              <td>${escapeHtml(displayName(s))}</td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                  ${statuses.map(([val, statusLabel]) => `
                    <button class="btn-sm ${byStudent[s.id] === val ? "btn-primary" : "btn-outline"}"
                      onclick="setAttendance('${s.id}','${val}')">${statusLabel}</button>`).join("")}
                </div>
              </td>
            </tr>`).join("")}
        </tbody>
      </table>`).join("");
}
async function setAttendance(studentId, status) {
  const date = document.getElementById("attDate").value;
  const { error } = await supabase.from("attendance").upsert(
    { section_id: state.section.id, student_id: studentId, attendance_date: date, status },
    { onConflict: "student_id,attendance_date" }
  );
  if (error) { toast("Error: " + error.message); return; }
  loadAttendanceForDate();
  loadAttendanceSummary();
}
async function markAll(status) {
  const date = document.getElementById("attDate").value;
  const rows = state.students.map((s) => ({ section_id: state.section.id, student_id: s.id, attendance_date: date, status }));
  if (rows.length === 0) return;
  await supabase.from("attendance").upsert(rows, { onConflict: "student_id,attendance_date" });
  toast("Marked all present.");
  loadAttendanceForDate();
  loadAttendanceSummary();
}
async function loadAttendanceSummary() {
  // AUDIT FIX (2026-09): this used to filter with only a lower bound
  // (`.gte(attendance_date, term.start_date || "2000-01-01")`) and NO upper
  // bound. Since terms.start_date was never populated anywhere in the app,
  // that fallback always fired — so "Attendance Summary (this term)" was
  // actually showing the section's ENTIRE attendance history under every
  // term's tab, not just the selected term. termDateRange() (shared with
  // student.js — see supabase-client.js) now gives every term a real,
  // distinct date range even before you've filled in exact dates, and both
  // bounds are applied here.
  const range = termDateRange(state.term, state.section.school_year);
  const { data } = await supabase.from("attendance").select("*").eq("section_id", state.section.id)
    .gte("attendance_date", range.start).lte("attendance_date", range.end);
  const counts = {};
  (data || []).forEach((a) => {
    counts[a.student_id] = counts[a.student_id] || { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0 };
    counts[a.student_id][a.status]++;
  });
  const groups = studentGroups(state.students);
  document.getElementById("attSummary").innerHTML = groups.map(([label, list]) => `
    <h4 style="margin-top:16px;">${label}</h4>
    <table>
      <thead><tr><th>Student</th><th>Present</th><th>Late</th><th>Absent (Excused)</th><th>Absent (Unexcused)</th></tr></thead>
      <tbody>
        ${list.map((s) => {
          const c = counts[s.id] || { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0 };
          return `<tr><td>${escapeHtml(displayName(s))}</td><td class="num">${c.present}</td><td class="num">${c.late}</td><td class="num">${c.absent_excused}</td><td class="num">${c.absent_unexcused}</td></tr>`;
        }).join("")}
      </tbody>
    </table>`).join("");
}

// ---------- Full Log: every raw record, filterable, inline-editable ----------
const ATT_STATUS_OPTIONS = [
  ["present", "Present"], ["late", "Late"],
  ["absent_excused", "Absent (Excused)"], ["absent_unexcused", "Absent (Unexcused)"],
];
async function loadAttendanceLog() {
  const container = document.getElementById("attLogTable");
  if (!container) return;
  const from = document.getElementById("attLogFrom").value;
  const to = document.getElementById("attLogTo").value;
  const studentId = document.getElementById("attLogStudent").value;

  let query = supabase.from("attendance").select("*").eq("section_id", state.section.id);
  if (from) query = query.gte("attendance_date", from);
  if (to) query = query.lte("attendance_date", to);
  if (studentId) query = query.eq("student_id", studentId);
  const { data, error } = await query.order("attendance_date", { ascending: false });
  if (error) { container.innerHTML = `<p class="muted">Error loading log: ${escapeHtml(error.message)}</p>`; return; }

  const studentsById = {};
  state.allStudents.forEach((s) => (studentsById[s.id] = s));

  // Students removed from THIS term are left out of this term's log (their records stay in the database).
  const logRows = (data || []).filter((a) => !isRemovedInTerm(a.student_id, state.term.id));
  if (logRows.length === 0) {
    container.innerHTML = `<p class="muted">No attendance records match these filters.</p>`;
    return;
  }

  container.innerHTML = `
    <table>
      <thead><tr><th>Date</th><th>Student</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${logRows.map((a) => {
          const student = studentsById[a.student_id];
          return `<tr>
            <td>${escapeHtml(a.attendance_date)}</td>
            <td>${student ? escapeHtml(displayName(student)) : "<span class=\"muted\">(removed student)</span>"}</td>
            <td>
              <select onchange="updateAttendanceStatus('${a.id}', this.value)">
                ${ATT_STATUS_OPTIONS.map(([val, label]) => `<option value="${val}" ${a.status === val ? "selected" : ""}>${label}</option>`).join("")}
              </select>
            </td>
            <td><button class="btn-sm btn-danger" onclick="deleteAttendanceRow('${a.id}')">Delete</button></td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>
    <p class="muted" style="margin-top:8px;">${logRows.length} record${logRows.length === 1 ? "" : "s"}.</p>`;
}
async function updateAttendanceStatus(recordId, newStatus) {
  const { error } = await supabase.from("attendance").update({ status: newStatus }).eq("id", recordId);
  if (error) { toast("Error: " + error.message); return; }
  toast("Attendance record updated.");
  loadAttendanceLog();
  loadAttendanceSummary();
  if (document.getElementById("attDate")) loadAttendanceForDate();
}
async function deleteAttendanceRow(recordId) {
  if (!confirm("Delete this attendance record? This removes that single day's entry for that student.")) return;
  const { error } = await supabase.from("attendance").delete().eq("id", recordId);
  if (error) { toast("Error: " + error.message); return; }
  toast("Attendance record deleted.");
  loadAttendanceLog();
  loadAttendanceSummary();
  if (document.getElementById("attDate")) loadAttendanceForDate();
}

// ============================================================================
// WEEKLY CHECK-IN — teacher posts the week's lesson; students rate how well
// they understood it (1-5) and can leave an optional comment. Replaces the
// old "Weekly Tasks" list, which saw little student engagement, with a
// formative-assessment signal: a ranked "Least Understood Topics" summary
// computed live from student ratings, so the panel doubles as an early
// warning system for what needs re-teaching. See migration-26.
// ============================================================================
async function renderLessons() {
  const el = document.getElementById("tab-lessons");
  const { data: lessons } = await supabase.from("lessons").select("*").eq("term_id", state.term.id).order("week_number", { ascending: false });
  const lessonIds = (lessons || []).map((l) => l.id);
  const { data: ratings } = lessonIds.length
    ? await supabase.from("topic_ratings").select("*").in("lesson_id", lessonIds)
    : { data: [] };

  const byLesson = {};
  (ratings || []).forEach((r) => { (byLesson[r.lesson_id] = byLesson[r.lesson_id] || []).push(r); });

  const { data: helpFlags } = lessonIds.length
    ? await supabase.from("help_flags").select("*").in("lesson_id", lessonIds).eq("addressed_by_teacher", false)
    : { data: [] };
  const helpFlagsByLesson = {};
  (helpFlags || []).forEach((f) => { (helpFlagsByLesson[f.lesson_id] = helpFlagsByLesson[f.lesson_id] || []).push(f); });

  const { data: reteachNotes } = lessonIds.length
    ? await supabase.from("reteach_notes").select("*").in("lesson_id", lessonIds)
    : { data: [] };
  const reteachByLesson = {};
  (reteachNotes || []).forEach((n) => (reteachByLesson[n.lesson_id] = n));

  const classSize = state.students.length;
  const summarized = (lessons || []).map((l) => {
    const rs = byLesson[l.id] || [];
    const avg = rs.length ? rs.reduce((a, r) => a + r.rating, 0) / rs.length : null;
    return { lesson: l, ratings: rs, avg, respondents: rs.length };
  });

  // "Least understood" = lowest average rating among lessons with at least
  // one response, worst first — the teacher's at-a-glance re-teach list.
  const leastUnderstood = summarized.filter((s) => s.avg !== null).sort((a, b) => a.avg - b.avg).slice(0, 3);

  el.innerHTML = `
    ${leastUnderstood.length > 0 ? `
    <div class="card" style="margin-bottom:20px;border-left:4px solid var(--clay);">
      <h3 style="margin-top:0;">⚠️ Least Understood Topics This Term</h3>
      <p class="muted" style="margin-top:-6px;">Ranked by average student understanding rating — worst first. Good candidates for a quick review or re-teach.</p>
      ${leastUnderstood.map((s, i) => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;${i < leastUnderstood.length - 1 ? "border-bottom:1px solid var(--paper-line);" : ""}">
          <div>
            <strong>Week ${s.lesson.week_number} · ${escapeHtml(s.lesson.title)}</strong>
            <div class="muted">${s.respondents}/${classSize} responded</div>
            ${(helpFlagsByLesson[s.lesson.id] || []).length > 0 ? `<span class="badge" style="background:var(--clay-light);color:var(--clay);margin-top:4px;display:inline-block;">🚩 ${helpFlagsByLesson[s.lesson.id].length} need help</span>` : ""}
          </div>
          <div style="text-align:right;">${renderStarDisplay(s.avg)}<div class="muted">${s.avg.toFixed(1)}/5</div></div>
        </div>`).join("")}
    </div>` : ""}

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <h3 style="margin:0;">📘 Weekly Lessons &amp; Understanding Check-In</h3>
        <button class="btn-gold btn-sm" onclick="openLessonModal()">+ Add Lesson</button>
      </div>
      ${summarized.length === 0 ? `<p class="muted">No lessons yet.</p>` : summarized.map((s) => {
        const l = s.lesson;
        const commented = s.ratings.filter((r) => r.comment);
        const flagsForLesson = helpFlagsByLesson[l.id] || [];
        const reteach = reteachByLesson[l.id];
        return `
        <div class="card" style="margin-top:12px;border-left:4px solid var(--sky);">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;">
            <div>
              <div class="muted">Week ${l.week_number}</div>
              <strong>${escapeHtml(l.title)}</strong>
              <div class="muted" style="margin:4px 0;">${TN.mathHtml(l.objectives || "")}</div>
            </div>
            <button class="btn-outline btn-sm" onclick="deleteRow('lessons','${l.id}','lessons')">Delete</button>
          </div>
          <div style="margin-top:6px;">
            <div class="muted" style="margin-bottom:4px;">📎 Lesson material link <span style="font-size:.8rem;">(Google Drive / Docs / Slides — optional)</span></div>
            <div style="display:flex;gap:8px;">
              <input id="lm_${l.id}" placeholder="https://drive.google.com/…" value="${escapeHtml(l.material_url || "")}" style="flex:1;" oninput="TN.lessonLinkChip('lm_${l.id}','lmchip_${l.id}')" autocomplete="off">
              <button class="btn-primary btn-sm" onclick="TN.saveLessonLink('${l.id}')">Save</button>
            </div>
            <div id="lmchip_${l.id}" class="tn-chipbox">${l.material_url ? TN.linkChipHtml(l.material_url) : ""}</div>
          </div>
          <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--paper-line);">
            ${s.respondents === 0 ? `<p class="muted">No student ratings yet.</p>` : `
              <div style="display:flex;align-items:center;gap:10px;">
                ${renderStarDisplay(s.avg)}
                <span class="muted">${s.avg.toFixed(1)}/5 · ${s.respondents}/${classSize} responded</span>
              </div>
              ${commented.length > 0 ? `
                <details style="margin-top:8px;">
                  <summary class="muted" style="cursor:pointer;">💬 Student comments (${commented.length})</summary>
                  ${commented.map((r) => `<p style="margin:6px 0;padding:6px 10px;background:var(--gold-light);border-radius:8px;">“${escapeHtml(r.comment)}” <span class="muted">— ${r.rating}★</span></p>`).join("")}
                </details>` : ""}
            `}
            ${flagsForLesson.length > 0 ? `
              <p style="margin-top:8px;">
                <span class="badge" style="background:var(--clay-light);color:var(--clay);">🚩 ${flagsForLesson.length} student${flagsForLesson.length > 1 ? "s" : ""} requested help</span>
                <button class="btn-outline btn-sm" style="margin-left:6px;" onclick="viewHelpFlags('${l.id}')">View</button>
              </p>` : ""}
          </div>
          <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--paper-line);">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
              <div class="muted">🔁 2-min recap ${reteach ? `<span style="font-size:.8rem;">(posted ${new Date(reteach.updated_at || reteach.posted_at).toLocaleDateString()})</span>` : ""}</div>
              <button class="btn-outline btn-sm" onclick="TN.openRecapEditor('${l.id}')">${reteach ? "✏️ Edit recap" : "+ Add 2-min recap"}</button>
            </div>
            ${reteach ? `
              <div style="margin-top:6px;">
                <strong>${escapeHtml(reteach.title)}</strong> ${TN.linkBadge(reteach.link_url)}
                ${reteach.content ? `<div class="muted" style="margin-top:2px;">${escapeHtml(reteach.content.length > 200 ? reteach.content.slice(0, 200) + "…" : reteach.content)}</div>` : ""}
              </div>` : `<p class="muted" style="margin:6px 0 0;font-size:.85rem;">Type or paste a short recap (math shows as proper notation), attach a Google Drive link, or both.</p>`}
          </div>
        </div>`;
      }).join("")}
    </div>`;
}
async function viewHelpFlags(lessonId) {
  const { data: flags } = await supabase.from("help_flags").select("*").eq("lesson_id", lessonId).eq("addressed_by_teacher", false);
  const studentById = {}; state.students.forEach((s) => (studentById[s.id] = s));
  showModal(`
    <h3>🚩 Students Requesting Help</h3>
    ${(flags || []).length === 0 ? `<p class="muted">No open help requests for this lesson.</p>` : (flags || []).map((f) => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--paper-line);">
        <div>
          <strong>${studentById[f.student_id] ? escapeHtml(displayName(studentById[f.student_id])) : "Unknown"}</strong>
          <div class="muted" style="font-size:.8rem;">Flagged ${new Date(f.flagged_at).toLocaleString()}</div>
        </div>
        <button class="btn-outline btn-sm" onclick="markHelpFlagAddressed('${f.id}','${lessonId}')">Mark Addressed</button>
      </div>`).join("")}
    <div style="display:flex;justify-content:flex-end;margin-top:14px;">
      <button class="btn-outline" onclick="closeModal()">Close</button>
    </div>`);
}
async function markHelpFlagAddressed(flagId, lessonId) {
  const { error } = await supabase.from("help_flags").update({ addressed_by_teacher: true, addressed_at: new Date().toISOString() }).eq("id", flagId);
  if (error) { toast("Error: " + error.message); return; }
  toast("Marked as addressed.");
  closeModal();
  renderLessons();
}
function renderStarDisplay(avg) {
  if (avg === null || avg === undefined) return `<span class="muted">No ratings yet</span>`;
  const full = Math.round(avg);
  return `<span style="color:var(--gold);letter-spacing:2px;">${"★".repeat(full)}${"☆".repeat(5 - full)}</span>`;
}
function openLessonModal() {
  showModal(`
    <h3>Add Weekly Lesson</h3>
    <div class="field"><label>Week Number</label><input type="number" id="l_week" min="1" value="1"></div>
    <div class="field"><label>Title</label><input id="l_title" placeholder="e.g. Solving Linear Equations"></div>
    <div class="field"><label>Objectives / Notes <span class="muted">(math like x^2, sqrt(x), 1/2 shows as proper notation)</span></label><textarea id="l_obj" data-mt="1" rows="3"></textarea></div>
    ${typeof MathText !== "undefined" ? MathText.paletteHtml("mtPalLesson", "l_obj") : ""}
    <div class="field"><label>📎 Lesson material link <span class="muted">(Google Drive / Docs / Slides — optional)</span></label>
      <input id="l_url" placeholder="https://drive.google.com/…" autocomplete="off" oninput="TN.lessonLinkChip('l_url','l_urlchip')">
      <div id="l_urlchip" class="tn-chipbox"></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createLesson()">Add</button>
    </div>`);
}
async function createLesson() {
  const week_number = Number(document.getElementById("l_week").value) || 1;
  const title = document.getElementById("l_title").value.trim();
  const objectives = document.getElementById("l_obj").value.trim();
  const material_url = document.getElementById("l_url").value.trim();
  if (!title) { toast("Enter a title."); return; }
  if (material_url) { const info = TN.driveInfo(material_url); if (!info || info.kind === "invalid") { toast("That link doesn't look right — it should start with https://"); return; } }
  const row = { section_id: state.section.id, term_id: state.term.id, week_number, title, objectives };
  if (material_url) row.material_url = material_url;
  const { error } = await supabase.from("lessons").insert(row);
  if (error) { toast(/material_url|column|schema cache/i.test(error.message) ? "Run migration-65 in Supabase first (adds the link column). " + error.message : "Error: " + error.message); return; }
  closeModal(); toast("Lesson added!"); renderLessons();
}
async function deleteRow(table, id, rerenderFn) {
  if (!confirm("Delete this item? Student ratings/comments tied to it will be removed too.")) return;
  await supabase.from(table).delete().eq("id", id);
  toast("Deleted.");
  if (rerenderFn === "lessons") renderLessons();
}

// ============================================================================
// BLENDED LEARNING (Learning Activity Sheets / Weekly Schedule / Announcements
// / Reflections) — the mode used when classes shift to blended due to a
// DepEd-declared suspension or emergency. The teacher posts each week's
// Learning Activity Sheet (LAS) as a PDF, viewable in-page. There is no file
// submission link here — output is turned in once face-to-face classes
// resume — instead students leave a short plain-text daily reflection, which
// the teacher can respond to directly on the same panel. See migration-26.
// ============================================================================
var blSubTab = "modules";
async function renderBlended() {
  const el = document.getElementById("tab-blended");
  el.innerHTML = `
    <div class="card">
      <div class="tabs">
        <div class="tab ${blSubTab === "modules" ? "active" : ""}" onclick="blSubTab='modules';renderBlended();">📄 Learning Activity Sheets</div>
        <div class="tab ${blSubTab === "schedule" ? "active" : ""}" onclick="blSubTab='schedule';renderBlended();">Weekly Schedule</div>
        <div class="tab ${blSubTab === "announcements" ? "active" : ""}" onclick="blSubTab='announcements';renderBlended();">Announcements</div>
        <div class="tab ${blSubTab === "notes" ? "active" : ""}" onclick="blSubTab='notes';renderBlended();">🗒️ Teaching Notes</div>
        <div class="tab ${blSubTab === "reflections" ? "active" : ""}" onclick="blSubTab='reflections';renderBlended();">📝 Reflections</div>
      </div>
      <div id="blContent"></div>
    </div>`;
  if (blSubTab === "modules") renderBlModules();
  else if (blSubTab === "schedule") renderBlSchedule();
  else if (blSubTab === "announcements") renderBlAnnouncements();
  else if (blSubTab === "notes") TN.renderTeacherNotes();
  else renderBlReflections();
}

async function renderBlModules() {
  const { data } = await supabase.from("modules").select("*").eq("term_id", state.term.id).order("week_number");
  const moduleIds = (data || []).map((m) => m.id);

  const { data: parentNotes } = moduleIds.length
    ? await supabase.from("module_parent_notes").select("*").in("module_id", moduleIds)
    : { data: [] };
  const parentNoteByModule = {}; (parentNotes || []).forEach((p) => (parentNoteByModule[p.module_id] = p));

  const { data: faqs } = moduleIds.length
    ? await supabase.from("module_faq").select("*").in("module_id", moduleIds).order("posted_at", { ascending: false })
    : { data: [] };
  const faqByModule = {}; (faqs || []).forEach((f) => { (faqByModule[f.module_id] = faqByModule[f.module_id] || []).push(f); });

  document.getElementById("blContent").innerHTML = `
    <p class="muted" style="margin-top:0;">Post this week's Learning Activity Sheet (LAS) here as a PDF link — students view it in-page below, no download needed. Use this tab whenever classes shift to blended learning.</p>
    <div style="text-align:right;"><button class="btn-gold btn-sm" onclick="openModuleModal()">+ Add Learning Activity Sheet</button></div>
    ${(data || []).length === 0 ? `<p class="muted">No LAS posted yet.</p>` : data.map((m) => {
      const pn = parentNoteByModule[m.id];
      const faqList = faqByModule[m.id] || [];
      return `
      <div class="card" style="margin-top:12px;">
        <div class="muted">Week ${m.week_number || "—"} · <span class="badge badge-ww">${m.modality || "online"}</span></div>
        <strong>${escapeHtml(m.title)}</strong>
        <p class="muted">${escapeHtml(m.description || "")}</p>
        ${m.file_url ? `
          <div class="pdf-viewer-frame"><iframe src="${escapeHtml(toEmbeddablePdfUrl(m.file_url))}" loading="lazy"></iframe></div>
          <a href="${escapeHtml(m.file_url)}" target="_blank" style="font-size:.85rem;">Open in a new tab ↗</a><br>` : ""}
        <button class="btn-outline btn-sm" style="margin-top:8px;" onclick="deleteBlRow('modules','${m.id}')">Delete</button>

        <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--paper-line);">
          <div class="muted" style="margin-bottom:4px;">👨‍👩‍👧 Parent note (1-2 lines, shown to student &amp; parent)</div>
          <div style="display:flex;gap:8px;">
            <input id="pn_${m.id}" placeholder="e.g. Please check that your child finished items 1-5" value="${pn ? escapeHtml(pn.parent_note) : ""}" style="flex:1;">
            <button class="btn-primary btn-sm" onclick="saveParentNote('${m.id}')">Save</button>
          </div>
        </div>

        <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--paper-line);">
          <div class="muted" style="margin-bottom:4px;">❓ FAQ for this LAS ${faqList.length ? `(${faqList.length})` : ""}</div>
          ${faqList.map((f) => `
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;padding:6px 0;">
              <p style="margin:0;flex:1;"><strong>Q:</strong> ${escapeHtml(f.question)}<br><strong>A:</strong> ${escapeHtml(f.answer)}</p>
              <button class="btn-outline btn-sm" onclick="deleteBlRow('module_faq','${f.id}')">Delete</button>
            </div>`).join("")}
          <div style="display:flex;flex-direction:column;gap:6px;margin-top:6px;">
            <input id="faqq_${m.id}" placeholder="Question students keep asking">
            <textarea id="faqa_${m.id}" rows="2" placeholder="Your answer — posted once, all students see it"></textarea>
            <button class="btn-outline btn-sm" style="align-self:flex-end;" onclick="addModuleFaq('${m.id}')">+ Add FAQ</button>
          </div>
        </div>
      </div>`;
    }).join("")}`;
}
async function saveParentNote(moduleId) {
  const parent_note = document.getElementById(`pn_${moduleId}`).value.trim();
  if (!parent_note) { toast("Write a short note first."); return; }
  const { error } = await supabase.from("module_parent_notes").upsert(
    { module_id: moduleId, section_id: state.section.id, parent_note, updated_at: new Date().toISOString() },
    { onConflict: "module_id" }
  );
  if (error) { toast("Error: " + error.message); return; }
  toast("Parent note saved!");
  renderBlModules();
}
async function addModuleFaq(moduleId) {
  const question = document.getElementById(`faqq_${moduleId}`).value.trim();
  const answer = document.getElementById(`faqa_${moduleId}`).value.trim();
  if (!question || !answer) { toast("Fill in both the question and answer."); return; }
  const { error } = await supabase.from("module_faq").insert({ module_id: moduleId, section_id: state.section.id, question, answer });
  if (error) { toast("Error: " + error.message); return; }
  toast("FAQ posted — all students will see it.");
  renderBlModules();
}
function openModuleModal() {
  showModal(`
    <h3>Add Learning Activity Sheet</h3>
    <div class="field"><label>Week Number</label><input type="number" id="m_week" value="1"></div>
    <div class="field"><label>Title</label><input id="m_title" placeholder="e.g. LAS Week 3: Quadratic Functions"></div>
    <div class="field"><label>Description / Instructions</label><textarea id="m_desc" rows="2"></textarea></div>
    <div class="field"><label>PDF Link (Google Drive share link or direct .pdf URL)</label><input id="m_url" placeholder="https://..."></div>
    <div class="field"><label>Modality</label>
      <select id="m_modality"><option value="online">Online</option><option value="offline">Offline (printed/module)</option><option value="face_to_face">Face-to-Face</option></select>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createModule()">Add</button>
    </div>`);
}
async function createModule() {
  const week_number = Number(document.getElementById("m_week").value) || 1;
  const title = document.getElementById("m_title").value.trim();
  const description = document.getElementById("m_desc").value.trim();
  const file_url = document.getElementById("m_url").value.trim();
  const modality = document.getElementById("m_modality").value;
  if (!title) { toast("Enter a title."); return; }
  await supabase.from("modules").insert({ section_id: state.section.id, term_id: state.term.id, week_number, title, description, file_url, modality });
  closeModal(); toast("Learning Activity Sheet posted!"); renderBlModules();
}

async function renderBlSchedule() {
  const { data } = await supabase.from("schedule").select("*").eq("term_id", state.term.id).order("week_number");
  document.getElementById("blContent").innerHTML = `
    <div style="text-align:right;"><button class="btn-gold btn-sm" onclick="openScheduleModal()">+ Add Entry</button></div>
    ${(data || []).length === 0 ? `<p class="muted">No schedule entries yet.</p>` : `
    <table style="margin-top:12px;">
      <thead><tr><th>Week</th><th>Day</th><th>Modality</th><th>Activity</th><th></th></tr></thead>
      <tbody>${data.map((r) => `
        <tr>
          <td class="num">${r.week_number}</td><td>${escapeHtml(r.day_label)}</td>
          <td><span class="badge badge-ww">${r.modality}</span></td><td>${escapeHtml(r.activity || "")}</td>
          <td><button class="btn-outline btn-sm" onclick="deleteBlRow('schedule','${r.id}')">Delete</button></td>
        </tr>`).join("")}</tbody>
    </table>`}`;
}
function openScheduleModal() {
  showModal(`
    <h3>Add Schedule Entry</h3>
    <div class="field-row">
      <div class="field"><label>Week</label><input type="number" id="sc_week" value="1"></div>
      <div class="field"><label>Day</label><input id="sc_day" placeholder="Monday"></div>
    </div>
    <div class="field"><label>Modality</label>
      <select id="sc_modality"><option value="online">Online</option><option value="offline">Offline</option><option value="face_to_face">Face-to-Face</option></select>
    </div>
    <div class="field"><label>Activity</label><input id="sc_activity" placeholder="e.g. Synchronous session via Zoom"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createSchedule()">Add</button>
    </div>`);
}
async function createSchedule() {
  const week_number = Number(document.getElementById("sc_week").value) || 1;
  const day_label = document.getElementById("sc_day").value.trim();
  const modality = document.getElementById("sc_modality").value;
  const activity = document.getElementById("sc_activity").value.trim();
  if (!day_label) { toast("Enter a day."); return; }
  await supabase.from("schedule").insert({ section_id: state.section.id, term_id: state.term.id, week_number, day_label, modality, activity });
  closeModal(); toast("Added!"); renderBlSchedule();
}

async function renderBlAnnouncements() {
  const { data } = await supabase.from("announcements").select("*").eq("section_id", state.section.id).order("created_at", { ascending: false });
  document.getElementById("blContent").innerHTML = `
    <div style="text-align:right;"><button class="btn-gold btn-sm" onclick="openAnnouncementModal()">+ New Announcement</button></div>
    ${(data || []).length === 0 ? `<p class="muted">No announcements yet.</p>` : data.map((a) => `
      <div class="card" style="margin-top:12px;">
        <strong>${escapeHtml(a.title)}</strong>
        <p class="muted">${new Date(a.created_at).toLocaleString()}</p>
        <p>${escapeHtml(a.content)}</p>
        <button class="btn-outline btn-sm" onclick="deleteBlRow('announcements','${a.id}')">Delete</button>
      </div>`).join("")}`;
}
function openAnnouncementModal() {
  showModal(`
    <h3>New Announcement</h3>
    <div class="field"><label>Title</label><input id="an_title"></div>
    <div class="field"><label>Content</label><textarea id="an_content" rows="4"></textarea></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createAnnouncement()">Post</button>
    </div>`);
}
async function createAnnouncement() {
  const title = document.getElementById("an_title").value.trim();
  const content = document.getElementById("an_content").value.trim();
  if (!title || !content) { toast("Fill in both fields."); return; }
  await supabase.from("announcements").insert({ section_id: state.section.id, title, content });
  closeModal(); toast("Posted!"); renderBlAnnouncements();
}

async function renderBlReflections() {
  const { data: modules } = await supabase.from("modules").select("*").eq("term_id", state.term.id).order("week_number");
  const moduleIds = (modules || []).map((m) => m.id);
  const { data: refs } = moduleIds.length
    ? await supabase.from("reflections_v2").select("*").in("module_id", moduleIds).order("submitted_at", { ascending: false })
    : { data: [] };
  const moduleById = {}; (modules || []).forEach((m) => (moduleById[m.id] = m));
  const studentById = {}; state.students.forEach((s) => (studentById[s.id] = s));

  document.getElementById("blContent").innerHTML = `
    <p class="muted" style="margin-top:0;">What students wrote about their learning while classes were blended. "✅ Seen" appears automatically the moment they submit — leave full feedback below whenever you get to it, students see it on their own panel. If you're seeing the same question repeatedly, post it once as an FAQ from the Learning Activity Sheets tab instead.</p>
    ${(refs || []).length === 0 ? `<p class="muted">No reflections submitted yet.</p>` : refs.map((r) => `
      <div class="card" style="margin-top:12px;">
        <div class="muted">${moduleById[r.module_id] ? `Week ${moduleById[r.module_id].week_number || "—"} · ${escapeHtml(moduleById[r.module_id].title)}` : "—"} · ✅ Seen ${new Date(r.acknowledged_at || r.submitted_at).toLocaleString()}</div>
        <strong>${escapeHtml(studentById[r.student_id] ? displayName(studentById[r.student_id]) : "Unknown")}</strong>
        ${r.material_reviewed ? `<span class="badge badge-ww" style="margin-left:6px;">✔ Reviewed material</span>` : ""}
        ${r.learned ? `<p style="margin-top:6px;"><strong>Learned:</strong> ${escapeHtml(r.learned)}</p>` : ""}
        ${r.confused ? `<p><strong>Confused by:</strong> ${escapeHtml(r.confused)}</p>` : ""}
        ${r.question ? `<p><strong>Question:</strong> ${escapeHtml(r.question)}</p>` : ""}
        <div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--paper-line);">
          ${r.teacher_feedback ? `<p class="muted" style="margin-bottom:6px;">Your feedback (${new Date(r.feedback_at).toLocaleDateString()}):</p><p style="background:var(--gold-light);padding:8px 10px;border-radius:8px;">${escapeHtml(r.teacher_feedback)}</p>` : ""}
          <div style="display:flex;gap:8px;margin-top:6px;">
            <input id="fb_${r.id}" placeholder="${r.teacher_feedback ? "Update your feedback…" : "Write feedback for this student…"}" value="${escapeHtml(r.teacher_feedback || "")}" style="flex:1;">
            <button class="btn-primary btn-sm" onclick="saveReflectionFeedback('${r.id}')">Save</button>
          </div>
        </div>
      </div>`).join("")}`;
}
async function saveReflectionFeedback(id) {
  const input = document.getElementById(`fb_${id}`);
  const teacher_feedback = input.value.trim();
  if (!teacher_feedback) { toast("Write a feedback message first."); return; }
  const { error } = await supabase.from("reflections_v2").update({ teacher_feedback, feedback_at: new Date().toISOString() }).eq("id", id);
  if (error) { toast("Error: " + error.message); return; }
  toast("Feedback saved!"); renderBlReflections();
}
async function deleteBlRow(table, id) {
  if (!confirm("Delete this item?")) return;
  await supabase.from(table).delete().eq("id", id);
  toast("Deleted."); renderBlended();
}

// ============================================================================
// EXPORT TO EXCEL — full backup of the current section's data
// ============================================================================
async function exportToExcel() {
  if (!state.section) { toast("Select a section first."); return; }
  toast("Building your Excel file — this may take a few seconds…");

  const wb = XLSX.utils.book_new();
  // Export covers the WHOLE section, so it uses everyone (allStudents) — a student removed from Term 2
  // still appears in the Term 1 rows. Each term below skips only the students removed from THAT term.
  const studentById = {};
  state.allStudents.forEach((s) => (studentById[s.id] = s));
  // Same order the teacher sees on screen: Female then Male then Not specified, alphabetical by surname within each.
  const orderedStudents = studentGroups(state.allStudents).flatMap(([, list]) => list);
  const removedFromNames = (sid) => (state.terms || []).filter((t) => isRemovedInTerm(sid, t.id)).sort((a, b) => a.term_number - b.term_number).map((t) => t.term_name).join(", ");

  // ---- Roster ----
  const rosterRows = orderedStudents.map((s, i) => ({
    "#": i + 1, "Surname": s.last_name || "", "First Name": s.first_name || "",
    "Middle Name": s.middle_name || "", "Full Name": s.full_name, "LRN": s.lrn || "", "Sex": s.sex || "",
    "Login Code": s.login_code || "", "Login Count": s.login_count || 0,
    "Last Login": s.last_login_at ? new Date(s.last_login_at).toLocaleString() : "",
    "Removed From Term(s)": removedFromNames(s.id),
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rosterRows), "Roster");

  // ---- Class Record (per term) + Final Grades ----
  const classRecordRows = [];
  const finalGradeMap = {};
  for (const term of state.terms) {
    const { data: assessments } = await supabase.from("assessments").select("*").eq("term_id", term.id);
    const assessmentIds = (assessments || []).map((a) => a.id);
    const [{ data: scores }, { data: bonusRows }] = await Promise.all([
      assessmentIds.length
        ? supabase.from("scores").select("*").in("assessment_id", assessmentIds)
        : Promise.resolve({ data: [] }),
      supabase.from("term_bonus_points").select("*").eq("term_id", term.id),
    ]);
    const scoresByStudent = {};
    (scores || []).forEach((sc) => {
      scoresByStudent[sc.student_id] = scoresByStudent[sc.student_id] || {};
      scoresByStudent[sc.student_id][sc.assessment_id] = sc;
    });
    const bonusByStudent = {};
    (bonusRows || []).forEach((b) => { bonusByStudent[b.student_id] = b; });
    for (const s of orderedStudents) {
      if (isRemovedInTerm(s.id, term.id)) continue; // removed from this term: not part of its class record
      const bonus = bonusByStudent[s.id] ? Number(bonusByStudent[s.id].points) : 0;
      const g = computeTermGrade(assessments || [], scoresByStudent[s.id] || {}, getSectionWeights(state.section), bonus);
      const d = gradeDescriptor(g.termGrade);
      classRecordRows.push({
        "Term": term.term_name, "Surname": s.last_name || "", "First Name": s.first_name || "",
        "WW %": g.wwPS !== null ? round2(g.wwPS) : "", "PT %": g.ptPS !== null ? round2(g.ptPS) : "",
        "EX %": g.exPS !== null ? round2(g.exPS) : "", "Initial Grade": g.initialGrade ?? "",
        "Bonus Points": bonus || "", "Bonus Reason": (bonusByStudent[s.id] && bonusByStudent[s.id].reason) || "",
        "Term Grade": g.termGrade ?? "", "Descriptor": d.label,
      });
      finalGradeMap[s.id] = finalGradeMap[s.id] || {};
      finalGradeMap[s.id][term.term_number] = g.termGrade;
    }
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(classRecordRows), "Class Record");

  const finalRows = orderedStudents.map((s) => {
    const tg = finalGradeMap[s.id] || {};
    const final = computeFinalGrade([tg[1], tg[2], tg[3]]);
    return {
      "Surname": s.last_name || "", "First Name": s.first_name || "",
      "Term 1": tg[1] ?? "", "Term 2": tg[2] ?? "", "Term 3": tg[3] ?? "",
      "Final Grade": final ?? "", "Descriptor": gradeDescriptor(final).label,
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(finalRows), "Final Grades");

  // ---- Term removals (migration-63) ----
  const removalRows = [];
  (state.terms || []).slice().sort((a, b) => a.term_number - b.term_number).forEach((t) => {
    Object.values(state.removals[t.id] || {}).forEach((r) => {
      const st = studentById[r.student_id];
      removalRows.push({ "Term": t.term_name, "Student": st ? displayName(st) : "Unknown", "Reason": r.reason || "", "Note": r.note || "", "Removed On": r.removed_at ? new Date(r.removed_at).toLocaleDateString() : "" });
    });
  });
  if (removalRows.length) XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(removalRows), "Term Removals");

  // ---- Attendance ----
  const { data: attendance } = await supabase.from("attendance").select("*").eq("section_id", state.section.id).order("attendance_date");
  const attLabels = { present: "Present", late: "Late", absent_excused: "Absent (Excused)", absent_unexcused: "Absent (Unexcused)" };
  const attLogRows = (attendance || []).map((a) => ({
    "Date": a.attendance_date, "Student": studentById[a.student_id] ? displayName(studentById[a.student_id]) : "Unknown",
    "Status": attLabels[a.status] || a.status, "Remarks": a.remarks || "",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(attLogRows), "Attendance Log");

  const attCounts = {};
  (attendance || []).forEach((a) => {
    attCounts[a.student_id] = attCounts[a.student_id] || { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0 };
    attCounts[a.student_id][a.status]++;
  });
  const attSummaryRows = orderedStudents.map((s) => {
    const c = attCounts[s.id] || { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0 };
    return {
      "Surname": s.last_name || "", "First Name": s.first_name || "",
      "Present": c.present, "Late": c.late, "Absent (Excused)": c.absent_excused, "Absent (Unexcused)": c.absent_unexcused,
    };
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(attSummaryRows), "Attendance Summary");

  // ---- Lessons & Weekly Check-In ratings (all terms) ----
  const lessonRows = [], ratingRows = [];
  for (const term of state.terms) {
    const { data: lessons } = await supabase.from("lessons").select("*").eq("term_id", term.id).order("week_number");
    const lessonIds = (lessons || []).map((l) => l.id);
    const { data: ratings } = lessonIds.length
      ? await supabase.from("topic_ratings").select("*").in("lesson_id", lessonIds)
      : { data: [] };
    const ratingsByLesson = {}; (ratings || []).forEach((r) => (ratingsByLesson[r.lesson_id] = ratingsByLesson[r.lesson_id] || []).push(r));
    (lessons || []).forEach((l) => {
      const rs = ratingsByLesson[l.id] || [];
      const avg = rs.length ? (rs.reduce((a, r) => a + r.rating, 0) / rs.length) : "";
      lessonRows.push({
        "Term": term.term_name, "Week": l.week_number, "Title": l.title, "Objectives": l.objectives || "", "Lesson Link": l.material_url || "",
        "Avg Understanding Rating": avg ? Number(avg.toFixed(2)) : "", "Respondents": rs.length,
      });
      rs.forEach((r) => ratingRows.push({
        "Term": term.term_name, "Week": l.week_number, "Lesson": l.title,
        "Student": studentById[r.student_id] ? displayName(studentById[r.student_id]) : "Unknown",
        "Rating": r.rating, "Comment": r.comment || "",
      }));
    });
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(lessonRows), "Lessons");
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(ratingRows), "Topic Ratings");

  // ---- Blended Learning ----
  const { data: modules } = await supabase.from("modules").select("*, terms:term_id(term_name)").eq("section_id", state.section.id).order("week_number");
  const moduleRows = (modules || []).map((m) => ({
    "Term": m.terms?.term_name || "", "Week": m.week_number || "", "Title": m.title,
    "Modality": m.modality || "", "Description": m.description || "", "Link": m.file_url || "",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(moduleRows), "Learning Activity Sheets");

  const { data: schedule } = await supabase.from("schedule").select("*, terms:term_id(term_name)").eq("section_id", state.section.id).order("week_number");
  const scheduleRows = (schedule || []).map((r) => ({
    "Term": r.terms?.term_name || "", "Week": r.week_number, "Day": r.day_label, "Modality": r.modality || "", "Activity": r.activity || "",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(scheduleRows), "Weekly Schedule");

  const { data: announcements } = await supabase.from("announcements").select("*").eq("section_id", state.section.id).order("created_at");
  const announcementRows = (announcements || []).map((a) => ({
    "Date": new Date(a.created_at).toLocaleDateString(), "Title": a.title, "Content": a.content,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(announcementRows), "Announcements");

  const { data: teachingNotes } = await supabase.from("teaching_notes").select("*, terms:term_id(term_name)").eq("section_id", state.section.id).order("week_number");
  const teachingNoteRows = (teachingNotes || []).map((n) => ({
    "Term": n.terms?.term_name || "", "Week": n.week_number || "", "Title": n.title, "Description": n.description || "",
    "Google Drive Link": n.drive_url || "",
    // Excel cells hold at most 32,767 characters.
    "Notes": (n.note_text || "").slice(0, 32000),
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(teachingNoteRows), "Teaching Notes");

  const { data: allModulesForRefs } = await supabase.from("modules").select("id, title, week_number").eq("section_id", state.section.id);
  const moduleTitleById = {}; (allModulesForRefs || []).forEach((m) => (moduleTitleById[m.id] = m));
  const allModuleIds = (allModulesForRefs || []).map((m) => m.id);
  const { data: reflectionsForExport } = allModuleIds.length
    ? await supabase.from("reflections_v2").select("*").in("module_id", allModuleIds)
    : { data: [] };
  const reflectionRows = (reflectionsForExport || []).map((r) => ({
    "Student": studentById[r.student_id] ? displayName(studentById[r.student_id]) : "Unknown",
    "LAS": moduleTitleById[r.module_id]?.title || "", "Week": moduleTitleById[r.module_id]?.week_number || "",
    "Submitted At": new Date(r.submitted_at).toLocaleString(), "Seen At": r.acknowledged_at ? new Date(r.acknowledged_at).toLocaleString() : "",
    "Material Reviewed": r.material_reviewed ? "Yes" : "No",
    "One Thing Learned": r.learned || "", "What Confused Me": r.confused || "", "Question for Teacher": r.question || "",
    "Teacher Feedback": r.teacher_feedback || "",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(reflectionRows), "Reflections");

  // ---- Other Concerns ----
  const { data: concerns } = await supabase.from("other_concerns").select("*").eq("section_id", state.section.id).order("concern_date");
  const concernRows = (concerns || []).map((c) => ({
    "Date": c.concern_date, "Logged At": fmtDateTime(c.created_at), "Student": studentById[c.student_id] ? displayName(studentById[c.student_id]) : "Unknown",
    "Category": c.category, "Note": c.note, "Shared with Student": c.visible_to_student ? "Yes" : "No",
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(concernRows), "Other Concerns");

  const dateStr = new Date().toISOString().slice(0, 10);
  const safeSectionName = state.section.section_name.replace(/[^A-Za-z0-9]+/g, "_");
  XLSX.writeFile(wb, `MathConnect_${safeSectionName}_${dateStr}.xlsx`);
  toast("Excel file downloaded!");
}

// ============================================================================
// OTHER CONCERNS
// ============================================================================
// fmtDate (supabase-client.js) expects a plain "YYYY-MM-DD" date — that's all
// concern_date is (a date the teacher picks, defaults to today, editable).
// This one is for other_concerns.created_at, the actual timestamptz Supabase
// stamps the row with the moment it's saved — used so a teacher can see
// exactly when a note/message was logged, not just the date it's filed under.
function fmtDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
}

async function renderConcerns() {
  const el = document.getElementById("tab-concerns");
  const { data } = await supabase.from("other_concerns").select("*").eq("section_id", state.section.id).order("concern_date", { ascending: false });
  const studentById = {}; state.students.forEach((s) => (studentById[s.id] = s));
  el.innerHTML = `
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <h3 style="margin:0;">Other Concerns</h3>
        <select id="oc_studentPick" style="width:auto;">${state.students.map((s) => `<option value="${s.id}">${escapeHtml(displayName(s))}</option>`).join("")}</select>
        <button class="btn-gold btn-sm" ${state.students.length === 0 ? "disabled" : ""} onclick="openConcernModal(document.getElementById('oc_studentPick').value)">+ Add Note</button>
      </div>
      <p class="muted" style="margin-top:8px;">Notes are private to you by default. Mark a note "Share with student" to have it appear as feedback on that student's own dashboard.</p>
      ${(data || []).length === 0 ? `<p class="muted" style="margin-top:14px;">No notes recorded yet.</p>` : data.map((c) => `
        <div class="card" style="margin-top:12px;border-left:4px solid ${c.visible_to_student ? "var(--gold)" : "var(--clay)"};">
          <div class="muted">${fmtDate(c.concern_date)} · ${escapeHtml(c.category)} · <strong>${escapeHtml(studentById[c.student_id] ? displayName(studentById[c.student_id]) : "Unknown")}</strong>
            ${c.visible_to_student ? `<span class="badge badge-present" style="margin-left:6px;">Shared with student</span>` : `<span class="badge badge-late" style="margin-left:6px;">Private</span>`}
          </div>
          <div class="muted" style="font-size:0.85em;">Logged ${fmtDateTime(c.created_at)}</div>
          <p>${escapeHtml(c.note)}</p>
          <div style="display:flex;gap:6px;">
            <button class="btn-outline btn-sm" onclick="toggleConcernVisibility('${c.id}', ${!c.visible_to_student})">${c.visible_to_student ? "Make Private" : "Share with Student"}</button>
            <button class="btn-outline btn-sm" onclick="deleteConcern('${c.id}')">Delete</button>
          </div>
        </div>`).join("")}
    </div>`;
}
function openConcernModal(studentId) {
  showModal(`
    <h3>Add Note — Other Concerns</h3>
    <div class="field"><label>Student</label>
      <select id="oc_student">${state.students.map((s) => `<option value="${s.id}" ${s.id === studentId ? "selected" : ""}>${escapeHtml(displayName(s))}</option>`).join("")}</select>
    </div>
    <div class="field"><label>Category</label>
      <select id="oc_category"><option>General</option><option>Behavior</option><option>Health</option><option>Family</option><option>Academic</option></select>
    </div>
    <div class="field"><label>Date</label><input type="date" id="oc_date" value="${new Date().toISOString().slice(0,10)}"></div>
    <div class="field"><label>Note</label><textarea id="oc_note" rows="3"></textarea></div>
    <div class="field" style="display:flex;align-items:center;gap:8px;">
      <input type="checkbox" id="oc_visible" style="width:auto;">
      <label style="margin:0;" for="oc_visible">Share this note with the student as feedback</label>
    </div>
    <p class="muted" style="margin-top:-8px;">Leave unchecked for private notes (e.g. health, family, behavior concerns).</p>
    <div style="display:flex;gap:10px;justify-content:flex-end;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="createConcern()">Save</button>
    </div>`);
}
async function createConcern() {
  const student_id = document.getElementById("oc_student").value;
  const category = document.getElementById("oc_category").value;
  const concern_date = document.getElementById("oc_date").value;
  const note = document.getElementById("oc_note").value.trim();
  const visible_to_student = document.getElementById("oc_visible").checked;
  if (!student_id) { toast("Add a student to the roster first."); return; }
  if (!note) { toast("Enter a note."); return; }
  await supabase.from("other_concerns").insert({ section_id: state.section.id, student_id, category, concern_date, note, visible_to_student });
  closeModal(); toast("Saved!"); renderConcerns();
}
async function toggleConcernVisibility(id, makeVisible) {
  const { error } = await supabase.from("other_concerns").update({ visible_to_student: makeVisible }).eq("id", id);
  if (error) { toast("Error: " + error.message); return; }
  toast(makeVisible ? "Shared with student." : "Made private.");
  renderConcerns();
}
async function deleteConcern(id) {
  if (!confirm("Delete this note?")) return;
  const { error } = await supabase.from("other_concerns").delete().eq("id", id);
  if (error) { toast("Error: " + error.message); return; }
  toast("Deleted.");
  renderConcerns();
}

// ============================================================================
// GROUPS & PICKER — random group generator + spinning wheel
// ============================================================================
var groupsSubTab = "groups";
var lastGeneratedGroups = null;
var wheelStudents = null;
var wheelRemoveAfterPick = true;
var wheelRotation = 0;
var wheelSpinning = false;

function renderGroups() {
  const el = document.getElementById("tab-groups");
  el.innerHTML = `
    <div class="card">
      <div class="tabs" style="margin-bottom:16px;">
        <div class="tab ${groupsSubTab === "groups" ? "active" : ""}" onclick="groupsSubTab='groups';renderGroups();">Random Groups</div>
        <div class="tab ${groupsSubTab === "wheel" ? "active" : ""}" onclick="groupsSubTab='wheel';renderGroups();">Spin the Wheel</div>
      </div>
      <div id="groupsContent"></div>
    </div>`;
  if (groupsSubTab === "groups") renderGroupGenerator();
  else renderWheelPicker();
}

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---------- Random Group Generator ----------
function renderGroupGenerator() {
  const el = document.getElementById("groupsContent");
  if (state.students.length === 0) {
    el.innerHTML = `<div class="empty">Add students to the roster first.</div>`;
    return;
  }
  el.innerHTML = `
    <p class="muted">${state.students.length} student(s) in this section.</p>
    <div class="field-row">
      <div class="field">
        <label>Grouping Mode</label>
        <select id="grp_mode" onchange="toggleCustomGroupField()">
          <option value="2">Pairs (2 per group)</option>
          <option value="3">Trios (3 per group)</option>
          <option value="4">Groups of 4</option>
          <option value="5">Groups of 5</option>
          <option value="custom_size">Custom group size</option>
          <option value="custom_count">Custom number of groups</option>
        </select>
      </div>
      <div class="field" id="grp_customField" style="display:none;">
        <label id="grp_customLabel">Value</label>
        <input type="number" id="grp_customValue" min="2" value="4">
      </div>
    </div>
    <div class="field" style="display:flex;align-items:center;gap:8px;">
      <input type="checkbox" id="grp_excludeAbsent" style="width:auto;">
      <label style="margin:0;" for="grp_excludeAbsent">Exclude students marked absent today</label>
    </div>
    <button class="btn-gold" onclick="generateGroups()">🎲 Generate Groups</button>
    <div id="groupsResult" style="margin-top:16px;"></div>`;
}

function toggleCustomGroupField() {
  const mode = document.getElementById("grp_mode").value;
  const field = document.getElementById("grp_customField");
  const label = document.getElementById("grp_customLabel");
  if (mode === "custom_size") { field.style.display = "block"; label.textContent = "Students per group"; }
  else if (mode === "custom_count") { field.style.display = "block"; label.textContent = "Number of groups"; }
  else field.style.display = "none";
}

async function generateGroups() {
  const mode = document.getElementById("grp_mode").value;
  const excludeAbsent = document.getElementById("grp_excludeAbsent").checked;
  let pool = [...state.students];

  if (excludeAbsent) {
    const today = new Date().toISOString().slice(0, 10);
    const { data: att } = await supabase.from("attendance").select("*").eq("section_id", state.section.id).eq("attendance_date", today);
    const absentIds = new Set((att || []).filter((a) => a.status.startsWith("absent")).map((a) => a.student_id));
    pool = pool.filter((s) => !absentIds.has(s.id));
  }

  if (pool.length < 2) { toast("Need at least 2 students (not marked absent) to form groups."); return; }

  const shuffled = shuffleArray(pool);
  let numGroups;
  if (mode === "custom_count") {
    numGroups = Math.max(1, Math.min(shuffled.length, parseInt(document.getElementById("grp_customValue").value) || 1));
  } else {
    const groupSize = mode === "custom_size" ? Math.max(2, parseInt(document.getElementById("grp_customValue").value) || 2) : parseInt(mode);
    numGroups = Math.max(1, Math.round(shuffled.length / groupSize));
  }

  const groups = Array.from({ length: numGroups }, () => []);
  shuffled.forEach((s, i) => groups[i % numGroups].push(s));
  lastGeneratedGroups = groups;
  renderGroupsResult(groups);
}

function renderGroupsResult(groups) {
  const el = document.getElementById("groupsResult");
  el.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <span class="muted">${groups.length} group(s) generated</span>
      <div style="display:flex;gap:8px;">
        <button class="btn-outline btn-sm" onclick="generateGroups()">🔄 Regenerate</button>
        <button class="btn-outline btn-sm" onclick="copyGroupsAsText()">Copy as Text</button>
      </div>
    </div>
    <div class="grid grid-3">
      ${groups.map((g, i) => `
        <div class="card" style="border-left:4px solid var(--gold);">
          <div class="muted" style="font-weight:600;">Group ${i + 1} <span style="font-weight:400;">(${g.length})</span></div>
          <ol style="margin:8px 0 0 18px;padding:0;">
            ${g.map((s) => `<li>${escapeHtml(displayName(s))}</li>`).join("")}
          </ol>
        </div>`).join("")}
    </div>`;
}

function copyGroupsAsText() {
  if (!lastGeneratedGroups) return;
  const text = lastGeneratedGroups.map((g, i) => `Group ${i + 1}: ${g.map((s) => displayName(s)).join(", ")}`).join("\n");
  navigator.clipboard.writeText(text).then(() => toast("Copied to clipboard!")).catch(() => toast("Couldn't copy — please select and copy manually."));
}

// ---------- Spin the Wheel ----------
function renderWheelPicker() {
  const el = document.getElementById("groupsContent");
  if (state.students.length === 0) {
    el.innerHTML = `<div class="empty">Add students to the roster first.</div>`;
    return;
  }
  if (!wheelStudents) wheelStudents = [...state.students];
  el.innerHTML = `
    <div style="text-align:center;">
      <div class="field" style="display:flex;align-items:center;gap:8px;justify-content:center;">
        <input type="checkbox" id="wheel_removeAfter" ${wheelRemoveAfterPick ? "checked" : ""} onchange="wheelRemoveAfterPick=this.checked;" style="width:auto;">
        <label style="margin:0;" for="wheel_removeAfter">Remove student after picking (no repeats until reset)</label>
      </div>
      <p class="muted">${wheelStudents.length} student(s) on the wheel</p>
      <div style="position:relative;width:320px;height:320px;margin:16px auto;">
        <canvas id="wheelCanvas" width="320" height="320" style="transition: transform 4s cubic-bezier(0.12,0.67,0.1,1); transform: rotate(${wheelRotation}deg);"></canvas>
        <div style="position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:0;height:0;border-left:14px solid transparent;border-right:14px solid transparent;border-top:24px solid var(--clay);"></div>
      </div>
      <button class="btn-gold" onclick="spinWheel()" ${wheelStudents.length === 0 ? "disabled" : ""}>🎡 Spin</button>
      <button class="btn-outline" onclick="resetWheel()">Reset Wheel</button>
      <div id="wheelResult" style="margin-top:14px;font-size:1.3rem;font-weight:700;color:var(--forest);"></div>
    </div>`;
  drawWheel();
}

function drawWheel() {
  const canvas = document.getElementById("wheelCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  const cx = w / 2, cy = h / 2, r = w / 2 - 4;
  ctx.clearRect(0, 0, w, h);
  const n = wheelStudents.length;
  if (n === 0) {
    ctx.fillStyle = "#E1E7DE";
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, 2 * Math.PI); ctx.fill();
    ctx.fillStyle = "#647266";
    ctx.font = "16px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("No students left", cx, cy);
    return;
  }
  const colors = ["#1E8449", "#F0A93B", "#2F8FD1", "#E8632E", "#8A6FD1", "#1FA6A0"];
  const anglePer = (2 * Math.PI) / n;
  wheelStudents.forEach((s, i) => {
    const start = i * anglePer;
    const end = start + anglePer;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, start, end);
    ctx.closePath();
    ctx.fillStyle = colors[i % colors.length];
    ctx.fill();
    ctx.strokeStyle = "#FFFFFF";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(start + anglePer / 2);
    ctx.textAlign = "right";
    ctx.fillStyle = "#fff";
    ctx.font = "12px Inter, sans-serif";
    const fullName = displayName(s);
    const shortName = fullName.length > 16 ? fullName.slice(0, 15) + "…" : fullName;
    ctx.fillText(shortName, r - 10, 4);
    ctx.restore();
  });
}

function spinWheel() {
  if (wheelSpinning) return;
  const n = wheelStudents.length;
  if (n === 0) return;
  wheelSpinning = true;
  document.getElementById("wheelResult").textContent = "";
  const canvas = document.getElementById("wheelCanvas");
  const anglePerDeg = 360 / n;
  const winnerIndex = Math.floor(Math.random() * n);
  const extraSpins = 5;
  // Pointer is fixed at the top (12 o'clock). Rotate so the winning
  // segment's center ends up under the pointer.
  const targetOffset = 360 - (winnerIndex * anglePerDeg + anglePerDeg / 2) - 90;
  wheelRotation += 360 * extraSpins + targetOffset - (wheelRotation % 360);
  canvas.style.transform = `rotate(${wheelRotation}deg)`;

  setTimeout(() => {
    const winner = wheelStudents[winnerIndex];
    document.getElementById("wheelResult").textContent = `🎉 ${displayName(winner)}`;
    wheelSpinning = false;
    if (wheelRemoveAfterPick) {
      wheelStudents = wheelStudents.filter((s, idx) => idx !== winnerIndex);
      drawWheel();
      const countEl = document.querySelector("#groupsContent .muted");
      if (countEl) countEl.textContent = `${wheelStudents.length} student(s) on the wheel`;
    }
  }, 4100);
}

function resetWheel() {
  wheelStudents = [...state.students];
  wheelRotation = 0;
  wheelSpinning = false;
  renderWheelPicker();
}
