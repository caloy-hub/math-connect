// ============================================================================
// MathConnect — Admin Overview Logic
// Read-only oversight across ALL teachers' classes: general average per
// class, DepEd proficiency level, attendance %, and usage counts.
// ============================================================================

const astate = { admin: null, teachers: [], sections: [], classRows: [], stationLocks: [], practiceDomains: [], loginAudit: [], adminActions: [], auditTab: "logins", schoolSettings: null };

// ============================================================================
// TAB NAVIGATION — Admin Overview used to be one long stacked page; it's now
// split into tabs (sidebar on desktop, drawer + quick tabbar on mobile) so
// no single screen needs long scrolling. Every panel is still rendered on
// load same as before — this only toggles which one is visible.
// ============================================================================
const ADMIN_TAB_TITLES = {
  overview: "Overview", term: "School Term", locks: "Content Locks", classes: "All Classes",
  championship: "Championship", teachers: "Teacher Accounts", students: "Student Accounts", audit: "Audit Log",
};

function switchAdminTab(tab) {
  closeAdminDrawer();
  document.querySelectorAll(".sidebar .tab, .mobile-tabbar .tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === tab));
  document.querySelectorAll(".tabpanel").forEach((p) => (p.style.display = "none"));
  const targetPanel = document.getElementById("tab-" + tab);
  if (targetPanel) targetPanel.style.display = "block";
  const titleEl = document.getElementById("adminTabTitle");
  if (titleEl) titleEl.textContent = ADMIN_TAB_TITLES[tab] || "Overview";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function toggleAdminDrawer() {
  const drawer = document.getElementById("adminDrawer");
  const overlay = document.getElementById("adminDrawerOverlay");
  const isOpen = drawer && drawer.classList.contains("open");
  if (isOpen) { closeAdminDrawer(); return; }
  if (drawer) drawer.classList.add("open");
  if (overlay) overlay.classList.add("open");
  document.body.classList.add("drawer-open");
}

function closeAdminDrawer() {
  const drawer = document.getElementById("adminDrawer");
  const overlay = document.getElementById("adminDrawerOverlay");
  if (drawer) drawer.classList.remove("open");
  if (overlay) overlay.classList.remove("open");
  document.body.classList.remove("drawer-open");
}

const AUDIT_ROLE_COLORS = { admin: "var(--gold-dark, #B8790E)", teacher: "var(--sky)", student: "var(--forest)" };
const AUDIT_ROLE_LABELS = { admin: "Admin", teacher: "Teacher", student: "Student" };

const ADMIN_ACTION_COLORS = {
  status_change: "var(--sky)",
  edit_account: "var(--purple)",
  delete_account: "var(--clay)",
  lock_change: "var(--gold-dark, #B8790E)",
  edit_entry: "var(--teal)",
  delete_entry: "var(--clay)",
  finalize_champion: "var(--forest)",
  password_reset: "var(--sky)",
  term_change: "var(--gold)",
};
const ADMIN_ACTION_LABELS = {
  status_change: "Status change",
  edit_account: "Account edit",
  delete_account: "Account deleted",
  lock_change: "Lock/unlock",
  edit_entry: "Entry corrected",
  delete_entry: "Entry deleted",
  finalize_champion: "Champion finalized",
  password_reset: "Password reset",
  term_change: "School term changed",
};

// Fire-and-forget admin action logger — never blocks or fails the actual
// admin action itself if the audit write has trouble.
function logAdminAction(actionType, targetTable, targetName, details) {
  supabase.rpc("record_admin_action", { p_action_type: actionType, p_target_table: targetTable, p_target_name: targetName, p_details: details || null }).then(({ error }) => {
    if (error) console.warn("Could not record admin action:", error.message);
  });
}

// NOTE: mirrors DRILL_TOPICS in drills.js (and TDRILL_TOPICS in
// teacher-drills.js) — admin.html loads standalone with no shared bundler,
// so if you ever add/rename a station, update all three lists.
const ADMIN_DRILL_TOPICS = [
  { key: "basic", icon: "➕", name: "Basic Operations" },
  { key: "order", icon: "🔢", name: "Order of Operations" },
  { key: "integers", icon: "➖", name: "Integers" },
  { key: "fractions", icon: "🍕", name: "Fractions" },
  { key: "decimals", icon: "💯", name: "Decimals" },
  { key: "algebra", icon: "🅧", name: "Algebraic Expressions" },
  { key: "ratio", icon: "⚖️", name: "Ratio & Proportion" },
  { key: "percent", icon: "💸", name: "Percent" },
  { key: "geometry", icon: "📐", name: "Geometry" },
  { key: "patterns", icon: "🧩", name: "Patterns & Sequences" },
  { key: "statistics", icon: "📊", name: "Statistics" },
  { key: "probability", icon: "🎡", name: "Probability" },
  { key: "exponents", icon: "⚡", name: "Exponents & Radicals" },
  { key: "equations", icon: "⚖️", name: "Equation Scale" },
  { key: "factoring", icon: "🧩", name: "Factor Vault" },
  { key: "measurement", icon: "🌾", name: "Farm Measure" },
  { key: "coordinates", icon: "📈", name: "Grid Navigator" },
  { key: "pythagoras", icon: "📐", name: "Surveyor's Post" },
];
const ADMIN_PRACTICE_DOMAINS = [
  { key: "addition", icon: "➕", name: "Addition" },
  { key: "subtraction", icon: "➖", name: "Subtraction" },
  { key: "multiplication", icon: "✖️", name: "Multiplication" },
  { key: "division", icon: "➗", name: "Division" },
  { key: "fractions", icon: "🍕", name: "Fractions" },
  { key: "decimals", icon: "💯", name: "Decimals" },
  { key: "ratio", icon: "⚖️", name: "Ratio & Proportion" },
  { key: "percent", icon: "💸", name: "Percent" },
  { key: "geometry", icon: "📐", name: "Geometry" },
  { key: "patterns", icon: "🧩", name: "Patterns & Sequences" },
  { key: "statistics", icon: "📊", name: "Statistics" },
  { key: "probability", icon: "🎡", name: "Probability" },
  { key: "exponents", icon: "⚡", name: "Exponents & Radicals" },
  { key: "equations", icon: "⚖️", name: "Equation Scale" },
  { key: "factoring", icon: "🧩", name: "Factor Vault" },
  { key: "measurement", icon: "🌾", name: "Farm Measure" },
  { key: "coordinates", icon: "📈", name: "Grid Navigator" },
  { key: "pythagoras", icon: "📐", name: "Surveyor's Post" },
];

initSupabase();
initAdmin();

async function initAdmin() {
  const admin = await requireAdmin();
  if (!admin) return;
  astate.admin = admin;
  document.getElementById("adminNameLabel").textContent = admin.full_name;
  await loadAllData();
  renderStats();
  renderTermControl();
  renderClassTable();
  renderStationLocks();
  renderPracticeDomainLocks();
  renderTeacherAccounts();
  renderStudentAccounts();
  renderChampionshipPanel();
  renderAuditLog();
}

// ============================================================================
// 🏆 MathLegends Grand Champion — one per grade level, per school year.
// Live standings + the one-time "Finalize School Year" action.
// (championshipEngine.js)
// ============================================================================
async function renderChampionshipPanel() {
  const wrap = document.getElementById("championshipWrap");
  if (!wrap) return;
  const gradeLevels = [...new Set(astate.sections.map((s) => s.grade_level).filter(Boolean))].sort();
  if (gradeLevels.length === 0) { wrap.innerHTML = `<div class="empty">No sections yet.</div>`; return; }

  const { data: hallOfFame } = await supabase.from("school_year_champions").select("*").order("school_year", { ascending: false });

  wrap.innerHTML = `
    <div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap;">
      <label style="margin:0;font-size:.8rem;">Grade level</label>
      <select id="champGradeSelect" onchange="renderChampionshipStandings()" style="width:auto;">
        ${gradeLevels.map((g) => `<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`).join("")}
      </select>
      <label style="margin:0 0 0 12px;font-size:.8rem;">School year</label>
      <input id="champSchoolYear" value="2026-2027" style="width:110px;" />
      <button class="btn-primary btn-sm" onclick="finalizeSchoolYearChampion()">🏆 Finalize School Year</button>
    </div>
    <div id="champStandingsWrap"></div>
    <h4 style="margin:20px 0 8px;">🏛️ Hall of Fame</h4>
    <div id="champHallOfFameWrap">
      ${(hallOfFame || []).length === 0 ? `<p class="muted">No champions crowned yet.</p>` : `
      <table><thead><tr><th>School Year</th><th>Grade</th><th>Champion</th><th>Score</th><th>Finalized</th></tr></thead>
      <tbody>${hallOfFame.map((h) => `<tr><td>${escapeHtml(h.school_year)}</td><td>${escapeHtml(h.grade_level)}</td><td>${escapeHtml(h.full_name_snapshot)}</td><td class="num">${Number(h.championship_score).toFixed(1)}</td><td>${fmtDate(h.finalized_at)}</td></tr>`).join("")}</tbody></table>`}
    </div>`;

  renderChampionshipStandings();
}

async function renderChampionshipStandings() {
  const grade = document.getElementById("champGradeSelect")?.value;
  const slot = document.getElementById("champStandingsWrap");
  if (!grade || !slot) return;
  slot.innerHTML = `<div class="empty">Loading standings…</div>`;
  const rows = await fetchGradeChampionStandings(grade, 50);
  slot.innerHTML = renderChampionshipStandingsCard(rows, grade, null);
}

async function finalizeSchoolYearChampion() {
  const grade = document.getElementById("champGradeSelect")?.value;
  const schoolYear = document.getElementById("champSchoolYear")?.value?.trim();
  if (!grade || !schoolYear) return;
  if (!confirm(`Finalize the ${schoolYear} Grand Champion for ${grade}? This freezes the current #1 into the permanent Hall of Fame and can be re-run later if you need to correct it.`)) return;

  const { data, error } = await supabase.rpc("finalize_school_year", { target_grade_level: grade, target_school_year: schoolYear });
  if (error) { alert("Error: " + error.message); return; }
  if (!data.crowned) { alert(data.reason || "No eligible student found."); return; }
  alert(`🏆 ${data.full_name} crowned Grand Champion of ${grade} for ${schoolYear} — score ${Number(data.total).toFixed(1)}.`);
  logAdminAction("finalize_champion", "school_year_champions", `${grade} — ${schoolYear}`, `${data.full_name}, score ${Number(data.total).toFixed(1)}`);
  renderChampionshipPanel();
}

async function loadAllData() {
  // AUDIT FIX (2026-09): teachers/sections/terms/term_bonus_points/station-locks/
  // practice-domains are small, bounded tables (one row per class/term/lock/
  // domain) that will never realistically approach the 1,000-row default cap,
  // so a plain select is fine for those. students/assessments/scores/attendance
  // grow with every enrollment, assessment, and day of school, so those four
  // now page through fetchAllRows() (see supabase-client.js) instead of relying
  // on a single unbounded select() that Supabase/PostgREST silently truncates
  // at ~1,000 rows — this was the root cause of Admin's averages/attendance
  // going stale or wrong once the school's data grew past that.
  const [{ data: teachers }, { data: sections }, students, { data: terms }, assessments, scores, attendance, { data: bonusPoints }, { data: stationLocks }, { data: practiceDomains }, { data: loginAudit }, { data: adminActions }, { data: teacherEmails }, schoolSettingsResult, termRemovalsResult] =
    await Promise.all([
      supabase.from("teachers").select("*"),
      supabase.from("sections").select("*"),
      fetchAllRows(() => supabase.from("students").select("*")),
      supabase.from("terms").select("*"),
      fetchAllRows(() => supabase.from("assessments").select("*")),
      fetchAllRows(() => supabase.from("scores").select("*")),
      fetchAllRows(() => supabase.from("attendance").select("*")),
      supabase.from("term_bonus_points").select("*"),
      supabase.from("drill_station_locks").select("*"),
      supabase.from("practice_domains").select("*"),
      supabase.from("login_audit_log").select("*").order("logged_in_at", { ascending: false }).limit(3000),
      supabase.from("admin_action_log").select("*").order("created_at", { ascending: false }).limit(3000),
      // Teacher emails aren't stored on the `teachers` table itself (only on
      // auth.users), so this goes through an admin-only RPC (migration-41)
      // rather than a plain select. Failure here shouldn't block the whole
      // panel from loading — swallow the error and fall back to blanks.
      supabase.rpc("admin_get_teacher_emails").then((r) => r, () => ({ data: [] })),
      // School-wide "current term" (migration-48) — may not exist yet on
      // older deployments that haven't run that migration, so this fails
      // quiet and the term control just shows "not set up yet" instead.
      supabase.from("school_settings").select("*").eq("id", "global").maybeSingle().then((r) => r, () => ({ data: null })),
      // Per-term student removals (migration-63) — quiet failure on older deployments: everyone counts as enrolled.
      supabase.from("student_term_status").select("student_id, term_id").then((r) => r, () => ({ data: [] })),
    ]);
  astate.schoolSettings = (schoolSettingsResult && schoolSettingsResult.data) || null;
  astate.stationLocks = stationLocks || [];
  astate.practiceDomains = practiceDomains || [];
  astate.loginAudit = loginAudit || [];
  astate.adminActions = adminActions || [];
  astate.teacherEmailById = {};
  (teacherEmails || []).forEach((e) => { astate.teacherEmailById[e.id] = e.email; });

  const teacherById = {}; (teachers || []).forEach((t) => (teacherById[t.id] = t));
  const studentsBySection = {}; (students || []).forEach((s) => {
    (studentsBySection[s.section_id] = studentsBySection[s.section_id] || []).push(s);
  });
  const termsBySection = {}; (terms || []).forEach((t) => {
    (termsBySection[t.section_id] = termsBySection[t.section_id] || []).push(t);
  });
  const assessmentsByTerm = {}; (assessments || []).forEach((a) => {
    (assessmentsByTerm[a.term_id] = assessmentsByTerm[a.term_id] || []).push(a);
  });
  const scoresByAssessment = {}; (scores || []).forEach((sc) => {
    scoresByAssessment[sc.assessment_id] = scoresByAssessment[sc.assessment_id] || {};
    scoresByAssessment[sc.assessment_id][sc.student_id] = sc;
  });
  const attendanceBySection = {}; (attendance || []).forEach((a) => {
    (attendanceBySection[a.section_id] = attendanceBySection[a.section_id] || []).push(a);
  });
  // Term-end bonus points (migration-36) keyed by term_id -> student_id, so
  // the same bonus-adjusted Term Grade admin shows here always matches what
  // the teacher's Class Record/Grade Summary/Dashboard show for that term.
  const bonusByTermStudent = {}; (bonusPoints || []).forEach((b) => {
    bonusByTermStudent[b.term_id] = bonusByTermStudent[b.term_id] || {};
    bonusByTermStudent[b.term_id][b.student_id] = Number(b.points);
  });

  // Students removed from a specific term (migration-63): term_id -> Set(student_id). A removed student is left
  // out of THAT term's averages/attendance/exam counts only — other terms are computed exactly as before.
  const removedByTerm = {}; ((termRemovalsResult && termRemovalsResult.data) || []).forEach((r) => {
    (removedByTerm[r.term_id] = removedByTerm[r.term_id] || new Set()).add(r.student_id);
  });
  const isRemovedInTerm = (term, studentId) => !!(term && removedByTerm[term.id] && removedByTerm[term.id].has(studentId));

  astate.teachers = teachers || [];
  astate.sections = sections || [];
  astate.students = students || [];
  astate.sectionById = {}; (sections || []).forEach((s) => (astate.sectionById[s.id] = s));

  astate.classRows = (sections || []).map((section) => {
    const weights = getSectionWeights(section);
    const sectionStudents = studentsBySection[section.id] || [];
    const sectionTerms = termsBySection[section.id] || [];
    // Keyed by term_number (1/2/3) -> term row, so per-term lookups below are
    // by the human "Term 1/2/3" identity rather than array position (a
    // section's terms may not come back from Supabase in term_number order).
    const termByNumber = {};
    sectionTerms.forEach((t) => { if (t.term_number) termByNumber[t.term_number] = t; });

    // Each student's grade in one specific term (or null if that term has no
    // assessments/scores yet for this student). Includes that term's bonus
    // points, if any, same as computeTermGrade everywhere else in the app.
    function studentTermGrade(student, term) {
      if (!term || isRemovedInTerm(term, student.id)) return null;
      const termAssessments = assessmentsByTerm[term.id] || [];
      const byStudent = {};
      termAssessments.forEach((a) => {
        const sByAssessment = scoresByAssessment[a.id];
        if (sByAssessment && sByAssessment[student.id] !== undefined) byStudent[a.id] = sByAssessment[student.id];
      });
      const bonus = (bonusByTermStudent[term.id] || {})[student.id] || 0;
      return computeTermGrade(termAssessments, byStudent, weights, bonus).termGrade;
    }

    // "Final" (cumulative) general average — mean of each student's Final
    // Grade, which is itself the average of their per-term grades.
    const studentFinals = [];
    // Per-term general averages (Term 1 / 2 / 3 only) — mean of each
    // student's grade in JUST that term, matching what a teacher sees when
    // viewing that specific term on their own dashboard.
    const perTermGrades = { 1: [], 2: [], 3: [] };
    sectionStudents.forEach((student) => {
      const termGrades = [1, 2, 3].map((n) => {
        const g = studentTermGrade(student, termByNumber[n]);
        if (g !== null) perTermGrades[n].push(g);
        return g;
      });
      const final = computeFinalGrade(termGrades);
      if (final !== null) studentFinals.push(final);
    });
    const generalAverage = studentFinals.length ? Math.round(studentFinals.reduce((s, g) => s + g, 0) / studentFinals.length) : null;
    const termAverages = {};
    [1, 2, 3].forEach((n) => {
      termAverages[n] = perTermGrades[n].length ? Math.round(perTermGrades[n].reduce((s, g) => s + g, 0) / perTermGrades[n].length) : null;
    });

    // Attendance % — also split by term (a term's date range), plus the
    // all-time figure used by the "Final" view.
    // Attendance % — also split by term. AUDIT FIX (2026-09): previously this
    // required term.start_date to be manually set or the term's attendance
    // was shown as blank, and even when start_date WAS set but end_date
    // wasn't, the upper bound silently defaulted to "9999-12-31" (unbounded).
    // termDateRange() (supabase-client.js) is the same helper Teacher's
    // "Attendance Summary (this term)" now uses, so both screens agree on
    // what "this term" means even before a teacher fills in exact dates.
    const records = attendanceBySection[section.id] || [];
    function attendancePctFor(list) {
      const present = list.filter((r) => r.status === "present").length;
      const late = list.filter((r) => r.status === "late").length;
      const total = list.length;
      return { pct: total > 0 ? Math.round(((present + late) / total) * 1000) / 10 : null, total };
    }
    // A record belongs to whichever term's date range contains it; if that student was removed from that
    // term the record is left out of the % (it stays in the database).
    const termRanges = sectionTerms.map((t) => ({ term: t, range: termDateRange(t, section.school_year) }));
    const recordCounts = (r) => !termRanges.some(({ term, range }) => r.attendance_date >= range.start && r.attendance_date <= range.end && isRemovedInTerm(term, r.student_id));
    const overallAtt = attendancePctFor(records.filter(recordCounts));
    const termAttendance = {};
    [1, 2, 3].forEach((n) => {
      const term = termByNumber[n];
      if (!term) { termAttendance[n] = { pct: null, total: 0 }; return; }
      const range = termDateRange(term, section.school_year);
      const list = records.filter((r) => r.attendance_date >= range.start && r.attendance_date <= range.end && !isRemovedInTerm(term, r.student_id));
      termAttendance[n] = attendancePctFor(list);
    });

    // Examinations for this class — the Class Record's "EX" component
    // assessments (Summative Test 1, Summative Test 2, Term Examination —
    // see grading.js), as opposed to the separate 📝 Exams feature. Lists
    // every EX item across all terms, each with the class's average score
    // on that specific item, plus the class's overall Exam (EX) average —
    // the same percentage that feeds 30% (or preset-specific %) of the
    // General Average shown in the main row, isolated on its own so admin
    // can monitor exam performance/GSA specifically.
    const examItems = [];
    sectionTerms.forEach((term) => {
      const termAssessments = assessmentsByTerm[term.id] || [];
      termAssessments.filter((a) => a.component === "EX").forEach((a) => {
        const sByAssessment = scoresByAssessment[a.id] || {};
        const enrolledHere = sectionStudents.filter((s) => !isRemovedInTerm(term, s.id));
        const studentScores = enrolledHere
          .map((s) => scoreForCalc(sByAssessment[s.id]))
          .filter((v) => v !== null);
        const classAveragePct = studentScores.length && a.highest_possible_score > 0
          ? Math.round((studentScores.reduce((s, v) => s + v, 0) / studentScores.length / a.highest_possible_score) * 1000) / 10
          : null;
        examItems.push({
          id: a.id,
          title: a.title,
          subtype: a.ex_subtype, // 'ST1' | 'ST2' | 'TE'
          termNumber: term.term_number,
          highestPossibleScore: a.highest_possible_score,
          dateGiven: a.date_given,
          studentsScored: studentScores.length,
          enrolled: enrolledHere.length,
          classAveragePct,
        });
      });
    });
    examItems.sort((a, b) => (a.termNumber || 0) - (b.termNumber || 0) || (a.dateGiven || "").localeCompare(b.dateGiven || "") || a.title.localeCompare(b.title));

    // Class-wide Exam (EX) average — same shape as generalAverage/termAverages
    // above (Final = mean of each student's own average EX% across the terms
    // they have one in; Term N = mean of the class's EX% in just that term),
    // but using computeTermGrade's `.exPS` (the EX component's percentage
    // score, 0–100, BEFORE the section's EX weight and BEFORE transmutation)
    // instead of the fully weighted, transmuted termGrade.
    function studentExamPS(student, term) {
      if (!term || isRemovedInTerm(term, student.id)) return null;
      const termAssessments = assessmentsByTerm[term.id] || [];
      const byStudent = {};
      termAssessments.forEach((a) => {
        const sByAssessment = scoresByAssessment[a.id];
        if (sByAssessment && sByAssessment[student.id] !== undefined) byStudent[a.id] = sByAssessment[student.id];
      });
      return computeTermGrade(termAssessments, byStudent, weights, 0).exPS;
    }
    const studentExamFinals = [];
    const perTermExamPS = { 1: [], 2: [], 3: [] };
    sectionStudents.forEach((student) => {
      const psByTerm = [1, 2, 3].map((n) => {
        const ps = studentExamPS(student, termByNumber[n]);
        if (ps !== null) perTermExamPS[n].push(ps);
        return ps;
      });
      const validPS = psByTerm.filter((p) => p !== null);
      if (validPS.length) studentExamFinals.push(validPS.reduce((s, p) => s + p, 0) / validPS.length);
    });
    const examGeneralAverage = studentExamFinals.length ? Math.round(studentExamFinals.reduce((s, p) => s + p, 0) / studentExamFinals.length) : null;
    const examTermAverages = {};
    [1, 2, 3].forEach((n) => {
      examTermAverages[n] = perTermExamPS[n].length ? Math.round(perTermExamPS[n].reduce((s, p) => s + p, 0) / perTermExamPS[n].length) : null;
    });

    return {
      section,
      teacherName: teacherById[section.teacher_id] ? teacherById[section.teacher_id].full_name : "Unknown",
      // Enrolled in the section's active term (students removed from it are not counted); all students if no term is active.
      studentCount: (() => { const at = sectionTerms.find((t) => t.is_active); return at ? sectionStudents.filter((s) => !isRemovedInTerm(at, s.id)).length : sectionStudents.length; })(),
      generalAverage,
      descriptor: gradeDescriptor(generalAverage),
      attendancePct: overallAtt.pct,
      attendanceRecords: overallAtt.total,
      termAverages,      // { 1: number|null, 2: ..., 3: ... }
      termAttendance,    // { 1: {pct, total}, 2: ..., 3: ... }
      hasTerm: { 1: !!termByNumber[1], 2: !!termByNumber[2], 3: !!termByNumber[3] },
      exams: examItems,   // [{ title, subtype, termNumber, highestPossibleScore, dateGiven, studentsScored, classAveragePct }]
      examGeneralAverage, // EX-component-only average (Final), same units as generalAverage
      examTermAverages,   // { 1: number|null, 2: ..., 3: ... }
    };
  });
}

function renderStats() {
  const totalTeachers = astate.teachers.length;
  const totalClasses = astate.sections.length;
  const totalEnrollments = astate.classRows.reduce((s, r) => s + r.studentCount, 0);
  const el = document.getElementById("statsRow");
  el.innerHTML = `
    <div class="card" style="text-align:center;">
      <div class="muted">Teachers Using MathConnect</div>
      <div style="font-size:2.4rem;font-weight:700;font-family:'Poppins';color:var(--forest-dark);">${totalTeachers}</div>
    </div>
    <div class="card" style="text-align:center;">
      <div class="muted">Classes / Sections</div>
      <div style="font-size:2.4rem;font-weight:700;font-family:'Poppins';color:var(--forest-dark);">${totalClasses}</div>
    </div>
    <div class="card" style="text-align:center;">
      <div class="muted">Total Student Enrollments</div>
      <div style="font-size:2.4rem;font-weight:700;font-family:'Poppins';color:var(--forest-dark);">${totalEnrollments}</div>
    </div>`;

  const lineEl = document.getElementById("overviewCurrentTermLine");
  if (lineEl) {
    lineEl.innerHTML = astate.schoolSettings
      ? `Current school term: <strong>Term ${astate.schoolSettings.current_term_number}</strong> — <a href="javascript:void(0)" onclick="switchAdminTab('term')">change it</a>`
      : `<a href="javascript:void(0)" onclick="switchAdminTab('term')">Set up the School Term control</a> to switch every class's current term at once.`;
  }
}

// ============================================================================
// 🗓️ SCHOOL TERM — one switch that sets the CURRENT term (Term 1/2/3) for
// EVERY class at once, including classes no teacher has opened yet. Calls
// the admin_set_current_term() RPC (migration-48), which is the only thing
// that ever flips a term's `is_active` flag after a section's Term rows are
// first created — see that migration's header comment for why this was
// needed (nothing previously ever moved is_active off Term 1).
// ============================================================================
function renderTermControl() {
  const wrap = document.getElementById("termControlWrap");
  if (!wrap) return;

  if (!astate.schoolSettings) {
    wrap.innerHTML = `<div class="empty">This school hasn't run <strong>migration-48-global-term-control.sql</strong> yet — run it in the Supabase SQL Editor, then reload this page, to turn on the School Term control.</div>`;
    return;
  }

  const current = astate.schoolSettings.current_term_number;
  const TERM_NAMES = { 1: "Term 1", 2: "Term 2", 3: "Term 3" };
  wrap.innerHTML = `
    <div class="termline" style="max-width:420px;margin:6px 0 0;">
      ${[1, 2, 3].map((n, i) => `
        ${i > 0 ? `<div class="seg ${n <= current ? "done" : ""}"></div>` : ""}
        <div class="node ${n === current ? "active" : n < current ? "done" : ""}" style="cursor:pointer;" onclick="setCurrentTerm(${n})" title="Set ${TERM_NAMES[n]} as the current term for every class">${n}</div>
      `).join("")}
    </div>
    <div class="term-labels" style="max-width:420px;margin-top:6px;">
      ${[1, 2, 3].map((n) => `<span style="cursor:pointer;" onclick="setCurrentTerm(${n})">${TERM_NAMES[n]}</span>`).join("")}
    </div>
    <p class="muted" style="margin:18px 0 0;">
      Now active school-wide: <strong style="color:var(--forest-dark);">${TERM_NAMES[current]}</strong>
      ${astate.schoolSettings.updated_at ? ` · last changed ${fmtDateTime(astate.schoolSettings.updated_at)}` : ""}
    </p>
    <p class="muted" style="margin:6px 0 0;">Click any circle above to switch. This updates every section immediately — Class Record, Attendance, and dashboards for every teacher and student will show the new term as current the next time they load.</p>`;
}

async function setCurrentTerm(termNumber) {
  if (astate.schoolSettings && astate.schoolSettings.current_term_number === termNumber) return;
  if (!confirm(`Set Term ${termNumber} as the CURRENT term for every class in the school? Teachers and students will see Term ${termNumber} as active the next time they load their dashboards. Past terms' data is kept — this doesn't delete or lock anything.`)) return;

  const { data, error } = await supabase.rpc("admin_set_current_term", { target_term_number: termNumber });
  if (error) { toast("Couldn't change the term — " + error.message); return; }
  if (data && data.error) { toast("Couldn't change the term — " + data.error); return; }

  toast(`Term ${termNumber} is now current for every class.`);
  logAdminAction("term_change", "school_settings", `School term`, `→ Term ${termNumber}`);
  await loadAllData();
  renderStats();
  renderTermControl();
  renderClassTable();
}

// Resolves the average/attendance/descriptor to display for a class row,
// given the term filter ("final" | "1" | "2" | "3"). "final" = the
// cumulative Final Grade average (mean of all terms a student has grades
// in) — same figure as before. "1"/"2"/"3" = that term only, matching what
// a teacher sees on their own dashboard for that specific term, so the two
// screens can be compared apples-to-apples instead of "final vs. current
// term" (see DEPLOY_NOTES / the mismatch this toggle was added to fix).
function classRowForTerm(r, termFilter) {
  if (termFilter === "final") {
    return { average: r.generalAverage, descriptor: r.descriptor, attendancePct: r.attendancePct, hasData: r.generalAverage !== null, termExists: true };
  }
  const n = Number(termFilter);
  const average = r.termAverages[n];
  return {
    average,
    descriptor: gradeDescriptor(average),
    attendancePct: r.termAttendance[n].pct,
    hasData: average !== null,
    termExists: r.hasTerm[n],
  };
}

function renderClassTable() {
  const sortBy = document.getElementById("sortSelect").value;
  const termFilter = document.getElementById("termFilterSelect")?.value || "final";

  const hint = document.getElementById("termFilterHint");
  if (hint) {
    hint.textContent = termFilter === "final"
      ? "Final = each student's Final Grade (average of every term they have grades in), then averaged across the class — the year-to-date figure."
      : `Term ${termFilter} only = each student's grade for Term ${termFilter} alone, averaged across the class — matches what the teacher sees on their dashboard when Term ${termFilter} is selected.`;
  }

  let rows = astate.classRows.map((r) => ({ r, view: classRowForTerm(r, termFilter) }));
  if (sortBy === "teacher") rows.sort((a, b) => a.r.teacherName.localeCompare(b.r.teacherName));
  else if (sortBy === "average_desc") rows.sort((a, b) => (b.view.average ?? -1) - (a.view.average ?? -1));
  else if (sortBy === "average_asc") rows.sort((a, b) => (a.view.average ?? 999) - (b.view.average ?? 999));
  else if (sortBy === "attendance_desc") rows.sort((a, b) => (b.view.attendancePct ?? -1) - (a.view.attendancePct ?? -1));
  else if (sortBy === "attendance_asc") rows.sort((a, b) => (a.view.attendancePct ?? 999) - (b.view.attendancePct ?? 999));

  const wrap = document.getElementById("classTableWrap");
  if (rows.length === 0) { wrap.innerHTML = `<div class="empty">No classes have been created yet.</div>`; return; }
  const avgHeader = termFilter === "final" ? "General Average (Final)" : `Term ${termFilter} Average`;
  wrap.innerHTML = `
    <table>
      <thead><tr><th>Teacher</th><th>Section</th><th>Subject</th><th>Grade Level</th><th>Students</th><th>${avgHeader}</th><th>Proficiency Level</th><th>Attendance %</th><th>Examinations</th></tr></thead>
      <tbody>
        ${rows.map(({ r, view }) => `
          <tr>
            <td>${escapeHtml(r.teacherName)}</td>
            <td>${escapeHtml(r.section.section_name)}</td>
            <td>${escapeHtml(r.section.subject || "—")}</td>
            <td>${escapeHtml(r.section.grade_level)}</td>
            <td class="num">${r.studentCount}</td>
            <td class="num" style="font-weight:700;">${view.average !== null ? view.average : "—"}</td>
            <td><span style="color:${view.descriptor.color};font-weight:600;">${!view.termExists ? "Term not set up" : view.average !== null ? view.descriptor.label : "No grades yet"}</span></td>
            <td class="num">${view.attendancePct !== null ? view.attendancePct + "%" : "—"}</td>
            <td><a href="javascript:void(0)" onclick="toggleClassExams('${r.section.id}')" style="font-weight:600;">${r.exams.length} exam item${r.exams.length === 1 ? "" : "s"} ▾</a></td>
          </tr>
          <tr id="examsRow-${r.section.id}" style="display:none;"><td colspan="9">${renderClassExamsPanel(r)}</td></tr>`).join("")}
      </tbody>
    </table>
    <p class="muted" style="margin-top:12px;">General Average = mean of each enrolled student's Final Grade (average of their term grades) in that class. Proficiency Level follows DepEd's standard descriptor bands (90–100 Outstanding · 85–89 Very Satisfactory · 80–84 Satisfactory · 75–79 Fairly Satisfactory · below 75 Did Not Meet Expectations). Attendance % = (Present + Late) ÷ total recorded attendance entries for that class. Examinations = every EX-component item (Summative Test 1/2, Term Examination) recorded in that class's Class Record; click to expand each item's class average plus the class's overall Exam-only average.</p>`;
}

// Per-class list of Examinations (the Class Record's EX component: Summative
// Test 1/2, Term Examination), shown in the collapsible "Examinations" row
// of the class table above. Data is precomputed in loadAllData() — this
// just formats it, no extra fetch.
function renderClassExamsPanel(r) {
  if (!r.exams.length) return `<div class="muted" style="padding:8px 2px;">No examinations recorded for this class yet.</div>`;
  const subtypeLabel = { ST1: "Summative Test 1", ST2: "Summative Test 2", TE: "Term Examination" };
  return `
    <div style="padding:8px 2px;">
      <table>
        <thead><tr><th>Term</th><th>Exam</th><th>Type</th><th>Date</th><th>Highest Score</th><th>Students Scored</th><th>Class Average</th></tr></thead>
        <tbody>
          ${r.exams.map((e) => `
          <tr>
            <td>${e.termNumber ? "Term " + e.termNumber : "—"}</td>
            <td>${escapeHtml(e.title)}</td>
            <td>${escapeHtml(subtypeLabel[e.subtype] || e.subtype || "—")}</td>
            <td>${e.dateGiven ? fmtDate(e.dateGiven) : "—"}</td>
            <td class="num">${e.highestPossibleScore}</td>
            <td class="num">${e.studentsScored} / ${e.enrolled !== undefined ? e.enrolled : r.studentCount}</td>
            <td class="num" style="font-weight:700;">${e.classAveragePct !== null ? e.classAveragePct + "%" : "—"}</td>
          </tr>`).join("")}
        </tbody>
      </table>
      <p class="muted" style="margin-top:10px;">
        Exam (EX component) average — Final: <strong>${r.examGeneralAverage !== null ? r.examGeneralAverage : "—"}</strong>
        ${[1, 2, 3].map((n) => ` · Term ${n}: <strong>${r.examTermAverages[n] !== null ? r.examTermAverages[n] : "—"}</strong>`).join("")}.
        This is each student's Examinations (Summative Tests + Term Exam) percentage score only, on its own 0–100 scale — not the fully weighted General Average shown in the main row above, which also folds in Written Work and Performance Tasks.
      </p>
    </div>`;
}

function toggleClassExams(sectionId) {
  const row = document.getElementById(`examsRow-${sectionId}`);
  if (!row) return;
  row.style.display = row.style.display === "none" ? "" : "none";
}

// ============================================================================
// MATH DRILL STATIONS — lock/unlock any station, school-wide
// ============================================================================
function renderStationLocks() {
  const wrap = document.getElementById("stationLocksWrap");
  const byKey = {};
  astate.stationLocks.forEach((r) => (byKey[r.station_key] = r));
  wrap.innerHTML = `
    <table>
      <thead><tr><th>Station</th><th>Status</th><th>Note shown to students</th></tr></thead>
      <tbody>
        ${ADMIN_DRILL_TOPICS.map((t) => {
          const row = byKey[t.key] || { station_key: t.key, locked: false, note: "" };
          return `
          <tr>
            <td>${t.icon} ${escapeHtml(t.name)}</td>
            <td>
              <select style="width:auto;color:${row.locked ? "var(--clay)" : "var(--forest-dark)"};font-weight:600;" onchange="updateStationLock('${t.key}','locked',this.value === 'true')">
                <option value="false" ${!row.locked ? "selected" : ""}>🔓 Unlocked</option>
                <option value="true" ${row.locked ? "selected" : ""}>🔒 Locked</option>
              </select>
            </td>
            <td><input type="text" value="${escapeHtml(row.note || "")}" placeholder="e.g. Coming for Term 2!" style="width:100%;" onchange="updateStationLock('${t.key}','note',this.value)" /></td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>`;
}

async function updateStationLock(stationKey, field, value) {
  const payload = { station_key: stationKey, [field]: value };
  if (field === "locked") { payload.locked_by = astate.admin.id; payload.locked_at = new Date().toISOString(); }
  const { error } = await supabase.from("drill_station_locks").upsert(payload, { onConflict: "station_key" });
  if (error) { toast("Couldn't save — " + error.message); return; }
  toast("Saved.");
  const existing = astate.stationLocks.find((r) => r.station_key === stationKey);
  if (existing) Object.assign(existing, payload);
  else astate.stationLocks.push(payload);
  if (field === "locked") {
    const label = ADMIN_DRILL_TOPICS.find((t) => t.key === stationKey)?.name || stationKey;
    logAdminAction("lock_change", "drill_station_locks", label, value ? "locked" : "unlocked");
  }
}

// ============================================================================
// 🧠 Intelligent Practice Domains — same lock/unlock pattern as Drill
// stations above, against the practice_domains table (which doubles as
// the Trial/Championship registry — see migration-24/25).
// ============================================================================
function renderPracticeDomainLocks() {
  const wrap = document.getElementById("practiceDomainLocksWrap");
  if (!wrap) return;
  const byKey = {};
  astate.practiceDomains.forEach((r) => (byKey[r.domain_key] = r));
  wrap.innerHTML = `
    <table>
      <thead><tr><th>Domain</th><th>Status</th><th>Note shown to students</th></tr></thead>
      <tbody>
        ${ADMIN_PRACTICE_DOMAINS.map((d) => {
          const row = byKey[d.key] || { domain_key: d.key, locked: false, note: "" };
          return `
          <tr>
            <td>${d.icon} ${escapeHtml(d.name)}</td>
            <td>
              <select style="width:auto;color:${row.locked ? "var(--clay)" : "var(--forest-dark)"};font-weight:600;" onchange="updatePracticeDomainLock('${d.key}','locked',this.value === 'true')">
                <option value="false" ${!row.locked ? "selected" : ""}>🔓 Unlocked</option>
                <option value="true" ${row.locked ? "selected" : ""}>🔒 Locked</option>
              </select>
            </td>
            <td><input type="text" value="${escapeHtml(row.note || "")}" placeholder="e.g. Coming for Term 2!" style="width:100%;" onchange="updatePracticeDomainLock('${d.key}','note',this.value)" /></td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>`;
}

async function updatePracticeDomainLock(domainKey, field, value) {
  // NOTE: practice_domains.label is NOT NULL with no default. Postgres checks
  // NOT NULL constraints on the row-to-insert BEFORE resolving ON CONFLICT,
  // even when the actual outcome is an UPDATE — so a payload missing `label`
  // 400s here every time, even for rows that already exist. Always carry the
  // known label (and other required fields) along so the upsert satisfies
  // the constraint whether it inserts or updates.
  const existingRow = astate.practiceDomains.find((r) => r.domain_key === domainKey);
  const staticDef = ADMIN_PRACTICE_DOMAINS.find((d) => d.key === domainKey);
  const label = existingRow?.label || staticDef?.name || domainKey;
  const payload = {
    domain_key: domainKey,
    label,
    term_added: existingRow?.term_added ?? 2,
    active: existingRow?.active ?? true,
    [field]: value,
  };
  if (field === "locked") { payload.locked_by = astate.admin.id; payload.locked_at = new Date().toISOString(); }
  const { error } = await supabase.from("practice_domains").upsert(payload, { onConflict: "domain_key" });
  if (error) { toast("Couldn't save — " + error.message); return; }
  toast("Saved.");
  const existing = astate.practiceDomains.find((r) => r.domain_key === domainKey);
  if (existing) Object.assign(existing, payload);
  else astate.practiceDomains.push(payload);
  if (field === "locked") {
    const label = ADMIN_PRACTICE_DOMAINS.find((d) => d.key === domainKey)?.name || domainKey;
    logAdminAction("lock_change", "practice_domains", label, value ? "locked" : "unlocked");
  }
}

// ============================================================================
// 📋 AUDIT LOG — two tabs (Logins / Admin Actions), each with a breakdown
// pie chart + activity trend line, filtered by the shared range selector.
// Pure inline SVG, no charting library needed.
// ============================================================================
function auditRangeStart(range) {
  const now = new Date();
  if (range === "today") { const d = new Date(now); d.setHours(0, 0, 0, 0); return d; }
  if (range === "all") return null;
  const days = Number(range);
  const d = new Date(now); d.setDate(d.getDate() - (days - 1)); d.setHours(0, 0, 0, 0);
  return d;
}

// Buckets a list of {timestamp} rows into a trend series — hourly for
// "today", daily (with zero-filled gaps) otherwise. Shared by both tabs.
function buildTrendSeries(rows, timestampField, range, start) {
  if (range === "today") {
    const byHour = {};
    rows.forEach((r) => { const h = new Date(r[timestampField]).getHours(); byHour[h] = (byHour[h] || 0) + 1; });
    const currentHour = new Date().getHours();
    const series = [];
    for (let h = 0; h <= currentHour; h++) {
      series.push({ label: new Date(2000, 0, 1, h).toLocaleTimeString(undefined, { hour: "numeric" }), count: byHour[h] || 0 });
    }
    return series;
  }
  const byDay = {};
  rows.forEach((r) => { const day = String(r[timestampField]).slice(0, 10); byDay[day] = (byDay[day] || 0) + 1; });
  const dayKeys = Object.keys(byDay).sort();
  if (dayKeys.length === 0) return [];
  const first = start ? new Date(start) : new Date(dayKeys[0] + "T00:00:00");
  const last = new Date();
  const series = [];
  for (let d = new Date(first); d <= last; d.setDate(d.getDate() + 1)) {
    const key = d.toISOString().slice(0, 10);
    series.push({ label: fmtShortDate(key), count: byDay[key] || 0 });
  }
  return series;
}

function setAuditTab(tab) {
  astate.auditTab = tab;
  document.getElementById("auditTabBtn-logins")?.classList.toggle("active", tab === "logins");
  document.getElementById("auditTabBtn-actions")?.classList.toggle("active", tab === "actions");
  document.getElementById("auditDescription").textContent = tab === "logins"
    ? "Every successful sign-in — admin, teacher, or student — is recorded automatically. Logins from before this feature was installed aren't included."
    : "Every account status change, delete, edited entry, lock/unlock, and champion finalization made from this panel, with who did it and when. Actions from before this feature was installed aren't included.";
  document.getElementById("auditRecentHeading").textContent = tab === "logins" ? "Recent Sign-Ins" : "Recent Admin Actions";
  renderAuditLog();
}

function renderAuditLog() {
  if (astate.auditTab === "actions") renderActionsAuditTab();
  else renderLoginsAuditTab();
}

function renderLoginsAuditTab() {
  const chartsWrap = document.getElementById("auditChartsWrap");
  const recentWrap = document.getElementById("auditRecentWrap");
  if (!chartsWrap || !recentWrap) return;

  const range = document.getElementById("auditRangeSelect")?.value || "7";
  const start = auditRangeStart(range);
  const rows = astate.loginAudit.filter((r) => !start || new Date(r.logged_in_at) >= start);

  if (astate.loginAudit.length === 0) {
    chartsWrap.innerHTML = `<div class="empty" style="grid-column:1/-1;">No logins recorded yet. This starts filling in as people sign in after the audit log migration is run.</div>`;
    recentWrap.innerHTML = "";
    return;
  }
  if (rows.length === 0) {
    chartsWrap.innerHTML = `<div class="empty" style="grid-column:1/-1;">No sign-ins in this range.</div>`;
    recentWrap.innerHTML = "";
    return;
  }

  const counts = { admin: 0, teacher: 0, student: 0 };
  rows.forEach((r) => { if (counts[r.user_role] !== undefined) counts[r.user_role]++; });
  const pieSlices = Object.keys(counts)
    .filter((role) => counts[role] > 0)
    .map((role) => ({ label: AUDIT_ROLE_LABELS[role], value: counts[role], color: AUDIT_ROLE_COLORS[role] }));

  const series = buildTrendSeries(rows, "logged_in_at", range, start);

  chartsWrap.innerHTML = `
    <div>
      <div class="muted" style="margin-bottom:8px;font-weight:600;">Sign-ins by role</div>
      ${buildPieChartSVG(pieSlices)}
    </div>
    <div>
      <div class="muted" style="margin-bottom:8px;font-weight:600;">Sign-ins per ${range === "today" ? "hour" : "day"}</div>
      ${buildLineChartSVG(series)}
    </div>`;

  const recent = rows.slice(0, 20);
  recentWrap.innerHTML = `
    <table>
      <thead><tr><th>Name</th><th>Role</th><th>Signed in</th></tr></thead>
      <tbody>
        ${recent.map((r) => `
          <tr>
            <td>${escapeHtml(r.full_name)}</td>
            <td><span style="color:${AUDIT_ROLE_COLORS[r.user_role] || "var(--ink-soft)"};font-weight:600;">${escapeHtml(AUDIT_ROLE_LABELS[r.user_role] || r.user_role)}</span></td>
            <td>${fmtDateTime(r.logged_in_at)}</td>
          </tr>`).join("")}
      </tbody>
    </table>`;
}

function renderActionsAuditTab() {
  const chartsWrap = document.getElementById("auditChartsWrap");
  const recentWrap = document.getElementById("auditRecentWrap");
  if (!chartsWrap || !recentWrap) return;

  const range = document.getElementById("auditRangeSelect")?.value || "7";
  const start = auditRangeStart(range);
  const rows = astate.adminActions.filter((r) => !start || new Date(r.created_at) >= start);

  if (astate.adminActions.length === 0) {
    chartsWrap.innerHTML = `<div class="empty" style="grid-column:1/-1;">No admin actions recorded yet. This starts filling in as status changes, deletes, edits, lock toggles, and finalizations happen after the admin action log migration is run.</div>`;
    recentWrap.innerHTML = "";
    return;
  }
  if (rows.length === 0) {
    chartsWrap.innerHTML = `<div class="empty" style="grid-column:1/-1;">No admin actions in this range.</div>`;
    recentWrap.innerHTML = "";
    return;
  }

  const counts = {};
  rows.forEach((r) => { counts[r.action_type] = (counts[r.action_type] || 0) + 1; });
  const pieSlices = Object.keys(counts)
    .map((type) => ({ label: ADMIN_ACTION_LABELS[type] || type, value: counts[type], color: ADMIN_ACTION_COLORS[type] || "var(--sage)" }));

  const series = buildTrendSeries(rows, "created_at", range, start);

  chartsWrap.innerHTML = `
    <div>
      <div class="muted" style="margin-bottom:8px;font-weight:600;">Actions by type</div>
      ${buildPieChartSVG(pieSlices)}
    </div>
    <div>
      <div class="muted" style="margin-bottom:8px;font-weight:600;">Actions per ${range === "today" ? "hour" : "day"}</div>
      ${buildLineChartSVG(series)}
    </div>`;

  const recent = rows.slice(0, 20);
  recentWrap.innerHTML = `
    <table>
      <thead><tr><th>Admin</th><th>Action</th><th>Target</th><th>When</th></tr></thead>
      <tbody>
        ${recent.map((r) => `
          <tr>
            <td>${escapeHtml(r.admin_name)}</td>
            <td><span style="color:${ADMIN_ACTION_COLORS[r.action_type] || "var(--ink-soft)"};font-weight:600;">${escapeHtml(ADMIN_ACTION_LABELS[r.action_type] || r.action_type)}</span></td>
            <td>${escapeHtml(r.target_name || "—")}${r.details ? ` <span class="muted">(${escapeHtml(r.details)})</span>` : ""}</td>
            <td>${fmtDateTime(r.created_at)}</td>
          </tr>`).join("")}
      </tbody>
    </table>`;
}

// fmtDate (supabase-client.js) expects a plain "YYYY-MM-DD" date, not a full
// timestamp — this one is for the login audit log's actual timestamptz values.
function fmtDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-PH", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
}

function fmtShortDate(isoDay) {
  const d = new Date(isoDay + "T00:00:00");
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function buildPieChartSVG(slices) {
  const total = slices.reduce((s, x) => s + x.value, 0);
  if (total === 0) return `<div class="empty">No data.</div>`;
  const cx = 100, cy = 100, r = 90;
  let angle = -90;
  const paths = slices.map((slice) => {
    const sweep = (slice.value / total) * 360;
    const startRad = (angle * Math.PI) / 180;
    const endRad = ((angle + sweep) * Math.PI) / 180;
    const x1 = cx + r * Math.cos(startRad), y1 = cy + r * Math.sin(startRad);
    const x2 = cx + r * Math.cos(endRad), y2 = cy + r * Math.sin(endRad);
    const largeArc = sweep > 180 ? 1 : 0;
    angle += sweep;
    // A single 100%-share slice degenerates to a zero-length arc — draw a full circle instead.
    if (slices.length === 1) {
      return `<circle cx="${cx}" cy="${cy}" r="${r}" style="fill:${slice.color};" />`;
    }
    return `<path d="M${cx},${cy} L${x1.toFixed(2)},${y1.toFixed(2)} A${r},${r} 0 ${largeArc} 1 ${x2.toFixed(2)},${y2.toFixed(2)} Z" style="fill:${slice.color};stroke:var(--white);stroke-width:2;" />`;
  }).join("");

  const legend = slices.map((slice) => `
    <div style="display:flex;align-items:center;gap:8px;margin:4px 0;font-size:.85rem;">
      <span style="width:11px;height:11px;border-radius:3px;background:${slice.color};display:inline-block;flex-shrink:0;"></span>
      <span>${escapeHtml(slice.label)}</span>
      <span class="muted" style="margin-left:auto;">${slice.value} (${Math.round((slice.value / total) * 100)}%)</span>
    </div>`).join("");

  return `
    <div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;">
      <svg viewBox="0 0 200 200" style="width:180px;height:180px;flex-shrink:0;">${paths}</svg>
      <div style="flex:1;min-width:140px;">${legend}</div>
    </div>`;
}

function buildLineChartSVG(series) {
  if (!series.length) return `<div class="empty">No data.</div>`;
  const w = 560, h = 220, padL = 34, padR = 12, padT = 14, padB = 28;
  const innerW = w - padL - padR, innerH = h - padT - padB;
  const maxCount = Math.max(1, ...series.map((s) => s.count));
  const stepX = series.length > 1 ? innerW / (series.length - 1) : 0;
  const yFor = (v) => padT + innerH - (v / maxCount) * innerH;
  const xFor = (i) => padL + stepX * i;

  const points = series.map((s, i) => `${xFor(i).toFixed(2)},${yFor(s.count).toFixed(2)}`).join(" ");
  const areaPoints = `${padL},${(padT + innerH).toFixed(2)} ${points} ${xFor(series.length - 1).toFixed(2)},${(padT + innerH).toFixed(2)}`;

  // Show at most ~6 x-axis labels so short and long ranges both stay readable.
  const labelEvery = Math.max(1, Math.ceil(series.length / 6));
  const xLabels = series.map((s, i) => (i % labelEvery === 0 || i === series.length - 1)
    ? `<text x="${xFor(i).toFixed(2)}" y="${h - 6}" font-size="10" fill="var(--ink-soft)" text-anchor="middle">${escapeHtml(s.label)}</text>` : "").join("");
  const dots = series.length <= 31 ? series.map((s, i) => `<circle cx="${xFor(i).toFixed(2)}" cy="${yFor(s.count).toFixed(2)}" r="3" style="fill:var(--forest);" />`).join("") : "";

  return `
    <svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;">
      <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${padT + innerH}" stroke="var(--paper-line)" />
      <line x1="${padL}" y1="${padT + innerH}" x2="${w - padR}" y2="${padT + innerH}" stroke="var(--paper-line)" />
      <text x="${padL - 6}" y="${padT + 4}" font-size="10" fill="var(--ink-soft)" text-anchor="end">${maxCount}</text>
      <text x="${padL - 6}" y="${padT + innerH}" font-size="10" fill="var(--ink-soft)" text-anchor="end">0</text>
      <polygon points="${areaPoints}" style="fill:var(--forest-light);opacity:0.6;" />
      <polyline points="${points}" style="fill:none;stroke:var(--forest);stroke-width:2.5;" />
      ${dots}
      ${xLabels}
    </svg>`;
}

// ============================================================================
// ACCOUNT MANAGEMENT — pause / delete / edit "joined" timestamp
// ============================================================================
function dtLocal(iso) {
  // yyyy-mm-dd for a <input type="date"> from a timestamptz/date string
  if (!iso) return "";
  return String(iso).slice(0, 10);
}

function statusBadgeColor(status) {
  return status === "frozen" ? "var(--clay)" : status === "readonly" ? "var(--gold-dark, #a67c00)" : "var(--forest-dark)";
}

function renderTeacherAccounts() {
  const wrap = document.getElementById("teacherAccountsWrap");
  if (!astate.teachers.length) { wrap.innerHTML = `<div class="empty">No teacher accounts yet.</div>`; return; }
  wrap.innerHTML = `
    <table>
      <thead><tr><th>Name</th><th>Email</th><th>School</th><th>Position</th><th>Joined</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${astate.teachers.map((t) => `
          <tr>
            <td><input type="text" value="${escapeHtml(t.full_name)}" style="min-width:150px;font-weight:600;" onchange="updateAccountField('teachers','${t.id}','full_name',this.value)" /></td>
            <td>${escapeHtml((astate.teacherEmailById && astate.teacherEmailById[t.id]) || "—")}</td>
            <td><input type="text" value="${escapeHtml(t.school || "")}" style="min-width:170px;" onchange="updateAccountField('teachers','${t.id}','school',this.value)" /></td>
            <td><input type="text" value="${escapeHtml(t.position || "")}" style="min-width:150px;" onchange="updateAccountField('teachers','${t.id}','position',this.value)" /></td>
            <td><input type="date" value="${dtLocal(t.created_at)}" style="width:150px;" onchange="updateAccountField('teachers','${t.id}','created_at',this.value)" /></td>
            <td>
              <select style="width:auto;color:${statusBadgeColor(t.account_status)};font-weight:600;" onchange="updateAccountField('teachers','${t.id}','account_status',this.value)">
                <option value="active" ${t.account_status === "active" ? "selected" : ""}>Active</option>
                <option value="readonly" ${t.account_status === "readonly" ? "selected" : ""}>Read-only</option>
                <option value="frozen" ${t.account_status === "frozen" ? "selected" : ""}>Frozen</option>
              </select>
            </td>
            <td style="white-space:nowrap;">
              <button class="btn-outline btn-sm" onclick="resetTeacherPassword('${t.id}','${escapeHtml(t.full_name).replace(/'/g, "\\'")}')">🔑 Reset Password</button>
              <button class="btn-outline btn-sm" style="color:var(--clay);border-color:var(--clay);" onclick="deleteAccount('teachers','${t.id}','${escapeHtml(t.full_name).replace(/'/g, "\\'")}')">Delete</button>
            </td>
          </tr>`).join("")}
      </tbody>
    </table>`;
}

// Sets a teacher's Supabase Auth password directly, via the SECURITY DEFINER
// RPC in migration-41 (no service_role key needed, no email round-trip —
// use this when a teacher has forgotten their password and needs back in
// right away; hand them the new password directly).
async function resetTeacherPassword(teacherId, teacherName) {
  const newPassword = prompt(`New password for ${teacherName} (at least 6 characters).\n\nThey will need this exact password to sign in next — share it with them directly.`);
  if (newPassword === null) return; // cancelled
  const trimmed = newPassword.trim();
  if (trimmed.length < 6) { alert("Password must be at least 6 characters."); return; }
  if (!confirm(`Reset ${teacherName}'s password now? This replaces their current password immediately.`)) return;

  const { data, error } = await supabase.rpc("admin_reset_teacher_password", { target_teacher_id: teacherId, new_password: trimmed });
  if (error) { toast("Couldn't reset password — " + error.message); return; }
  if (data && data.error) { toast("Couldn't reset password — " + data.error); return; }
  toast(`Password reset for ${teacherName}.`);
  logAdminAction("password_reset", "teachers", teacherName);
}

function renderStudentAccounts() {
  const wrap = document.getElementById("studentAccountsWrap");
  const q = (document.getElementById("studentSearchInput")?.value || "").trim().toLowerCase();
  let rows = astate.students || [];
  if (q) rows = rows.filter((s) => s.full_name.toLowerCase().includes(q));
  if (!rows.length) { wrap.innerHTML = `<div class="empty">No matching students.</div>`; return; }
  wrap.innerHTML = `
    <table>
      <thead><tr><th>Name</th><th>Section</th><th>Joined</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${rows.map((s) => {
          const section = astate.sectionById[s.section_id];
          return `
          <tr>
            <td><a href="javascript:void(0)" onclick="toggleStudentEntries('${s.id}')" style="font-weight:600;">${escapeHtml(s.full_name)} ▾</a></td>
            <td>${section ? escapeHtml(section.section_name) : "—"}</td>
            <td><input type="date" value="${dtLocal(s.created_at)}" style="width:150px;" onchange="updateAccountField('students','${s.id}','created_at',this.value)" /></td>
            <td>
              <select style="width:auto;color:${statusBadgeColor(s.account_status)};font-weight:600;" onchange="updateAccountField('students','${s.id}','account_status',this.value)">
                <option value="active" ${s.account_status === "active" ? "selected" : ""}>Active</option>
                <option value="readonly" ${s.account_status === "readonly" ? "selected" : ""}>Read-only</option>
                <option value="frozen" ${s.account_status === "frozen" ? "selected" : ""}>Frozen</option>
              </select>
            </td>
            <td><button class="btn-outline btn-sm" style="color:var(--clay);border-color:var(--clay);" onclick="deleteAccount('students','${s.id}','${escapeHtml(s.full_name).replace(/'/g, "\\'")}')">Delete</button></td>
          </tr>
          <tr id="entriesRow-${s.id}" style="display:none;"><td colspan="5"><div id="entriesBox-${s.id}" class="muted">Loading…</div></td></tr>`;
        }).join("")}
      </tbody>
    </table>`;
}

async function updateAccountField(table, id, field, value) {
  if (field === "full_name" && !value.trim()) { toast("Name can't be blank."); renderTeacherAccounts(); renderStudentAccounts(); return; }
  const payload = { [field]: value };
  if (field === "account_status") payload.status_updated_at = new Date().toISOString();
  const { error } = await supabase.from(table).update(payload).eq("id", id);
  if (error) { toast("Couldn't save — " + error.message); return; }
  toast("Saved.");
  const list = table === "teachers" ? astate.teachers : astate.students;
  const row = list.find((r) => r.id === id);
  const oldValue = row ? row[field] : undefined;
  if (row) row[field] = value;
  if (field === "account_status") {
    logAdminAction("status_change", table, (row && row.full_name) || id, `${oldValue || "active"} → ${value}`);
  } else {
    logAdminAction("edit_account", table, (row && row.full_name) || id, `${field}: ${oldValue || "—"} → ${value}`);
  }
  // Renaming a teacher/student should be reflected anywhere else on the
  // panel that already shows their name (All Classes table, dropdowns, etc.)
  if (field === "full_name") { renderClassTable(); }
}

async function deleteAccount(table, id, name) {
  const sectionCount = table === "teachers" ? astate.sections.filter((s) => s.teacher_id === id).length : 0;
  const warning = table === "teachers"
    ? `Permanently delete ${name}'s teacher account? This also deletes ${sectionCount === 0 ? "any classes/sections" : sectionCount + " class" + (sectionCount === 1 ? "" : "es")} they own, along with those classes' students, terms, assessments, scores, and attendance. This cannot be undone.`
    : `Permanently delete ${name}'s account? This removes their login and cannot be undone.`;
  if (!confirm(warning)) return;
  const { data, error } = await supabase.from(table).delete().eq("id", id).select("id");
  if (error) { toast("Couldn't delete — " + error.message); return; }
  if (!data || data.length === 0) {
    // No error, but nothing came back deleted — the database silently
    // matched zero rows. This almost always means Row Level Security
    // blocked it (e.g. migration-19-admin-account-controls.sql, which adds
    // the "admin delete teachers"/"admin delete students" policies, hasn't
    // been run on this Supabase project yet) rather than a real success.
    toast("Delete didn't go through — the database rejected it (likely a missing admin permission/migration). The account was NOT removed.");
    return;
  }
  toast("Deleted.");
  if (table === "teachers") {
    astate.teachers = astate.teachers.filter((t) => t.id !== id);
    astate.sections = astate.sections.filter((s) => s.teacher_id !== id);
    astate.classRows = astate.classRows.filter((r) => r.section.teacher_id !== id);
  } else {
    astate.students = astate.students.filter((s) => s.id !== id);
  }
  logAdminAction("delete_account", table, name);
  renderTeacherAccounts();
  renderStudentAccounts();
  renderStats();
  renderClassTable();
}


// ---------- Per-student entry editor (attendance / scores / drill attempts) ----------
async function toggleStudentEntries(studentId) {
  const row = document.getElementById(`entriesRow-${studentId}`);
  if (!row) return;
  if (row.style.display !== "none") { row.style.display = "none"; return; }
  row.style.display = "";
  const box = document.getElementById(`entriesBox-${studentId}`);
  box.innerHTML = "Loading…";

  const [{ data: attendance }, { data: scores }, { data: drills }] = await Promise.all([
    supabase.from("attendance").select("*").eq("student_id", studentId).order("attendance_date", { ascending: false }).limit(15),
    supabase.from("scores").select("*, assessments(title)").eq("student_id", studentId).order("updated_at", { ascending: false }).limit(15),
    supabase.from("drill_attempts").select("*").eq("student_id", studentId).order("played_at", { ascending: false }).limit(15),
  ]);

  box.innerHTML = `
    <div class="grid grid-3" style="gap:14px;">
      <div>
        <strong>Attendance</strong> (most recent 15)
        ${(attendance || []).length === 0 ? `<div class="muted" style="font-size:.8rem;">No records.</div>` : (attendance || []).map((a) => `
          <div style="display:flex;gap:6px;align-items:center;margin:6px 0;font-size:.82rem;">
            <input type="date" value="${a.attendance_date}" style="width:130px;" onchange="updateEntryField('attendance','${a.id}','attendance_date',this.value,'${studentId}')" />
            <span class="muted">${escapeHtml(a.status)}</span>
            <button class="btn-outline btn-sm" onclick="deleteEntry('attendance','${a.id}','${studentId}')">✕</button>
          </div>`).join("")}
      </div>
      <div>
        <strong>Scores</strong> (most recent 15)
        ${(scores || []).length === 0 ? `<div class="muted" style="font-size:.8rem;">No records.</div>` : (scores || []).map((s) => `
          <div style="display:flex;gap:6px;align-items:center;margin:6px 0;font-size:.82rem;">
            <input type="datetime-local" value="${s.updated_at ? s.updated_at.slice(0, 16) : ""}" style="width:180px;" onchange="updateEntryField('scores','${s.id}','updated_at',this.value,'${studentId}')" />
            <span class="muted">${escapeHtml((s.assessments && s.assessments.title) || "—")}: ${s.raw_score ?? "—"}</span>
            <button class="btn-outline btn-sm" onclick="deleteEntry('scores','${s.id}','${studentId}')">✕</button>
          </div>`).join("")}
      </div>
      <div>
        <strong>Drill Attempts</strong> (most recent 15)
        ${(drills || []).length === 0 ? `<div class="muted" style="font-size:.8rem;">No records.</div>` : (drills || []).map((d) => `
          <div style="display:flex;gap:6px;align-items:center;margin:6px 0;font-size:.82rem;">
            <input type="datetime-local" value="${d.played_at ? d.played_at.slice(0, 16) : ""}" style="width:180px;" onchange="updateEntryField('drill_attempts','${d.id}','played_at',this.value,'${studentId}')" />
            <span class="muted">${escapeHtml(d.topic)} L${d.level}: ${d.correct_count}/${d.total_questions}</span>
            <button class="btn-outline btn-sm" onclick="deleteEntry('drill_attempts','${d.id}','${studentId}')">✕</button>
          </div>`).join("")}
      </div>
    </div>`;
}

async function updateEntryField(table, id, field, value, studentId) {
  const iso = field.includes("date") && !field.includes("_local") ? value : value; // date/datetime-local inputs are already acceptable ISO-ish strings for Postgres
  const { error } = await supabase.from(table).update({ [field]: iso }).eq("id", id);
  if (error) { toast("Couldn't save — " + error.message); return; }
  toast("Saved.");
  const studentName = astate.students.find((s) => s.id === studentId)?.full_name || studentId || "—";
  logAdminAction("edit_entry", table, studentName, `${field} → ${value}`);
  // AUDIT FIX (2026-09): the Class Overview table (averages / attendance %)
  // used to be computed once at page load and never refreshed after an
  // admin corrected an attendance/score entry here, so it could silently
  // show stale numbers until a manual page reload.
  await loadAllData();
  renderClassTable();
}

async function deleteEntry(table, id, studentId) {
  if (!confirm("Delete this entry? This cannot be undone.")) return;
  const { data, error } = await supabase.from(table).delete().eq("id", id).select("id");
  if (error) { toast("Couldn't delete — " + error.message); return; }
  if (!data || data.length === 0) {
    toast("Delete didn't go through — the database rejected it (likely a missing admin permission/migration). The entry was NOT removed.");
    return;
  }
  toast("Deleted.");
  const studentName = astate.students.find((s) => s.id === studentId)?.full_name || studentId || "—";
  logAdminAction("delete_entry", table, studentName);
  toggleStudentEntries(studentId); // collapse
  toggleStudentEntries(studentId); // reopen refreshed
  // AUDIT FIX (2026-09): keep the Class Overview table in sync — see note
  // in updateEntryField() above.
  await loadAllData();
  renderClassTable();
}
