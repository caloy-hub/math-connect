-- ============================================================================
-- MathConnect — Migration 36: Term-end bonus points
-- ----------------------------------------------------------------------------
-- Lets a teacher award a small number of extra points directly onto a
-- specific student's TERM GRADE (e.g. Term 2's grade) — NOT the cumulative
-- Final Grade average across Term 1-3. One row per (student, term); the
-- "Add Points" button in Class Record → Grade Summary upserts into this
-- table, so re-awarding for the same term just overwrites the previous
-- value instead of stacking.
--
-- WHY IT'S SAFE TO STORE THE BONUS SEPARATELY RATHER THAN BAKING IT INTO
-- initial_grade: keeping it as its own additive layer on top of the
-- transmuted Term Grade means every screen that already calls
-- computeTermGrade(...) — Grade Summary, the teacher dashboard's Class
-- Average, admin.js's per-term/General Average, and the Excel export — picks
-- it up automatically as soon as it's passed the bonus argument, with zero
-- risk of it silently double-counting inside the WW/PT/EX weighted average
-- itself. And because the cumulative Final Grade is just the average of the
-- (already bonus-adjusted) per-term grades, the bonus naturally flows into
-- Final Grade too without any separate "cumulative bonus" logic anywhere.
-- ============================================================================

create table if not exists term_bonus_points (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  term_id uuid not null references terms(id) on delete cascade,
  points numeric not null default 0 check (points >= 0 and points <= 20),
  reason text,
  awarded_by uuid references teachers(id),
  awarded_at timestamptz not null default now(),
  unique (student_id, term_id)
);

alter table term_bonus_points enable row level security;

-- Read: same "public read" shape as scores/attendance — anon (student/teacher
-- app running on the anon key) can read, plus admin oversight.
drop policy if exists "public read term_bonus_points" on term_bonus_points;
create policy "public read term_bonus_points" on term_bonus_points for select using (
  auth.role() = 'anon' or is_admin() or exists (
    select 1 from terms t where t.id = term_bonus_points.term_id and is_teacher_of_section(t.section_id)
  )
);

-- Write: only the teacher who owns the section that the term belongs to
-- (mirrors "teacher write scores" via is_teacher_of_assessment, just walked
-- through terms -> sections instead of assessments -> sections).
drop policy if exists "teacher write term_bonus_points" on term_bonus_points;
create policy "teacher write term_bonus_points" on term_bonus_points for insert with check (
  exists (select 1 from terms t where t.id = term_bonus_points.term_id and is_teacher_of_section(t.section_id))
);
drop policy if exists "teacher update term_bonus_points" on term_bonus_points;
create policy "teacher update term_bonus_points" on term_bonus_points for update using (
  exists (select 1 from terms t where t.id = term_bonus_points.term_id and is_teacher_of_section(t.section_id))
);
drop policy if exists "teacher delete term_bonus_points" on term_bonus_points;
create policy "teacher delete term_bonus_points" on term_bonus_points for delete using (
  exists (select 1 from terms t where t.id = term_bonus_points.term_id and is_teacher_of_section(t.section_id))
);

-- Also allow admin to correct/remove entries from the Admin overview, same
-- as every other "admin can fix a stray entry" pattern in this app.
drop policy if exists "admin write term_bonus_points" on term_bonus_points;
create policy "admin write term_bonus_points" on term_bonus_points for all using (is_admin()) with check (is_admin());

-- ============================================================================
-- Done. Next: deploy the updated grading.js (computeTermGrade now accepts an
-- optional bonus argument), teacher.js (Grade Summary "Add Points" button +
-- Final Grades sub-view), and admin.js (per-term/General Average now folds
-- the bonus in too, so it stays consistent with what teachers see).
-- ============================================================================
