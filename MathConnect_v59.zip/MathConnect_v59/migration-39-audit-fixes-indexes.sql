-- ============================================================================
-- MathConnect — Migration 39: Audit fixes support (indexes)
-- ----------------------------------------------------------------------------
-- Companion migration for the 2026-09 Class Record / Attendance audit fixes
-- shipped in supabase-client.js, admin.js, teacher.js, and student.js:
--   1. admin.js now paginates through `students`, `assessments`, `scores`,
--      and `attendance` instead of relying on a single unbounded select()
--      (which Supabase/PostgREST silently caps at ~1,000 rows). Paginating
--      via `.range()` still benefits from an index on the columns used to
--      join/filter these tables.
--   2. teacher.js's "Attendance Summary (this term)" and student.js's "My
--      Attendance" now both filter `attendance` by section_id + a date
--      range (previously section_id + student_id with no date bound at
--      all in one case, and no bound whatsoever in the other). An index on
--      (section_id, attendance_date) and (student_id, attendance_date)
--      keeps those newly-added range filters fast as attendance history
--      grows.
-- No data is changed by this migration — indexes only. Safe to re-run.
-- ============================================================================

create index if not exists attendance_section_date_idx on attendance (section_id, attendance_date);
create index if not exists attendance_student_date_idx on attendance (student_id, attendance_date);
create index if not exists scores_assessment_idx on scores (assessment_id);
create index if not exists scores_student_idx on scores (student_id);
create index if not exists assessments_term_idx on assessments (term_id);
create index if not exists students_section_idx on students (section_id);
create index if not exists terms_section_idx on terms (section_id);

-- ----------------------------------------------------------------------------
-- Note on terms.start_date / terms.end_date:
-- These columns already existed in supabase-schema.sql but were never
-- written to by any part of the app — they were permanently NULL, which was
-- the root cause of the "days present" mismatch documented in the audit
-- (the "this term" attendance summary had no real term boundary to filter
-- on). No backfill is attempted here because the correct dates are known
-- only to each school/teacher, not derivable from existing data. Instead:
--   - teacher.js now ships an "Edit Term Dates" control (Attendance tab)
--     that writes directly to these columns.
--   - Until a teacher sets them, supabase-client.js's termDateRange()
--     helper computes a reasonable estimated 1/3-of-school-year slice per
--     term from `sections.school_year`, so attendance figures are never
--     silently unbounded even before exact dates are entered.
-- Recommended: have each teacher open Attendance → "Edit Term Dates" once
-- per section to enter the real term boundaries for full accuracy.
-- ============================================================================
