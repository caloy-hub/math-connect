-- ============================================================================
-- MathConnect — migration 54 (OPTIONAL, DESTRUCTIVE)
-- Permanently deletes all Tournament data: every tournament, bracket, match and
-- participant ever created.
--
-- The Tournament feature was removed from the app in v47 and migration-53
-- already switched off its database hooks, so leaving these tables in place is
-- harmless. Run this only if you are sure you don't want the history (past
-- champions, brackets). There is no undo — export first if in doubt:
--   copy (select * from tournaments) to stdout with csv header;   -- or use the Table Editor's CSV export
-- ============================================================================
drop trigger if exists trg_handle_tournament_battle_complete on battles;
drop function if exists public.handle_tournament_battle_complete();
drop function if exists public.generate_tournament_bracket(uuid);
drop function if exists public.advance_tournament_match(uuid, uuid);
drop function if exists public.tournament_force_winner(uuid, uuid);
drop table if exists tournament_matches cascade;
drop table if exists tournament_participants cascade;
drop table if exists tournaments cascade;
