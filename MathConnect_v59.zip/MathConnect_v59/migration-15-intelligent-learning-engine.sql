-- ============================================================================
-- Migration 15 — Intelligent Learning Engine
-- (Adaptive Difficulty + Error Diagnosis + Skill Proficiency Trees, unified)
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this if supabase-schema.sql was
-- already updated to include it.
--
-- What this adds:
--   1. learning_engine_state — ONE row per student holding the three things
--      the unified system needs to make its next decision instantly on
--      load: adaptive_levels (tier 1-4 per domain), skill_proficiency
--      (0-100 mastery bar per domain), and recent_answers (last 5 outcomes
--      per domain, used by the Adaptive Difficulty Engine).
--   2. learning_engine_log — one row per SUBMITTED ANSWER (append-only
--      history). This is what powers the teacher heatmap: which mistake
--      types a student keeps making, and what tier they were on when they
--      made them.
--   3. teacher_learning_heatmap() — a read-only function that returns,
--      per student, their current tier/proficiency per domain plus their
--      single most common recent mistake type — exactly the "Ah, Student A
--      is stuck on Carry-over errors" view the teacher dashboard needs,
--      computed in one query instead of the client crunching raw logs.
-- ============================================================================

-- ---------- STATE (one row per student — the "unified student object") ----------
create table if not exists learning_engine_state (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade unique,
  -- tier 1-4 per domain: 1=Easy, 2=Medium, 3=Hard, 4=Expert
  adaptive_levels jsonb not null default
    '{"basic":1,"order":1,"integers":1,"fractions":1,"decimals":1,"algebra":1}'::jsonb,
  -- mastery bar 0-100 per domain (this is what the Skill Tree renders — NOT the same
  -- number as drill_progress.topic_points, which is arcade score, not mastery)
  skill_proficiency jsonb not null default
    '{"basic":0,"order":0,"integers":0,"fractions":0,"decimals":0,"algebra":0}'::jsonb,
  -- last 5 outcomes per domain, oldest first: 1 = correct (1st try), 0 = missed.
  -- A question that took a 2nd try to get right is logged as 0 here on purpose —
  -- it still earns effort points on the skill bar, but it should NOT look like
  -- an unassisted correct answer to the Adaptive Difficulty Engine.
  recent_answers jsonb not null default
    '{"basic":[],"order":[],"integers":[],"fractions":[],"decimals":[],"algebra":[]}'::jsonb,
  updated_at timestamptz default now()
);

-- ---------- LOG (append-only — every submitted attempt, right or wrong) ----------
create table if not exists learning_engine_log (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  domain text not null,
  tier int not null,
  attempt_number int not null default 1,          -- 1 = first try, 2 = retry
  is_correct boolean not null,
  mistake_type text,                                -- null when correct
  question_prompt text,
  correct_answer text,
  student_answer text,
  points_awarded int not null default 0,
  created_at timestamptz default now()
);
create index if not exists learning_engine_log_student_idx on learning_engine_log (student_id);
create index if not exists learning_engine_log_student_domain_idx on learning_engine_log (student_id, domain);

-- ---------- RLS — same open client-side model as drill_progress/drill_attempts ----------
-- (students authenticate via class code + login code, not Supabase Auth, so
-- writes happen as the anon key from the browser — see the note in
-- migration-13-math-drills.sql for why this is an acceptable tradeoff here.)
alter table learning_engine_state enable row level security;
alter table learning_engine_log enable row level security;

drop policy if exists "public read learning_engine_state" on learning_engine_state;
create policy "public read learning_engine_state" on learning_engine_state for select using (true);
drop policy if exists "anyone insert learning_engine_state" on learning_engine_state;
create policy "anyone insert learning_engine_state" on learning_engine_state for insert with check (true);
drop policy if exists "anyone update learning_engine_state" on learning_engine_state;
create policy "anyone update learning_engine_state" on learning_engine_state for update using (true);
drop policy if exists "teacher delete learning_engine_state" on learning_engine_state;
create policy "teacher delete learning_engine_state" on learning_engine_state for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read learning_engine_log" on learning_engine_log;
create policy "public read learning_engine_log" on learning_engine_log for select using (true);
drop policy if exists "anyone insert learning_engine_log" on learning_engine_log;
create policy "anyone insert learning_engine_log" on learning_engine_log for insert with check (true);
drop policy if exists "teacher delete learning_engine_log" on learning_engine_log;
create policy "teacher delete learning_engine_log" on learning_engine_log for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ----------------------------------------------------------------------------
-- TEACHER HEATMAP — one row per student: current tier + proficiency per
-- domain, plus their single most frequent mistake type over their last 20
-- logged wrong answers (school-recent, not all-time, so it reflects what a
-- student is stuck on RIGHT NOW, not a mistake they fixed months ago).
-- Scoped to one teacher's own section via is_teacher_of_student(), same
-- pattern as the rest of the app's teacher-facing functions.
-- ----------------------------------------------------------------------------
create or replace function public.teacher_learning_heatmap(target_section_id uuid)
returns table(
  student_id uuid,
  full_name text,
  adaptive_levels jsonb,
  skill_proficiency jsonb,
  top_mistake_domain text,
  top_mistake_type text,
  top_mistake_count bigint
)
language sql security definer stable as $$
  with ranked_wrong as (
    select student_id, domain, mistake_type,
      row_number() over (partition by student_id order by created_at desc) as recency_rnk
    from learning_engine_log
    where mistake_type is not null
  ),
  recent_wrong as (
    select * from ranked_wrong where recency_rnk <= 20
  ),
  top_mistake as (
    select student_id, domain, mistake_type, count(*) as cnt,
      row_number() over (partition by student_id order by count(*) desc) as rnk
    from recent_wrong
    group by student_id, domain, mistake_type
  )
  select
    st.id, st.full_name,
    coalesce(les.adaptive_levels, '{"basic":1,"order":1,"integers":1,"fractions":1,"decimals":1,"algebra":1}'::jsonb),
    coalesce(les.skill_proficiency, '{"basic":0,"order":0,"integers":0,"fractions":0,"decimals":0,"algebra":0}'::jsonb),
    tm.domain, tm.mistake_type, tm.cnt
  from students st
  left join learning_engine_state les on les.student_id = st.id
  left join top_mistake tm on tm.student_id = st.id and tm.rnk = 1
  where st.section_id = target_section_id
    and (is_teacher_of_student(st.id) or is_admin());
$$;
grant execute on function public.teacher_learning_heatmap(uuid) to anon, authenticated;

-- ============================================================================
-- Done. Load difficultyEngine.js, diagnosisEngine.js, skillEngine.js, and
-- learningEngine.js on student.html to enable Adaptive Practice, and
-- teacher-learning-heatmap.js on teacher.html for the class heatmap.
-- ============================================================================
