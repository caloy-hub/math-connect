// ============================================================================
// MathConnect — Streak Flame UI
// Renders the TikTok-style animated flame: color + "capacity" (size) change
// per tier (see FLAME_TIERS in streakEngine.js), a rising fill inside the
// flame showing progress to the next tier, an "off" (extinguished) state
// with a Restore button when the streak was broken by an absence, and a
// burst/particle animation that plays every time the flame levels up.
//
// Two render sizes:
//   renderFlameSVG(streak, streakOff, idSuffix, px)  -> raw <svg> string
//   renderTopbarMiniFlame()                          -> small inline flame + count for the topbar
//   renderStreakWidget(containerId)                  -> the big card used on the Attendance tab
//
// Depends on: streakEngine.js (estate, FLAME_TIERS, getFlameTier,
// flameTierProgress, currentRestoreCost, restoreStreak), escapeHtml/toast
// (supabase-client.js).
// ============================================================================

// Remembers the last tier index we actually showed the student, per widget
// instance, purely to detect "did we just level up" so we know when to fire
// the burst animation. localStorage (not sessionStorage) so it survives a
// refresh — we don't want to re-play the burst just because the page reloaded
// at the same streak value.
function _flameLastSeenKey(idSuffix) {
  return `mc_flame_seen_tier_${sstate && sstate.student ? sstate.student.id : "anon"}_${idSuffix}`;
}
function _flameGetLastSeen(idSuffix) {
  try { const v = localStorage.getItem(_flameLastSeenKey(idSuffix)); return v === null ? null : parseInt(v, 10); }
  catch (e) { return null; }
}
function _flameSetLastSeen(idSuffix, tierIdx) {
  try { localStorage.setItem(_flameLastSeenKey(idSuffix), String(tierIdx)); } catch (e) {}
}

/**
 * Builds the flame <svg> markup itself. A single flame path is drawn twice:
 * once as a dim full-size silhouette (so you can always see the tier's max
 * shape), and once clipped by a rising rect that fills bottom-up as the
 * student gets closer to the next tier — that's the "capacity" gauge.
 */
function renderFlameSVG(streak, streakOff, idSuffix, px) {
  const size = px || 96;
  const { tier, fraction } = flameTierProgress(streak || 0);
  const clipId = `flameClip-${idSuffix}`;
  const gradId = `flameGrad-${idSuffix}`;
  const flamePath = "M50,97 C27,97 12,79 12,58 C12,40 22,27 32,8 C31,26 41,32 42,18 C50,27 54,18 51,3 C68,12 82,29 82,55 C82,78 71,97 50,97 Z";
  const off = !!streakOff;
  const fillTop = 100 - Math.round(fraction * 100);
  const color = off ? "#B9C0C6" : tier.color;
  const glow = off ? "none" : `drop-shadow(0 0 ${Math.round(6 * tier.scale)}px ${tier.glow})`;

  return `
  <svg id="flameSvg-${idSuffix}" class="flame-svg" viewBox="0 0 100 100" width="${size}" height="${size}"
       style="transform:scale(${off ? 0.6 : tier.scale});transform-origin:50% 100%;filter:${glow};transition:transform .25s ease;">
    <defs>
      <clipPath id="${clipId}"><path d="${flamePath}"/></clipPath>
      <linearGradient id="${gradId}" x1="0" y1="1" x2="0" y2="0">
        <stop offset="0%" stop-color="${color}"/>
        <stop offset="100%" stop-color="${tier.rainbow && !off ? "#E8632E" : color}"/>
        ${tier.rainbow && !off ? `<stop offset="50%" stop-color="#8E44AD"/>` : ""}
      </linearGradient>
    </defs>
    <path d="${flamePath}" fill="${color}" opacity="${off ? 0.35 : 0.16}"/>
    <g clip-path="url(#${clipId})">
      <rect x="0" y="${off ? 100 : fillTop}" width="100" height="${off ? 0 : 100}" fill="url(#${gradId})">
        ${off ? "" : `<animate attributeName="y" from="100" to="${fillTop}" dur=".6s" fill="freeze"/>`}
      </rect>
    </g>
    <path d="${flamePath}" fill="none" stroke="${color}" stroke-width="${off ? 1.5 : 0}" stroke-opacity=".6"/>
    ${tier.sparkle && !off ? `
      <circle cx="30" cy="30" r="2.2" fill="#fff" opacity=".85"><animate attributeName="opacity" values="0;.9;0" dur="1.6s" repeatCount="indefinite"/></circle>
      <circle cx="66" cy="40" r="1.6" fill="#fff" opacity=".7"><animate attributeName="opacity" values="0;.8;0" dur="1.3s" begin=".4s" repeatCount="indefinite"/></circle>
      <circle cx="50" cy="18" r="1.3" fill="#fff" opacity=".6"><animate attributeName="opacity" values="0;.7;0" dur="1.9s" begin=".8s" repeatCount="indefinite"/></circle>
    ` : ""}
    ${off ? `<text x="50" y="55" text-anchor="middle" font-size="26" fill="#8A93A1">💨</text>` : ""}
  </svg>`;
}

/** Small flame + day count for the topbar badge (used by engagement-ui.js). */
function renderTopbarMiniFlame() {
  if (!estate.loaded || !estate.data) return "";
  const e = estate.data;
  return `<span class="flame-inline" style="display:inline-flex;align-items:center;gap:3px;vertical-align:middle;">${renderFlameSVG(e.current_streak, e.streak_off, "topbar", 22)}<span>${e.streak_off ? "off" : e.current_streak + "d"}</span></span>`;
}

/**
 * The big card for the Attendance tab: flame, tier label, progress to next
 * tier, and — if the streak is off — a restore banner with the coin cost.
 * Call this AFTER estate is loaded (loadEngagement()).
 */
function renderStreakWidgetHtml() {
  const e = estate.data;
  const streak = e.current_streak || 0;
  const { tier, next, fraction } = flameTierProgress(streak);
  const restoreCost = currentRestoreCost();

  const progressHtml = next ? `
    <div class="muted" style="font-size:.75rem;margin-top:10px;">${Math.max(0, next.min - streak)} more day${(next.min - streak) === 1 ? "" : "s"} to <strong>${next.label}</strong></div>
    <div class="gbar" style="max-width:220px;margin-top:4px;"><div style="width:${Math.round(fraction * 100)}%;height:100%;background:${tier.color};border-radius:6px;"></div></div>
  ` : `<div class="muted" style="font-size:.75rem;margin-top:10px;">🏆 Max flame tier reached!</div>`;

  const reasonLabel = { absent_excused: "Absent (Excused)", absent_unexcused: "Absent (Unexcused)" }[e.streak_off_reason] || "an absence";

  return `
    <div class="card" id="streakWidgetCard" style="margin-bottom:16px;">
      <div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;">
        <div id="streakFlameHolder" style="width:96px;height:96px;display:flex;align-items:flex-end;justify-content:center;">
          ${renderFlameSVG(streak, e.streak_off, "widget", 96)}
        </div>
        <div style="flex:1;min-width:200px;">
          <div class="muted">Daily Attendance Streak</div>
          <h2 style="margin:2px 0;color:${e.streak_off ? "var(--sage)" : tier.color};">${e.streak_off ? "Streak off" : streak + " day" + (streak === 1 ? "" : "s")}</h2>
          <div class="muted" style="font-size:.8rem;">${e.streak_off ? "Waiting to be restored" : tier.label} · Longest: ${e.longest_streak || 0} days</div>
          ${e.streak_off ? "" : progressHtml}
        </div>
      </div>
      ${e.streak_off ? `
        <div class="flame-restore-banner" style="margin-top:14px;padding:12px 14px;background:var(--clay-light);border-radius:8px;">
          <strong>🔥💨 Your flame went out.</strong>
          <p class="muted" style="margin:4px 0 10px;font-size:.85rem;">
            You were marked <strong>${reasonLabel}</strong>${e.streak_off_date ? ` on ${fmtDate(e.streak_off_date)}` : ""}.
            Your ${e.streak_off_value}-day streak is saved — restore it for coins.
          </p>
          <button class="btn-gold" ${(estate.data.coins || 0) >= restoreCost ? "" : "disabled"} onclick="handleRestoreStreak()">
            ${(estate.data.coins || 0) >= restoreCost ? `🔥 Restore for 🪙 ${restoreCost}` : `🪙 ${restoreCost} needed (need more)`}
          </button>
        </div>` : `
        <p class="muted" style="margin-top:12px;font-size:.78rem;">Marked Present or Late each day keeps your flame lit. An absence — excused or unexcused — puts it out, but you can restore it with coins. Every 7-day streak unlocks a 24h 🪙×2 power-up + a Skip Question pass.</p>`}
    </div>`;
}

/** Mounts the widget into a container and handles the level-up burst if the tier just went up. */
function renderStreakWidget(containerId) {
  const el = document.getElementById(containerId);
  if (!el || !estate.loaded) return;
  el.innerHTML = renderStreakWidgetHtml();
  _maybePlayLevelUp("widget");
}

function _maybePlayLevelUp(idSuffix) {
  const e = estate.data;
  const { idx } = getFlameTier(e.current_streak || 0);
  const effectiveIdx = e.streak_off ? -1 : idx; // treat "off" as below tier 0 so restoring always re-triggers a burst
  const lastSeen = _flameGetLastSeen(idSuffix);
  _flameSetLastSeen(idSuffix, effectiveIdx);
  if (lastSeen === null) return; // first time ever seeing this widget — don't burst on load
  if (effectiveIdx > lastSeen) {
    const holder = document.getElementById(idSuffix === "widget" ? "streakFlameHolder" : "streakBadge");
    if (holder) triggerFlameLevelUp(holder, FLAME_TIERS[idx].color);
    if (idx > 0) toast(`🔥 Level up! Your flame is now ${FLAME_TIERS[idx].label}!`);
  }
}

/** The TikTok-style pop: the flame briefly scales/glows and a burst of embers flies outward. */
function triggerFlameLevelUp(anchorEl, color) {
  const svg = anchorEl.querySelector ? anchorEl.querySelector(".flame-svg") : null;
  if (svg) {
    svg.classList.remove("flame-burst-anim"); void svg.offsetWidth; // restart animation if already applied
    svg.classList.add("flame-burst-anim");
    setTimeout(() => svg.classList.remove("flame-burst-anim"), 700);
  }
  const rect = anchorEl.getBoundingClientRect();
  const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
  const layer = document.createElement("div");
  layer.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999;overflow:hidden;";
  for (let i = 0; i < 16; i++) {
    const bit = document.createElement("div");
    const angle = (Math.PI * 2 * i) / 16;
    const dist = 40 + Math.random() * 30;
    const dx = Math.cos(angle) * dist, dy = Math.sin(angle) * dist - 10;
    bit.style.cssText = `position:absolute;left:${cx}px;top:${cy}px;width:6px;height:6px;border-radius:50%;
      background:${color};box-shadow:0 0 6px ${color};
      animation:flameEmberBurst .7s ease-out forwards;--dx:${dx}px;--dy:${dy}px;`;
    layer.appendChild(bit);
  }
  document.body.appendChild(layer);
  setTimeout(() => layer.remove(), 800);
}

async function handleRestoreStreak() {
  const row = await restoreStreak();
  if (row && row.success) {
    if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
    if (document.getElementById("streakWidgetMount")) renderStreakWidget("streakWidgetMount");
  }
}
