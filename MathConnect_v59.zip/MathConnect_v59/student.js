// ============================================================================
// MathConnect — Student Dashboard Logic
// ============================================================================

var sstate = { session: null, section: null, terms: [], term: null, student: null, assessments: [], rankTier: null, rankStars: 0, avatarUrl: null };

// Profile picture (migration-46 + avatarUpload.js) — tap the avatar chip in
// the top header to change it.
function changeStudentAvatar() {
  if (!sstate.student) return;
  pickAndUploadAvatar("student", sstate.student.id, async (url) => {
    const { error } = await supabase.from("student_preferences").upsert({ student_id: sstate.student.id, avatar_url: url, updated_at: new Date().toISOString() });
    if (error) throw error;
    sstate.avatarUrl = url;
    renderAvatarInto(document.getElementById("studentAvatarImg"), url, "🎓");
  });
}

initSupabase();
initStudent();

async function initStudent() {
  const session = requireStudent();
  if (!session) return;
  sstate.session = session;
  document.getElementById("studentNameLabel").textContent = session.name;

  const { data: prefs } = await supabase.from("student_preferences").select("avatar_url").eq("student_id", session.studentId).maybeSingle();
  sstate.avatarUrl = prefs ? prefs.avatar_url : null;
  renderAvatarInto(document.getElementById("studentAvatarImg"), sstate.avatarUrl, "🎓");

  const { data: student } = await supabase.from("students").select("*").eq("id", session.studentId).maybeSingle();
  const { data: section } = await supabase.from("sections").select("*").eq("id", session.sectionId).maybeSingle();
  sstate.student = student;
  sstate.section = section;
  if (!student || !section) { clearStudentSession(); window.location.href = "login.html"; return; }

  // Re-check pause status fresh from the DB every load — an admin may have
  // paused this account after the student's session was already saved.
  if (student.account_status === "frozen") {
    clearStudentSession();
    alert("Your account has been paused by the administrator. Please see your teacher.");
    window.location.href = "login.html";
    return;
  }
  sstate.readOnly = student.account_status === "readonly";
  if (sstate.readOnly) {
    const banner = document.createElement("div");
    banner.className = "card";
    banner.style.cssText = "margin-bottom:16px;border-left:4px solid var(--clay);";
    banner.innerHTML = `<strong>⏸️ Read-only mode</strong> — an administrator has paused new activity on this account. You can still view your grades and progress, but drills, raids, and other submissions are disabled.`;
    document.querySelector("main")?.prepend(banner) || document.body.prepend(banner);
  }

  const { data: terms } = await supabase.from("terms").select("*").eq("section_id", section.id).order("term_number");
  sstate.terms = terms || [];
  sstate.term = sstate.terms.find((t) => t.is_active) || sstate.terms[0];

  await loadGradeLevelScope();
  renderTermTracker();
  applySubjectTabRestrictionStudent();
  const { data: assessments } = await supabase.from("assessments").select("*").eq("term_id", sstate.term?.id || "");
  sstate.assessments = assessments || [];

  // MathLegends rank -> mathematician spotlight (mathBios.js). Fetched here,
  // once per login, so both the "every login" welcome-back modal and the
  // persistent Overview dashboard card can use the same tier/stars.
  const { data: progress } = await supabase.from("drill_progress").select("mastery_tier, mastery_stars").eq("student_id", sstate.student.id).maybeSingle();
  sstate.rankTier = rankTierByLevel(progress?.mastery_tier || 1);
  sstate.rankStars = progress?.mastery_stars || 0;

  switchStudentTab("overview");

  // Always show the mathematician spotlight on login, per current rank.
  if (typeof showMathBioLoginModal === "function" && sstate.rankTier) showMathBioLoginModal(sstate.rankTier);

  // Follow-companion pet widget (MATHCONNECT 2.0 Phase 1) — no-ops on its
  // own for non-math sections or students without an adopted pet yet.
  if (typeof initPetCompanion === "function") initPetCompanion();

  // "Student enters, pet runs toward them" (MATHCONNECT 2.0 Phase 4) — the
  // existing showPetCheerBubble() already no-ops without a pet and throttles
  // itself to once per 2 minutes, so calling it once here at login naturally
  // gives the session-entrance greeting without any new bubble mechanism.
  if (typeof showPetCheerBubble === "function" && typeof isMathSubjectStudent === "function" && isMathSubjectStudent(sstate.section && sstate.section.subject)) {
    showPetCheerBubble();
  }

  // Shout-outs side panel (migration-57). Stays invisible if the migration
  // isn't installed yet or the teacher has switched the section's mode to Off.
  if (typeof initShoutouts === "function") initShoutouts();
}

// ============================================================================
// GRADE-LEVEL SCOPE — Blended Learning and Exams posted in ANY section that
// shares this student's grade level, subject, and school year are visible
// here too (not just their own section), so a teacher only has to post once
// per grade level instead of duplicating it into every section.
//
// grade_level/subject/school_year are free-text fields the teacher retypes
// for every section, so we match them normalized (trimmed + lowercased)
// instead of with an exact `.eq()` — otherwise "Grade 8" vs "Grade 8 " (a
// stray trailing space) or "Mathematics" vs "mathematics" silently fail to
// match and the section looks like an island of one. We also scope the
// lookup to the same teacher, since two different teachers could otherwise
// happen to use identical-looking grade/subject labels for unrelated classes.
// ============================================================================
function normText(v) {
  return (v || "").toString().trim().toLowerCase();
}
async function loadGradeLevelScope() {
  const own = sstate.section;
  sstate.gradeScope = {
    sectionIds: own ? [own.id] : [],
    termIds: sstate.term ? [sstate.term.id] : [],
    sectionNameById: own ? { [own.id]: own.section_name } : {},
  };
  if (!own || !own.grade_level) return;

  const { data: teacherSections } = await supabase.from("sections")
    .select("id, section_name, grade_level, subject, school_year")
    .eq("teacher_id", own.teacher_id);

  const matches = (teacherSections || []).filter((s) =>
    normText(s.grade_level) === normText(own.grade_level) &&
    normText(s.subject || "Mathematics") === normText(own.subject || "Mathematics") &&
    normText(s.school_year) === normText(own.school_year)
  );
  const sections = matches.length ? matches : [{ id: own.id, section_name: own.section_name }];
  const sectionIds = sections.map((s) => s.id);
  const sectionNameById = {};
  sections.forEach((s) => (sectionNameById[s.id] = s.section_name));

  let termIds = sstate.term ? [sstate.term.id] : [];
  if (sstate.term) {
    const { data: siblingTerms } = await supabase.from("terms").select("id")
      .in("section_id", sectionIds).eq("term_number", sstate.term.term_number);
    if (siblingTerms && siblingTerms.length) termIds = siblingTerms.map((t) => t.id);
  }

  sstate.gradeScope = { sectionIds, termIds, sectionNameById };
}

function renderTermTracker() {
  const box = document.getElementById("termTrackerBox");
  if (!sstate.term) { box.innerHTML = ""; return; }
  box.innerHTML = `
    <div class="card" style="margin-bottom:20px;">
      <div class="muted">${escapeHtml(sstate.section.section_name)} · ${escapeHtml(sstate.section.subject || "Mathematics")} · SY ${escapeHtml(sstate.section.school_year)}</div>
      <div class="termline" style="margin-top:14px;">
        ${sstate.terms.map((t, i) => `
          ${i > 0 ? `<div class="seg ${t.term_number <= sstate.term.term_number ? "done" : ""}"></div>` : ""}
          <div class="node ${t.id === sstate.term.id ? "active" : t.term_number < sstate.term.term_number ? "done" : ""}">${t.term_number}</div>
        `).join("")}
      </div>
      <div class="term-labels">${sstate.terms.map((t) => `<span>${escapeHtml(t.term_name)}</span>`).join("")}</div>
    </div>`;
}

var _lastArenaTab = "drills";
var _lastProgressTab = "grades";

function openStudentArenaTab() {
  switchStudentTab(_lastArenaTab || "drills");
}

function openStudentProgressTab() {
  switchStudentTab(_lastProgressTab || "grades");
}

function openStudentMoreDrawer() {
  const drawer = document.getElementById("studentMoreDrawer");
  const overlay = document.getElementById("studentMoreDrawerOverlay");
  if (drawer) drawer.classList.add("open");
  if (overlay) overlay.classList.add("open");
  document.body.classList.add("drawer-open");
}

function closeStudentMoreDrawer() {
  const drawer = document.getElementById("studentMoreDrawer");
  const overlay = document.getElementById("studentMoreDrawerOverlay");
  if (drawer) drawer.classList.remove("open");
  if (overlay) overlay.classList.remove("open");
  document.body.classList.remove("drawer-open");
}

function renderStudentSubNavbar(tab) {
  const subBar = document.getElementById("studentSubNavBar");
  if (!subBar) return;

  const arenaTabs = ["drills", "quest", "learning", "battle", "challenges"];
  const progressTabs = ["grades", "attendance", "legends", "status"];

  if (arenaTabs.includes(tab)) {
    subBar.style.display = "flex";
    subBar.innerHTML = `
      <div class="sub-nav-pill ${tab === 'drills' ? 'active' : ''}" onclick="switchStudentTab('drills')">🎮 Drills</div>
      <div class="sub-nav-pill ${tab === 'quest' ? 'active' : ''}" onclick="switchStudentTab('quest')">🗺️ Quest</div>
      <div class="sub-nav-pill ${tab === 'learning' ? 'active' : ''}" onclick="switchStudentTab('learning')">🧠 Practice</div>
      <div class="sub-nav-pill ${tab === 'battle' ? 'active' : ''}" onclick="switchStudentTab('battle')">🐉 Raids</div>
      <div class="sub-nav-pill ${tab === 'challenges' ? 'active' : ''}" onclick="switchStudentTab('challenges')">🎯 Daily</div>
    `;
  } else if (progressTabs.includes(tab)) {
    subBar.style.display = "flex";
    subBar.innerHTML = `
      <div class="sub-nav-pill ${tab === 'grades' ? 'active' : ''}" onclick="switchStudentTab('grades')">📊 Grades</div>
      <div class="sub-nav-pill ${tab === 'attendance' ? 'active' : ''}" onclick="switchStudentTab('attendance')">🗓️ Attendance</div>
      <div class="sub-nav-pill ${tab === 'legends' ? 'active' : ''}" onclick="switchStudentTab('legends')">👑 Rankings</div>
      <div class="sub-nav-pill ${tab === 'status' ? 'active' : ''}" onclick="switchStudentTab('status')">📋 Status</div>
    `;
  } else {
    subBar.style.display = "none";
  }
}

function switchStudentTab(tab) {
  // Leaving the Boss Raids tab in the middle of a fight asks first (the fight
  // keeps going for the team), then tears down its realtime subscriptions so
  // they don't keep running in the background.
  if (typeof raidLeaveGuard === "function" && !raidLeaveGuard(tab)) return;
  if (tab !== "battle" && typeof teardownRaidChannels === "function") teardownRaidChannels();

  if (["drills", "quest", "learning", "battle", "challenges"].includes(tab)) {
    _lastArenaTab = tab;
  }
  if (["grades", "attendance", "legends", "status"].includes(tab)) {
    _lastProgressTab = tab;
  }

  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === tab));

  // Sync mobile bottom navigation active indicators
  document.querySelectorAll(".bottom-nav-item").forEach((btn) => {
    const bTab = btn.dataset.bottomTab;
    let active = false;
    if (bTab === "overview" && tab === "overview") active = true;
    else if (bTab === "arena" && ["drills", "quest", "learning", "battle", "challenges"].includes(tab)) active = true;
    else if (bTab === "pet" && tab === "pet") active = true;
    else if (bTab === "progress" && ["grades", "attendance", "legends", "status"].includes(tab)) active = true;
    else if (bTab === "more" && ["blended", "literacy", "exams", "shop", "share", "report"].includes(tab)) active = true;
    btn.classList.toggle("active", active);
  });

  renderStudentSubNavbar(tab);

  document.querySelectorAll(".tabpanel").forEach((p) => (p.style.display = "none"));
  const panel = document.getElementById("tab-" + tab);
  if (panel) panel.style.display = "block";
  if (typeof renderTopbarStreakBadge === "function") renderTopbarStreakBadge();
  ({ overview: renderOverview, status: renderStatusPanel, grades: renderGrades, attendance: renderStudentAttendance, blended: renderStudentBlended, drills: renderDrillsHub, quest: renderQuestHub, learning: renderLearningHub, challenges: renderChallengesTab, shop: renderShopTab, pet: renderPetTab, share: renderShareTab, battle: renderRaidHub, legends: renderLegendsTab, exams: renderStudentExams, literacy: renderLiteracyHub, report: renderStudentReportCard }[tab])();
  if (typeof onPetCompanionTabChange === "function") onPetCompanionTabChange(tab);
}

// ----------------------------------------------------------------------------
// SUBJECT-BASED TAB RESTRICTION (mirrors teacher.js)
// Non-Math sections only get the core class-facing tabs plus Exams and
// Literacy, both useful across every subject (see migration-59 for why
// Literacy is deliberately NOT in this list). All of the Math-specific
// gamified tabs are hidden: Status, Math Drills, Quest Mode, Intelligent
// Practice, Challenges, Shop, Boss Raids, Legends.
// ----------------------------------------------------------------------------
const STUDENT_MATH_ONLY_TABS = ["status", "drills", "quest", "learning", "challenges", "shop", "pet", "share", "battle", "legends"];

function applySubjectTabRestrictionStudent() {
  const mathSubject = isMathSubjectStudent(sstate.section && sstate.section.subject);
  STUDENT_MATH_ONLY_TABS.forEach((tab) => {
    document.querySelectorAll(`.tab[data-tab="${tab}"]`).forEach((tabBtn) => {
      tabBtn.style.display = mathSubject ? "" : "none";
    });
    document.querySelectorAll(`.drawer-item[onclick*="${tab}"]`).forEach((item) => {
      item.style.display = mathSubject ? "" : "none";
    });
  });
  const arenaBtn = document.querySelector('.bottom-nav-item[data-bottom-tab="arena"]');
  if (arenaBtn) arenaBtn.style.display = mathSubject ? "" : "none";
  const petBtn = document.querySelector('.bottom-nav-item[data-bottom-tab="pet"]');
  if (petBtn) petBtn.style.display = mathSubject ? "" : "none";
}
function isMathSubjectStudent(subject) {
  const s = (subject || "Mathematics").trim().toLowerCase();
  // Contains-match, not exact-match — see isMathSubject() in teacher.js for
  // the same reasoning; keep these two functions in sync.
  return s.indexOf("math") !== -1;
}

// ============================================================================
// DASHBOARD HEADER — welcome banner, at-a-glance stats, progress ring +
// grade component bars, upcoming assessments, and a Drill Arena preview.
// Prepended onto the "This Week" (Overview) tab.
// ============================================================================
async function renderDashboardHeader() {
  const firstName = (sstate.session.name || sstate.student.first_name || sstate.student.full_name || "").split(" ")[0];

  // Points / streak / level — reuse the drills + engagement engines if present.
  let totalPoints = 0, gamesPlayed = 0;
  if (typeof loadDrillProgress === "function") {
    if (!dstate.loaded) await loadDrillProgress();
    totalPoints = dstate.progress.total_points || 0;
    gamesPlayed = dstate.progress.games_played || 0;
  }
  let currentStreak = 0;
  if (typeof loadEngagement === "function") {
    if (!estate.loaded) await loadEngagement();
    currentStreak = (estate.data && estate.data.current_streak) || 0;
  }
  const tier = sstate.rankTier;

  // Math Pet status widget — loaded here (not lazily in the Pet tab) so it's
  // ready the moment the dashboard renders. Math-subject sections only,
  // same scoping as the Pet tab itself; fails quiet if anything's off so a
  // pet hiccup never blocks the rest of the dashboard from showing.
  let petWidgetHtml = "";
  if (typeof isMathSubjectStudent === "function" && isMathSubjectStudent(sstate.section && sstate.section.subject) && typeof loadPetCatalog === "function") {
    try {
      await loadPetCatalog();
      await loadMyPets();
      petWidgetHtml = dashboardPetWidgetHtml();
    } catch (e) { /* pet widget is a nice-to-have — fail quiet */ }
  }

  // Overall grade + component breakdown for the current term, for the ring + bars.
  let overallPct = null, wwPS = null, ptPS = null, exPS = null;
  try {
    const weights = getSectionWeights(sstate.section);
    const { data: scores } = await supabase.from("scores").select("*").eq("student_id", sstate.student.id)
      .in("assessment_id", sstate.assessments.map((a) => a.id).length ? sstate.assessments.map((a) => a.id) : ["00000000-0000-0000-0000-000000000000"]);
    const byAssessment = {};
    (scores || []).forEach((s) => (byAssessment[s.assessment_id] = s));
    const g = computeTermGrade(sstate.assessments || [], byAssessment, weights);
    wwPS = g.wwPS; ptPS = g.ptPS; exPS = g.exPS;
    overallPct = g.termGrade !== null ? g.termGrade : null;
  } catch (e) { /* grading data not ready yet — ring falls back below */ }
  const ringPct = overallPct !== null ? Math.round(overallPct) : (gamesPlayed ? Math.round((totalPoints % 100)) : 0);

  // Upcoming assessments (not yet given a score) for this term.
  let upcoming = [];
  try {
    const { data: myScores } = await supabase.from("scores").select("assessment_id").eq("student_id", sstate.student.id);
    const scored = new Set((myScores || []).map((s) => s.assessment_id));
    upcoming = (sstate.assessments || [])
      .filter((a) => !scored.has(a.id))
      .sort((a, b) => new Date(a.date_given) - new Date(b.date_given))
      .slice(0, 3);
  } catch (e) { /* ignore — assignment list just stays empty */ }

  const monthShort = (d) => new Date(d).toLocaleDateString("en-US", { month: "short" }).toUpperCase();
  const dayNum = (d) => new Date(d).getDate();
  const compLabel = { WW: "Written Work", PT: "Performance Task", EX: "Examination" };

  return `
    <div class="hero-banner">
      <h1>Welcome back, ${escapeHtml(firstName)}! 👋</h1>
      <p class="quote">"The only way to learn mathematics is to do mathematics."<span class="who">— Paul Halmos</span></p>
      <button class="btn-hero" onclick="switchStudentTab('drills')">Continue Learning →</button>
    </div>

    ${petWidgetHtml}

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-icon green">📖</div>
        <div><div class="stat-value">${escapeHtml(sstate.section.section_name)}</div><div class="stat-label">My Class</div><div class="stat-sub">${escapeHtml(sstate.section.subject || "Mathematics")}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon gold">🏆</div>
        <div><div class="stat-value">${totalPoints.toLocaleString()}</div><div class="stat-label">Total Points</div><div class="stat-sub">Keep it up!</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon orange">🔥</div>
        <div><div class="stat-value">${currentStreak}</div><div class="stat-label">Day Streak</div><div class="stat-sub">${currentStreak > 0 ? "You're on fire!" : "Start today!"}</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon sky">🎖️</div>
        <div><div class="stat-value">${tier ? escapeHtml(tier.name) : "Level 1"}</div><div class="stat-label">MathLegends Rank</div><div class="stat-sub">${sstate.rankStars || 0} ⭐ earned</div></div>
      </div>
    </div>

    <div class="dash-grid">
      <div class="card">
        <div class="section-title-row"><h3 style="margin:0;">My Progress</h3></div>
        <div class="muted" style="font-size:.8rem;">Overall Grade (${escapeHtml(sstate.term.term_name)})</div>
        <div class="progress-ring" style="--pct:${overallPct !== null ? ringPct : 0};">
          <div class="progress-ring-inner">
            <div class="pct">${overallPct !== null ? ringPct + "%" : "—"}</div>
            <div class="lbl">${overallPct !== null ? "Great job!" : "No grades yet"}</div>
          </div>
        </div>
        ${["WW", "PT", "EX"].map((k) => {
          const val = { WW: wwPS, PT: ptPS, EX: exPS }[k];
          const color = { WW: "var(--forest)", PT: "var(--gold)", EX: "var(--clay)" }[k];
          return `
          <div class="subject-bar-row"><span>${compLabel[k]}</span><span class="val">${val !== null && val !== undefined ? Math.round(val) + "%" : "—"}</span></div>
          <div class="gbar"><div style="width:${val || 0}%;background:${color};"></div></div>`;
        }).join("")}
      </div>

      <div class="card">
        <div class="section-title-row"><h3 style="margin:0;">Upcoming Assignments</h3>
          <span class="link-btn" onclick="switchStudentTab('grades')">View All →</span>
        </div>
        ${upcoming.length === 0 ? `<p class="muted">Nothing due right now — nice and clear!</p>` : upcoming.map((a) => `
          <div class="assign-item">
            <div class="assign-date"><span class="mon">${monthShort(a.date_given)}</span><span class="day">${dayNum(a.date_given)}</span></div>
            <div class="assign-info">
              <div class="title">${escapeHtml(a.title || a.component)}</div>
              <div class="sub">${escapeHtml(sstate.section.subject || "Mathematics")} • Due ${fmtDate(a.date_given)}</div>
            </div>
            <div class="assign-arrow">›</div>
          </div>`).join("")}
      </div>
    </div>

    <div class="card" style="margin-bottom:20px;">
      <div class="section-title-row">
        <div>
          <h3 style="margin:0;">Math Drills Arena</h3>
          <div class="muted" style="font-size:.82rem;">Practice skills and earn points!</div>
        </div>
        <span class="link-btn" onclick="switchStudentTab('drills')">Go to Arena →</span>
      </div>
    </div>`;
}

// ============================================================================
// OVERVIEW — Lesson of the week, Task of the week, Announcements
// ============================================================================
async function renderOverview() {
  const el = document.getElementById("tab-overview");
  if (!sstate.term) { el.innerHTML = `<div class="empty">No term set up yet — check back soon!</div>`; return; }

  el.innerHTML = await renderDashboardHeader();

  const { data: lessons } = await supabase.from("lessons").select("*").eq("term_id", sstate.term.id).order("week_number", { ascending: false });
  const { data: announcements } = await supabase.from("announcements").select("*").eq("section_id", sstate.section.id).order("created_at", { ascending: false }).limit(3);

  const currentLesson = lessons && lessons[0];
  const pastLessons = (lessons || []).slice(1);
  sstate.currentLessonId = currentLesson ? currentLesson.id : null;

  let myRating = null, ratingHistory = [], classContext = null, reteachNote = null, myHelpFlag = null;
  if (currentLesson) {
    const { data: r } = await supabase.from("topic_ratings").select("*").eq("lesson_id", currentLesson.id).eq("student_id", sstate.student.id).maybeSingle();
    myRating = r;

    // Trend: this student's history of ratings for this specific lesson
    // (a student can re-rate after a re-teach note goes up).
    const { data: hist } = await supabase.from("topic_ratings_history").select("rating, submitted_at").eq("lesson_id", currentLesson.id).eq("student_id", sstate.student.id).order("submitted_at", { ascending: true });
    ratingHistory = hist || [];

    // Class context: anonymized "X% of classmates also found this tricky",
    // computed live from everyone's current rating on this lesson.
    const { data: allRatings } = await supabase.from("topic_ratings").select("rating").eq("lesson_id", currentLesson.id);
    if (allRatings && allRatings.length > 0) {
      const total = allRatings.length;
      const struggling = allRatings.filter((x) => x.rating <= 3).length;
      classContext = { total, pct: Math.round((struggling / total) * 100) };
    }

    const { data: rt } = await supabase.from("reteach_notes").select("*").eq("lesson_id", currentLesson.id).maybeSingle();
    reteachNote = rt;

    const { data: hf } = await supabase.from("help_flags").select("*").eq("lesson_id", currentLesson.id).eq("student_id", sstate.student.id).maybeSingle();
    myHelpFlag = hf;
  }

  const { data: feedback } = await supabase.from("other_concerns").select("*").eq("student_id", sstate.student.id).eq("visible_to_student", true).order("concern_date", { ascending: false }).limit(5);

  el.innerHTML += `
    <div class="section-title-row" style="margin-top:6px;"><h3 style="margin:0;">📘 This Week's Check-in</h3></div>
    <div class="grid grid-2">
      <div class="card section-card">
        <div class="pill">📘 Lesson of the Week</div>
        ${currentLesson ? `
          <h3 style="margin-top:12px;">${escapeHtml(currentLesson.title)}</h3>
          <p class="muted">Week ${currentLesson.week_number}</p>
          <div>${TN.mathHtml(currentLesson.objectives || "")}</div>
          ${currentLesson.material_url ? TN.attachmentHtml(currentLesson.material_url, { compact: true, label: "Lesson material" }) : ""}
        ` : `<p class="muted" style="margin-top:12px;">Your teacher hasn't posted this week's lesson yet.</p>`}
      </div>

      <div class="card" style="border-left:4px solid var(--gold);">
        <div class="pill" style="background:var(--gold-light);color:var(--forest-dark);">📊 How well did you understand this week's topic?</div>
        ${currentLesson ? `
          <div id="ratingWidget" style="margin-top:12px;">
            ${renderRatingWidget(currentLesson.id, myRating, ratingHistory, classContext, myHelpFlag)}
          </div>
        ` : `<p class="muted" style="margin-top:12px;">No topic posted yet this week.</p>`}
      </div>
    </div>

    ${reteachNote ? `
    <div class="card" style="margin-top:16px;border-left:4px solid var(--sky);">
      <div class="pill" style="background:var(--sky-light);color:var(--forest);">🔁 Re-teach Recap from Your Teacher</div>
      <h4 style="margin:10px 0 4px;">${escapeHtml(reteachNote.title)}</h4>
      ${TN.viewerHtml("rt_" + currentLesson.id, { text: reteachNote.content, url: reteachNote.link_url, label: "Recap material" })}
      <p class="muted" style="margin-top:6px;font-size:.82rem;">Posted ${new Date(reteachNote.updated_at || reteachNote.posted_at).toLocaleString()}</p>
    </div>` : ""}

    ${pastLessons.length > 0 ? `
    <div class="card" style="margin-top:16px;">
      <details>
        <summary style="cursor:pointer;font-weight:600;">📚 Previous Weeks — rate or update a past topic</summary>
        <div style="margin-top:12px;">
          ${pastLessons.map((l) => `
            <details style="margin-top:8px;padding:10px;background:var(--paper);border-radius:8px;" ontoggle="if(this.open) loadPastLessonWidget('${l.id}')">
              <summary style="cursor:pointer;">Week ${l.week_number} · ${escapeHtml(l.title)}</summary>
              ${l.objectives ? `<div class="muted" style="margin-top:8px;">${TN.mathHtml(l.objectives)}</div>` : ""}
              ${l.material_url ? TN.attachmentHtml(l.material_url, { compact: true, label: "Lesson material" }) : ""}
              <div id="pastLessonWidget_${l.id}" style="margin-top:10px;"></div>
            </details>`).join("")}
        </div>
      </details>
    </div>` : ""}

    ${sstate.rankTier && typeof renderMathBioOverviewCard === "function" ? renderMathBioOverviewCard(sstate.rankTier, sstate.rankStars) : ""}

    <div id="overviewTrialTeaser"></div>

    ${(feedback && feedback.length > 0) ? `
    <div class="card" style="margin-top:16px;border-left:4px solid var(--forest);">
      <h3>💬 Feedback from Your Teacher</h3>
      ${feedback.map((f) => `
        <div style="padding:10px 0;border-bottom:1px solid var(--paper-line);">
          <span class="muted">${fmtDate(f.concern_date)}</span>
          <p>${escapeHtml(f.note)}</p>
        </div>`).join("")}
    </div>` : ""}

    <div class="card" style="margin-top:16px;">
      <h3>📣 Announcements</h3>
      ${(announcements || []).length === 0 ? `<p class="muted">Nothing new.</p>` : announcements.map((a) => `
        <div style="padding:10px 0;border-bottom:1px solid var(--paper-line);">
          <strong>${escapeHtml(a.title)}</strong> <span class="muted">— ${new Date(a.created_at).toLocaleDateString()}</span>
          <p>${escapeHtml(a.content)}</p>
        </div>`).join("")}
    </div>`;

  // Fire-and-forget: only Eureka-tier students see the Trial teaser, and it
  // shouldn't block the rest of the Overview tab from rendering.
  if (sstate.rankTier && sstate.rankTier.level >= RANK_MAX_TIER && typeof loadTrialStatus === "function") {
    loadTrialStatus().then((status) => {
      const slot = document.getElementById("overviewTrialTeaser");
      if (slot && status) slot.innerHTML = renderArchimedesTrialCard(status, { compact: true });
    });
  }
}

// ============================================================================
// WEEKLY UNDERSTANDING RATING — students rate 1-5 how well they understood
// the current lesson, with an optional comment. Feeds the teacher's "Least
// Understood Topics" summary on the Weekly Check-In tab. See migration-26.
// ============================================================================
var pendingRatingValue = {};
var pendingHelpFlag = {};
var RATING_DOT_COLORS = ["#D9D2C4", "#F4A460", "#FFD700", "#90EE90", "#32CD32"];
function renderRatingWidget(lessonId, existing, history, classContext, helpFlag) {
  pendingRatingValue[lessonId] = existing ? existing.rating : 0;
  pendingHelpFlag[lessonId] = !!helpFlag;
  const labels = { 1: "😵 Lost", 2: "😕 Confused", 3: "🙂 Getting there", 4: "😃 Understood", 5: "🤩 Mastered it" };

  const trend = (history || []).slice(-4);
  const trendHtml = trend.length > 1 ? `
    <div class="muted" style="font-size:.8rem;margin-bottom:10px;">
      Your understanding over time:
      <div style="display:flex;gap:4px;margin-top:4px;">
        ${trend.map((r) => `<span title="${r.rating}★" style="display:inline-flex;width:22px;height:22px;border-radius:50%;align-items:center;justify-content:center;font-size:.65rem;color:#fff;font-weight:700;background:${RATING_DOT_COLORS[r.rating - 1]};">${r.rating}</span>`).join("")}
      </div>
    </div>` : "";

  const classContextHtml = classContext && classContext.total > 0 ? `
    <div class="muted" style="font-size:.82rem;margin-bottom:10px;background:var(--sage-light);padding:8px 10px;border-radius:6px;">
      ${classContext.pct}% of your classmates also found this confusing or challenging. You're not alone!
    </div>` : "";

  return `
    ${trendHtml}
    ${classContextHtml}
    <div id="starRow_${lessonId}" style="font-size:1.6rem;letter-spacing:6px;cursor:pointer;">
      ${[1, 2, 3, 4, 5].map((n) => `<span data-star="${n}" onclick="setRatingStar('${lessonId}', ${n})" style="color:${n <= pendingRatingValue[lessonId] ? "var(--gold)" : "#D9D2C4"};">★</span>`).join("")}
    </div>
    <div id="starLabel_${lessonId}" class="muted" style="margin-top:4px;min-height:1.2em;">${pendingRatingValue[lessonId] ? labels[pendingRatingValue[lessonId]] : "Tap a star to rate"}</div>
    <textarea id="ratingComment_${lessonId}" rows="2" placeholder="Optional: what part was confusing or clear? (optional)" style="margin-top:8px;">${escapeHtml((existing && existing.comment) || "")}</textarea>
    <label style="display:flex;align-items:center;gap:6px;margin-top:10px;font-size:.85rem;cursor:pointer;">
      <input type="checkbox" id="helpFlagCheck_${lessonId}" ${pendingHelpFlag[lessonId] ? "checked" : ""} onchange="pendingHelpFlag['${lessonId}']=this.checked;">
      🚩 I could use extra help with this — only your teacher sees this
    </label>
    <button class="btn-primary btn-sm" style="margin-top:8px;" onclick="submitRating('${lessonId}')">${existing ? "Update My Rating" : "Submit My Rating"}</button>
    ${existing ? `<p class="muted" style="margin-top:6px;">✅ Last rated ${new Date(existing.updated_at || existing.created_at).toLocaleString()}</p>` : ""}`;
}
function setRatingStar(lessonId, n) {
  pendingRatingValue[lessonId] = n;
  const labels = { 1: "😵 Lost", 2: "😕 Confused", 3: "🙂 Getting there", 4: "😃 Understood", 5: "🤩 Mastered it" };
  document.querySelectorAll(`#starRow_${lessonId} span`).forEach((el) => {
    el.style.color = Number(el.dataset.star) <= n ? "var(--gold)" : "#D9D2C4";
  });
  document.getElementById(`starLabel_${lessonId}`).textContent = labels[n];
}
async function submitRating(lessonId) {
  const rating = pendingRatingValue[lessonId];
  if (!rating) { toast("Tap a star to rate first."); return; }
  const comment = document.getElementById(`ratingComment_${lessonId}`).value.trim();
  const helpFlagged = !!pendingHelpFlag[lessonId];

  // Checked before the upsert so we know whether this is a first-time rating
  // for this lesson — Green Points only pay out once per lesson, otherwise
  // editing a rating repeatedly would farm free points.
  const { data: existingRating } = await supabase.from("topic_ratings").select("student_id")
    .eq("lesson_id", lessonId).eq("student_id", sstate.student.id).maybeSingle();

  // topic_ratings stays the "current" pointer teacher.js aggregates against;
  // topic_ratings_history logs every submission so the student sees a trend.
  const { error } = await supabase.from("topic_ratings").upsert(
    { lesson_id: lessonId, student_id: sstate.student.id, section_id: sstate.section.id, rating, comment: comment || null, updated_at: new Date().toISOString() },
    { onConflict: "lesson_id,student_id" }
  );
  if (error) { toast("Error: " + error.message); return; }

  await supabase.from("topic_ratings_history").insert(
    { lesson_id: lessonId, student_id: sstate.student.id, section_id: sstate.section.id, rating, comment: comment || null }
  );

  // Green Points for the Math Pet — only on a genuine first rating of this
  // lesson, and only in Math sections (that's where the Pet feature lives).
  // 10 Green Points for a plain star rating; 20 if the student also wrote a
  // reflection (the optional comment) with it.
  if (!existingRating && typeof awardGreenPoints === "function" && isMathSubjectStudent(sstate.section && sstate.section.subject)) {
    await awardGreenPoints(comment ? 20 : 10, false);
    if (typeof markDailyActivity === "function") await markDailyActivity("rating");
  }

  if (helpFlagged) {
    await supabase.from("help_flags").upsert(
      { lesson_id: lessonId, student_id: sstate.student.id, section_id: sstate.section.id, flagged_at: new Date().toISOString(), addressed_by_teacher: false, addressed_at: null },
      { onConflict: "lesson_id,student_id" }
    );
  } else {
    await supabase.from("help_flags").delete().eq("lesson_id", lessonId).eq("student_id", sstate.student.id);
  }

  toast("Thanks! Your rating helps your teacher plan review sessions.");
  if (typeof triggerPetEvent === "function" && isMathSubjectStudent(sstate.section && sstate.section.subject)) triggerPetEvent("OWNER_RATING");

  // Refresh in place: the current week's widget lives inside renderOverview's
  // own markup, but a past-week widget lives in its own lazy-loaded mount —
  // reloading just that mount keeps the "Previous Weeks" accordion expanded.
  if (lessonId === sstate.currentLessonId) {
    renderOverview();
  } else {
    const mount = document.getElementById(`pastLessonWidget_${lessonId}`);
    if (mount) { mount.dataset.loaded = ""; loadPastLessonWidget(lessonId); }
    else renderOverview();
  }
}

// ============================================================================
// PAST-WEEK RATINGS — students can rate or update any earlier lesson too,
// not just the current week's. Rendered inside a lazy-loaded accordion on
// Overview so we don't fetch rating data for every week on every page load.
// ============================================================================
async function loadPastLessonWidget(lessonId) {
  const mount = document.getElementById(`pastLessonWidget_${lessonId}`);
  if (!mount || mount.dataset.loaded === "1") return;
  mount.dataset.loaded = "1";
  mount.innerHTML = `<p class="muted">Loading…</p>`;

  const { data: r } = await supabase.from("topic_ratings").select("*").eq("lesson_id", lessonId).eq("student_id", sstate.student.id).maybeSingle();
  const { data: hist } = await supabase.from("topic_ratings_history").select("rating, submitted_at").eq("lesson_id", lessonId).eq("student_id", sstate.student.id).order("submitted_at", { ascending: true });
  const { data: allRatings } = await supabase.from("topic_ratings").select("rating").eq("lesson_id", lessonId);
  let classContext = null;
  if (allRatings && allRatings.length > 0) {
    const total = allRatings.length;
    const struggling = allRatings.filter((x) => x.rating <= 3).length;
    classContext = { total, pct: Math.round((struggling / total) * 100) };
  }
  const { data: rt } = await supabase.from("reteach_notes").select("*").eq("lesson_id", lessonId).maybeSingle();
  const { data: hf } = await supabase.from("help_flags").select("*").eq("lesson_id", lessonId).eq("student_id", sstate.student.id).maybeSingle();

  mount.innerHTML = `
    ${renderRatingWidget(lessonId, r, hist || [], classContext, hf)}
    ${rt ? `
    <div style="margin-top:12px;padding:10px;background:var(--sky-light);border-radius:8px;">
      <div class="muted" style="font-size:.8rem;">🔁 Re-teach recap from your teacher</div>
      <strong>${escapeHtml(rt.title)}</strong>
      ${TN.viewerHtml("rtp_" + lessonId, { text: rt.content, url: rt.link_url, label: "Recap material" })}
    </div>` : ""}`;
}

// ============================================================================
// GRADES — Class Record breakdown (WW/PT/EX per term)
// ============================================================================
async function renderGrades() {
  const el = document.getElementById("tab-grades");
  if (sstate.terms.length === 0) { el.innerHTML = `<div class="empty">No grades recorded yet.</div>`; return; }
  const weights = getSectionWeights(sstate.section);
  const wwPct = Math.round(weights.WW * 100), ptPct = Math.round(weights.PT * 100), exPct = Math.round(weights.EX * 100);

  const termResults = [];
  for (const term of sstate.terms) {
    const { data: assessments } = await supabase.from("assessments").select("*").eq("term_id", term.id).order("date_given");
    const { data: scores } = await supabase.from("scores").select("*").eq("student_id", sstate.student.id).in("assessment_id", (assessments || []).map((a) => a.id).length ? (assessments || []).map((a) => a.id) : ["00000000-0000-0000-0000-000000000000"]);
    const byAssessment = {};
    (scores || []).forEach((s) => (byAssessment[s.assessment_id] = s));
    const g = computeTermGrade(assessments || [], byAssessment, weights);
    termResults.push({ term, g, assessments: assessments || [], byAssessment });
  }
  const finalGrade = computeFinalGrade(termResults.map((r) => r.g.termGrade));
  const finalDesc = gradeDescriptor(finalGrade);

  el.innerHTML = `
    <div class="grid grid-3">
      ${termResults.map(({ term, g, assessments, byAssessment }) => {
        const d = gradeDescriptor(g.termGrade);
        const wc = wwPerformanceCategory(g.wwPS);
        return `
        <div class="card">
          <div class="muted">${escapeHtml(term.term_name)}</div>
          <h2 style="font-size:2.2rem;margin:6px 0;color:${d.color};">${g.termGrade !== null ? g.termGrade : "—"}</h2>
          <div class="muted" style="margin-bottom:10px;">${d.label}</div>
          <div style="display:flex;justify-content:space-between;align-items:baseline;">
            <div class="muted" style="font-size:.8rem;">Written Works (${wwPct}%) — ${g.wwPS !== null ? g.wwPS.toFixed(1) + "%" : "no data"}</div>
            <span class="badge" style="background:${wc.bg};color:${wc.color};">${wc.label}</span>
          </div>
          <div class="gbar"><div style="width:${g.wwPS || 0}%;"></div></div>
          <div class="muted" style="font-size:.8rem;margin-top:8px;">Performance Tasks (${ptPct}%) — ${g.ptPS !== null ? g.ptPS.toFixed(1) + "%" : "no data"}</div>
          <div class="gbar"><div style="width:${g.ptPS || 0}%;background:var(--gold);"></div></div>
          <div class="muted" style="font-size:.8rem;margin-top:8px;">Examinations (${exPct}%) — ${g.exPS !== null ? g.exPS.toFixed(1) + "%" : "no data"}</div>
          <div class="gbar"><div style="width:${g.exPS || 0}%;background:var(--clay);"></div></div>
          <details style="margin-top:12px;">
            <summary style="cursor:pointer;color:var(--gold);font-size:.83rem;font-weight:600;">View item breakdown</summary>
            ${renderAssessmentBreakdown(assessments, byAssessment)}
          </details>
        </div>`;
      }).join("")}
    </div>
    <div class="card" style="margin-top:16px;text-align:center;">
      <div class="muted">Final Grade (Average of 3 Terms)</div>
      <h1 style="font-size:3rem;color:${finalDesc.color};">${finalGrade !== null ? finalGrade : "—"}</h1>
      <div style="color:${finalDesc.color};font-weight:600;">${finalDesc.label}</div>
    </div>
    <p class="muted" style="margin-top:10px;">Based on DepEd Order No. 015, s. 2026 grading weights for ${escapeHtml(sstate.section.subject || "this subject")}: Written Works ${wwPct}% · Performance Tasks ${ptPct}% · Examinations ${exPct}%.</p>`;
}

// Renders each individual assessment's score, grouped by component (WW/PT/EX),
// with EX further labeled by subtype (ST1/ST2/TE) — used inside the expandable
// "View item breakdown" section on the Grades tab.
function renderAssessmentBreakdown(assessments, byAssessment) {
  const groups = { WW: [], PT: [], EX: [] };
  assessments.forEach((a) => groups[a.component].push(a));
  const labels = { WW: "Written Works", PT: "Performance Tasks", EX: "Examinations" };
  const subtypeLabels = { ST1: "Summative Test 1", ST2: "Summative Test 2", TE: "Term Exam" };

  const sections = ["WW", "PT", "EX"].map((comp) => {
    const list = groups[comp];
    if (list.length === 0) return "";
    return `
      <div style="margin-top:10px;">
        <div class="muted" style="font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.03em;">${labels[comp]}</div>
        <table style="margin-top:2px;">
          <tbody>
            ${list.map((a) => {
              const entry = byAssessment[a.id];
              const status = entry ? entry.status : null;
              const subtypeTag = a.component === "EX" && a.ex_subtype ? ` <span class="muted">— ${subtypeLabels[a.ex_subtype] || a.ex_subtype}</span>` : "";
              let scoreCell;
              if (status === "excused") {
                scoreCell = `<span style="color:var(--ink-soft);font-weight:600;">Excused</span>`;
              } else if (status === "unexcused") {
                scoreCell = `<span style="color:var(--clay);font-weight:700;">Unexcused (0)</span>`;
              } else {
                const hasScore = entry && entry.raw_score !== undefined && entry.raw_score !== null && entry.raw_score !== "";
                scoreCell = `<span style="font-weight:${hasScore ? "600" : "400"};color:${hasScore ? "var(--ink)" : "var(--ink-soft)"};">${hasScore ? entry.raw_score : "—"} / ${a.highest_possible_score}</span>`;
              }
              return `<tr>
                <td style="padding:3px 8px 3px 0;font-size:.85rem;">${escapeHtml(a.title)}${subtypeTag}</td>
                <td class="num" style="padding:3px 0;text-align:right;font-size:.85rem;">${scoreCell}</td>
              </tr>`;
            }).join("")}
          </tbody>
        </table>
      </div>`;
  }).join("");

  return sections || `<p class="muted" style="margin-top:8px;">No assessments recorded yet this term.</p>`;
}

// ============================================================================
// ATTENDANCE
// ============================================================================
async function renderStudentAttendance() {
  const el = document.getElementById("tab-attendance");
  if (!estate.loaded) await loadEngagement();
  // AUDIT FIX (2026-09): this used to query `attendance` by student_id ONLY
  // — no section_id filter and no term/date scoping at all — so it showed a
  // permanently unscoped lifetime total with no way to check "how many days
  // was I present in Term 2 specifically" (unlike the Grades tab, which was
  // already correctly broken out per term). It's now scoped to the current
  // section, and broken out per term using the same termDateRange() helper
  // teacher.js uses for its Attendance Summary, so the two screens agree on
  // what "this term" means.
  const { data } = await supabase.from("attendance").select("*")
    .eq("student_id", sstate.student.id).eq("section_id", sstate.section.id)
    .order("attendance_date", { ascending: false });
  const all = data || [];
  const labels = { present: "Present", late: "Late", absent_excused: "Absent (Excused)", absent_unexcused: "Absent (Unexcused)" };
  const countOf = (list) => {
    const c = { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0 };
    list.forEach((a) => c[a.status]++);
    return c;
  };
  const overallCounts = countOf(all);

  const termCards = (sstate.terms || []).map((term) => {
    const range = termDateRange(term, sstate.section.school_year);
    const inTerm = all.filter((a) => a.attendance_date >= range.start && a.attendance_date <= range.end);
    const c = countOf(inTerm);
    return { term, range, counts: c, total: inTerm.length };
  });

  el.innerHTML = `
    <div id="streakWidgetMount"></div>
    <h4 style="margin-bottom:8px;">All Terms Combined (${escapeHtml(sstate.section.section_name)})</h4>
    <div class="grid grid-3" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px;">
      ${Object.keys(overallCounts).map((k) => `
        <div class="card" style="text-align:center;">
          <div class="muted" style="font-size:.78rem;">${labels[k]}</div>
          <div style="font-size:1.8rem;font-weight:700;font-family:'Poppins';">${overallCounts[k]}</div>
        </div>`).join("")}
    </div>

    ${termCards.length ? `
    <h4 style="margin-bottom:8px;">Per Term</h4>
    <div class="grid grid-3" style="margin-bottom:16px;">
      ${termCards.map(({ term, range, counts, total }) => `
        <div class="card">
          <div class="muted" style="font-size:.8rem;">${escapeHtml(term.term_name)} <span style="font-size:.72rem;">(${fmtDate(range.start)} – ${fmtDate(range.end)})</span></div>
          <div style="display:flex;justify-content:space-between;margin-top:8px;font-size:.85rem;">
            <span>Present: <strong>${counts.present}</strong></span><span>Late: <strong>${counts.late}</strong></span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-top:4px;font-size:.85rem;">
            <span>Absent (Exc.): <strong>${counts.absent_excused}</strong></span><span>Absent (Unexc.): <strong>${counts.absent_unexcused}</strong></span>
          </div>
          ${total === 0 ? `<p class="muted" style="font-size:.72rem;margin-top:6px;">No attendance recorded yet for this term.</p>` : ""}
        </div>`).join("")}
    </div>` : ""}

    <div class="card">
      <h4>Attendance Log</h4>
      ${all.length === 0 ? `<p class="muted">No attendance recorded yet.</p>` : `
      <table>
        <thead><tr><th>Date</th><th>Status</th></tr></thead>
        <tbody>${all.map((a) => `<tr><td>${fmtDate(a.attendance_date)}</td><td><span class="badge badge-${a.status}">${labels[a.status]}</span></td></tr>`).join("")}</tbody>
      </table>`}
    </div>`;
  if (typeof renderStreakWidget === "function") renderStreakWidget("streakWidgetMount");
}

async function renderStudentBlended() {
  const el = document.getElementById("tab-blended");
  if (!sstate.term) { el.innerHTML = `<div class="empty">Nothing here yet.</div>`; return; }
  const scope = sstate.gradeScope || { termIds: [sstate.term.id], sectionNameById: {} };
  if (sstate.blTab === "notes") {
    el.innerHTML = `${TN.studentTabsHtml("notes")}<div id="stuNotesMount"></div>`;
    await TN.renderStudentNotes(document.getElementById("stuNotesMount"), { termIds: scope.termIds, sectionId: sstate.section.id, sectionNameById: scope.sectionNameById });
    return;
  }
  const { data: modules } = await supabase.from("modules").select("*").in("term_id", scope.termIds).order("week_number");
  const { data: schedule } = await supabase.from("schedule").select("*").in("term_id", scope.termIds).order("week_number");
  const moduleIds = (modules || []).map((m) => m.id);

  const { data: myReflections } = moduleIds.length
    ? await supabase.from("reflections_v2").select("*").eq("student_id", sstate.student.id).in("module_id", moduleIds)
    : { data: [] };
  const reflectionByModule = {}; (myReflections || []).forEach((r) => (reflectionByModule[r.module_id] = r));

  const { data: faqs } = moduleIds.length
    ? await supabase.from("module_faq").select("*").in("module_id", moduleIds).order("posted_at", { ascending: false })
    : { data: [] };
  const faqByModule = {}; (faqs || []).forEach((f) => { (faqByModule[f.module_id] = faqByModule[f.module_id] || []).push(f); });

  const { data: parentNotes } = moduleIds.length
    ? await supabase.from("module_parent_notes").select("*").in("module_id", moduleIds)
    : { data: [] };
  const parentNoteByModule = {}; (parentNotes || []).forEach((p) => (parentNoteByModule[p.module_id] = p));

  el.innerHTML = `
    ${TN.studentTabsHtml("las")}
    <p class="muted">Used when classes shift to blended learning (DepEd-declared suspension/emergency). Review each Learning Activity Sheet (LAS) below and jot down a short reflection — no file needed. Your printed output goes to your teacher once face-to-face classes resume.</p>
    <div class="card">
      <h3 style="margin-top:0;">📄 Learning Activity Sheets</h3>
      ${(modules || []).length === 0 ? `<p class="muted">No LAS posted yet.</p>` : modules.map((m) => {
        const myRef = reflectionByModule[m.id];
        const pn = parentNoteByModule[m.id];
        const faqList = faqByModule[m.id] || [];
        const otherSectionName = m.section_id !== sstate.section.id ? scope.sectionNameById[m.section_id] : null;
        return `
        <div style="padding:14px 0;border-bottom:1px solid var(--paper-line);">
          <div class="muted">Week ${m.week_number || "—"} · <span class="badge badge-ww">${m.modality || "online"}</span>${otherSectionName ? ` · <span class="badge badge-pt">Posted for ${escapeHtml(otherSectionName)}</span>` : ""}</div>
          <strong>${escapeHtml(m.title)}</strong>
          <p class="muted">${escapeHtml(m.description || "")}</p>
          ${m.file_url ? `
            <div class="pdf-viewer-frame"><iframe src="${escapeHtml(toEmbeddablePdfUrl(m.file_url))}" loading="lazy"></iframe></div>
            <a href="${escapeHtml(m.file_url)}" target="_blank" style="font-size:.85rem;">Open in a new tab ↗</a>` : ""}
          ${pn ? `<div style="margin-top:10px;padding:8px 10px;background:var(--gold-light);border-radius:8px;font-size:.85rem;">👨‍👩‍👧 <strong>For parents:</strong> ${escapeHtml(pn.parent_note)}</div>` : ""}
          ${faqList.length > 0 ? `
            <details style="margin-top:8px;">
              <summary class="muted" style="cursor:pointer;">❓ Frequently Asked Questions (${faqList.length})</summary>
              ${faqList.map((f) => `<p style="margin:8px 0;padding:6px 10px;background:var(--sky-light);border-radius:8px;"><strong>Q:</strong> ${escapeHtml(f.question)}<br><strong>A:</strong> ${escapeHtml(f.answer)}</p>`).join("")}
            </details>` : ""}
          <div style="margin-top:10px;padding:10px;background:var(--sage-light);border-radius:8px;">
            <div class="muted" style="margin-bottom:6px;">📝 My reflection on this LAS</div>
            <label class="muted" style="display:block;font-size:.8rem;margin-bottom:2px;">One thing I learned…</label>
            <textarea id="learned_${m.id}" rows="2">${escapeHtml((myRef && myRef.learned) || "")}</textarea>
            <label class="muted" style="display:block;font-size:.8rem;margin:8px 0 2px;">One thing that confused me…</label>
            <textarea id="confused_${m.id}" rows="2">${escapeHtml((myRef && myRef.confused) || "")}</textarea>
            <label class="muted" style="display:block;font-size:.8rem;margin:8px 0 2px;">One question for my teacher…</label>
            <textarea id="question_${m.id}" rows="2">${escapeHtml((myRef && myRef.question) || "")}</textarea>
            <label style="display:flex;align-items:center;gap:6px;margin-top:10px;font-size:.85rem;cursor:pointer;">
              <input type="checkbox" id="reviewed_${m.id}" ${myRef && myRef.material_reviewed ? "checked" : ""}>
              I reviewed this LAS material
            </label>
            <button class="btn-primary btn-sm" style="margin-top:8px;" onclick="submitReflection('${m.id}')">${myRef ? "Update My Reflection" : "Save My Reflection"}</button>
            ${myRef ? `<p class="muted" style="margin-top:6px;">✅ Seen ${new Date(myRef.acknowledged_at || myRef.submitted_at).toLocaleString()}</p>` : ""}
            ${myRef && myRef.teacher_feedback ? `<div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--paper-line);"><span class="muted">💬 Feedback from your teacher:</span><p>${escapeHtml(myRef.teacher_feedback)}</p></div>` : ""}
          </div>
        </div>`;
      }).join("")}
    </div>
    <div class="card" style="margin-top:16px;">
      <h3 style="margin-top:0;">🗓️ Weekly Schedule (Online/Offline)</h3>
      ${(schedule || []).length === 0 ? `<p class="muted">No schedule posted yet.</p>` : `
      <table>
        <thead><tr><th>Week</th><th>Day</th><th>Mode</th><th>Activity</th></tr></thead>
        <tbody>${schedule.map((r) => {
          const otherSectionName = r.section_id !== sstate.section.id ? scope.sectionNameById[r.section_id] : null;
          return `<tr><td class="num">${r.week_number}</td><td>${escapeHtml(r.day_label)}${otherSectionName ? ` <span class="badge badge-pt" style="font-size:.7rem;">${escapeHtml(otherSectionName)}</span>` : ""}</td><td><span class="badge badge-ww">${r.modality}</span></td><td>${escapeHtml(r.activity || "")}</td></tr>`;
        }).join("")}</tbody>
      </table>`}
    </div>`;
}
async function submitReflection(moduleId) {
  const learned = document.getElementById(`learned_${moduleId}`).value.trim();
  const confused = document.getElementById(`confused_${moduleId}`).value.trim();
  const question = document.getElementById(`question_${moduleId}`).value.trim();
  const material_reviewed = document.getElementById(`reviewed_${moduleId}`).checked;
  if (!learned && !confused && !question) { toast("Write at least one reflection first."); return; }
  const { error } = await supabase.from("reflections_v2").upsert(
    {
      module_id: moduleId, student_id: sstate.student.id, section_id: sstate.section.id,
      learned: learned || null, confused: confused || null, question: question || null,
      material_reviewed, updated_at: new Date().toISOString(), acknowledged_at: new Date().toISOString(),
    },
    { onConflict: "module_id,student_id" }
  );
  if (error) { toast("Error: " + error.message); return; }
  toast("Reflection saved! ✅ Seen");
  renderStudentBlended();
}

// ============================================================================
// LEGENDS TAB — Eureka gem sub-tier, the Archimedes Trial, and the Grade
// Champion race. Only meaningful once a student is at least close to tier
// 15, but visible to everyone so it's a goal to see coming.
// (rankEngine.js, trialEngine.js, championshipEngine.js)
// ============================================================================
async function renderLegendsTab() {
  const el = document.getElementById("tab-legends");
  el.innerHTML = `<div class="empty">Loading your MathLegends standing…</div>`;

  const { data: p } = await supabase.from("drill_progress")
    .select("mastery_tier, mastery_stars, post_eureka_stars, trial_clears_count, trial_last_cleared_at")
    .eq("student_id", sstate.student.id).maybeSingle();

  const tier = (p && p.mastery_tier) || 1;
  const isEureka = tier >= RANK_MAX_TIER;
  const tierObj = rankTierByLevel(tier);

  let gemSection = "";
  if (isEureka) {
    gemSection = `
    <div class="card" style="border-left:4px solid var(--gold);margin-bottom:16px;">
      <div class="pill" style="background:var(--gold-light);color:var(--forest-dark);">${tierObj.emoji} ${escapeHtml(tierObj.name)}</div>
      <h2 style="margin:10px 0 4px;">${renderEurekaGemBadge(p.post_eureka_stars || 0, { withProgress: true })}</h2>
      ${p.trial_clears_count > 0 ? `<p class="muted" style="margin-top:8px;">🏛️ Cleared the Archimedes Trial ${p.trial_clears_count}x — last on ${p.trial_last_cleared_at ? fmtDate(p.trial_last_cleared_at) : "—"}.</p>` : ""}
    </div>`;
  } else {
    gemSection = `
    <div class="card" style="border-left:4px solid var(--sky);margin-bottom:16px;">
      <div class="pill" style="background:var(--sky-light);color:var(--forest);">${tierObj.emoji} ${escapeHtml(tierObj.name)}</div>
      <p class="muted" style="margin-top:8px;">Reach ${RANK_TIERS[RANK_MAX_TIER - 1].name} (Tier 15) to unlock Eureka gem sub-tiers, the Archimedes Trial, and a spot in the Grade Champion race.</p>
    </div>`;
  }

  el.innerHTML = `<div class="grid grid-2" style="align-items:start;">
    <div>${gemSection}<div id="legendsTrialSlot"></div></div>
    <div><div id="legendsChampSlot"></div></div>
  </div>`;

  // Trial + Championship both require live RPC calls — load independently
  // so a slow one doesn't block the other from rendering.
  if (isEureka) {
    loadTrialStatus().then((status) => {
      document.getElementById("legendsTrialSlot").innerHTML = renderArchimedesTrialCard(status);
    });
    fetchMyChampionshipScore(sstate.student.id).then((score) => {
      document.getElementById("legendsChampSlot").innerHTML = renderMyChampionshipCard(score);
      if (score && score.eligible && sstate.section && sstate.section.grade_level) {
        fetchGradeChampionStandings(sstate.section.grade_level, 20).then((rows) => {
          document.getElementById("legendsChampSlot").innerHTML += renderChampionshipStandingsCard(rows, sstate.section.grade_level, sstate.student.id);
        });
      }
    });
  } else {
    document.getElementById("legendsTrialSlot").innerHTML = "";
    document.getElementById("legendsChampSlot").innerHTML = `<div class="card"><p class="muted">The Grade Champion board unlocks once you reach Eureka rank.</p></div>`;
  }
}

// ============================================================================
// MY REPORT CARD — embeds report-card.html (locked to this student/section,
// term-selectable) so the full report is viewable and saveable-as-PDF right
// from the student dashboard, with no need to ever print it on paper.
// ============================================================================
function renderStudentReportCard() {
  const el = document.getElementById("tab-report");
  const terms = sstate.terms || [];
  const activeTermId = (sstate.term && sstate.term.id) || (terms[0] && terms[0].id) || "";

  if (terms.length === 0) {
    el.innerHTML = `<div class="card"><p class="muted">No terms have been set up for your section yet — check back once your teacher adds one.</p></div>`;
    return;
  }

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-top:0;">🖨️ My Report Card</h3>
      <p class="muted">Your full report card — grades, attendance, lesson understanding, and progress — for any term. View it here anytime; save it as a PDF from the "Export to PDF" button inside if you'd like your own copy, no printing needed.</p>
      <div class="field" style="max-width:280px;">
        <label>Term</label>
        <select id="reportTermSelect" onchange="loadStudentReportCardFrame()">
          ${terms.map((t) => `<option value="${t.id}" ${t.id === activeTermId ? "selected" : ""}>${escapeHtml(t.term_name)}${t.is_active ? " (current)" : ""}</option>`).join("")}
        </select>
      </div>
    </div>
    <div style="border-radius:14px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);background:#EDF1EC;">
      <iframe id="reportCardFrame" title="My Report Card" style="width:100%;height:82vh;border:none;display:block;"></iframe>
    </div>`;
  loadStudentReportCardFrame();
}

function loadStudentReportCardFrame() {
  const frame = document.getElementById("reportCardFrame");
  const termSel = document.getElementById("reportTermSelect");
  const termId = termSel ? termSel.value : (sstate.term && sstate.term.id);
  if (!frame || !termId) return;
  const src = `report-card.html?embed=1&section=${encodeURIComponent(sstate.section.id)}&student=${encodeURIComponent(sstate.student.id)}&term=${encodeURIComponent(termId)}`;
  frame.src = src;
}
