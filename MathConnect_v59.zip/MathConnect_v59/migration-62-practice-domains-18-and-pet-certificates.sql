-- ============================================================================
-- MathConnect — Migration 62 (v55)
--   1. Intelligent Practice grows from 12 to 18 domains, matching the 18 Math
--      Drill stations: Exponents & Radicals, Equation Scale, Factor Vault,
--      Farm Measure, Grid Navigator, Surveyor's Post.
--   2. Station certificates can now be issued for Legendary pets
--      (source 'pet', kind 'legendary').
--
-- Run AFTER migration-25 (practice_domains.locked) and migration-61
-- (station_certificates). SAFE TO RE-RUN.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. Six new practice domains.
--    They ship UNLOCKED (the six matching Drill stations from migration-47 are
--    also unlocked), so students can practise them right away. Lock any of them
--    from Admin -> "Intelligent Practice Domains" if you want to hold them back.
--    Re-running never re-locks/unlocks a row an admin has already changed.
--
--    NOTE: the Archimedes Trial / Grand Champion formulas (migrations 44 and 53)
--    count every ACTIVE practice domain, so "expert in every Intelligent
--    Practice domain" now means 18 domains instead of 12 — the same way the
--    Trial already requires all 18 Drill stations.
-- ----------------------------------------------------------------------------
insert into practice_domains (domain_key, label, term_added, active, locked) values
  ('exponents',   'Exponents & Radicals', 3, true, false),
  ('equations',   'Equation Scale',       3, true, false),
  ('factoring',   'Factor Vault',         3, true, false),
  ('measurement', 'Farm Measure',         3, true, false),
  ('coordinates', 'Grid Navigator',       3, true, false),
  ('pythagoras',  'Surveyor''s Post',     3, true, false)
on conflict (domain_key) do update set label = excluded.label;

-- ----------------------------------------------------------------------------
-- 2. Legendary Pet certificates: widen the two CHECK constraints on
--    station_certificates. The old constraints are found by definition (their
--    auto-generated names can differ between projects), dropped, and replaced
--    with named ones that also allow 'pet' / 'legendary'.
--    Skipped quietly if migration-61 hasn't been run yet (the app then keeps
--    certificates on the student's device until it is).
-- ----------------------------------------------------------------------------
do $$
declare
  c record;
begin
  if to_regclass('public.station_certificates') is null then
    raise notice 'station_certificates not found - run migration-61 first, then re-run this migration to enable Legendary Pet certificates.';
    return;
  end if;

  for c in
    select conname
    from pg_constraint
    where conrelid = 'public.station_certificates'::regclass
      and contype = 'c'
      and pg_get_constraintdef(oid) ~* '\m(source|kind)\M'
  loop
    execute format('alter table public.station_certificates drop constraint %I', c.conname);
  end loop;

  alter table public.station_certificates
    add constraint station_certificates_source_check
    check (source in ('drills', 'quest', 'practice', 'pet'));

  alter table public.station_certificates
    add constraint station_certificates_kind_check
    check (kind in ('completion', 'excellence', 'perfect', 'chapter', 'legendary'));
end
$$;

-- ============================================================================
-- Done. Nothing else to configure:
--   * Students see the six new cards in "Intelligent Practice" after a refresh.
--   * Every pet that is (or becomes) Legendary gets ONE certificate, issued
--     automatically the next time the student opens the app or the moment the
--     pet evolves — including pets that were already Legendary before today.
-- ============================================================================
