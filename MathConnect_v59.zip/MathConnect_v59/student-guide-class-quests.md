# MathConnect: Let's Work Together! 🌱
### A quick guide to the new Class Quest features

MathConnect isn't just about who's #1 anymore. We added a few features so your **whole class can win together** — and so nobody has to feel bad just because someone else scored higher. Here's how it works.

---

## 🌱 Class Quest — Your Class's Shared Goal

Your teacher can set up a **Class Quest**: one shared points goal for the *entire class* to reach together — like "1,000 points for a free-choice activity Friday."

**How to contribute:**
- Just do your normal Drill practice — any topic, any station.
- Every point you earn from a drill (as long as you're not in the negatives) automatically adds to your class's shared total. You don't need to do anything extra.

**Where to see it:**
- Open the **Drills** tab. At the very top, you'll see a green progress bar labeled **🌱 Class Quest** showing:
  - The class's combined progress toward the goal
  - The reward your teacher set
  - How many points *you personally* have contributed

**What happens when the goal is reached:**
- Everyone gets a celebration message, and your teacher gives out the reward. 🎉

> There's no ranked list of who contributed the most — this is about the whole class getting there together, not about outscoring your classmates.

---

## 🌱 Most Improved — A Fresh Start Every Week

Next to the regular leaderboard, there's now a **🌱 Most Improved** tab.

- This board only counts points you earned **in the last 7 days** — not your whole history.
- That means **every week is a clean slate.** Even if you're new to a topic or had a slow start, you have just as much of a shot at this board as anyone else.
- To check it: open any drill's **Leaderboard**, then tap the **🌱 Most Improved** tab at the top.

---

## 🙈 Show or Hide Yourself on Leaderboards

Not everyone loves being ranked publicly — and that's completely okay.

- Open any **Leaderboard** from the Drills tab.
- At the top, you'll see a checkbox: **"Show me on leaderboards."**
- **Uncheck it** if you'd rather not appear on the Top 10 lists your classmates see. Your own private stats, progress, and rank are still there for *you* — you're just hidden from everyone else's view.
- **Check it again** anytime if you change your mind.

---

## 💡 A Few Reminders

- Helping your class hit a Class Quest goal now counts toward your own progress too (it's even part of the requirements for the highest ranks) — so helping others really does help you.
- It's okay to hide from leaderboards. It's okay to have a slow week and bounce back the next. Progress matters more than rank.
- Cheer each other on — a classmate doing well on a drill isn't a loss for you.

**Questions?** Ask your teacher — they can also show you the Class Quest progress from their side.
