-- ============================================================================
-- Migration 31 — Boss Battle Tournaments (single-elimination bracket)
-- Run this once in Supabase → SQL Editor. Like migration-18-boss-battles.sql
-- and migration-24-eureka-legacy-champion.sql, this one is NOT folded into
-- supabase-schema.sql yet — run it even on a brand-new project.
--
-- HOW IT WORKS (read this before running):
--   - A teacher creates a `tournaments` row (scoped to one section) and
--     students see a "🏆 Join Tournament" button while it's `open`.
--   - When the teacher clicks "Generate Bracket & Start", the client calls
--     generate_tournament_bracket(), which does the shuffle AND the bye
--     placement itself, server-side, with `order by random()` — so the
--     pairing can't be biased or predicted by either the teacher's or a
--     student's browser. This is the single most important trust boundary
--     in this feature, matching the note in migration-18 that arbitration
--     always happens in Postgres, never client JS.
--   - Every matchup reuses the *exact same* `battles` table and 5-round
--     real-time engine as a normal Boss Battle challenge (per your setup
--     choice) — a tournament match IS a `battles` row under the hood, just
--     one that a `tournament_matches` row points to. Nothing about how a
--     battle plays out changes; only how the pairing happens and what
--     happens after it ends is new.
--   - A trigger on `battles` (trg_handle_tournament_battle_complete) fires
--     whenever a battle linked to a tournament match finishes:
--       • decisive result → advance_tournament_match() moves the winner
--         into their next-round slot (or crowns them champion if this was
--         the final).
--       • true draw (health AND round-wins tied — rare, but a single-
--         elimination bracket can't leave a match undecided) → instead of
--         inventing new battle mechanics, it simply starts a fresh 5-round
--         rematch between the same two students and re-points the match at
--         the new battle. Boss Battle mechanics stay completely untouched.
--   - Byes (when the roster isn't a power of 2) are assigned to random
--     slots at generation time, not clustered at the end, and resolve
--     instantly — that student's opponent slot just says "BYE" and they
--     advance automatically.
--
-- ⚠️ TRUST NOTE: same open-client-write model as the rest of this app (see
--   migration-18's note) — this is a low-stakes classroom game, not a
--   secured competitive platform.
-- ============================================================================

-- ---------- TOURNAMENTS ----------
create table if not exists tournaments (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade not null,
  teacher_id uuid references teachers(id) on delete set null,
  name text not null default 'Boss Battle Tournament',
  topic text not null default 'mixed',  -- one of DRILL_TOPICS keys, or 'mixed'
  status text not null default 'open' check (status in ('open','in_progress','completed','cancelled')),
  bracket_size int,               -- set once the bracket is generated (next power of 2 >= participant count)
  champion_id uuid references students(id),
  created_at timestamptz default now(),
  started_at timestamptz,
  completed_at timestamptz
);
create index if not exists tournaments_section_idx on tournaments (section_id, status);

-- ---------- PARTICIPANTS (who hit "Join Tournament" while it was open) ----------
create table if not exists tournament_participants (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references tournaments(id) on delete cascade not null,
  student_id uuid references students(id) on delete cascade not null,
  joined_at timestamptz default now(),
  unique (tournament_id, student_id)
);
create index if not exists tournament_participants_tournament_idx on tournament_participants (tournament_id);

-- ---------- BRACKET MATCHES (one row per bracket slot; drives the tree UI) ----------
create table if not exists tournament_matches (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references tournaments(id) on delete cascade not null,
  round_number int not null,
  slot_index int not null,             -- position within the round, 0-based; feeds slot_index/2 next round
  participant_a_id uuid references students(id),
  participant_b_id uuid references students(id),
  is_bye boolean not null default false,
  battle_id uuid references battles(id),
  winner_id uuid references students(id),
  status text not null default 'pending' check (status in ('pending','ready','active','completed','bye')),
  -- pending: participant(s) not decided yet (waiting on earlier matches)
  -- ready:   both participants known, battle not started yet
  -- active:  battle_id is set, battle in progress
  -- completed: winner_id set, resolved
  -- bye:     one participant auto-advanced, no battle was played
  created_at timestamptz default now(),
  completed_at timestamptz,
  unique (tournament_id, round_number, slot_index)
);
create index if not exists tournament_matches_tournament_idx on tournament_matches (tournament_id, round_number);
create index if not exists tournament_matches_battle_idx on tournament_matches (battle_id);

-- ============================================================================
-- BRACKET GENERATION — random shuffle + random bye placement, all server-side
-- ============================================================================
create or replace function public.generate_tournament_bracket(p_tournament_id uuid)
returns void language plpgsql security definer as $$
declare
  v_tournament tournaments%rowtype;
  v_participants uuid[];
  v_n int;
  v_bracket_size int;
  v_rounds int;
  v_slots uuid[];
  v_positions int[];
  v_a uuid;
  v_b uuid;
  v_bye_winner uuid;
  i int;
  r int;
  matches_in_round int;
begin
  select * into v_tournament from tournaments where id = p_tournament_id for update;
  if not found then raise exception 'Tournament not found'; end if;
  if v_tournament.status <> 'open' then raise exception 'Tournament already started or closed'; end if;

  select array_agg(student_id order by random()) into v_participants
  from tournament_participants where tournament_id = p_tournament_id;
  v_n := coalesce(array_length(v_participants, 1), 0);
  if v_n < 2 then raise exception 'Need at least 2 joined students to start a tournament'; end if;

  -- smallest power of 2 that fits everyone
  v_bracket_size := 1;
  while v_bracket_size < v_n loop
    v_bracket_size := v_bracket_size * 2;
  end loop;
  v_rounds := 0;
  declare v_bs int := v_bracket_size;
  begin
    while v_bs > 1 loop v_bs := v_bs / 2; v_rounds := v_rounds + 1; end loop;
  end;

  -- Spread real students across bracket_size slots at random positions, so
  -- byes (the leftover empty slots) land randomly rather than clustering
  -- at the end of the bracket.
  v_slots := array_fill(null::uuid, array[v_bracket_size]);
  select array_agg(x order by random()) into v_positions from generate_series(1, v_bracket_size) as x;
  for i in 1..v_n loop
    v_slots[v_positions[i]] := v_participants[i];
  end loop;

  -- Round 1 matches (real vs real = 'ready', real vs empty = instant 'bye')
  matches_in_round := v_bracket_size / 2;
  for i in 0..matches_in_round - 1 loop
    v_a := v_slots[i * 2 + 1];
    v_b := v_slots[i * 2 + 2];
    v_bye_winner := case when v_a is null then v_b when v_b is null then v_a else null end;
    insert into tournament_matches (
      tournament_id, round_number, slot_index, participant_a_id, participant_b_id,
      is_bye, status, winner_id, completed_at
    ) values (
      p_tournament_id, 1, i, v_a, v_b,
      (v_a is null or v_b is null),
      case when v_bye_winner is not null then 'bye' else 'ready' end,
      v_bye_winner,
      case when v_bye_winner is not null then now() else null end
    );
  end loop;

  -- Placeholder rows for every later round, filled in as earlier rounds resolve.
  for r in 2..v_rounds loop
    matches_in_round := v_bracket_size / power(2, r)::int;
    for i in 0..matches_in_round - 1 loop
      insert into tournament_matches (tournament_id, round_number, slot_index, status)
      values (p_tournament_id, r, i, 'pending');
    end loop;
  end loop;

  update tournaments set status = 'in_progress', bracket_size = v_bracket_size, started_at = now()
  where id = p_tournament_id;

  -- Propagate any round-1 byes now that round 2's placeholder rows exist.
  declare v_bye_row record;
  begin
    for v_bye_row in
      select id, winner_id from tournament_matches
      where tournament_id = p_tournament_id and round_number = 1 and status = 'bye'
    loop
      perform public.advance_tournament_match(v_bye_row.id, v_bye_row.winner_id);
    end loop;
  end;
end;
$$;

-- ============================================================================
-- ADVANCEMENT — moves a match's winner into their next-round slot, or
-- crowns the champion if this was the final. Called by the bracket
-- generator (for byes) and by the battle-completion trigger below.
-- ============================================================================
create or replace function public.advance_tournament_match(p_match_id uuid, p_winner_id uuid)
returns void language plpgsql security definer as $$
declare
  v_match tournament_matches%rowtype;
  v_final_round int;
  v_next_round int;
  v_next_slot int;
  v_is_a boolean;
  v_next tournament_matches%rowtype;
begin
  select * into v_match from tournament_matches where id = p_match_id for update;
  if not found or v_match.status = 'completed' then return; end if;

  update tournament_matches set
    winner_id = p_winner_id,
    status = case when status = 'bye' then 'bye' else 'completed' end,
    completed_at = coalesce(completed_at, now())
  where id = p_match_id;

  select max(round_number) into v_final_round from tournament_matches where tournament_id = v_match.tournament_id;

  if v_match.round_number = v_final_round then
    update tournaments set status = 'completed', champion_id = p_winner_id, completed_at = now()
    where id = v_match.tournament_id;
    return;
  end if;

  v_next_round := v_match.round_number + 1;
  v_next_slot := v_match.slot_index / 2;
  v_is_a := (v_match.slot_index % 2 = 0);

  select * into v_next from tournament_matches
  where tournament_id = v_match.tournament_id and round_number = v_next_round and slot_index = v_next_slot
  for update;
  if not found then return; end if;

  if v_is_a then
    update tournament_matches set participant_a_id = p_winner_id where id = v_next.id;
  else
    update tournament_matches set participant_b_id = p_winner_id where id = v_next.id;
  end if;

  select * into v_next from tournament_matches where id = v_next.id;
  if v_next.participant_a_id is not null and v_next.participant_b_id is not null and v_next.status = 'pending' then
    update tournament_matches set status = 'ready' where id = v_next.id;
  end if;
end;
$$;

-- Teacher-only safety valve: force a match's result (technical issue,
-- no-show/forfeit, etc.) without playing it out. Client restricts this to
-- the host UI, same trust model as the rest of the table.
create or replace function public.tournament_force_winner(p_match_id uuid, p_winner_id uuid)
returns void language plpgsql security definer as $$
begin
  perform public.advance_tournament_match(p_match_id, p_winner_id);
end;
$$;

-- ============================================================================
-- BATTLE COMPLETION HOOK — the piece that connects the two systems.
-- ============================================================================
create or replace function public.handle_tournament_battle_complete() returns trigger
language plpgsql security definer as $$
declare
  v_tm tournament_matches%rowtype;
  v_new_battle_id uuid;
begin
  if new.status <> 'completed' or old.status = 'completed' then return new; end if;

  select * into v_tm from tournament_matches where battle_id = new.id for update;
  if not found or v_tm.status = 'completed' then return new; end if;

  if new.winner_id is not null then
    perform public.advance_tournament_match(v_tm.id, new.winner_id);
  else
    -- True draw (health and round-wins both tied) — start a decisive
    -- rematch between the same two students rather than leaving the
    -- bracket stuck. Boss Battle rules themselves are untouched.
    insert into battles (student_a_id, student_b_id, topic, battle_level)
    values (new.student_a_id, new.student_b_id, new.topic, new.battle_level)
    returning id into v_new_battle_id;
    update tournament_matches set battle_id = v_new_battle_id where id = v_tm.id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_handle_tournament_battle_complete on battles;
create trigger trg_handle_tournament_battle_complete
  after update on battles
  for each row execute function public.handle_tournament_battle_complete();

grant execute on function public.generate_tournament_bracket(uuid) to anon, authenticated;
grant execute on function public.advance_tournament_match(uuid, uuid) to anon, authenticated;
grant execute on function public.tournament_force_winner(uuid, uuid) to anon, authenticated;

-- ============================================================================
-- RLS — same "public read, open client-side write, teacher/admin delete"
-- pattern as battle_challenges/battles (migration-18).
-- ============================================================================
alter table tournaments enable row level security;
alter table tournament_participants enable row level security;
alter table tournament_matches enable row level security;

drop policy if exists "public read tournaments" on tournaments;
create policy "public read tournaments" on tournaments for select using (true);
drop policy if exists "anyone insert tournaments" on tournaments;
create policy "anyone insert tournaments" on tournaments for insert with check (true);
drop policy if exists "anyone update tournaments" on tournaments;
create policy "anyone update tournaments" on tournaments for update using (true);
drop policy if exists "teacher delete tournaments" on tournaments;
create policy "teacher delete tournaments" on tournaments for delete using (
  teacher_id = auth.uid() or is_admin()
);

drop policy if exists "public read tournament_participants" on tournament_participants;
create policy "public read tournament_participants" on tournament_participants for select using (true);
drop policy if exists "anyone insert tournament_participants" on tournament_participants;
create policy "anyone insert tournament_participants" on tournament_participants for insert with check (true);
drop policy if exists "anyone delete tournament_participants" on tournament_participants;
create policy "anyone delete tournament_participants" on tournament_participants for delete using (true);

drop policy if exists "public read tournament_matches" on tournament_matches;
create policy "public read tournament_matches" on tournament_matches for select using (true);
drop policy if exists "anyone insert tournament_matches" on tournament_matches;
create policy "anyone insert tournament_matches" on tournament_matches for insert with check (true);
drop policy if exists "anyone update tournament_matches" on tournament_matches;
create policy "anyone update tournament_matches" on tournament_matches for update using (true);
drop policy if exists "teacher delete tournament_matches" on tournament_matches;
create policy "teacher delete tournament_matches" on tournament_matches for delete using (is_admin());

-- ============================================================================
-- REALTIME — students' and the teacher's projector view all get pushed
-- live updates instead of polling, same as battles/battle_rounds.
-- ============================================================================
do $$
begin
  begin
    alter publication supabase_realtime add table tournaments;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table tournament_participants;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table tournament_matches;
  exception when duplicate_object then null;
  end;
end $$;

-- ============================================================================
-- Done. Students get a new "🏆 Tournament" tab; teachers get a matching
-- "🏆 Tournament" tab with bracket setup + a projector Arena view.
-- ============================================================================
