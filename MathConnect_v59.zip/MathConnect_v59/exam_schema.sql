-- ============================================================================
-- MathConnect — Exam Feature (CORE) — Supabase SQL
-- Run this once in Supabase Dashboard → SQL Editor.
--
-- Scope: teacher creates/publishes/locks exams with manual MC/True-False
-- questions; students take a timed exam and get auto-scored results with
-- optional review. No document parsing, no analytics dashboards (Phase 2).
--
-- Harmonized against your existing schema assumptions (seen in teacher.js /
-- student.js): teachers.id = auth.users.id, sections.teacher_id = auth
-- user id, terms.section_id, students.id is the student's own PK (students
-- do NOT have Supabase Auth sessions — they use a custom localStorage
-- session, same pattern as your other apps). Because students aren't
-- Supabase-authenticated, all student-facing reads/writes that matter for
-- integrity (starting an attempt, saving answers, submitting, scoring) go
-- through SECURITY DEFINER RPCs below rather than raw table RLS — this is
-- what actually prevents a student from editing scores or reading answer
-- keys client-side, matching the "server-side timer validation" and
-- "answer validation" requirements in the exam feature guide.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TABLES
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  section_id UUID NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  term_id UUID REFERENCES terms(id) ON DELETE SET NULL,

  title TEXT NOT NULL,
  description TEXT,
  question_format TEXT NOT NULL DEFAULT 'mixed', -- 'multiple_choice' | 'true_false' | 'mixed'

  is_published BOOLEAN NOT NULL DEFAULT FALSE,
  is_locked BOOLEAN NOT NULL DEFAULT FALSE,

  duration_minutes INTEGER NOT NULL DEFAULT 60,
  total_questions INTEGER NOT NULL DEFAULT 0,
  passing_score INTEGER, -- percentage, e.g. 75

  show_correct_answers BOOLEAN NOT NULL DEFAULT TRUE,
  allow_review BOOLEAN NOT NULL DEFAULT TRUE,
  allow_multiple_attempts BOOLEAN NOT NULL DEFAULT FALSE,
  max_attempts INTEGER NOT NULL DEFAULT 1,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_exams_teacher ON exams(teacher_id);
CREATE INDEX IF NOT EXISTS idx_exams_section ON exams(section_id);
CREATE INDEX IF NOT EXISTS idx_exams_term ON exams(term_id);

CREATE TABLE IF NOT EXISTS public.exam_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,

  question_number INTEGER NOT NULL,
  question_text TEXT NOT NULL,
  question_type TEXT NOT NULL, -- 'multiple_choice' | 'true_false'

  options JSONB, -- ["Option 1","Option 2","Option 3","Option 4"] (null for true/false)
  correct_answer TEXT NOT NULL, -- 'A'|'B'|'C'|'D' or 'True'|'False'
  explanation TEXT,
  points INTEGER NOT NULL DEFAULT 1,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(exam_id, question_number)
);

CREATE INDEX IF NOT EXISTS idx_exam_questions_exam ON exam_questions(exam_id);

CREATE TABLE IF NOT EXISTS public.exam_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,

  attempt_number INTEGER NOT NULL DEFAULT 1,

  start_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  expected_end_time TIMESTAMP WITH TIME ZONE NOT NULL,
  submission_time TIMESTAMP WITH TIME ZONE,

  is_submitted BOOLEAN NOT NULL DEFAULT FALSE,
  total_score INTEGER,
  total_points INTEGER,
  percentage_score NUMERIC(5, 2),
  time_taken_seconds INTEGER,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(exam_id, student_id, attempt_number)
);

CREATE INDEX IF NOT EXISTS idx_exam_attempts_exam ON exam_attempts(exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_attempts_student ON exam_attempts(student_id);
CREATE INDEX IF NOT EXISTS idx_exam_attempts_submitted ON exam_attempts(is_submitted);

CREATE TABLE IF NOT EXISTS public.exam_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID NOT NULL REFERENCES exam_attempts(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES exam_questions(id) ON DELETE CASCADE,

  student_answer TEXT,
  is_correct BOOLEAN,

  answered_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(attempt_id, question_id)
);

CREATE INDEX IF NOT EXISTS idx_exam_responses_attempt ON exam_responses(attempt_id);
CREATE INDEX IF NOT EXISTS idx_exam_responses_question ON exam_responses(question_id);

-- ----------------------------------------------------------------------------
-- 2. ROW-LEVEL SECURITY
-- ----------------------------------------------------------------------------

ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_responses ENABLE ROW LEVEL SECURITY;

-- exams: teacher has full control over their own exams.
DROP POLICY IF EXISTS exams_teacher_all ON exams;
CREATE POLICY exams_teacher_all ON exams
  FOR ALL USING (teacher_id = auth.uid()) WITH CHECK (teacher_id = auth.uid());

-- exams: anyone (students, via anon key) may read published+unlocked exams.
-- The app filters by section/term client-side; this is a read-only listing
-- policy (no answer keys live here — those are on exam_questions, which is
-- locked down separately below).
DROP POLICY IF EXISTS exams_public_read_published ON exams;
CREATE POLICY exams_public_read_published ON exams
  FOR SELECT USING (is_published = TRUE);

-- exam_questions: teacher has full control over questions on their own exams.
DROP POLICY IF EXISTS exam_questions_teacher_all ON exam_questions;
CREATE POLICY exam_questions_teacher_all ON exam_questions
  FOR ALL USING (EXISTS (SELECT 1 FROM exams e WHERE e.id = exam_questions.exam_id AND e.teacher_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM exams e WHERE e.id = exam_questions.exam_id AND e.teacher_id = auth.uid()));

-- exam_questions: intentionally NO public/anon SELECT policy. Students never
-- read this table directly (it holds correct_answer + explanation) — they
-- get sanitized questions only through get_exam_questions_for_student() below.

-- exam_attempts / exam_responses: teacher can read attempts/responses that
-- belong to their own exams (for results review).
DROP POLICY IF EXISTS exam_attempts_teacher_select ON exam_attempts;
CREATE POLICY exam_attempts_teacher_select ON exam_attempts
  FOR SELECT USING (EXISTS (SELECT 1 FROM exams e WHERE e.id = exam_attempts.exam_id AND e.teacher_id = auth.uid()));

DROP POLICY IF EXISTS exam_responses_teacher_select ON exam_responses;
CREATE POLICY exam_responses_teacher_select ON exam_responses
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM exam_attempts a JOIN exams e ON e.id = a.exam_id
    WHERE a.id = exam_responses.attempt_id AND e.teacher_id = auth.uid()
  ));

-- exam_attempts / exam_responses: students never get direct INSERT/UPDATE
-- policies. All writes go through the SECURITY DEFINER RPCs below, which
-- validate ownership, timing, and locking server-side. A narrow SELECT is
-- granted so the app can show "already attempted" state (matched by
-- student_id, same self-report pattern used elsewhere in your apps).
DROP POLICY IF EXISTS exam_attempts_student_select ON exam_attempts;
CREATE POLICY exam_attempts_student_select ON exam_attempts
  FOR SELECT USING (TRUE);

-- ----------------------------------------------------------------------------
-- 3. SECURITY DEFINER RPCs (the actual write/scoring path for students)
-- ----------------------------------------------------------------------------

-- Starts (or resumes) an attempt. Validates published/unlocked, enforces
-- max_attempts, and computes expected_end_time server-side so the timer
-- can't be manipulated from the browser. Returns the attempt row plus a
-- SANITIZED question list (no correct_answer / explanation).
CREATE OR REPLACE FUNCTION public.start_exam_attempt(p_exam_id UUID, p_student_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_exam exams%ROWTYPE;
  v_attempt exam_attempts%ROWTYPE;
  v_existing_count INTEGER;
  v_questions JSONB;
BEGIN
  SELECT * INTO v_exam FROM exams WHERE id = p_exam_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('error', 'exam_not_found');
  END IF;
  IF NOT v_exam.is_published OR v_exam.is_locked THEN
    RETURN jsonb_build_object('error', 'exam_unavailable');
  END IF;

  -- Resume an in-progress (not yet submitted) attempt if one exists.
  SELECT * INTO v_attempt FROM exam_attempts
    WHERE exam_id = p_exam_id AND student_id = p_student_id AND is_submitted = FALSE
    ORDER BY attempt_number DESC LIMIT 1;

  IF NOT FOUND THEN
    SELECT COUNT(*) INTO v_existing_count FROM exam_attempts
      WHERE exam_id = p_exam_id AND student_id = p_student_id;

    IF v_existing_count > 0 AND NOT v_exam.allow_multiple_attempts THEN
      RETURN jsonb_build_object('error', 'already_attempted');
    END IF;
    IF v_existing_count >= v_exam.max_attempts THEN
      RETURN jsonb_build_object('error', 'max_attempts_reached');
    END IF;

    INSERT INTO exam_attempts (exam_id, student_id, attempt_number, start_time, expected_end_time)
    VALUES (p_exam_id, p_student_id, v_existing_count + 1, NOW(), NOW() + (v_exam.duration_minutes || ' minutes')::INTERVAL)
    RETURNING * INTO v_attempt;
  END IF;

  SELECT jsonb_agg(jsonb_build_object(
    'id', q.id, 'question_number', q.question_number, 'question_text', q.question_text,
    'question_type', q.question_type, 'options', q.options, 'points', q.points
  ) ORDER BY q.question_number)
  INTO v_questions
  FROM exam_questions q WHERE q.exam_id = p_exam_id;

  RETURN jsonb_build_object(
    'attempt', to_jsonb(v_attempt),
    'exam', jsonb_build_object('id', v_exam.id, 'title', v_exam.title, 'duration_minutes', v_exam.duration_minutes,
      'passing_score', v_exam.passing_score, 'allow_review', v_exam.allow_review, 'show_correct_answers', v_exam.show_correct_answers),
    'questions', COALESCE(v_questions, '[]'::jsonb)
  );
END;
$$;

-- Autosaves / updates a single answer. Rejects writes once the attempt is
-- submitted or the server-computed time has expired.
CREATE OR REPLACE FUNCTION public.save_exam_response(p_attempt_id UUID, p_question_id UUID, p_student_answer TEXT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_attempt exam_attempts%ROWTYPE;
BEGIN
  SELECT * INTO v_attempt FROM exam_attempts WHERE id = p_attempt_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'attempt_not_found'); END IF;
  IF v_attempt.is_submitted THEN RETURN jsonb_build_object('error', 'already_submitted'); END IF;
  IF NOW() > v_attempt.expected_end_time THEN RETURN jsonb_build_object('error', 'time_expired'); END IF;

  INSERT INTO exam_responses (attempt_id, question_id, student_answer, answered_at)
  VALUES (p_attempt_id, p_question_id, p_student_answer, NOW())
  ON CONFLICT (attempt_id, question_id)
  DO UPDATE SET student_answer = EXCLUDED.student_answer, answered_at = NOW();

  RETURN jsonb_build_object('ok', TRUE);
END;
$$;

-- Finalizes and auto-scores an attempt. Safe to call once; also what an
-- auto-submit-on-timeout client call hits. Grades every saved response
-- against exam_questions.correct_answer server-side, marks is_correct,
-- and totals the score. Returns a results payload (with per-question review
-- only if the exam allows it).
CREATE OR REPLACE FUNCTION public.submit_exam_attempt(p_attempt_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_attempt exam_attempts%ROWTYPE;
  v_exam exams%ROWTYPE;
  v_total_score INTEGER := 0;
  v_total_points INTEGER := 0;
  v_review JSONB;
BEGIN
  SELECT * INTO v_attempt FROM exam_attempts WHERE id = p_attempt_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'attempt_not_found'); END IF;
  SELECT * INTO v_exam FROM exams WHERE id = v_attempt.exam_id;

  IF v_attempt.is_submitted THEN
    -- idempotent: fall through and just return the existing result below
    NULL;
  ELSE
    UPDATE exam_responses r
    SET is_correct = (lower(trim(r.student_answer)) = lower(trim(q.correct_answer)))
    FROM exam_questions q
    WHERE r.question_id = q.id AND r.attempt_id = p_attempt_id;

    SELECT COALESCE(SUM(q.points), 0), COALESCE(SUM(CASE WHEN r.is_correct THEN q.points ELSE 0 END), 0)
      INTO v_total_points, v_total_score
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;

    UPDATE exam_attempts SET
      is_submitted = TRUE,
      submission_time = NOW(),
      total_score = v_total_score,
      total_points = v_total_points,
      percentage_score = CASE WHEN v_total_points > 0 THEN ROUND((v_total_score::NUMERIC / v_total_points) * 100, 2) ELSE 0 END,
      time_taken_seconds = GREATEST(0, EXTRACT(EPOCH FROM (LEAST(NOW(), v_attempt.expected_end_time) - v_attempt.start_time))::INTEGER),
      updated_at = NOW()
    WHERE id = p_attempt_id
    RETURNING * INTO v_attempt;
  END IF;

  IF v_exam.allow_review THEN
    SELECT jsonb_agg(jsonb_build_object(
      'question_number', q.question_number, 'question_text', q.question_text,
      'options', q.options, 'student_answer', r.student_answer, 'is_correct', r.is_correct,
      'correct_answer', CASE WHEN v_exam.show_correct_answers THEN q.correct_answer ELSE NULL END,
      'explanation', CASE WHEN v_exam.show_correct_answers THEN q.explanation ELSE NULL END
    ) ORDER BY q.question_number)
    INTO v_review
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;
  END IF;

  RETURN jsonb_build_object('attempt', to_jsonb(v_attempt), 'review', v_review);
END;
$$;

-- Allow the anon/authenticated roles to call the RPCs (RLS/logic inside
-- each function is what actually enforces correctness).
GRANT EXECUTE ON FUNCTION public.start_exam_attempt(UUID, UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.save_exam_response(UUID, UUID, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.submit_exam_attempt(UUID) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- Done. Sanity check:
-- select * from exams limit 1;
-- ----------------------------------------------------------------------------
