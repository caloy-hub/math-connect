// ============================================================================
// MathConnect — Daily Challenge (Real-World Math Simulator)
// One story-problem per calendar day (Philippine time), same for every
// student — generated deterministically from the date so nobody needs a
// server job to "roll" it, and the whole class can compare notes on the
// same problem. Pesos, sari-sari-store/party-budget framing throughout to
// keep it locally relevant.
// Depends on: supabase-client.js (supabase, escapeHtml), sstate (student.js),
// streakEngine.js (phDateString, recordDailyActivity, coinMultiplier, awardCoins).
// ============================================================================

const DC_BASE_COINS = 20;

// ---------- tiny seeded RNG so today's challenge is identical for every student ----------
function dcHashSeed(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (Math.imul(h, 31) + str.charCodeAt(i)) | 0;
  return h >>> 0;
}
function dcMulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function dcPick(rand, arr) { return arr[Math.floor(rand() * arr.length)]; }
function dcRandInt(rand, min, max) { return Math.floor(rand() * (max - min + 1)) + min; }

// ---------- story templates — each returns {icon, story, prompt, type, answer, tolerance?} ----------
const DC_ITEMS = ["chips", "soda", "pizza", "hotdog on a stick", "spaghetti tray", "juice packs", "ice candy", "cupcakes", "balloons", "paper plates"];
const DC_NAMES = ["Kuya Jun", "Ate Liza", "Mr. Santos", "your Nanay", "your class", "the barangay", "Coach Reyes", "your Tita"];

function dcBudgetTemplate(rand) {
  const budget = dcPick(rand, [300, 500, 800, 1000, 1500]);
  const items = [dcPick(rand, DC_ITEMS), dcPick(rand, DC_ITEMS), dcPick(rand, DC_ITEMS)];
  let prices, total;
  do {
    prices = items.map(() => dcRandInt(rand, 15, Math.round(budget * 0.4)));
    total = prices.reduce((a, b) => a + b, 0);
  } while (total >= budget);
  const change = budget - total;
  const list = items.map((it, i) => `${it} (₱${prices[i]})`).join(", ");
  return {
    icon: "🎉", type: "integer", answer: change,
    story: `${dcPick(rand, DC_NAMES)} gave you a ₱${budget} budget for a party.`,
    prompt: `You buy ${list}. How much change do you have left?`,
  };
}

function dcSplitBillTemplate(rand) {
  const friends = dcRandInt(rand, 2, 8);
  const perPerson = dcRandInt(rand, 15, 80);
  const total = friends * perPerson;
  const meal = dcPick(rand, ["pancit", "lugaw", "isaw", "fishball and kikiam", "halo-halo", "siomai rice", "milk tea"]);
  return {
    icon: "🍜", type: "integer", answer: perPerson,
    story: `${friends} friends split a ₱${total} bill for ${meal}, equally.`,
    prompt: `How much does each friend pay?`,
  };
}

function dcDiscountTemplate(rand) {
  const price = dcPick(rand, [200, 400, 600, 800, 1000, 1200]);
  const pct = dcPick(rand, [10, 20, 25, 50]);
  const item = dcPick(rand, ["pair of shoes", "school bag", "jacket", "basketball", "umbrella", "backpack", "cap"]);
  const finalPrice = price - (price * pct) / 100;
  return {
    icon: "🏷️", type: "integer", answer: Math.round(finalPrice),
    story: `A ${item} originally costs ₱${price}.`,
    prompt: `It's on sale with a ${pct}% discount. How much will you pay?`,
  };
}

function dcSavingTemplate(rand) {
  const price = dcPick(rand, [500, 800, 1000, 1500, 2000]);
  const saved = dcRandInt(rand, 50, Math.round(price * 0.4));
  const weekly = dcPick(rand, [25, 50, 75, 100]);
  const weeksNeeded = Math.ceil((price - saved) / weekly);
  const item = dcPick(rand, ["new phone case", "pair of sneakers", "bicycle", "art set", "gaming headset", "study lamp"]);
  return {
    icon: "🐷", type: "integer", answer: weeksNeeded,
    story: `You want to buy a ${item} that costs ₱${price}. You already saved ₱${saved}.`,
    prompt: `If you save ₱${weekly} every week, how many more weeks until you can afford it?`,
  };
}

function dcBestBuyTemplate(rand) {
  const n1 = dcPick(rand, [3, 4, 5, 6]), n2 = dcPick(rand, [8, 10, 12]);
  const perPiece = dcPick(rand, [3, 4, 5, 6, 8]);
  const price1 = n1 * perPiece;
  const price2 = n2 * (perPiece - 1); // store B is intentionally the better deal
  const item = dcPick(rand, ["candies", "eggs", "pandesal", "sticks of ice candy", "pieces of siopao"]);
  return {
    icon: "🛒", type: "decimal", tolerance: 0.05, answer: +(price2 / n2).toFixed(2),
    story: `Store A sells ${n1} ${item} for ₱${price1}. Store B sells ${n2} ${item} for ₱${price2}.`,
    prompt: `What is the price PER PIECE (in pesos) at the store with the better deal?`,
  };
}

const DC_TEMPLATES = [dcBudgetTemplate, dcSplitBillTemplate, dcDiscountTemplate, dcSavingTemplate, dcBestBuyTemplate];

/** getDailyChallenge(dateStr) — deterministic: same dateStr always returns the same challenge. */
function getDailyChallenge(dateStr) {
  const rand = dcMulberry32(dcHashSeed(dateStr));
  const template = DC_TEMPLATES[Math.floor(rand() * DC_TEMPLATES.length)];
  const challenge = template(rand);
  challenge.date = dateStr;
  return challenge;
}

function checkChallengeAnswer(challenge, raw) {
  const s = String(raw == null ? "" : raw).trim();
  if (!s) return false;
  if (challenge.type === "decimal") { if (!/^\d+(\.\d+)?$/.test(s)) return false; return Math.abs(parseFloat(s) - challenge.answer) <= (challenge.tolerance || 0.05); }
  if (!/^\d+$/.test(s)) return false;
  return parseInt(s, 10) === challenge.answer;
}

/** A light, encouraging nudge — not a full diagnosis, just "too high"/"too low"/"close". */
function dcHint(challenge, raw) {
  const given = challenge.type === "decimal" ? parseFloat(raw) : parseInt(raw, 10);
  if (!Number.isFinite(given)) return "Enter a number to check your answer.";
  const diff = given - challenge.answer;
  if (Math.abs(diff) <= (challenge.type === "decimal" ? 0.1 : 1)) return "So close! Recheck your last computation step.";
  return diff > 0 ? "A little too high — recheck your subtraction/division." : "A little too low — recheck your addition/multiplication.";
}

// ---------- Supabase: has today's challenge already been completed? ----------
async function fetchTodayCompletion() {
  const today = phDateString(0);
  const { data } = await supabase.from("daily_challenge_completions").select("*")
    .eq("student_id", sstate.student.id).eq("challenge_date", today).maybeSingle();
  return data || null;
}

/**
 * Submits a CORRECT answer: records the completion, awards multiplier-adjusted
 * coins, counts today toward the streak, AND awards a MathLegends star (plus
 * a bonus star for a 3+ day streak) toward the overall rank.
 */
async function completeDailyChallenge(baseCoins) {
  const today = phDateString(0);
  const mult = coinMultiplier();
  const coinsAwarded = baseCoins * mult;
  await supabase.from("daily_challenge_completions").insert({
    student_id: sstate.student.id, challenge_date: today, is_correct: true, coins_awarded: coinsAwarded,
  });
  await awardCoins(coinsAwarded);
  // Green Points for the Math Pet — flat reward for solving today's challenge.
  if (typeof awardGreenPoints === "function") await awardGreenPoints(5);
  if (typeof markDailyActivity === "function") await markDailyActivity("challenge");
  const streakResult = await recordDailyActivity();

  // 1 star for solving it, +1 bonus star if this keeps a 3+ day streak alive.
  const starsEarned = 1 + (streakResult.streak >= 3 ? 1 : 0);
  const rankResult = await awardMasteryStars(sstate.student.id, starsEarned);

  return { coinsAwarded, multiplier: mult, ...streakResult, starsEarned, rankResult };
}
