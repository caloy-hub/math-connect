-- ============================================================================
-- MathConnect — Migration 30: Admin action audit log
-- ----------------------------------------------------------------------------
-- Extends the login audit log (migration-29) with a second trail: every
-- write an admin makes from the Admin Overview panel — pausing/freezing an
-- account, deleting one, correcting an attendance/score/drill entry,
-- deleting an entry, locking/unlocking a drill station or practice domain,
-- and finalizing a school-year champion.
--
-- Design notes (mirrors migration-29):
--   - admin_name is a snapshot taken at the time of the action, so the log
--     still reads correctly if that admin's name changes later.
--   - target_name is a plain-text label for whatever was acted on (a
--     teacher's name, a student's name, a station key, etc.) rather than a
--     foreign key, because the target itself may be deleted by the very
--     action being logged (e.g. "delete_account").
--   - Rows can only be created through record_admin_action(), which itself
--     re-checks is_admin() against the caller and looks up the admin's name
--     server-side — the client can't spoof who performed an action.
--   - Only admins can read this table.
--
-- Safe to run on your existing database — nothing is deleted.
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

create table if not exists admin_action_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references admins(id) on delete set null,
  admin_name text not null,
  action_type text not null check (action_type in (
    'status_change', 'edit_account', 'delete_account',
    'lock_change', 'edit_entry', 'delete_entry', 'finalize_champion'
  )),
  target_table text,
  target_name text,
  details text,
  created_at timestamptz not null default now()
);
create index if not exists admin_action_log_created_at_idx on admin_action_log (created_at desc);
create index if not exists admin_action_log_action_type_idx on admin_action_log (action_type);

alter table admin_action_log enable row level security;

drop policy if exists "admin read admin_action_log" on admin_action_log;
create policy "admin read admin_action_log" on admin_action_log for select using (is_admin());

create or replace function public.record_admin_action(
  p_action_type text, p_target_table text, p_target_name text, p_details text default null
)
returns void language plpgsql security definer as $$
begin
  if not is_admin() then
    raise exception 'only admins can record admin actions';
  end if;
  insert into admin_action_log (admin_id, admin_name, action_type, target_table, target_name, details)
  select auth.uid(), a.full_name, p_action_type, p_target_table, p_target_name, p_details
  from admins a where a.id = auth.uid();
end;
$$;
-- Admin-only action, and only ever called from an authenticated admin
-- session — no anon grant needed here (unlike record_login_event).
grant execute on function public.record_admin_action(text, text, text, text) to authenticated;

-- ============================================================================
-- Done. Reload the admin panel — the Login Audit Log card now has an
-- "Actions" tab alongside "Logins", showing what admins have changed,
-- broken down by action type with the same pie/line charts, plus a recent
-- list. Actions taken before this migration are not retroactively logged.
-- ============================================================================
