-- ============================================================================
-- Migration 18 — Math Boss Battles (Real-Time PvP)
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this — supabase-schema.sql already
-- includes it.
--
-- HOW IT WORKS (read this before running):
--   - Two students challenge each other. Once accepted, a `battles` row is
--     created and both students' dashboards subscribe to it (and its rounds)
--     via Supabase Realtime — the same mechanism used by chat apps.
--   - Question TEXT for each round is generated client-side (reusing the
--     same generators as the Math Drill Arena) and inserted into
--     `battle_rounds`. A unique constraint on (battle_id, round_number)
--     means if both clients race to create the same round, only one insert
--     wins and both clients pick up that row via Realtime — no duplicate
--     rounds, no server-side question generator needed.
--   - Each student submits their own answer as a row in `battle_answers`
--     (client checks correctness itself, same trust model as the rest of
--     the app — see note below). A Postgres TRIGGER on that table is what
--     actually decides who "got there first": it locks the round row
--     (`for update`), so if both students answer within milliseconds of
--     each other, Postgres — not either browser — decides which insert's
--     trigger runs first, and that is treated as the winning answer. This
--     is fair regardless of network latency differences between students.
--   - "First correct answer wins" + "wrong answer loses your turn" +
--     "both wrong = draw" are all handled inside `finalize_or_wait()`.
--   - Damage per round win is 20 plus a small speed bonus (0–15, based on
--     how many seconds the winner took), so total health remaining differs
--     even when both students win the same number of rounds — this is what
--     lets a 2-2 tie (possible if there's a draw round) be broken by "more
--     health remaining wins", per your setup choice.
--
-- ⚠️ TRUST NOTE (same tradeoff as Math Drills / Shop elsewhere in this app):
--   the correct answer for the CURRENT round is technically visible to a
--   technically sophisticated student who inspects network traffic, the
--   same way drill answers already are. This is an acceptable tradeoff for
--   a low-stakes classroom game, consistent with the rest of the app.
-- ============================================================================

-- ---------- CHALLENGES ----------
create table if not exists battle_challenges (
  id uuid primary key default gen_random_uuid(),
  challenger_id uuid references students(id) on delete cascade not null,
  opponent_id uuid references students(id) on delete cascade not null,
  scope text not null default 'section' check (scope in ('section','grade')),
  topic text not null default 'mixed',  -- one of DRILL_TOPICS keys, or 'mixed' (random topic each round)
  status text not null default 'pending' check (status in ('pending','accepted','declined','cancelled','expired')),
  battle_id uuid, -- set once accepted
  created_at timestamptz default now(),
  responded_at timestamptz
);
create index if not exists battle_challenges_opponent_idx on battle_challenges (opponent_id, status);
create index if not exists battle_challenges_challenger_idx on battle_challenges (challenger_id, status);

-- ---------- BATTLES ----------
create table if not exists battles (
  id uuid primary key default gen_random_uuid(),
  student_a_id uuid references students(id) on delete cascade not null,
  student_b_id uuid references students(id) on delete cascade not null,
  topic text not null default 'mixed',
  battle_level int not null default 1,
  a_wins int not null default 0,
  b_wins int not null default 0,
  a_health int not null default 100,
  b_health int not null default 100,
  current_round int not null default 1,
  status text not null default 'active' check (status in ('active','completed')),
  winner_id uuid references students(id),
  is_draw boolean not null default false,
  created_at timestamptz default now(),
  completed_at timestamptz
);
create index if not exists battles_student_a_idx on battles (student_a_id, status);
create index if not exists battles_student_b_idx on battles (student_b_id, status);

-- ---------- ROUNDS (one per round, question text generated client-side) ----------
create table if not exists battle_rounds (
  id uuid primary key default gen_random_uuid(),
  battle_id uuid references battles(id) on delete cascade not null,
  round_number int not null check (round_number between 1 and 5),
  topic text not null,
  level int not null,
  prompt text not null,
  answer_type text not null,          -- 'integer' | 'decimal' | 'fraction'
  answer_payload jsonb not null,      -- correct answer, tolerance, hint — see trust note above
  deadline timestamptz not null,      -- created_at + round time limit (client enforces + can call expire_battle_round)
  resolved boolean not null default false,
  winner_side text check (winner_side in ('a','b','draw')),
  a_wrong boolean not null default false,
  b_wrong boolean not null default false,
  a_damage int not null default 0,
  b_damage int not null default 0,
  created_at timestamptz default now(),
  resolved_at timestamptz,
  unique (battle_id, round_number)
);
create index if not exists battle_rounds_battle_idx on battle_rounds (battle_id);

-- ---------- ANSWERS (one per student per round — trigger arbitrates the race) ----------
create table if not exists battle_answers (
  id uuid primary key default gen_random_uuid(),
  round_id uuid references battle_rounds(id) on delete cascade not null,
  battle_id uuid references battles(id) on delete cascade not null,
  student_id uuid references students(id) on delete cascade not null,
  side text not null check (side in ('a','b')),
  is_correct boolean not null,
  answer_text text,
  answer_ms int, -- client-reported time taken this round, used only for speed-bonus damage (same trust model as Drill Arena's speed bonus)
  created_at timestamptz default now(),
  unique (round_id, student_id)
);
create index if not exists battle_answers_round_idx on battle_answers (round_id);

-- ============================================================================
-- CORE ARBITRATION LOGIC
-- ============================================================================

-- Applies a resolved round's result to the parent battle: updates wins/health,
-- advances current_round, and closes out the battle after round 5 (using
-- health remaining as the tiebreaker when wins are equal, per your setup).
create or replace function public.apply_battle_round_result(
  p_round_id uuid, p_winner_side text, p_a_damage int, p_b_damage int
) returns void language plpgsql security definer as $$
declare
  v_round battle_rounds%rowtype;
  v_battle battles%rowtype;
begin
  select * into v_round from battle_rounds where id = p_round_id for update;
  if v_round.resolved then return; end if;

  update battle_rounds set
    resolved = true, winner_side = p_winner_side, resolved_at = now(),
    a_damage = coalesce(p_a_damage, 0), b_damage = coalesce(p_b_damage, 0)
  where id = p_round_id;

  select * into v_battle from battles where id = v_round.battle_id for update;
  if v_battle.status = 'completed' then return; end if;

  update battles set
    a_wins = a_wins + (case when p_winner_side = 'a' then 1 else 0 end),
    b_wins = b_wins + (case when p_winner_side = 'b' then 1 else 0 end),
    b_health = greatest(0, b_health - coalesce(p_a_damage, 0)),
    a_health = greatest(0, a_health - coalesce(p_b_damage, 0)),
    current_round = greatest(current_round, v_round.round_number + 1)
  where id = v_battle.id;

  -- battle ends once round 5 has been resolved
  if v_round.round_number >= 5 then
    select * into v_battle from battles where id = v_battle.id;
    update battles set
      status = 'completed',
      completed_at = now(),
      is_draw = (a_wins = b_wins and a_health = b_health),
      winner_id = case
        when a_wins > b_wins then student_a_id
        when b_wins > a_wins then student_b_id
        when a_health > b_health then student_a_id
        when b_health > a_health then student_b_id
        else null
      end
    where id = v_battle.id;
  end if;
end;
$$;

-- Called automatically whenever a student submits an answer. Decides,
-- atomically, whether this answer wins the round, loses the student their
-- turn (waiting on the opponent), or completes a mutual-wrong draw.
create or replace function public.handle_battle_answer() returns trigger
language plpgsql security definer as $$
declare
  v_round battle_rounds%rowtype;
  v_speed_bonus int;
  v_damage int;
  v_other_wrong boolean;
begin
  select * into v_round from battle_rounds where id = new.round_id for update;
  if v_round.resolved then return new; end if;

  if new.is_correct then
    v_speed_bonus := greatest(0, least(15, floor((15000 - least(coalesce(new.answer_ms, 15000), 15000)) / 1000)));
    v_damage := 20 + v_speed_bonus;
    if new.side = 'a' then
      perform public.apply_battle_round_result(v_round.id, 'a', v_damage, 0);
    else
      perform public.apply_battle_round_result(v_round.id, 'b', 0, v_damage);
    end if;
    return new;
  end if;

  -- wrong answer: mark this side's turn as used, then check if both are now wrong
  if new.side = 'a' then
    update battle_rounds set a_wrong = true where id = v_round.id;
    v_other_wrong := v_round.b_wrong;
  else
    update battle_rounds set b_wrong = true where id = v_round.id;
    v_other_wrong := v_round.a_wrong;
  end if;

  if v_other_wrong then
    perform public.apply_battle_round_result(v_round.id, 'draw', 0, 0);
  end if;

  return new;
end;
$$;

drop trigger if exists trg_handle_battle_answer on battle_answers;
create trigger trg_handle_battle_answer
  after insert on battle_answers
  for each row execute function public.handle_battle_answer();

-- Client-callable safety valve: if neither student answers before the round's
-- deadline, any connected client can call this to force a no-damage draw so
-- the battle doesn't stall forever.
create or replace function public.expire_battle_round(p_round_id uuid) returns void
language plpgsql security definer as $$
declare v_round battle_rounds%rowtype;
begin
  select * into v_round from battle_rounds where id = p_round_id for update;
  if v_round.resolved or now() < v_round.deadline then return; end if;
  perform public.apply_battle_round_result(p_round_id, 'draw', 0, 0);
end;
$$;

grant execute on function public.apply_battle_round_result(uuid, text, int, int) to anon, authenticated;
grant execute on function public.expire_battle_round(uuid) to anon, authenticated;

-- ============================================================================
-- RLS — same "public read, open client-side write, teacher/admin can delete"
-- pattern already used for drill_progress/drill_attempts (see migration-13).
-- Students are anon requests (no Supabase Auth), so this matches the rest
-- of the app rather than introducing a new security model.
-- ============================================================================
alter table battle_challenges enable row level security;
alter table battles enable row level security;
alter table battle_rounds enable row level security;
alter table battle_answers enable row level security;

drop policy if exists "public read battle_challenges" on battle_challenges;
create policy "public read battle_challenges" on battle_challenges for select using (true);
drop policy if exists "anyone insert battle_challenges" on battle_challenges;
create policy "anyone insert battle_challenges" on battle_challenges for insert with check (true);
drop policy if exists "anyone update battle_challenges" on battle_challenges;
create policy "anyone update battle_challenges" on battle_challenges for update using (true);
drop policy if exists "teacher delete battle_challenges" on battle_challenges;
create policy "teacher delete battle_challenges" on battle_challenges for delete using (
  is_teacher_of_student(challenger_id) or is_admin()
);

drop policy if exists "public read battles" on battles;
create policy "public read battles" on battles for select using (true);
drop policy if exists "anyone insert battles" on battles;
create policy "anyone insert battles" on battles for insert with check (true);
drop policy if exists "anyone update battles" on battles;
create policy "anyone update battles" on battles for update using (true);
drop policy if exists "teacher delete battles" on battles;
create policy "teacher delete battles" on battles for delete using (
  is_teacher_of_student(student_a_id) or is_admin()
);

drop policy if exists "public read battle_rounds" on battle_rounds;
create policy "public read battle_rounds" on battle_rounds for select using (true);
drop policy if exists "anyone insert battle_rounds" on battle_rounds;
create policy "anyone insert battle_rounds" on battle_rounds for insert with check (true);
drop policy if exists "anyone update battle_rounds" on battle_rounds;
create policy "anyone update battle_rounds" on battle_rounds for update using (true);
drop policy if exists "teacher delete battle_rounds" on battle_rounds;
create policy "teacher delete battle_rounds" on battle_rounds for delete using (is_admin());

drop policy if exists "public read battle_answers" on battle_answers;
create policy "public read battle_answers" on battle_answers for select using (true);
drop policy if exists "anyone insert battle_answers" on battle_answers;
create policy "anyone insert battle_answers" on battle_answers for insert with check (true);
drop policy if exists "teacher delete battle_answers" on battle_answers;
create policy "teacher delete battle_answers" on battle_answers for delete using (is_admin());

-- ============================================================================
-- REALTIME — add the new tables to Supabase's realtime publication so
-- students' browsers get pushed live updates instead of having to poll.
-- Wrapped so re-running this migration doesn't error if already added.
-- ============================================================================
do $$
begin
  begin
    alter publication supabase_realtime add table battle_challenges;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table battles;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table battle_rounds;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table battle_answers;
  exception when duplicate_object then null;
  end;
end $$;

-- ============================================================================
-- Done. Students will see a new "⚔️ Boss Battles" tab on their dashboard next
-- time they load the app — no other setup needed.
-- ============================================================================
