# MathConnect v54 — 90% certificate line, teacher Certificates tab, equations & formulas

Builds on v53. No new SQL: `migration-61-station-certificates.sql` from v53 is still the only migration.

## 1. Certificate pass line is now 90%
| Mode | Certificate earned when |
|---|---|
| 🎮 Math Drills | run scores **9/10** or better |
| 🗺️ Quest Mode | level scores **9/10** or better |
| 🧠 Intelligent Practice | session scores **90%+** — with 8-question sessions that means **8/8** |

Awards re-based on the new line: **90–94% Certificate of Completion**, **95–99% Certificate of Award (High Honors)**,
**100% Certificate of Award (Perfect Score)**. With 10-question runs that means 9/10 → Completion, 10/10 → Perfect Score
(High Honors appears if runs are ever lengthened to 20+ questions).
**Chapter Champion** now requires a 90%+ level certificate for **all 10 levels** of a chapter (it's issued automatically when the last one is earned).
Result screens show a nudge ("Score 9/10 (90%) or better to earn a certificate") when a run falls short.
Level *clearing/unlocking* in Quest Mode and level-ups in Drills are unchanged (still 70%) — only certificates use 90%.
Certificates already issued under the old 70% line are kept.

## 2. Teacher "🎓 Certificates" tab (Gamification & Analytics)
`teacher-certificates.js` — per section: totals (issued, students with ≥1, perfect scores, chapter champions), filters by mode /
type / student, a table of every certificate with **View / Print** (same viewer: Download PDF, Print, Save image),
and a collapsible list of students without a certificate yet. Hidden for non-math sections like the other math tabs.

## 3. Equations & formulas display properly (`mathText.js`)
* General fractions: `x/2`, `3x/4`, `d/t`, `1/(x+1)`, `(a+b)/c`, `(-b +- sqrt(b^2-4ac))/(2a)` → stacked
* `sum_(i=1)^n`, `prod_`, `lim_(x->0)` (also `\sum \prod \lim`) → symbol with limits above/below; `int_0^1` → ∫ with limits
* `$$ … $$` / `\[ … \]` → centred display equation on its own line
* `3 x 4` (lone x between numbers) → 3 × 4 · `\quad` spacing
* New **Formulas** palette tab in the question editor: quadratic formula, Pythagorean, slope, distance, midpoint, circle/sphere/triangle,
  sequences, compound interest, mean, ∑ 1…n, factoring identities, speed, own-line equation.
* Guards so ordinary text isn't touched: `20 m/s`, `5 km/h`, `coffee w/o sugar`, `and/or`, `sin(x)/x`, dates, prices.

## Files
New: `teacher-certificates.js`
Changed: `certificateEngine.js`, `drills.js`, `quest-ui.js`, `adaptive-practice.js`, `mathText.js`, `teacher.html`, `teacher.js`,
`style.css`, `service-worker.js` (cache → v54-1)
