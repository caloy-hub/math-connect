// ============================================================================
// MathConnect — Math Pet tab UI
// Renders the "🐾 My Pet" tab (adopt screen if no pet yet, else a pet
// switcher + the active pet's display/feed/mentor actions) and gets called
// into from shop-ui.js to render the "Adopt a Pet" (free) and "Pet Food" /
// "Pet Care" (coins) sections of the Shop.
// All logic lives in petEngine.js — this file only renders state and
// reacts to clicks. Depends on: petEngine.js, streakEngine.js (estate),
// escapeHtml/toast (supabase-client.js).
//
// MULTI-PET (migration-35): a student can own more than one living pet once
// every pet they currently have has reached peak (Legendary). The tab shows
// a small switcher strip when there's more than one, and every feed/care
// action below operates on whichever pet is currently "active"
// (activePet() in petEngine.js).
// ============================================================================

async function renderPetTab() {
  const el = document.getElementById("tab-pet");
  if (!el) return;
  el.innerHTML = `<div class="empty">Loading your pet…</div>`;
  if (!estate.loaded) await loadEngagement();
  // Always refresh (not just on first load this session) — if the catalog
  // changes server-side (new/retired pet types) after this session's tab
  // was already open, a cached-once list would silently hide the update.
  await loadPetCatalog();
  await loadMyPets();
  if (pstate.pets.length) await loadCarePromise();

  if (!pstate.pets.length) {
    el.innerHTML = petAdoptOrMemorialHtml();
    return;
  }

  renderPetPanel();
}

/** Shown on the My Pet tab when there's no living pet at all — either a
 *  fresh "go adopt one" prompt, or (if their last pet died) a memorial. */
function petAdoptOrMemorialHtml() {
  const dead = pstate.lastDeadPet;
  if (!dead) {
    return `
      <div class="card" style="text-align:center;padding:28px;">
        <div style="font-size:2.6rem;">🐾</div>
        <h2 style="margin:6px 0;">You don't have a pet yet!</h2>
        <p class="muted">Pick one for free in the 🛒 Rewards Shop, then come back here to feed and grow it.</p>
        <button class="btn-primary" style="margin-top:10px;" onclick="switchStudentTab('shop')">🛒 Go Adopt a Pet</button>
      </div>`;
  }
  const typeMeta = PET_TYPE_META[dead.pet_type_key] || { icon: "🐾" };
  return `
    <div class="card" style="text-align:center;padding:28px;">
      <div style="font-size:2.6rem;opacity:.6;">🕊️</div>
      <h2 style="margin:6px 0;">${escapeHtml(dead.pet_name || typeMeta.icon + " your pet")} passed away before pets could rest safely</h2>
      <p class="muted" style="max-width:440px;margin:0 auto;">
        Pets in MathConnect can't pass away any more — if one is neglected it simply falls asleep, and a quick warm-up wakes it up.
        ${escapeHtml(dead.pet_name || "Your pet")} was lost under the old rules, so a new friend is the way forward. Ask your teacher if you'd like your old pet back.
      </p>
      <p style="margin:14px 0 6px;"><strong>Your new pet will be safe with you.</strong> Visit it when you can — and if life gets busy, it will wait.</p>
      <button class="btn-primary" onclick="switchStudentTab('shop')">🛒 Adopt a New Pet</button>
    </div>`;
}

/** Small strip of tappable icons — one per living pet — shown only when the
 *  student owns more than one. Clicking switches which pet the panel below
 *  shows. A peaked pet gets a 👑 corner badge so it's easy to spot at a
 *  glance which ones are available to assign as mentors. */
function petSwitcherHtml() {
  if (pstate.pets.length < 2 && !canAdoptNewPet()) return "";
  const chips = pstate.pets.map((p) => {
    const stage = petGrowthStage(p.growth_points);
    const form = petDisplayForm(p.pet_type_key, stage.label);
    const active = p.id === pstate.activePetId;
    return `
      <button class="pet-switcher-chip${active ? " pet-switcher-chip-active" : ""}" onclick="handleSwitchPet('${p.id}')" title="${escapeHtml(p.pet_name || stage.label)}">
        ${form.image
          ? `<img src="${form.image}" alt="${escapeHtml(form.title || "Legendary pet")}" style="max-width:82%;max-height:82%;object-fit:contain;display:block;">`
          : `<span style="font-size:1.4rem;">${form.icon}</span>`}
        ${petIsPeak(p) ? `<span class="pet-switcher-crown">👑</span>` : ""}
      </button>`;
  }).join("");
  const adoptChip = canAdoptNewPet() ? `
    <button class="pet-switcher-chip pet-switcher-chip-add" onclick="switchStudentTab('shop')" title="Adopt another pet">+</button>` : "";
  return `<div class="pet-switcher-row">${chips}${adoptChip}</div>`;
}

function renderPetPanel() {
  const el = document.getElementById("tab-pet");
  if (!el) return;
  const pet = activePet();
  if (!pet) { el.innerHTML = petAdoptOrMemorialHtml(); return; }

  const peak = petIsPeak(pet);
  const type = pstate.petTypes.find((t) => t.key === pet.pet_type_key) || {};
  const stage = petGrowthStage(pet.growth_points);
  const form = petDisplayForm(pet.pet_type_key, stage.label);
  const nextStage = petNextStageProgress(pet.growth_points);
  const mood = petMood(pet);
  const hungerInfo = pet.resting ? { label: "Resting 💤", color: "var(--ink-soft, #6b7280)" } : petHungerLabel(mood.hunger);
  const gp = (estate.data && estate.data.green_points) || 0;
  const owned = pstate.foodItems.filter((f) => ownedFoodCount(pet, f.key) > 0);
  const ownedCare = pstate.careItems.filter((c) => c.category !== "equipment" && ownedCareCount(pet, c.key) > 0);
  const ownedEquip = pstate.careItems.filter((c) => c.category === "equipment" && ownsEquipment(pet, c.key));
  const vitaminActive = !peak && pet.vitamin_boost_until && new Date(pet.vitamin_boost_until) > new Date();
  const vaccineActive = !peak && pet.vaccinated_until && new Date(pet.vaccinated_until) > new Date();
  const gemImmune = petHasGemImmunity(pet);
  const gems = (estate.data && estate.data.gemstones) || 0;
  const gemUsesToday = (pet.gem_uses_date && new Date(pet.gem_uses_date).toDateString() === new Date().toDateString()) ? (pet.gem_uses_today || 0) : 0;

  el.innerHTML = `
    ${petSwitcherHtml()}
    <div class="card" style="text-align:center;padding:28px;">
      ${peak ? `
        <div class="card" style="background:#FFF8E6;border-color:#F0D896;margin-bottom:14px;padding:10px 14px;">
          <strong style="color:var(--gold-dark,#B8790E);">👑 ${escapeHtml(pet.pet_name || "Your pet")} reached Legendary — immune to hunger and sickness for good!</strong>
          <div class="muted" style="font-size:.8rem;margin-top:2px;">It can now mentor a growing pet, or you can adopt a new one from the Shop.</div>
          ${typeof certShelfButtonHtml === "function" ? `<div style="margin-top:8px;">${certShelfButtonHtml("pet").replace("🎓 My Certificates", "🎓 Legendary Pet Certificate")}</div>` : ""}
        </div>` : ""}

      ${pet.resting ? petRestingCardHtml(pet) : ""}

      ${(!peak && !pet.resting && pet.sick) ? `
        <div class="card" style="background:#FCEBEA;border-color:#E8B4AF;margin-bottom:14px;padding:10px 14px;">
          <strong style="color:var(--clay);">🤒 ${escapeHtml(pet.pet_name || "Your pet")} is sick!</strong>
          <div class="muted" style="font-size:.8rem;margin-top:2px;">Give it a 💉 Wellness Vaccine or a good meal soon — if it stays sick too long, it will fall asleep and need a Wake-up Warm-up.</div>
          ${ownedCareCount(pet, "wellness_vaccine") > 0
            ? `<button class="btn-danger btn-sm" style="margin-top:8px;" onclick="handleUseCareItem('wellness_vaccine')">💉 Use Vaccine Now</button>`
            : `<div style="margin-top:8px;"><a href="#" onclick="switchStudentTab('shop');return false;">🛒 Buy a Vaccine →</a></div>`}
        </div>` : ""}

      ${(!peak && gemImmune) ? `
        <div class="card" style="background:#F0EAFC;border-color:#C8ADE8;margin-bottom:14px;padding:10px 14px;">
          <strong style="color:#7A4FB0;">🛡️ ${escapeHtml(pet.pet_name || "Your pet")} is Gemstone-shielded!</strong>
          <div class="muted" style="font-size:.8rem;margin-top:2px;">Immune to hunger and sickness until ${new Date(pet.gem_immune_until).toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} — and your Green Points earnings are +30% everywhere while it lasts.</div>
        </div>` : ""}

      <!-- Living Virtual Pet Habitat Stage -->
      <div class="pet-habitat-stage" id="petHabitatStage">
        <div class="pet-speech-bubble" id="petLivingSpeechBubble">${mood.icon} “${escapeHtml(mood.text)}”</div>
        <div class="pet-habitat-viewport" onclick="handlePetHabitatTap(event)" title="Tap to pet and cuddle!">
          <div class="pet-habitat-character" id="petHabitatCharacter">
            ${petVisualHtml(form, mood.anim, stage.glow, 3.4 * stage.scale)}
          </div>
          <div class="pet-tap-hint">👋 Tap to pet & cuddle!</div>
        </div>
        <div class="pet-quick-actions">
          <button type="button" class="btn-sm btn-outline" onclick="handlePetHabitatTap(event)">💖 Pet Cuddle</button>
          <button type="button" class="btn-sm btn-outline" onclick="handleQuickFeedSnack()">🍪 Quick Snack</button>
          <button type="button" class="btn-sm btn-outline" onclick="handleTogglePetNap()">💤 Rest / Nap</button>
        </div>
      </div>

      <h2 style="margin:14px 0 2px;">${escapeHtml(pet.pet_name || type.name || "Your Pet")} ${PET_STAGE_BADGE[stage.label] || ""}</h2>
      <div class="muted" style="margin-bottom:2px;">${stage.label}${nextStage ? ` · ${nextStage.needed} growth pts to ${nextStage.nextLabel}` : " · Peak stage reached!"}</div>
      ${form.title ? `<div style="color:var(--gold-dark,#B8790E);font-weight:600;font-size:.9rem;margin-bottom:8px;">✨ ${escapeHtml(form.title)} ✨</div>` : `<div style="margin-bottom:8px;"></div>`}

      <div style="display:flex;gap:6px;justify-content:center;align-items:center;flex-wrap:wrap;margin-bottom:10px;">
        <input id="petRenameInput" type="text" maxlength="24" placeholder="Rename your pet…" value="${escapeHtml(pet.pet_name || "")}"
          style="padding:6px 10px;border:1px solid var(--paper-line);border-radius:8px;font-size:.85rem;max-width:180px;">
        <button class="btn-outline btn-sm" onclick="handleRenamePet()">✏️ Rename</button>
      </div>

      ${vitaminActive || vaccineActive ? `
        <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:10px;">
          ${vitaminActive ? `<span class="badge" style="background:#EAF0EA;color:var(--forest-dark);">💊 Vitamin boost active until ${new Date(pet.vitamin_boost_until).toLocaleString()}</span>` : ""}
          ${vaccineActive ? `<span class="badge" style="background:#EAF0EA;color:var(--forest-dark);">💉 Protected until ${new Date(pet.vaccinated_until).toLocaleString()}</span>` : ""}
        </div>` : ""}

      ${peak ? `
        <p class="muted" style="font-size:.78rem;margin:10px auto 0;max-width:360px;">🛡️ Immune — no longer needs food or care, but you're welcome to feed it anyway just for fun.</p>
      ` : `
      <div style="max-width:360px;margin:14px auto 6px;">
        <div style="display:flex;justify-content:space-between;font-size:.78rem;"><span>🍖 Hunger</span><span style="color:${hungerInfo.color};font-weight:600;">${hungerInfo.label}</span></div>
        <div style="height:10px;background:var(--paper-line);border-radius:6px;overflow:hidden;margin-top:4px;">
          <div style="height:100%;width:${mood.hunger}%;background:${hungerInfo.color};transition:width .4s;"></div>
        </div>
      </div>`}
      ${nextStage ? `
      <div style="max-width:360px;margin:12px auto 0;">
        <div style="display:flex;justify-content:space-between;font-size:.78rem;"><span>🌱 Growth</span><span class="muted">${pet.growth_points} pts</span></div>
        <div style="height:10px;background:var(--paper-line);border-radius:6px;overflow:hidden;margin-top:4px;">
          <div style="height:100%;width:${Math.round(nextStage.fraction * 100)}%;background:var(--forest-dark);"></div>
        </div>
      </div>` : ""}
      ${!peak ? `<p class="muted" style="font-size:.72rem;margin-top:12px;">💤 If life gets busy and your pet goes hungry for a few days, it just falls asleep — a quick Wake-up Warm-up brings it back and nothing is ever lost. Once it reaches Legendary it never needs waking at all.</p>` : ""}
    </div>

    ${petMentorCardHtml(pet)}

    ${petCarePromiseCardHtml(pet)}

    ${pet.resting ? "" : `<div class="dash-grid" style="margin-top:16px;">
      <div class="card">
        <h3 style="margin:0 0 6px;">💚 Feed with Green Points</h3>
        <p class="muted" style="font-size:.85rem;">${peak ? "Optional now, but still fun — " : ""}Grows your pet AND tops up hunger. Earn Green Points by playing anywhere in the app.</p>
        <div style="display:flex;justify-content:space-between;align-items:center;margin:10px 0;">
          <span class="muted">Your balance</span>
          <strong style="color:var(--forest-dark);">💚 ${gp}</strong>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          ${[5, 10, 25].map((amt) => `
            <button class="btn-outline btn-sm" ${gp < amt ? "disabled" : ""} onclick="handleFeedGreenPoints(${amt})">Feed ${amt} 💚</button>`).join("")}
        </div>
      </div>

      <div class="card">
        <h3 style="margin:0 0 6px;">💎 All-Rounder Gemstone</h3>
        <p class="muted" style="font-size:.85rem;">Complete every activity in one day — Drills, Quest, Practice, a Boss Raid, the Daily Challenge, a Rating, and feeding your pet — to earn one. Use it here for +3 days of hunger/sickness immunity (stacks!) and +30% Green Points everywhere.</p>
        <div style="display:flex;justify-content:space-between;align-items:center;margin:10px 0;">
          <span class="muted">Your Gemstones</span>
          <strong style="color:#7A4FB0;">💎 ${gems}</strong>
        </div>
        ${peak ? `<p class="muted" style="font-size:.78rem;">This pet is already immune for good — no need to spend a Gemstone on it.</p>` : `
        <button class="btn-outline btn-sm" ${gems < 1 || gemUsesToday >= 3 ? "disabled" : ""} onclick="handleUseGemstone()">🛡️ Use 1 Gemstone on ${escapeHtml(pet.pet_name || "this pet")}</button>
        <div class="muted" style="font-size:.72rem;margin-top:6px;">${gemUsesToday >= 3 ? "Max 3 Gemstones used on this pet today — try again tomorrow." : `Used ${gemUsesToday}/3 on this pet today.`}</div>`}
      </div>

      <div class="card">
        <h3 style="margin:0 0 6px;">🍪 Feed with Food</h3>
        <p class="muted" style="font-size:.85rem;">Buy food in the 🛒 Shop with Coins, then feed it here to restore hunger fast.</p>
        ${owned.length ? `
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            ${owned.map((f) => `
              <button class="btn-outline btn-sm" onclick="handleFeedFood('${f.key}')">
                ${PET_FOOD_META[f.key]?.icon || "🍽️"} ${escapeHtml(f.name)} ×${ownedFoodCount(pet, f.key)}
              </button>`).join("")}
          </div>
        ` : `<p class="muted" style="font-size:.82rem;">This pet doesn't own any food yet. <a href="#" onclick="switchStudentTab('shop');return false;">Visit the Shop →</a></p>`}
      </div>

      <div class="card">
        <h3 style="margin:0 0 6px;">💊 Vitamins, Vaccine &amp; Cheat Meals</h3>
        <p class="muted" style="font-size:.85rem;">Buy these in the 🛒 Shop, then use them here.</p>
        ${ownedCare.length ? `
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            ${ownedCare.map((c) => `
              <button class="btn-outline btn-sm" onclick="handleUseCareItem('${c.key}')">
                ${PET_CARE_META[c.key]?.icon || "💊"} ${escapeHtml(c.name)} ×${ownedCareCount(pet, c.key)}
              </button>`).join("")}
          </div>
        ` : `<p class="muted" style="font-size:.82rem;">Nothing on hand yet. <a href="#" onclick="switchStudentTab('shop');return false;">Visit the Shop →</a></p>`}
      </div>

      <div class="card">
        <h3 style="margin:0 0 6px;">🛏️ Equipment</h3>
        <p class="muted" style="font-size:.85rem;">One equipped at a time — gives a permanent slower hunger decay while equipped.</p>
        ${ownedEquip.length ? `
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            ${ownedEquip.map((c) => `
              <button class="${pet.equipped_item === c.key ? "btn-gold" : "btn-outline"} btn-sm"
                onclick="handleEquipPetItem('${pet.equipped_item === c.key ? "" : c.key}')">
                ${PET_CARE_META[c.key]?.icon || "🛏️"} ${escapeHtml(c.name)} ${pet.equipped_item === c.key ? "(equipped)" : ""}
              </button>`).join("")}
          </div>
        ` : `<p class="muted" style="font-size:.82rem;">No equipment yet. <a href="#" onclick="switchStudentTab('shop');return false;">Visit the Shop →</a></p>`}
      </div>
    </div>`}`;
}

/** The mentor card: differs a lot depending on whether the ACTIVE pet is
 *  itself peaked (show its mentoring status + who it can help) or still
 *  growing (show whether it's currently mentored, and by whom it could
 *  be). Returns "" if there's nothing useful to show (e.g. only one pet
 *  total and it's still growing). */
function petMentorCardHtml(pet) {
  const peak = petIsPeak(pet);

  if (peak) {
    const mentee = petMentee(pet);
    if (mentee) {
      const menteeStage = petGrowthStage(mentee.growth_points);
      return `
        <div class="card" style="margin-top:16px;background:#F3F0FF;border-color:#D9CFFA;">
          <h3 style="margin:0 0 6px;">🎓 Mentoring</h3>
          <p style="margin:0 0 10px;">Currently helping <strong>${escapeHtml(mentee.pet_name || menteeStage.label)}</strong> grow 1.5x faster.</p>
          <button class="btn-outline btn-sm" onclick="handleUnassignMentor('${mentee.id}')">Unassign</button>
        </div>`;
    }
    const candidates = growingPets();
    if (!candidates.length) {
      return `
        <div class="card" style="margin-top:16px;">
          <h3 style="margin:0 0 6px;">🎓 Mentor Duty</h3>
          <p class="muted" style="margin:0;">No growing pets to mentor right now. ${canAdoptNewPet() ? `<a href="#" onclick="switchStudentTab('shop');return false;">Adopt a new one →</a>` : ""}</p>
        </div>`;
    }
    return `
      <div class="card" style="margin-top:16px;">
        <h3 style="margin:0 0 6px;">🎓 Mentor Duty</h3>
        <p class="muted" style="font-size:.85rem;margin:0 0 10px;">Assign ${escapeHtml(pet.pet_name || "this pet")} to help a growing pet reach Legendary 1.5x faster.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          ${candidates.map((c) => `
            <button class="btn-outline btn-sm" onclick="handleAssignMentor('${pet.id}','${c.id}')">
              Mentor ${escapeHtml(c.pet_name || petGrowthStage(c.growth_points).label)}${c.assigned_mentor_id ? " (reassign)" : ""}
            </button>`).join("")}
        </div>
      </div>`;
  }

  // Growing pet: show its current mentor, or a way to pick one.
  const mentor = petMentor(pet);
  if (mentor) {
    return `
      <div class="card" style="margin-top:16px;background:#F3F0FF;border-color:#D9CFFA;">
        <h3 style="margin:0 0 6px;">🎓 Mentored</h3>
        <p style="margin:0 0 10px;"><strong>${escapeHtml(mentor.pet_name || "Your Legendary pet")}</strong> is helping this pet grow 1.5x faster from Green-Point feeding.</p>
        <button class="btn-outline btn-sm" onclick="handleUnassignMentor('${pet.id}')">Unassign</button>
      </div>`;
  }
  const mentors = peakPets();
  if (!mentors.length) return "";
  return `
    <div class="card" style="margin-top:16px;">
      <h3 style="margin:0 0 6px;">🎓 Get a Mentor</h3>
      <p class="muted" style="font-size:.85rem;margin:0 0 10px;">You have a Legendary pet that can grow this one 1.5x faster.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        ${mentors.map((m) => `
          <button class="btn-outline btn-sm" onclick="handleAssignMentor('${m.id}','${pet.id}')">Assign ${escapeHtml(m.pet_name || "mentor")}</button>`).join("")}
      </div>
    </div>`;
}

async function handleSwitchPet(petId) {
  setActivePet(petId);
  renderPetPanel();
}

async function handleFeedGreenPoints(amount) {
  const pet = activePet();
  if (!pet) return;
  const stageBefore = petGrowthStage(pet.growth_points);
  const row = await feedPetWithGreenPoints(pet.id, amount);
  if (row && row.success) {
    renderPetPanel(); playPetHappyBounce(); if (typeof renderDashboardPetWidget === "function") renderDashboardPetWidget();
    if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_FEED");
    const stageAfter = petGrowthStage(pet.growth_points);
    if (typeof maybePlayPetEvolutionCeremony === "function") maybePlayPetEvolutionCeremony(pet, stageBefore, stageAfter);
  }
}

async function handleFeedFood(foodKey) {
  const pet = activePet();
  if (!pet) return;
  const row = await feedPetWithFood(pet.id, foodKey);
  if (row && row.success) { renderPetPanel(); playPetHappyBounce(); if (typeof renderDashboardPetWidget === "function") renderDashboardPetWidget(); if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_FEED"); }
}

async function handleUseCareItem(itemKey) {
  const pet = activePet();
  if (!pet) return;
  const row = await useCareItem(pet.id, itemKey);
  if (row && row.success) { renderPetPanel(); playPetHappyBounce(); if (typeof renderDashboardPetWidget === "function") renderDashboardPetWidget(); if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_CARE"); }
}

async function handleUseGemstone() {
  const pet = activePet();
  if (!pet) return;
  const row = await useGemstoneOnPet(pet.id);
  if (row && row.success) { renderPetPanel(); playPetHappyBounce(); if (typeof renderDashboardPetWidget === "function") renderDashboardPetWidget(); if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_CARE"); }
}

async function handleEquipPetItem(itemKey) {
  const pet = activePet();
  if (!pet) return;
  const row = await equipPetItem(pet.id, itemKey);
  if (row && row.success) renderPetPanel();
}

async function handleRenamePet() {
  const pet = activePet();
  const input = document.getElementById("petRenameInput");
  if (!input || !pet) return;
  const row = await renamePet(pet.id, input.value);
  if (row && row.success) renderPetPanel();
}

async function handleAssignMentor(mentorId, menteeId) {
  const row = await assignMentor(mentorId, menteeId);
  if (row && row.success) renderPetPanel();
}

async function handleUnassignMentor(menteeId) {
  const row = await unassignMentor(menteeId);
  if (row && row.success) renderPetPanel();
}

/** A one-shot bounce animation on whichever pet icon(s) are currently on screen, right after a feed. */
function playPetHappyBounce() {
  document.querySelectorAll(".pet-anim-sad, .pet-anim-idle, .pet-anim-happy-idle").forEach((elm) => {
    elm.classList.add("pet-anim-bounce-once");
    setTimeout(() => elm.classList.remove("pet-anim-bounce-once"), 700);
  });
}

// ============================================================================
// Shop tab hooks — called from shop-ui.js's renderShopTab() so "adopt a pet"
// and "pet food"/"pet care" live in the Rewards Shop, per spec. Food/care
// purchases need to know WHICH pet's inventory to add to (inventory is
// per-pet since migration-33/35), so these sections show a small pet
// selector whenever the student owns more than one pet.
// ============================================================================
async function renderShopPetSections() {
  const adoptSlot = document.getElementById("shopAdoptPetWrap");
  const foodSlot = document.getElementById("shopPetFoodWrap");
  const careSlot = document.getElementById("shopPetCareWrap");
  const accessorySlot = document.getElementById("shopPetAccessoryWrap");
  if (!adoptSlot && !foodSlot && !careSlot && !accessorySlot) return;
  // Always refresh (not just on first load this session) — a new pet type
  // added server-side after this session's tab was already open must show
  // up without needing a full page reload, same reasoning as loadMyPets()
  // just below.
  await loadPetCatalog();
  // Always re-check (not just on first load this session) — the adopt
  // button must never stay hidden behind a stale "already has a pet"
  // snapshot if a pet died or reached peak since the last check.
  await loadMyPets();

  const shopPet = findPet(window._shopSelectedPetId) || activePet();
  if (shopPet) window._shopSelectedPetId = shopPet.id;

  if (adoptSlot) {
    adoptSlot.innerHTML = !canAdoptNewPet() ? "" : `
      <div class="card" style="margin-bottom:16px;">
        <h3 style="margin:0 0 4px;">🐾 Adopt a Pet — Free!</h3>
        <p class="muted" style="margin:0 0 12px;">
          ${pstate.pets.length ? "Every pet you own has reached Legendary — you're free to start raising a new one from zero. " : ""}
          Name it now (or leave blank and rename it later) — you can feed and grow it from the 🐾 My Pet tab.
          Every pet can evolve all the way to a legendary mythical form if you take good care of it — and once it does, it can mentor your next one.
        </p>
        <div class="shop-grid">
          ${pstate.petTypes.map((t) => `
            <div class="shop-item-card">
              <div class="shop-item-icon">${PET_TYPE_META[t.key]?.icon || "🐾"}</div>
              <h4 style="margin:8px 0 2px;">${escapeHtml(t.name)}</h4>
              <p class="muted" style="font-size:.8rem;min-height:34px;">${escapeHtml(t.description || "")}</p>
              <input id="petNameInput-${t.key}" type="text" maxlength="24" placeholder="Name (optional)"
                style="width:100%;box-sizing:border-box;padding:5px 8px;margin-bottom:6px;border:1px solid var(--paper-line);border-radius:8px;font-size:.8rem;">
              <button class="btn-gold" style="width:100%;" onclick="handleAdoptPet('${t.key}')">Adopt — Free</button>
            </div>`).join("")}
        </div>
      </div>`;
  }

  const petPickerHtml = pstate.pets.length > 1 ? `
    <div style="margin-bottom:10px;">
      <label for="shopPetSelector" style="display:inline;margin-right:8px;">Feed which pet?</label>
      <select id="shopPetSelector" onchange="window._shopSelectedPetId=this.value;renderShopPetSections();" style="width:auto;display:inline-block;padding:5px 8px;">
        ${pstate.pets.map((p) => `<option value="${p.id}" ${p.id === (shopPet && shopPet.id) ? "selected" : ""}>${escapeHtml(p.pet_name || petGrowthStage(p.growth_points).label)}${petIsPeak(p) ? " 👑" : ""}</option>`).join("")}
      </select>
    </div>` : "";

  if (foodSlot) {
    foodSlot.innerHTML = !shopPet ? "" : `
      <div class="card" style="margin-bottom:16px;">
        <h3 style="margin:0 0 4px;">🍪 Pet Food</h3>
        <p class="muted" style="margin:0 0 12px;">Buy with coins, then feed your pet from the 🐾 My Pet tab.</p>
        ${petPickerHtml}
        <div class="shop-grid">
          ${pstate.foodItems.map((f) => {
            const affordable = (estate.data.coins || 0) >= f.cost_coins;
            const owned = ownedFoodCount(shopPet, f.key);
            return `
            <div class="shop-item-card">
              <div class="shop-item-icon">${PET_FOOD_META[f.key]?.icon || "🍽️"}</div>
              <h4 style="margin:8px 0 2px;">${escapeHtml(f.name)}</h4>
              <p class="muted" style="font-size:.8rem;min-height:34px;">Restores ${f.restore_amount} hunger.</p>
              ${owned > 0 ? `<div class="muted" style="font-size:.75rem;margin-bottom:6px;">You own: ${owned}</div>` : ""}
              <button class="btn-gold" style="width:100%;" ${affordable ? "" : "disabled"} onclick="handlePurchasePetFood('${f.key}')">
                ${affordable ? `Buy — 🪙 ${f.cost_coins}` : `🪙 ${f.cost_coins} (need more)`}
              </button>
            </div>`;
          }).join("")}
        </div>
      </div>`;
  }

  if (careSlot) {
    const nonEquipItems = pstate.careItems.filter((c) => c.category !== "equipment");
    careSlot.innerHTML = !shopPet || !nonEquipItems.length ? "" : `
      <div class="card" style="margin-bottom:16px;">
        <h3 style="margin:0 0 4px;">💊 Pet Care</h3>
        <p class="muted" style="margin:0 0 12px;">Vitamins slow hunger decay, a Vaccine cures/prevents sickness, and Cheat Meals are a cheap-but-risky shortcut. None of these are needed once a pet reaches Legendary.</p>
        ${petPickerHtml}
        <div class="shop-grid">
          ${nonEquipItems.map((c) => {
            const affordable = (estate.data.coins || 0) >= c.cost_coins;
            const owned = ownedCareCount(shopPet, c.key);
            const blurb = c.category === "vitamin" ? `Slows hunger decay ${c.decay_reduction_pct}% for ${c.effect_hours}h.`
              : c.category === "vaccine" ? `Cures sickness + protects for ${c.effect_hours}h.`
              : `Restores ${c.restore_amount} hunger — ${c.sickness_risk_pct}% chance of sickness.`;
            return `
            <div class="shop-item-card">
              <div class="shop-item-icon">${PET_CARE_META[c.key]?.icon || "💊"}</div>
              <h4 style="margin:8px 0 2px;">${escapeHtml(c.name)}</h4>
              <p class="muted" style="font-size:.8rem;min-height:34px;">${escapeHtml(blurb)}</p>
              ${owned > 0 ? `<div class="muted" style="font-size:.75rem;margin-bottom:6px;">You own: ${owned}</div>` : ""}
              <button class="btn-gold" style="width:100%;" ${affordable ? "" : "disabled"} onclick="handlePurchaseCareItem('${c.key}')">
                ${affordable ? `Buy — 🪙 ${c.cost_coins}` : `🪙 ${c.cost_coins} (need more)`}
              </button>
            </div>`;
          }).join("")}
        </div>
      </div>`;
  }

  // 👒 Pet Accessories (migration-47) — the "equipment" category on its own
  // shop tab, separate from vitamins/vaccine/cheat food above. Same
  // pet_care_items table and purchase flow, just rendered in its own card
  // so cosmetic gear reads as its own section.
  if (accessorySlot) {
    const equipItems = pstate.careItems.filter((c) => c.category === "equipment");
    accessorySlot.innerHTML = !shopPet || !equipItems.length ? "" : `
      <div class="card" style="margin-bottom:16px;">
        <h3 style="margin:0 0 4px;">👒 Pet Accessories</h3>
        <p class="muted" style="margin:0 0 12px;">One equipped at a time — cosmetic flair, plus a small permanent hunger-decay perk while equipped.</p>
        ${petPickerHtml}
        <div class="shop-grid">
          ${equipItems.map((c) => {
            const affordable = (estate.data.coins || 0) >= c.cost_coins;
            const owned = ownsEquipment(shopPet, c.key);
            const blurb = `+${c.decay_reduction_pct}% slower hunger decay while equipped.`;
            return `
            <div class="shop-item-card">
              <div class="shop-item-icon">${PET_CARE_META[c.key]?.icon || "👒"}</div>
              <h4 style="margin:8px 0 2px;">${escapeHtml(c.name)}</h4>
              <p class="muted" style="font-size:.8rem;min-height:34px;">${escapeHtml(blurb)}</p>
              ${owned ? `<div class="muted" style="font-size:.75rem;margin-bottom:6px;">✅ Owned</div>` : ""}
              <button class="btn-gold" style="width:100%;" ${(affordable && !owned) ? "" : "disabled"} onclick="handlePurchaseCareItem('${c.key}')">
                ${owned ? "Owned" : (affordable ? `Buy — 🪙 ${c.cost_coins}` : `🪙 ${c.cost_coins} (need more)`)}
              </button>
            </div>`;
          }).join("")}
        </div>
      </div>`;
  }
}

async function handleAdoptPet(petTypeKey) {
  const nameInput = document.getElementById(`petNameInput-${petTypeKey}`);
  const row = await adoptPet(petTypeKey, nameInput ? nameInput.value : "");
  if (row && row.success) { window._shopSelectedPetId = row.pet.id; renderShopPetSections(); }
}

async function handlePurchasePetFood(foodKey) {
  const petId = window._shopSelectedPetId || (activePet() && activePet().id);
  if (!petId) return;
  const row = await purchasePetFood(petId, foodKey);
  if (row && row.success) { renderShopPetSections(); if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_SHOP"); }
}

async function handlePurchaseCareItem(itemKey) {
  const petId = window._shopSelectedPetId || (activePet() && activePet().id);
  if (!petId) return;
  const row = await purchaseCareItem(petId, itemKey);
  if (row && row.success) { renderShopPetSections(); if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_SHOP"); }
}

// ============================================================================
// Dashboard widget — shown on the "This Week" tab (the very first thing a
// student sees on login) so the pet's status is visible without having to
// go find the Pet tab. Built as a self-contained wrapper div so it can be
// re-rendered in place after a feed even while that tab is hidden (all
// tabpanels stay mounted in the DOM, just display:none — see student.js).
// Shows the active pet; if the student owns more than one, a small badge
// hints at how many more.
// ============================================================================
function dashboardPetWidgetHtml() {
  if (!pstate.pets.length) {
    if (pstate.lastDeadPet) {
      return `
      <div class="card pet-hero-card" id="dashboardPetWidgetWrap" style="margin-bottom:20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
        <div style="font-size:2.2rem;opacity:.6;">🕊️</div>
        <div style="flex:1;min-width:200px;">
          <h3 style="margin:0 0 2px;">${escapeHtml(pstate.lastDeadPet.pet_name || "Your pet")} has passed away</h3>
          <p class="muted" style="margin:0;font-size:.85rem;">Adopt a new one any time — a pet that reaches Legendary can never die.</p>
        </div>
        <button class="btn-outline btn-sm" onclick="switchStudentTab('shop')">🛒 Adopt Again</button>
      </div>`;
    }
    return `
    <div class="card pet-hero-card" id="dashboardPetWidgetWrap" style="margin-bottom:20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
      <div style="font-size:2.2rem;">🐾</div>
      <div style="flex:1;min-width:200px;">
        <h3 style="margin:0 0 2px;">Adopt a Math Pet!</h3>
        <p class="muted" style="margin:0;font-size:.85rem;">Pick one for free in the Shop, then feed it with points you earn by playing.</p>
      </div>
      <button class="btn-outline btn-sm" onclick="switchStudentTab('shop')">🛒 Adopt Now</button>
    </div>`;
  }

  const pet = activePet();
  const peak = petIsPeak(pet);
  const stage = petGrowthStage(pet.growth_points);
  const form = petDisplayForm(pet.pet_type_key, stage.label);
  const mood = petMood(pet);
  const hungerInfo = petHungerLabel(mood.hunger);
  const moreCount = pstate.pets.length - 1;

  return `
    <div class="card pet-hero-card" id="dashboardPetWidgetWrap" style="margin-bottom:20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
      ${petVisualHtml(form, mood.anim, stage.glow, 2.8, "cursor:pointer;", "switchStudentTab('pet')")}
      <div style="flex:1;min-width:220px;">
        <div style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap;">
          <h3 style="margin:0;">${escapeHtml(pet.pet_name || "Your Pet")} ${PET_STAGE_BADGE[stage.label] || ""}</h3>
          <span class="muted" style="font-size:.78rem;">${stage.label}</span>
          ${pet.resting ? `<span class="badge" style="background:#EEF0F7;color:#4B5680;">😴 Resting</span>` : (!peak && pet.sick) ? `<span class="badge" style="background:#FCEBEA;color:var(--clay);">🤒 Sick</span>` : ""}
          ${moreCount > 0 ? `<span class="muted" style="font-size:.72rem;">+${moreCount} more pet${moreCount === 1 ? "" : "s"}</span>` : ""}
        </div>
        <div style="font-size:.82rem;margin:2px 0 6px;">${mood.icon} <em>“${escapeHtml(mood.text)}”</em></div>
        ${(peak || pet.resting) ? "" : `
        <div style="max-width:280px;">
          <div style="display:flex;justify-content:space-between;font-size:.72rem;"><span>🍖 Hunger</span><span style="color:${hungerInfo.color};font-weight:600;">${hungerInfo.label}</span></div>
          <div style="height:8px;background:var(--paper-line);border-radius:5px;overflow:hidden;margin-top:3px;">
            <div style="height:100%;width:${mood.hunger}%;background:${hungerInfo.color};transition:width .4s;"></div>
          </div>
        </div>`}
      </div>
      <button class="btn-outline btn-sm" onclick="switchStudentTab('pet')">${pet.resting ? "☀️ Wake it up" : "🐾 Feed & Visit"}</button>
    </div>`;
}

/** Re-renders the dashboard widget in place (used after a feed elsewhere so the Overview tab is fresh when the student switches back to it). */
async function renderDashboardPetWidget() {
  const wrap = document.getElementById("dashboardPetWidgetWrap");
  if (!wrap) return; // Overview hasn't been rendered this session yet — nothing to patch
  if (!pstate.loaded) await loadMyPets();
  wrap.outerHTML = dashboardPetWidgetHtml();
}

// ============================================================================
// VIRTUAL PET INTERACTIVITY — Touch Petting, Particle Bursts, Snacks, & Nap
// ============================================================================

var _petHappinessClicks = 0;
var _isPetNapping = false;

function handlePetHabitatTap(e) {
  const pet = activePet();
  if (!pet) return;

  _petHappinessClicks++;

  // Spawn floating heart particles near tap
  const stage = document.getElementById("petHabitatStage");
  if (stage) {
    const rect = stage.getBoundingClientRect();
    const x = e && e.clientX ? (e.clientX - rect.left) : (rect.width / 2);
    const y = e && e.clientY ? (e.clientY - rect.top) : (rect.height / 2);
    spawnPetFloatingParticle(stage, x, y, Math.random() > 0.3 ? "💖" : "✨");
  }

  // Trigger cheerful animation and update speech bubble
  const charEl = document.getElementById("petHabitatCharacter");
  if (charEl) {
    charEl.classList.remove("pet-tap-joy");
    void charEl.offsetWidth; // trigger reflow
    charEl.classList.add("pet-tap-joy");
  }

  const speechEl = document.getElementById("petLivingSpeechBubble");
  if (speechEl) {
    const happyQuotes = [
      "✨ *Purrrrr!* You're the best coach!",
      "💖 *Nuzzles hand happily!*",
      "🎉 Let's crush our next Math drill together!",
      "⭐ *Happy hop!* I feel so energized!",
      "🌱 Solving math problems makes us both stronger!"
    ];
    const pick = happyQuotes[_petHappinessClicks % happyQuotes.length];
    speechEl.innerHTML = `💖 “${escapeHtml(pick)}”`;
  }

  // Also trigger companion animation if available
  if (typeof triggerPetEvent === "function") {
    triggerPetEvent("HAPPY", { silent: true });
  }
}

function handleQuickFeedSnack() {
  const pet = activePet();
  if (!pet) return;
  const stage = document.getElementById("petHabitatStage");
  if (stage) {
    const rect = stage.getBoundingClientRect();
    spawnPetFloatingParticle(stage, rect.width / 2, rect.height * 0.7, "🍪");
    setTimeout(() => {
      spawnPetFloatingParticle(stage, rect.width / 2, rect.height * 0.5, "✨");
    }, 300);
  }

  // Feed with available Green Points or first owned food
  const gp = (estate && estate.data && estate.data.green_points) || 0;
  if (gp >= 5) {
    handleFeedGreenPoints(5);
  } else {
    // Try feeding food if owned
    const foods = ["math_snack", "number_nuggets", "equation_cake"];
    const owned = foods.find((f) => ownedFoodCount(pet, f) > 0);
    if (owned) {
      handleFeedFood(owned);
    } else {
      toast("Earn 5 💚 Green Points in Math Drills to feed a full snack!");
    }
  }
}

function handleTogglePetNap() {
  const pet = activePet();
  if (!pet) return;
  _isPetNapping = !_isPetNapping;

  const charEl = document.getElementById("petHabitatCharacter");
  const speechEl = document.getElementById("petLivingSpeechBubble");

  if (_isPetNapping) {
    if (charEl) charEl.classList.add("pet-anim-sleep");
    if (speechEl) speechEl.innerHTML = `💤 “*Zzz... dreaming of equations and stars...*”`;
    const stage = document.getElementById("petHabitatStage");
    if (stage) {
      const rect = stage.getBoundingClientRect();
      spawnPetFloatingParticle(stage, rect.width / 2, rect.height * 0.4, "💤");
    }
  } else {
    if (charEl) charEl.classList.remove("pet-anim-sleep");
    if (speechEl) speechEl.innerHTML = `☀️ “*Yawn!* Ready for more math practice!”`;
  }
}

function spawnPetFloatingParticle(parentEl, x, y, emoji) {
  if (!parentEl) return;
  const p = document.createElement("div");
  p.className = "pet-floating-particle";
  p.textContent = emoji;
  p.style.left = `${x}px`;
  p.style.top = `${y}px`;
  parentEl.appendChild(p);
  setTimeout(() => {
    if (p.parentNode) p.parentNode.removeChild(p);
  }, 1000);
}



// ============================================================================
// RESTING PET: card + Wake-up Warm-up (migration-55)
// ============================================================================
function petRestingCardHtml(pet) {
  const name = escapeHtml(pet.pet_name || "Your pet");
  const since = pet.rested_since ? new Date(pet.rested_since).toLocaleDateString("en-PH", { month: "short", day: "numeric" }) : "";
  return `
    <div class="card" style="background:#EEF0F7;border-color:#C5CBE3;margin-bottom:14px;padding:14px 16px;">
      <strong style="color:#3F4A78;">😴 ${name} is resting${since ? ` (since ${since})` : ""}</strong>
      <div class="muted" style="font-size:.85rem;margin:4px 0 10px;">
        Nothing is lost — ${name} just fell asleep waiting for you. Answer <strong>${PET_WAKE_QUESTIONS} easy questions</strong> (get ${PET_WAKE_PASS} right) to wake it up.
        No timer, no penalty, and you can try as many times as you like.
      </div>
      <button class="btn-primary" onclick="openWakeUpWarmup('${pet.id}')">☀️ Start the Wake-up Warm-up</button>
    </div>`;
}

var wstate = null;
function petModal(html) {
  document.getElementById("modalRoot").innerHTML = `<div class="modal-backdrop"><div class="modal">${html}</div></div>`;
}
function petModalClose() { document.getElementById("modalRoot").innerHTML = ""; }

async function openWakeUpWarmup(petId) {
  const pet = findPet(petId);
  if (!pet) return;
  petModal(`<div class="empty">Getting your questions ready…</div>`);
  wstate = { petId, questions: await wakeUpQuestions(), idx: 0, correct: 0, results: [], phase: "quiz", reason: null, busy: false, last: null };
  renderWakeUp();
}

function renderWakeUp() {
  const w = wstate;
  if (!w) return;
  const pet = findPet(w.petId);
  const name = escapeHtml((pet && pet.pet_name) || "your pet");

  if (w.phase === "quiz") {
    const q = w.questions[w.idx];
    petModal(`
      <div style="display:flex;justify-content:space-between;align-items:baseline;">
        <h3 style="margin:0;">☀️ Wake-up Warm-up</h3>
        <span class="muted" style="font-size:.85rem;">Question ${w.idx + 1} of ${w.questions.length}</span>
      </div>
      <div style="display:flex;gap:6px;margin:8px 0 12px;">${w.questions.map((_, i) => `<div style="flex:1;height:6px;border-radius:4px;background:${i < w.results.length ? (w.results[i] ? "var(--forest)" : "var(--gold)") : "var(--paper-line)"};"></div>`).join("")}</div>
      ${w.last ? `<div style="margin-bottom:8px;font-weight:600;color:${w.last.ok ? "var(--forest)" : "var(--ink-soft,#6b7280)"};">${w.last.ok ? "✅ Yes!" : `Not quite — the answer was ${escapeHtml(w.last.answer)}. On to the next one 🙂`}</div>` : ""}
      <div style="text-align:center;">
        ${q.svg ? `<div style="display:flex;justify-content:center;">${q.svg}</div>` : ""}
        <div style="font-size:1.4rem;font-weight:700;margin:10px 0;">${escapeHtml(q.prompt)}</div>
        ${q.hint ? `<div class="muted" style="font-size:.8rem;margin-bottom:6px;">${escapeHtml(q.hint)}</div>` : ""}
        <div id="wakeInputWrap" style="max-width:300px;margin:0 auto;"><input id="wakeAnswerInput" type="text" placeholder="Your answer" autocomplete="off" style="width:100%;padding:10px;border-radius:8px;border:1px solid var(--paper-line);text-align:center;font-size:1.1rem;"></div>
        <div style="margin-top:10px;"><button class="btn-primary" onclick="wakeSubmit()">Check ✔</button></div>
      </div>
      <div style="text-align:center;margin-top:10px;"><a href="#" class="muted" style="font-size:.8rem;" onclick="petModalClose();return false;">Not now</a></div>`);
    const input = document.getElementById("wakeAnswerInput");
    input.onkeydown = (e) => { if (e.key === "Enter") wakeSubmit(); };
    attachNumericKeypad("wakeAnswerInput", { type: q.type });
    input.focus();
    return;
  }

  if (w.phase === "retry") {
    petModal(`
      <div style="text-align:center;">
        <div style="font-size:2.4rem;">💪</div>
        <h3 style="margin:6px 0;">${w.correct} of ${w.questions.length} — so close!</h3>
        <p class="muted">You need ${PET_WAKE_PASS} to wake ${name}. Here are five fresh questions — you've got this.</p>
        <button class="btn-primary" onclick="wakeTryAgain()">Try again</button>
        <div style="margin-top:8px;"><a href="#" class="muted" style="font-size:.8rem;" onclick="petModalClose();return false;">Not now</a></div>
      </div>`);
    return;
  }

  if (w.phase === "reflect") {
    petModal(`
      <div style="text-align:center;">
        <div style="font-size:2.4rem;">🎉</div>
        <h3 style="margin:6px 0;">${w.correct} of ${w.questions.length} — ${name} is waking up!</h3>
        <p class="muted" style="margin:0 0 10px;">One quick question before ${name} opens its eyes: <strong>what got in the way?</strong><br>
          This isn't a punishment — it just helps your teacher support you, and it helps you notice what to plan for.</p>
        <div style="display:flex;flex-direction:column;gap:8px;max-width:320px;margin:0 auto;">
          ${PET_WAKE_REASONS.map((r) => `<button class="btn-outline" onclick="wakeChooseReason('${r.key}')">${r.icon} ${r.label}</button>`).join("")}
        </div>
      </div>`);
    return;
  }

  if (w.phase === "done") {
    const promise = pstate.promise;
    petModal(`
      <div style="text-align:center;">
        <div style="font-size:2.6rem;">🌟</div>
        <h3 style="margin:6px 0;">${name} is awake and happy!</h3>
        <p class="muted">You showed up and put it right — that's what being responsible looks like. ${w.reason === "hard" ? "And thank you for being honest that the math felt hard — that's exactly what your teacher can help with." : ""}</p>
        ${promise && promise.target_days ? "" : `<p style="margin:12px 0 6px;"><strong>Want to make a small promise for this week?</strong><br><span class="muted" style="font-size:.85rem;">I'll visit my pet on…</span></p>
          <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">${[2, 3, 4, 5].map((d) => `<button class="btn-outline" onclick="wakeMakePromise(${d})">${d} days</button>`).join("")}</div>`}
        <div style="margin-top:14px;"><button class="btn-primary" onclick="wakeClose()">Go see ${name} 🐾</button></div>
      </div>`);
  }
}

function wakeSubmit() {
  const w = wstate;
  if (!w || w.phase !== "quiz") return;
  const input = document.getElementById("wakeAnswerInput");
  const raw = input ? input.value.trim() : "";
  if (!raw) return;
  const q = w.questions[w.idx];
  const ok = checkDrillAnswer(q, raw);
  if (ok) w.correct += 1;
  w.results.push(ok);
  w.last = { ok, answer: fmtDrillAnswer(q) };
  w.idx += 1;
  if (w.idx < w.questions.length) return renderWakeUp();
  w.last = null;
  w.phase = w.correct >= PET_WAKE_PASS ? "reflect" : "retry";
  renderWakeUp();
}

async function wakeTryAgain() {
  const w = wstate; if (!w) return;
  petModal(`<div class="empty">Fresh questions coming…</div>`);
  w.questions = await wakeUpQuestions(); w.idx = 0; w.correct = 0; w.results = []; w.last = null; w.phase = "quiz";
  renderWakeUp();
}

async function wakeChooseReason(reason) {
  const w = wstate; if (!w || w.busy) return;
  w.busy = true; w.reason = reason;
  const res = await wakePet(w.petId, w.correct, w.questions.length, reason);
  w.busy = false;
  if (!res || !res.ok) return renderWakeUp();
  if (typeof triggerPetEvent === "function") triggerPetEvent("OWNER_FEED");
  await loadCarePromise();
  w.phase = "done";
  renderWakeUp();
  if (typeof renderDashboardPetWidget === "function") renderDashboardPetWidget();
}

async function wakeMakePromise(days) {
  const res = await setCarePromise(days);
  if (res && res.ok) toast(`🎗️ Promise made: ${days} days this week. You can do it!`);
  renderWakeUp();
}

function wakeClose() { petModalClose(); wstate = null; renderPetPanel(); }

// ============================================================================
// CARE PROMISE card (migration-55)
// ============================================================================
function petCarePromiseCardHtml(pet) {
  if (!pet || petIsPeak(pet) || pet.resting) return "";      // a Legendary pet needs no care; a resting one needs waking first
  const p = pstate.promise;
  if (!p) return "";
  const kept = p.kept_total || 0;
  const ribbon = kept >= 8 ? "🏅 Gold" : kept >= 4 ? "🥈 Silver" : kept >= 1 ? "🥉 Bronze" : "";
  const keptLine = kept > 0 ? `<span class="muted" style="font-size:.8rem;">🎗️ Promises kept so far: <strong>${kept}</strong>${ribbon ? ` · ${ribbon} Caretaker` : ""}</span>` : `<span class="muted" style="font-size:.8rem;">Keep a promise and it's added to your 🎗️ total — a total that never resets.</span>`;
  if (!p.target_days) {
    return `
      <div class="card" style="margin-top:16px;">
        <h3 style="margin:0 0 4px;">🎗️ Care Promise</h3>
        <p class="muted" style="font-size:.85rem;margin:0 0 8px;">Being responsible starts with a promise you choose yourself. <strong>This week I'll visit ${escapeHtml(pet.pet_name || "my pet")} on…</strong></p>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">${[2, 3, 4, 5, 6, 7].map((d) => `<button class="btn-outline btn-sm" onclick="handleSetPromise(${d})">${d} days</button>`).join("")}</div>
        ${keptLine}
      </div>`;
  }
  const done = Math.min(p.days_cared || 0, p.target_days);
  const dots = Array.from({ length: p.target_days }, (_, i) => `<span style="display:inline-block;width:22px;height:22px;line-height:22px;text-align:center;border-radius:50%;background:${i < done ? "var(--forest)" : "var(--paper-line)"};color:#fff;font-size:.8rem;">${i < done ? "✓" : ""}</span>`).join(" ");
  const complete = (p.days_cared || 0) >= p.target_days;
  return `
    <div class="card" style="margin-top:16px;${complete ? "border-color:var(--forest);" : ""}">
      <h3 style="margin:0 0 4px;">🎗️ My Care Promise this week</h3>
      <p class="muted" style="font-size:.85rem;margin:0 0 8px;">I promised to visit ${escapeHtml(pet.pet_name || "my pet")} on <strong>${p.target_days} days</strong> (Mon–Sun). Feeding your pet counts as a visit.</p>
      <div style="margin-bottom:8px;">${dots}</div>
      <div style="font-weight:600;margin-bottom:6px;">${complete ? "🎉 Promise kept — well done! It will be added to your total when the week ends." : `${done} of ${p.target_days} days so far${done > 0 ? " — keep going!" : " — a quick feed today starts it off."}`}</div>
      ${p.target_days < 7 ? `<div style="margin-bottom:6px;"><span class="muted" style="font-size:.78rem;">Feeling strong? Raise it:</span> ${[p.target_days + 1, 7].filter((d, i, a) => d <= 7 && a.indexOf(d) === i).map((d) => `<button class="btn-outline btn-sm" onclick="handleSetPromise(${d})">${d} days</button>`).join(" ")}</div>` : ""}
      ${keptLine}
    </div>`;
}

async function handleSetPromise(days) {
  const res = await setCarePromise(days);
  if (res && res.ok) { toast(`🎗️ Promise made: ${days} days this week.`); renderPetPanel(); }
}
