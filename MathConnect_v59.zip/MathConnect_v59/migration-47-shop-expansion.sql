-- ============================================================================
-- Migration 47 — High School Drill Expansion: Shop Relics, Wheel of
-- Archimedes, and expanded Pet Shop catalog.
-- Run this once in Supabase → SQL Editor. Companion to the client-side
-- changes in drills.js / teacher-drills.js / shopEngine.js / shop-ui.js /
-- pet-ui.js / style.css (no schema changes were needed for the 6 new drill
-- stations themselves — they're purely client-side generators keyed by
-- topic strings that drill_attempts / skill_proficiency already handle
-- generically).
--
-- What this adds:
--   1. student_engagement.coin_magnet_expires_at — timed-buff column for
--      the new 🧲 Coin Magnet relic, same pattern as double_xp_expires_at.
--   2. 3 new shop_items: coin_magnet, streak_shield, genius_pass.
--   3. consume_shop_item(...) — re-created (return columns changed) to
--      also branch on coin_magnet and set its expiry. streak_shield and
--      genius_pass need no special branch — they're one-shot consumables
--      the client arms/uses within a single Drills run (see drills.js
--      shopEffects.streakShieldArmed / useGeniusPassOnDrill()), so the
--      generic "just decrement inventory" path already covers them.
--   4. award_gemstone(...) — small RPC so the 🎡 Wheel of Archimedes (and
--      the Mystery Box's rare gemstone-shard drop) can grant a gemstone
--      the same safe, atomic way mark_daily_activity() already does.
--   5. 3 new pet_food_items ("Superfoods") + 4 new pet_care_items
--      (category='equipment', "Accessories"). Both tables are read
--      generically by pet-ui.js's renderShopPetSections(), so these show
--      up in the Shop's new "🍕 Pet Treats & Superfoods" / "👒 Pet
--      Accessories" tabs with no further code changes.
-- ============================================================================

-- ---------- 1. Coin Magnet timed-buff column ----------
alter table student_engagement add column if not exists coin_magnet_expires_at timestamptz;

-- ---------- 2. New shop_items: Gameplay Relics ----------
insert into shop_items (id, name, description, cost, effect_type, effect_duration_seconds, sort_order) values
  ('coin_magnet',   'Coin Magnet',    'Doubles Coins earned from correct answers for 15 minutes.',                35, 'buff_timed',  900,  6),
  ('streak_shield', 'Streak Shield',  'Protects your Drills streak from your very next wrong answer.',           25, 'consumable',  null, 7),
  ('genius_pass',   'Genius Pass',    'A 50/50 assist you can use on demand on any Drills question.',            20, 'consumable',  null, 8)
on conflict (id) do update set
  name = excluded.name, description = excluded.description, cost = excluded.cost,
  effect_type = excluded.effect_type, effect_duration_seconds = excluded.effect_duration_seconds,
  sort_order = excluded.sort_order, active = true;

-- ---------- 3. consume_shop_item — re-created with a coin_magnet branch ----------
-- The return signature is gaining a column (new_coin_magnet_expires_at), and
-- Postgres won't let create-or-replace change a function's return columns,
-- so this drops the old signature first.
drop function if exists public.consume_shop_item(uuid, text);

create or replace function public.consume_shop_item(target_student_id uuid, target_item_id text)
returns table(success boolean, message text, new_inventory jsonb, new_double_xp_expires_at timestamptz, new_coin_magnet_expires_at timestamptz)
language plpgsql security definer as $$
declare
  current_inventory jsonb;
  owned_count integer;
  duration_secs integer;
  new_double_xp_expiry timestamptz;
  new_coin_magnet_expiry timestamptz;
begin
  select coalesce(inventory, '{}'::jsonb) into current_inventory
  from student_engagement where student_id = target_student_id for update;

  if current_inventory is null then
    return query select false, 'Nothing owned yet.', '{}'::jsonb, null::timestamptz, null::timestamptz;
    return;
  end if;

  owned_count := coalesce((current_inventory ->> target_item_id)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that item.', current_inventory, null::timestamptz, null::timestamptz;
    return;
  end if;

  current_inventory := jsonb_set(current_inventory, array[target_item_id], to_jsonb(owned_count - 1));

  if target_item_id = 'double_xp' then
    select effect_duration_seconds into duration_secs from shop_items where id = 'double_xp';
    new_double_xp_expiry := now() + make_interval(secs => coalesce(duration_secs, 600));
    update student_engagement set inventory = current_inventory, double_xp_expires_at = new_double_xp_expiry, updated_at = now()
      where student_id = target_student_id;
  elsif target_item_id = 'coin_magnet' then
    select effect_duration_seconds into duration_secs from shop_items where id = 'coin_magnet';
    new_coin_magnet_expiry := now() + make_interval(secs => coalesce(duration_secs, 900));
    update student_engagement set inventory = current_inventory, coin_magnet_expires_at = new_coin_magnet_expiry, updated_at = now()
      where student_id = target_student_id;
  else
    -- streak_shield / genius_pass / confetti_burst / time_freeze / shield:
    -- one-shot consumables the client arms or uses immediately — just
    -- decrementing inventory (already done above) is all the server needs to do.
    update student_engagement set inventory = current_inventory, updated_at = now() where student_id = target_student_id;
  end if;

  return query select true, 'Activated!', current_inventory, new_double_xp_expiry, new_coin_magnet_expiry;
end;
$$;
grant execute on function public.consume_shop_item(uuid, text) to anon, authenticated;

-- ---------- 4. award_gemstone — for the Wheel of Archimedes + enhanced Mystery Box ----------
create or replace function public.award_gemstone(target_student_id uuid, amount integer default 1)
returns integer
language plpgsql security definer as $$
declare
  new_count integer;
begin
  if amount is null or amount <= 0 then amount := 1; end if;
  update student_engagement
    set gemstones = gemstones + amount, updated_at = now()
    where student_id = target_student_id
    returning gemstones into new_count;
  return new_count;
end;
$$;
grant execute on function public.award_gemstone(uuid, integer) to anon, authenticated;

-- ---------- 4b. grant_pet_food — a FREE food grant (no coin charge), for the ----------
-- Mystery Box's "free snack" drop. Mirrors purchase_pet_food's inventory
-- bump but skips the coin deduction entirely, since this is a reward, not a purchase.
create or replace function public.grant_pet_food(target_student_id uuid, target_pet_id uuid, target_food_key text, amount integer default 1)
returns jsonb
language plpgsql security definer as $$
declare
  current_inventory jsonb;
  owned_count integer;
  new_inventory jsonb;
begin
  if amount is null or amount <= 0 then amount := 1; end if;
  select coalesce(food_inventory, '{}'::jsonb) into current_inventory
    from student_pets where id = target_pet_id and student_id = target_student_id for update;

  if current_inventory is null then
    return null;
  end if;

  owned_count := coalesce((current_inventory ->> target_food_key)::integer, 0);
  new_inventory := jsonb_set(current_inventory, array[target_food_key], to_jsonb(owned_count + amount));
  update student_pets set food_inventory = new_inventory, updated_at = now() where id = target_pet_id;
  return new_inventory;
end;
$$;
grant execute on function public.grant_pet_food(uuid, uuid, text, integer) to anon, authenticated;

-- ---------- 5. New Pet Superfoods (pet_food_items) ----------
insert into pet_food_items (key, name, icon, cost_coins, restore_amount, sort_order) values
  ('polynomial_pizza', 'Polynomial Pizza', '🍕', 15, 50,  4),
  ('golden_apple',     'Golden Apple',     '🍎', 30, 100, 5),
  ('geometry_gelato',  'Geometry Gelato',  '🧃', 12, 35,  6)
on conflict (key) do update set
  name = excluded.name, icon = excluded.icon, cost_coins = excluded.cost_coins,
  restore_amount = excluded.restore_amount, sort_order = excluded.sort_order, active = true;

-- ---------- 6. New Pet Accessories (pet_care_items, category='equipment') ----------
insert into pet_care_items (key, name, icon, category, description, cost_coins, decay_reduction_pct, sort_order) values
  ('scholar_cap',  'Scholar''s Cap',  '🎓', 'equipment', 'An academic mortarboard for your pet.',            40, 5, 5),
  ('straw_hat',    'Harvester Hat',   '🌾', 'equipment', 'A woven straw hat, MCPBAHS agri-style.',           40, 5, 6),
  ('neon_visor',   'Neon Visor',      '🕶️', 'equipment', 'Cyber shades with a neon glow.',                   45, 6, 7),
  ('golden_ribbon','Royal Ribbon',    '👑', 'equipment', 'A golden ribbon fit for a champion pet.',          60, 8, 8)
on conflict (key) do update set
  name = excluded.name, icon = excluded.icon, category = excluded.category, description = excluded.description,
  cost_coins = excluded.cost_coins, decay_reduction_pct = excluded.decay_reduction_pct,
  sort_order = excluded.sort_order, active = true;
