-- ============================================================================
-- MathConnect — migration 43: Motivation & Cooperation
-- Part A: Opt-in leaderboard visibility (students can hide from Top 10s)
-- Part B: "Most Improved" — a weekly board that resets every 7 days, so a
--         rough lifetime total never permanently locks a student out of
--         ever appearing on top
-- Part C: Class Quests — a shared section-wide XP goal every student
--         contributes to together, with a teacher-set cooperative reward
--
-- Run this once in Supabase Dashboard → SQL Editor, AFTER supabase-schema.sql,
-- migration-13-math-drills.sql, and migration-14-station-leaderboard-mastery.sql
-- have already been applied.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- PART A.1 — student_preferences (the opt-in switch)
-- A new table rather than a column on `students`, because students write to
-- their own row as anon requests (same model as drill_progress) — `students`
-- itself stays teacher-write-only so a compromised student session can never
-- edit its own name/LRN/section.
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.student_preferences (
  student_id UUID PRIMARY KEY REFERENCES students(id) ON DELETE CASCADE,
  show_on_leaderboard BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

ALTER TABLE student_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public read student_preferences" ON student_preferences;
CREATE POLICY "public read student_preferences" ON student_preferences FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "anyone insert student_preferences" ON student_preferences;
CREATE POLICY "anyone insert student_preferences" ON student_preferences FOR INSERT WITH CHECK (TRUE);
DROP POLICY IF EXISTS "anyone update student_preferences" ON student_preferences;
CREATE POLICY "anyone update student_preferences" ON student_preferences FOR UPDATE USING (TRUE);

-- ----------------------------------------------------------------------------
-- PART A.2 — existing leaderboard/rank functions, made opt-in-aware.
-- A student who opts out disappears from everyone ELSE's Top 10, but still
-- sees their own private rank (their own row is always included for
-- themselves, opted in or not — hiding from classmates isn't the same as
-- hiding your own progress from yourself).
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.grade_level_drill_leaderboard(target_grade_level TEXT, result_limit INT DEFAULT 10)
RETURNS TABLE(student_id UUID, full_name TEXT, section_id UUID, section_name TEXT, total_points INTEGER, games_played INTEGER, best_streak INTEGER)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT st.id, st.full_name, se.id, se.section_name, dp.total_points, dp.games_played, dp.best_streak
  FROM drill_progress dp
  JOIN students st ON st.id = dp.student_id
  JOIN sections se ON se.id = st.section_id
  LEFT JOIN student_preferences sp ON sp.student_id = st.id
  WHERE se.grade_level = target_grade_level
    AND COALESCE(sp.show_on_leaderboard, TRUE) = TRUE
  ORDER BY dp.total_points DESC
  LIMIT result_limit;
$$;
GRANT EXECUTE ON FUNCTION public.grade_level_drill_leaderboard(TEXT, INT) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.student_drill_rank(target_student_id UUID)
RETURNS TABLE(rnk BIGINT, total_points INTEGER, total_students BIGINT)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  WITH target_grade AS (
    SELECT se.grade_level FROM students st JOIN sections se ON se.id = st.section_id WHERE st.id = target_student_id
  ), board AS (
    SELECT dp.student_id, dp.total_points, ROW_NUMBER() OVER (ORDER BY dp.total_points DESC) AS rnk
    FROM drill_progress dp
    JOIN students st ON st.id = dp.student_id
    JOIN sections se ON se.id = st.section_id
    LEFT JOIN student_preferences sp ON sp.student_id = st.id
    WHERE se.grade_level = (SELECT grade_level FROM target_grade)
      AND (COALESCE(sp.show_on_leaderboard, TRUE) = TRUE OR st.id = target_student_id)
  )
  SELECT b.rnk, b.total_points, (SELECT COUNT(*) FROM board) FROM board b WHERE b.student_id = target_student_id;
$$;
GRANT EXECUTE ON FUNCTION public.student_drill_rank(UUID) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.station_leaderboard(target_grade_level TEXT, target_topic TEXT, result_limit INT DEFAULT 10)
RETURNS TABLE(student_id UUID, full_name TEXT, section_id UUID, section_name TEXT, topic_points INTEGER, topic_level INTEGER)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT st.id, st.full_name, se.id, se.section_name,
    COALESCE((dp.topic_points ->> target_topic)::INT, 0),
    COALESCE((dp.topic_levels ->> target_topic)::INT, 1)
  FROM drill_progress dp
  JOIN students st ON st.id = dp.student_id
  JOIN sections se ON se.id = st.section_id
  LEFT JOIN student_preferences sp ON sp.student_id = st.id
  WHERE se.grade_level = target_grade_level
    AND COALESCE((dp.topic_points ->> target_topic)::INT, 0) > 0
    AND COALESCE(sp.show_on_leaderboard, TRUE) = TRUE
  ORDER BY COALESCE((dp.topic_points ->> target_topic)::INT, 0) DESC
  LIMIT result_limit;
$$;
GRANT EXECUTE ON FUNCTION public.station_leaderboard(TEXT, TEXT, INT) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.student_station_rank(target_student_id UUID, target_topic TEXT)
RETURNS TABLE(rnk BIGINT, topic_points INTEGER, total_students BIGINT)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  WITH target_grade AS (
    SELECT se.grade_level FROM students st JOIN sections se ON se.id = st.section_id WHERE st.id = target_student_id
  ), board AS (
    SELECT dp.student_id, COALESCE((dp.topic_points ->> target_topic)::INT, 0) AS pts,
      ROW_NUMBER() OVER (ORDER BY COALESCE((dp.topic_points ->> target_topic)::INT, 0) DESC) AS rnk
    FROM drill_progress dp
    JOIN students st ON st.id = dp.student_id
    JOIN sections se ON se.id = st.section_id
    LEFT JOIN student_preferences sp ON sp.student_id = st.id
    WHERE se.grade_level = (SELECT grade_level FROM target_grade)
      AND (COALESCE(sp.show_on_leaderboard, TRUE) = TRUE OR st.id = target_student_id)
  )
  SELECT b.rnk, b.pts, (SELECT COUNT(*) FROM board) FROM board b WHERE b.student_id = target_student_id;
$$;
GRANT EXECUTE ON FUNCTION public.student_station_rank(UUID, TEXT) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PART B — "Most Improved" (weekly growth board). Scored on points EARNED in
-- the last 7 days only, not lifetime totals — every student starts each week
-- level with everyone else regardless of past scores, so recent effort is
-- what gets the spotlight instead of who's been playing longest.
-- ----------------------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_drill_attempts_played_at ON drill_attempts(played_at);

CREATE OR REPLACE FUNCTION public.weekly_growth_leaderboard(target_grade_level TEXT, result_limit INT DEFAULT 10)
RETURNS TABLE(student_id UUID, full_name TEXT, section_id UUID, section_name TEXT, weekly_points INTEGER)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT st.id, st.full_name, se.id, se.section_name, GREATEST(0, SUM(da.points_earned))::INT AS weekly_points
  FROM drill_attempts da
  JOIN students st ON st.id = da.student_id
  JOIN sections se ON se.id = st.section_id
  LEFT JOIN student_preferences sp ON sp.student_id = st.id
  WHERE se.grade_level = target_grade_level
    AND da.played_at >= NOW() - INTERVAL '7 days'
    AND COALESCE(sp.show_on_leaderboard, TRUE) = TRUE
  GROUP BY st.id, st.full_name, se.id, se.section_name
  HAVING GREATEST(0, SUM(da.points_earned)) > 0
  ORDER BY weekly_points DESC
  LIMIT result_limit;
$$;
GRANT EXECUTE ON FUNCTION public.weekly_growth_leaderboard(TEXT, INT) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.student_weekly_growth_rank(target_student_id UUID)
RETURNS TABLE(rnk BIGINT, weekly_points INTEGER, total_students BIGINT)
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  WITH target_grade AS (
    SELECT se.grade_level FROM students st JOIN sections se ON se.id = st.section_id WHERE st.id = target_student_id
  ), board AS (
    SELECT st.id AS student_id, GREATEST(0, SUM(da.points_earned))::INT AS pts
    FROM drill_attempts da
    JOIN students st ON st.id = da.student_id
    JOIN sections se ON se.id = st.section_id
    LEFT JOIN student_preferences sp ON sp.student_id = st.id
    WHERE se.grade_level = (SELECT grade_level FROM target_grade)
      AND da.played_at >= NOW() - INTERVAL '7 days'
      AND (COALESCE(sp.show_on_leaderboard, TRUE) = TRUE OR st.id = target_student_id)
    GROUP BY st.id
  ), ranked AS (
    SELECT student_id, pts, ROW_NUMBER() OVER (ORDER BY pts DESC) AS rnk FROM board
  )
  SELECT r.rnk, r.pts, (SELECT COUNT(*) FROM ranked) FROM ranked r WHERE r.student_id = target_student_id;
$$;
GRANT EXECUTE ON FUNCTION public.student_weekly_growth_rank(UUID) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PART C — Class Quests: one shared XP bar per section that every student in
-- that section fills together. No individual ranking is exposed to students
-- (only "you contributed X" + the shared total) — the teacher alone can see
-- a private contributor breakdown, useful for quiet 1:1 encouragement rather
-- than public comparison.
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.class_quests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id UUID NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  reward_text TEXT,                 -- what the class earns, in the teacher's own words
  goal_points INTEGER NOT NULL CHECK (goal_points > 0),
  current_points INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_class_quests_section ON class_quests(section_id);

CREATE TABLE IF NOT EXISTS public.class_quest_contributions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quest_id UUID NOT NULL REFERENCES class_quests(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  points_contributed INTEGER NOT NULL,
  contributed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_cqc_quest ON class_quest_contributions(quest_id);
CREATE INDEX IF NOT EXISTS idx_cqc_student ON class_quest_contributions(student_id);

ALTER TABLE class_quests ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_quest_contributions ENABLE ROW LEVEL SECURITY;

-- Students (anon) can read their own section's quests (needed for the shared
-- progress bar); only the owning teacher (or admin) can create/edit/delete.
DROP POLICY IF EXISTS "public read class_quests" ON class_quests;
CREATE POLICY "public read class_quests" ON class_quests FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "teacher write class_quests" ON class_quests;
CREATE POLICY "teacher write class_quests" ON class_quests FOR INSERT WITH CHECK (is_teacher_of_section(section_id));
DROP POLICY IF EXISTS "teacher update class_quests" ON class_quests;
CREATE POLICY "teacher update class_quests" ON class_quests FOR UPDATE USING (is_teacher_of_section(section_id) OR is_admin());
DROP POLICY IF EXISTS "teacher delete class_quests" ON class_quests;
CREATE POLICY "teacher delete class_quests" ON class_quests FOR DELETE USING (is_teacher_of_section(section_id) OR is_admin());

-- Contributions: only the owning teacher can read the breakdown (kept off
-- the student view on purpose, to keep the quest cooperative rather than a
-- ranked list); all writes go through contribute_to_class_quest() below.
DROP POLICY IF EXISTS "teacher read class_quest_contributions" ON class_quest_contributions;
CREATE POLICY "teacher read class_quest_contributions" ON class_quest_contributions FOR SELECT USING (
  EXISTS (SELECT 1 FROM class_quests q WHERE q.id = class_quest_contributions.quest_id AND (is_teacher_of_section(q.section_id) OR is_admin()))
);

-- ----------------------------------------------------------------------------
-- contribute_to_class_quest — called after any drill run (net-positive points
-- only). Atomically increments the section's active quest, logs who
-- contributed how much (for the teacher's private view), and reports back
-- whether this contribution just pushed the quest over its goal so the
-- client can show a class-wide celebration.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.contribute_to_class_quest(p_student_id UUID, p_points INTEGER)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_section_id UUID;
  v_quest class_quests%ROWTYPE;
  v_was_incomplete BOOLEAN;
BEGIN
  IF p_points IS NULL OR p_points <= 0 THEN
    RETURN jsonb_build_object('ok', FALSE, 'reason', 'no_points');
  END IF;

  SELECT section_id INTO v_section_id FROM students WHERE id = p_student_id;
  IF v_section_id IS NULL THEN RETURN jsonb_build_object('ok', FALSE, 'reason', 'student_not_found'); END IF;

  SELECT * INTO v_quest FROM class_quests
    WHERE section_id = v_section_id AND is_active = TRUE
    ORDER BY created_at DESC LIMIT 1;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', FALSE, 'reason', 'no_active_quest'); END IF;

  v_was_incomplete := v_quest.completed_at IS NULL;

  UPDATE class_quests SET
    current_points = current_points + p_points,
    completed_at = CASE WHEN v_was_incomplete AND (current_points + p_points) >= goal_points THEN NOW() ELSE completed_at END,
    updated_at = NOW()
  WHERE id = v_quest.id
  RETURNING * INTO v_quest;

  INSERT INTO class_quest_contributions (quest_id, student_id, points_contributed)
  VALUES (v_quest.id, p_student_id, p_points);

  RETURN jsonb_build_object(
    'ok', TRUE,
    'quest', jsonb_build_object('id', v_quest.id, 'title', v_quest.title, 'reward_text', v_quest.reward_text,
      'goal_points', v_quest.goal_points, 'current_points', v_quest.current_points),
    'just_completed', v_was_incomplete AND v_quest.completed_at IS NOT NULL
  );
END;
$$;
GRANT EXECUTE ON FUNCTION public.contribute_to_class_quest(UUID, INTEGER) TO anon, authenticated;

-- get_active_class_quest — convenience read for the student dashboard widget
-- (a plain SELECT would also work under the public-read policy above, but a
-- function keeps the "one active quest, most recent" rule in one place).
CREATE OR REPLACE FUNCTION public.get_active_class_quest(p_section_id UUID)
RETURNS JSONB
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT to_jsonb(q) FROM class_quests q
  WHERE q.section_id = p_section_id AND q.is_active = TRUE
  ORDER BY q.created_at DESC LIMIT 1;
$$;
GRANT EXECUTE ON FUNCTION public.get_active_class_quest(UUID) TO anon, authenticated;

-- Top contributors — teacher-only, for quiet private encouragement rather
-- than a public ranked list.
CREATE OR REPLACE FUNCTION public.get_class_quest_contributors(p_quest_id UUID)
RETURNS TABLE(student_id UUID, full_name TEXT, total_contributed BIGINT)
LANGUAGE plpgsql SECURITY DEFINER STABLE
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM class_quests q WHERE q.id = p_quest_id AND (is_teacher_of_section(q.section_id) OR is_admin())) THEN
    RETURN;
  END IF;
  RETURN QUERY
  SELECT st.id, st.full_name, SUM(c.points_contributed)
  FROM class_quest_contributions c
  JOIN students st ON st.id = c.student_id
  WHERE c.quest_id = p_quest_id
  GROUP BY st.id, st.full_name
  ORDER BY SUM(c.points_contributed) DESC;
END;
$$;
GRANT EXECUTE ON FUNCTION public.get_class_quest_contributors(UUID) TO authenticated;

-- Self-lookup for the student widget ("you've contributed X pts") — narrower
-- than opening class_quest_contributions to public read, which would let any
-- student see every classmate's individual contribution (exactly the kind of
-- ranked exposure this feature is designed to avoid).
CREATE OR REPLACE FUNCTION public.get_my_quest_contribution(p_quest_id UUID, p_student_id UUID)
RETURNS INTEGER
LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT COALESCE(SUM(points_contributed), 0)::INT FROM class_quest_contributions
  WHERE quest_id = p_quest_id AND student_id = p_student_id;
$$;
GRANT EXECUTE ON FUNCTION public.get_my_quest_contribution(UUID, UUID) TO anon, authenticated;

-- ============================================================================
-- Done. Sanity check:
-- select * from student_preferences limit 1;
-- select * from class_quests limit 1;
-- ============================================================================
