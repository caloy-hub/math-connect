# MathConnect v51 — "Math Lab" UI/UX Overhaul

Zero-build, additive layer on top of v50. No Supabase schema, RLS, or edge
function changes. No existing CSS variables or class names were removed —
everything below is new, so a rollback is just removing the new files/blocks.

## What shipped

**Design system (`style.css`, appended section "MATH LAB DESIGN SYSTEM v51")**
- New palette tokens: `--math-navy`, `--math-slate`, `--math-blueprint`,
  `--math-gold`, `--math-cyan`, `--math-emerald`, `--math-purple`, `--math-rose`
- `.graph-paper-fine` / `.blueprint-grid` millimeter-grid texture utilities
- `.tabular` utility + `tabular-nums` applied directly to existing score/stat/
  timer classes (`.stat-value`, `.progress-ring-inner .pct`, `.drill-stat .num`,
  `.leaderboard-rank`, `.quest-level-num`, `#streakBadge`, drill/raid timers)
- `.math-card` crosshair-corner utility (opt-in, not applied automatically)
- Math Dock: glassmorphic upgrade of the existing mobile bottom nav
  (`backdrop-filter: blur(20px)`, floating rounded capsule, glowing active
  dot) — safe-area padding was already correct in v50, left untouched
- Command Palette, Formula HUD, and Blackboard Scratchpad surface styles
- Login page background layered with a millimeter grid; login/class code
  inputs now render as spaced monospace blocks
- Homepage hero sandbox styles
- Respects `prefers-reduced-motion` throughout

**New file: `math-fx.js`** (vanilla, no deps, included on every portal page)
- Web Audio oscillator synth — click, correct chime (pentatonic), wrong buzz,
  swoosh, fanfare — with a mute toggle persisted to `localStorage`
- Command Palette (`⌘K` / `Ctrl+K` / `/`): **auto-discovers** nav targets by
  scanning `.tab[data-tab]`, `.bottom-nav-item`, `.drawer-item`, and report-
  card links already on the page, so it stays in sync with student.html/
  teacher.html without a hand-maintained list — arrow-key navigation + fuzzy
  text filter
- Formula Reference HUD — static DepEd JHS formulas (area/perimeter/volume,
  quadratic formula, slope, Pythagorean theorem, exponent laws) plus the
  DO 15 WW/PT/Exam weighting, opened from the floating Math Tools button
- Blackboard Scratchpad — pencil/eraser/grid-toggle/clear canvas for scratch
  work, no persistence needed
- `MathFX.countUp()` + an auto-observing rolling-counter that watches for
  `.stat-value` nodes with plain numeric text and animates them once,
  **without requiring any change to student.js/teacher.js's render logic**
- Floating Math Tools button (bottom-right, above the Math Dock)

**Wired into:** `student.html`, `teacher.html`, `admin.html` (full `MathFX.init()`
with FAB + palette + counters), `login.html` (audio module only, no nav to
build a palette from), `index.html` (audio only, for the new hero widget)

**Homepage (`index.html`)**
- New section below the hero: a live Canvas sine/cosine wave sandbox that
  bends toward the cursor/touch position, plus a 3-question rapid math
  challenge (multiplication/addition/subtraction) with instant correct/
  wrong feedback and a chime — the existing cycling drill-problem panel in
  the hero itself was left as-is since it already works well
- Left the existing hero `.calc-panel` alone rather than replacing it

**Navigation labeling (student.html / teacher.html)**
- Sidebar category headers now carry math set-notation prefixes:
  ∑ / ∏ / √ / ∫, per the plan's "mathematical set headers" idea

## Deliberately left out of this pass
- Full canvas-based homepage hero *replacement* (kept the working cycling
  panel, added the sandbox alongside it instead of a risky rewrite)
- Coordinate-vector breadcrumbs inside student.js tab switches (would touch
  the render pipeline directly — flag if you want this wired in next)
- Deep "100% data consistency" audit across student/teacher/admin views —
  that's a QA pass against live data, not a styling change, and is best done
  by you against your Supabase data or by a follow-up audit request
- Admin.html-specific precision-grid dashboard tables (admin got the shared
  design tokens + FAB/palette, but its specific tables weren't individually
  restyled)

## Verification done
- `node -c math-fx.js` — syntax OK
- HTML parse check on all 5 modified pages — OK
- CSS brace balance check on `style.css` — OK (934/934)
- Not run: a live Supabase/browser smoke test, since this sandbox has no
  network access to your Supabase project. Please click through Command
  Palette (⌘K), Formula HUD, and Scratchpad once after deploying.
