-- ============================================================================
-- MathConnect — Literacy Arena difficulty-tier expansion, GRADES 7-12
-- Run AFTER migration-59-literacy-arena.sql, seed-literacy-question-bank.sql,
-- and seed-literacy-grade11-12.sql. This file is additive and independent.
--
-- WHY THIS FILE EXISTS
-- literacyEngine.js now lets a student pick Easy / Medium / Hard before each
-- station, and splits each grade+skill question pool into three RELATIVE
-- difficulty bands by rank (not fixed numbers) — see literacyBucketByTier().
-- The original seed only had 2 raw difficulty values per grade per skill,
-- which made for thin, uneven bands. This file adds a 3rd (harder) band
-- across every grade and roughly doubles vocabulary/spelling, so all three
-- tiers have genuine content instead of leaning on the run-length "repeat
-- with reshuffle" fallback as much.
--
-- Per grade, this adds:
--   - 1 more reading passage (harder: base difficulty + 2) + 4 more
--     comprehension questions for it
--   - 8 more vocabulary items (spread across a 3rd, harder difficulty value)
--   - 8 more spelling items (same)
--
-- Combined with the two earlier seed files, each grade now has 2 passages
-- (8 comprehension questions), 16 vocabulary items, and 16 spelling items —
-- 40 items per grade, 240 total across Grades 7-12.
--
-- Safe to re-run: every insert is idempotent via a fixed id + ON CONFLICT.
-- ============================================================================

-- ============================================================================
-- GRADE 7 — Passage: "Composting at School" (difficulty 4; base passage was 2)
-- ============================================================================
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000013', 'Grade 7', 'Composting at School',
  'Behind the school nursery, students maintain three compost bins labeled "Fresh," "Turning," and "Ready." Every day, the cafeteria''s vegetable peelings and the garden''s dried leaves go into the Fresh bin, layered so that wet, green material alternates with dry, brown material. Once a week, students shovel the Fresh bin''s contents into the Turning bin and mix it thoroughly, a step that lets air reach the microorganisms breaking the material down and keeps the pile from smelling bad. After about two months, the material in the Turning bin becomes dark, crumbly, and earthy-smelling, and it is moved to the Ready bin, where it waits to be mixed into the nursery''s potting soil. Students learned early on that skipping the weekly turning slows everything down: without enough air, the pile turns slimy and sour instead of breaking down properly. The system is simple, but it depends entirely on nobody skipping their turn.',
  'informational', 4
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000025','comprehension','11111111-0000-0000-0000-000000000013','Grade 7',4,'multiple_choice',
 'What is the main idea of this passage?',
 '["Composting is too difficult for students to manage","The school''s three-bin composting system works well only if students keep up with the weekly turning","Cafeteria scraps should not be composted","The Ready bin is the most important of the three bins"]',
 'The school''s three-bin composting system works well only if students keep up with the weekly turning',
 'The passage explains the three-bin process, then closes on the idea that "it depends entirely on nobody skipping their turn."'),
('21111111-0000-0000-0000-000000000026','comprehension','11111111-0000-0000-0000-000000000013','Grade 7',4,'multiple_choice',
 'Based on the passage, what would most likely happen if students stopped turning the Fresh bin''s contents?',
 '["The compost would finish faster","The pile would become slimy and sour instead of breaking down properly","Nothing would change","The bin would need to be turned twice as often"]',
 'The pile would become slimy and sour instead of breaking down properly',
 'The passage states directly that without enough air from turning, "the pile turns slimy and sour instead of breaking down properly."'),
('21111111-0000-0000-0000-000000000027','comprehension','11111111-0000-0000-0000-000000000013','Grade 7',4,'multiple_choice',
 'In the passage, what does "crumbly" describe about the finished compost?',
 '["Wet and sticky","Breaking apart easily into small pieces","Hard like a rock","Bright green in color"]',
 'Breaking apart easily into small pieces',
 '"Dark, crumbly, and earthy-smelling" describes finished compost''s texture — crumbly means it breaks apart easily.'),
('21111111-0000-0000-0000-000000000028','comprehension','11111111-0000-0000-0000-000000000013','Grade 7',4,'multiple_choice',
 'What is the correct order of the compost''s journey through the three bins?',
 '["Ready, Turning, Fresh","Fresh, Turning, Ready","Turning, Fresh, Ready","Fresh, Ready, Turning"]',
 'Fresh, Turning, Ready',
 'The passage describes material starting in Fresh, being moved weekly to Turning, and finally moved to Ready after about two months.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000049','vocabulary','Grade 7',4,'multiple_choice','Choose the word that means the SAME as "maintain" (as used for the compost bins).','["ignore","keep in good condition","destroy","sell"]','keep in good condition','To "maintain" something is to keep it in good working condition through regular care.'),
('22222222-0000-0000-0000-000000000050','vocabulary','Grade 7',4,'multiple_choice','Choose the word that means the OPPOSITE of "fresh" (as used for the Fresh bin).','["new","stale or old","clean","raw"]','stale or old','"Fresh" describes something new or recently added; its opposite here is stale or old.'),
('22222222-0000-0000-0000-000000000051','vocabulary','Grade 7',4,'multiple_choice','"The compost pile released an EARTHY smell." EARTHY most nearly means:','["sweet like candy","smelling like soil","smelling like smoke","having no smell at all"]','smelling like soil','"Earthy" describes a smell reminiscent of soil or the ground — fitting for finished compost.'),
('22222222-0000-0000-0000-000000000052','vocabulary','Grade 7',4,'multiple_choice','The prefix "micro-" in "microorganisms" means:','["very large","very small","very fast","very old"]','very small','"Micro-" means very small, so microorganisms are tiny living things too small to see individually.'),
('22222222-0000-0000-0000-000000000053','vocabulary','Grade 7',4,'multiple_choice','Choose the word that means the SAME as "thoroughly."','["carelessly","completely and carefully","quickly","partly"]','completely and carefully','"Thoroughly" means done completely and with care, leaving nothing out.'),
('22222222-0000-0000-0000-000000000054','vocabulary','Grade 7',4,'multiple_choice','Choose the word that means the OPPOSITE of "skip" (as in skipping a turn).','["miss","do as scheduled","forget","delay"]','do as scheduled','To "skip" a turn means to miss it; its opposite is to do it as scheduled.'),
('22222222-0000-0000-0000-000000000055','vocabulary','Grade 7',4,'multiple_choice','"Students layered wet and dry material ALTERNATELY." ALTERNATELY most nearly means:','["all at once","taking turns, one after the other","never together","only on weekends"]','taking turns, one after the other','"Alternately" describes items placed in turns, one type then the other, repeating.'),
('22222222-0000-0000-0000-000000000056','vocabulary','Grade 7',4,'multiple_choice','The suffix "-ism" in "organism" typically forms:','["a verb showing action","a noun naming a system, state, or living thing","an adjective describing color","an adverb showing time"]','a noun naming a system, state, or living thing','"-ism" forms nouns, often naming a system or entity, as in "organism" — a living thing.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000049','spelling','Grade 7',4,'typed','Spell the word you hear.',null,'nutrient','nutrient',null),
('23333333-0000-0000-0000-000000000050','spelling','Grade 7',4,'typed','Spell the word you hear.',null,'moisture','moisture',null),
('23333333-0000-0000-0000-000000000051','spelling','Grade 7',4,'typed','Spell the word you hear.',null,'temperature','temperature',null),
('23333333-0000-0000-0000-000000000052','spelling','Grade 7',4,'typed','Spell the word you hear.',null,'schedule','schedule',null),
('23333333-0000-0000-0000-000000000053','spelling','Grade 7',4,'multiple_choice','Which sentence uses the correct word? "The students ___ the compost every week."','["turn","turned","turns","turning"]','turn',null,'The sentence needs the base present-tense verb "turn" to agree with the plural subject "students."'),
('23333333-0000-0000-0000-000000000054','spelling','Grade 7',4,'multiple_choice','Choose the correctly spelled word.','["vegetible","vegetable","vegtable","vegetabel"]','vegetable',null,'"Vegetable" is the correct spelling — note the "e" after "vege" and before "table."'),
('23333333-0000-0000-0000-000000000055','spelling','Grade 7',4,'multiple_choice','Which sentence uses the correct word? "___ material, like dried leaves, balances wet scraps in the bin."','["Dry","Dryed","Dried","Drys"]','Dry',null,'"Dry" is the correct adjective describing the leaves — "dried" would describe something that underwent drying, not fit here as the pairing term used in the passage.'),
('23333333-0000-0000-0000-000000000056','spelling','Grade 7',4,'multiple_choice','Spot the misspelled word: "The nusery grows seedlings before they are transferred outside."','["nusery","grows","seedlings","transferred"]','nusery',null,'"Nusery" should be spelled "nursery" — missing the "r" after "nu."')
on conflict (id) do nothing;

-- ============================================================================
-- GRADE 8 — Passage: "The Farmer Who Waited" (difficulty 5; base passage was 3)
-- ============================================================================
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000014', 'Grade 8', 'The Farmer Who Waited',
  'Mang Ilyong had farmed the same half-hectare for thirty years, and every season his neighbors asked him the same question: why did he leave part of his land unplanted while everyone else squeezed in one more row of vegetables? His answer was always the same — crop rotation. By planting legumes like mung beans in the section that had just finished a heavy corn harvest, he let the soil recover nitrogen that the corn had used up, instead of immediately demanding more from it. His neighbors, eager for a fuller harvest each season, often skipped this resting period, and over the years their soil grew harder and less productive, requiring more and more fertilizer just to match yields Mang Ilyong achieved with less. It was not that he harvested less overall; his fields simply took longer, season by season, to show it. By the time the neighbors began asking to borrow his methods, Mang Ilyong had already spent three decades proving that some investments only pay off if you are willing to wait for them.',
  'narrative', 5
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000029','comprehension','11111111-0000-0000-0000-000000000014','Grade 8',5,'multiple_choice',
 'What is the main idea of this passage?',
 '["Mang Ilyong wasted land by leaving it unplanted","Mang Ilyong''s patient crop rotation eventually outperformed his neighbors'' methods","Corn should never be planted on the same land as vegetables","Neighbors should never ask farmers for advice"]',
 'Mang Ilyong''s patient crop rotation eventually outperformed his neighbors'' methods',
 'The passage follows Mang Ilyong''s long-term strategy and ends with his neighbors eventually asking to borrow his methods.'),
('21111111-0000-0000-0000-000000000030','comprehension','11111111-0000-0000-0000-000000000014','Grade 8',5,'multiple_choice',
 'What can you infer caused the neighbors'' soil to grow "harder and less productive" over the years?',
 '["They planted legumes too often","They skipped the resting/rotation period Mang Ilyong used","They used too much water","They planted only corn every other year"]',
 'They skipped the resting/rotation period Mang Ilyong used',
 'The passage states the neighbors "often skipped this resting period," which is directly linked to their declining soil quality.'),
('21111111-0000-0000-0000-000000000031','comprehension','11111111-0000-0000-0000-000000000014','Grade 8',5,'multiple_choice',
 'In the passage, what does "yields" mean, as used about the neighbors'' harvests?',
 '["The amount a farm produces","The price of crops at market","The size of the farmland","The number of workers on a farm"]',
 'The amount a farm produces',
 '"Yields" refers to the quantity of crop a farm produces — here, what the neighbors needed more fertilizer to match.'),
('21111111-0000-0000-0000-000000000032','comprehension','11111111-0000-0000-0000-000000000014','Grade 8',5,'multiple_choice',
 'What is the author''s likely purpose in the closing line about "investments that only pay off if you are willing to wait"?',
 '["To criticize Mang Ilyong for being slow","To sum up the lesson of patience and long-term thinking the story illustrates","To suggest farming is not worth the effort","To argue that neighbors should stop farming entirely"]',
 'To sum up the lesson of patience and long-term thinking the story illustrates',
 'The closing line is a summarizing statement that frames the whole narrative''s point: patience pays off over time.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000057','vocabulary','Grade 8',5,'multiple_choice','Choose the word that means the SAME as "recover" (as used for soil recovering nitrogen).','["lose","regain","waste","avoid"]','regain','"Recover" means to get something back — here, the soil regaining nitrogen it had lost.'),
('22222222-0000-0000-0000-000000000058','vocabulary','Grade 8',5,'multiple_choice','Choose the word that means the OPPOSITE of "productive" (as used for the soil).','["fertile","unproductive or barren","rich","abundant"]','unproductive or barren','"Productive" soil produces good yields; its opposite is unproductive or barren soil.'),
('22222222-0000-0000-0000-000000000059','vocabulary','Grade 8',5,'multiple_choice','"The two methods achieved similar yields EVENTUALLY." EVENTUALLY most nearly means:','["immediately","after some time had passed","never","only once"]','after some time had passed','"Eventually" signals that something happens after a period of time, not right away.'),
('22222222-0000-0000-0000-000000000060','vocabulary','Grade 8',5,'multiple_choice','The root "rot" in "rotation" relates to:','["to turn or revolve","to grow quickly","to decay","to measure"]','to turn or revolve','"Rot-" comes from Latin "rotare," to turn — crop rotation means cycling through different crops.'),
('22222222-0000-0000-0000-000000000061','vocabulary','Grade 8',5,'multiple_choice','Choose the word that means the SAME as "demanding" (as used for soil demanding more fertilizer).','["requiring a lot","offering a lot","ignoring","reducing"]','requiring a lot','Soil that is "demanding" requires more input, such as fertilizer, to keep producing.'),
('22222222-0000-0000-0000-000000000062','vocabulary','Grade 8',5,'multiple_choice','Choose the word that means the OPPOSITE of "patient" (as used to describe Mang Ilyong''s approach).','["calm","hasty or impatient","careful","steady"]','hasty or impatient','"Patient" describes someone willing to wait; its opposite is hasty or impatient.'),
('22222222-0000-0000-0000-000000000063','vocabulary','Grade 8',5,'multiple_choice','"The neighbors were EAGER for a fuller harvest each season." EAGER most nearly means:','["reluctant","strongly wanting something","indifferent","afraid"]','strongly wanting something','"Eager" describes strong enthusiasm or desire for something.'),
('22222222-0000-0000-0000-000000000064','vocabulary','Grade 8',5,'multiple_choice','The suffix "-ity" in "productivity" typically forms:','["a verb","an adjective","a noun naming a quality or state","a preposition"]','a noun naming a quality or state','"-ity" turns adjectives into abstract nouns naming a quality, e.g. productive → productivity.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000057','spelling','Grade 8',5,'typed','Spell the word you hear.',null,'nitrogen','nitrogen',null),
('23333333-0000-0000-0000-000000000058','spelling','Grade 8',5,'typed','Spell the word you hear.',null,'fertilizer','fertilizer',null),
('23333333-0000-0000-0000-000000000059','spelling','Grade 8',5,'typed','Spell the word you hear.',null,'legumes','legumes',null),
('23333333-0000-0000-0000-000000000060','spelling','Grade 8',5,'typed','Spell the word you hear.',null,'decade','decade',null),
('23333333-0000-0000-0000-000000000061','spelling','Grade 8',5,'multiple_choice','Which sentence uses the correct word? "His fields ___ longer to show results."','["took","taken","takes","taking"]','took',null,'The past-tense narrative needs "took," matching the past-tense verbs used throughout the passage.'),
('23333333-0000-0000-0000-000000000062','spelling','Grade 8',5,'multiple_choice','Choose the correctly spelled word.','["harvist","harvest","harvast","harvust"]','harvest',null,'"Harvest" is the correct spelling.'),
('23333333-0000-0000-0000-000000000063','spelling','Grade 8',5,'multiple_choice','Which sentence uses the correct word? "The soil needed time to ___ its nutrients."','["regain","regane","regayn","reagin"]','regain',null,'"Regain" (to get back) is the correctly spelled word fitting the sentence.'),
('23333333-0000-0000-0000-000000000064','spelling','Grade 8',5,'multiple_choice','Spot the misspelled word: "His neighbers eventually asked to borrow his methods."','["neighbers","eventually","asked","borrow"]','neighbers',null,'"Neighbers" should be spelled "neighbors."')
on conflict (id) do nothing;

-- ============================================================================
-- GRADE 9 — Passage: "Why the Fish Pond Turned Green" (difficulty 6; base was 4)
-- ============================================================================
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000015', 'Grade 9', 'Why the Fish Pond Turned Green',
  'Two weeks after the school''s tilapia pond turned a thick, murky green, several fish began floating near the surface, gasping at the waterline. The Fishery Arts adviser explained that the color change was an algal bloom, caused by an excess of nutrients, mainly from uneaten fish feed and waste, accumulating in the water. During the day, the algae had actually been producing oxygen through photosynthesis, but at night, without sunlight, both the algae and the fish competed for the pond''s dissolved oxygen, and the algae population had grown so large that the fish began losing that competition. The fix was not a single action but a combination: students reduced the feeding rate to cut down on uneaten food, partially drained and refreshed a portion of the pond water, and installed a small aerator to keep oxygen levels stable through the night. Within a week, the water cleared and the fish returned to normal behavior. The adviser used the incident as a case study, noting that a pond''s health is rarely threatened by one mistake alone, but by several small ones compounding unnoticed.',
  'informational', 6
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000033','comprehension','11111111-0000-0000-0000-000000000015','Grade 9',6,'multiple_choice',
 'What is the main idea of this passage?',
 '["Algae is always harmful to fish ponds","An algal bloom caused by excess nutrients nearly harmed the fish, and fixing it required several combined actions","Tilapia cannot survive in green water under any circumstances","Aerators are unnecessary for healthy fish ponds"]',
 'An algal bloom caused by excess nutrients nearly harmed the fish, and fixing it required several combined actions',
 'The passage traces the cause (excess nutrients → algal bloom) and explains that the fix combined several steps, not one.'),
('21111111-0000-0000-0000-000000000034','comprehension','11111111-0000-0000-0000-000000000015','Grade 9',6,'multiple_choice',
 'Based on the passage, why were the fish gasping at night specifically, rather than during the day?',
 '["Algae only appears at night","At night, algae stopped producing oxygen and competed with fish for the pond''s remaining dissolved oxygen","Fish only breathe at night","The water was colder at night"]',
 'At night, algae stopped producing oxygen and competed with fish for the pond''s remaining dissolved oxygen',
 'The passage explains that without sunlight at night, algae no longer produced oxygen and instead competed with fish for it.'),
('21111111-0000-0000-0000-000000000035','comprehension','11111111-0000-0000-0000-000000000015','Grade 9',6,'multiple_choice',
 'In the passage, what does "compounding" mean, as used about small mistakes?',
 '["Cancelling each other out","Building up together to create a bigger effect","Happening only once","Being immediately noticed"]',
 'Building up together to create a bigger effect',
 'The adviser notes pond health is threatened by several small mistakes "compounding unnoticed" — building up together over time.'),
('21111111-0000-0000-0000-000000000036','comprehension','11111111-0000-0000-0000-000000000015','Grade 9',7,'multiple_choice',
 'What is the author''s likely purpose in including the adviser''s closing observation about compounding mistakes?',
 '["To blame the students for the incident","To generalize a lesson about pond management beyond this one event","To argue that fish ponds are too risky to maintain","To suggest the aerator alone solved the problem"]',
 'To generalize a lesson about pond management beyond this one event',
 'The closing observation turns a specific incident into a broader lesson — a common technique for ending an informational case study.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000065','vocabulary','Grade 9',6,'multiple_choice','Choose the word that means the SAME as "excess" (as used for excess nutrients).','["shortage","more than needed","exact amount","balanced"]','more than needed','"Excess" means an amount beyond what is needed or normal.'),
('22222222-0000-0000-0000-000000000066','vocabulary','Grade 9',6,'multiple_choice','Choose the word that means the OPPOSITE of "accumulate" (as used for nutrients building up).','["gather","disperse or reduce","increase","collect"]','disperse or reduce','"Accumulate" means to gather or build up; its opposite is to disperse or reduce.'),
('22222222-0000-0000-0000-000000000067','vocabulary','Grade 9',6,'multiple_choice','"The fish began to lose the COMPETITION for oxygen." COMPETITION most nearly means:','["a friendly game","a struggle between rivals for a limited resource","a scientific test","a type of pond plant"]','a struggle between rivals for a limited resource','"Competition" here describes fish and algae both needing the pond''s limited dissolved oxygen.'),
('22222222-0000-0000-0000-000000000068','vocabulary','Grade 9',6,'multiple_choice','The root "photo" in "photosynthesis" relates to:','["light","water","food","air"]','light','"Photo-" comes from Greek, meaning light — photosynthesis is the process plants use light to make food.'),
('22222222-0000-0000-0000-000000000069','vocabulary','Grade 9',6,'multiple_choice','Choose the word that means the SAME as "dissolved" (as used for dissolved oxygen).','["mixed thoroughly into a liquid","frozen solid","evaporated completely","separated out"]','mixed thoroughly into a liquid','"Dissolved" describes a substance, like oxygen, mixed completely into a liquid.'),
('22222222-0000-0000-0000-000000000070','vocabulary','Grade 9',6,'multiple_choice','Choose the word that means the OPPOSITE of "murky" (as used to describe the pond water).','["cloudy","clear","dark","green"]','clear','"Murky" means cloudy or unclear; its opposite is clear.'),
('22222222-0000-0000-0000-000000000071','vocabulary','Grade 9',7,'multiple_choice','"The adviser used the incident as a CASE STUDY." CASE STUDY most nearly means:','["a random guess","a detailed examination of one specific example used to draw a lesson","a type of container","an exam question"]','a detailed examination of one specific example used to draw a lesson','A "case study" examines one real example in depth to draw broader lessons — exactly how the adviser used the pond incident.'),
('22222222-0000-0000-0000-000000000072','vocabulary','Grade 9',7,'multiple_choice','The suffix "-ate" in "aerate" typically forms:','["a noun","a verb meaning to cause or make something happen","an adjective","a plural form"]','a verb meaning to cause or make something happen','"-ate" often forms verbs meaning to cause a state, e.g. "aerate" = to introduce air into.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000065','spelling','Grade 9',6,'typed','Spell the word you hear.',null,'photosynthesis','photosynthesis',null),
('23333333-0000-0000-0000-000000000066','spelling','Grade 9',6,'typed','Spell the word you hear.',null,'oxygen','oxygen',null),
('23333333-0000-0000-0000-000000000067','spelling','Grade 9',7,'typed','Spell the word you hear.',null,'aerator','aerator',null),
('23333333-0000-0000-0000-000000000068','spelling','Grade 9',6,'typed','Spell the word you hear.',null,'nutrients','nutrients',null),
('23333333-0000-0000-0000-000000000069','spelling','Grade 9',6,'multiple_choice','Which sentence uses the correct word? "The students ___ the feeding rate to fix the problem."','["reduced","reduce","reducing","reduces"]','reduced',null,'The past-tense narrative needs "reduced," matching the other past-tense verbs describing what the students did.'),
('23333333-0000-0000-0000-000000000070','spelling','Grade 9',6,'multiple_choice','Choose the correctly spelled word.','["bloom","bloome","bllom","bloom"]','bloom',null,'"Bloom" is the correct spelling, referring to a sudden growth of algae.'),
('23333333-0000-0000-0000-000000000071','spelling','Grade 9',7,'multiple_choice','Which sentence uses the correct word? "The pond water began to ___ within a week."','["clear","cleer","clere","clear"]','clear',null,'"Clear" is correctly spelled, describing the water returning to normal.'),
('23333333-0000-0000-0000-000000000072','spelling','Grade 9',6,'multiple_choice','Spot the misspelled word: "The advisor explained the algea bloom to the class."','["advisor","explained","algea","class"]','algea',null,'"Algea" should be spelled "algae."')
on conflict (id) do nothing;

-- ============================================================================
-- GRADE 10 — Passage: "Choosing Between Two Loans" (difficulty 7; base was 5)
-- ============================================================================
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000016', 'Grade 10', 'Choosing Between Two Loans',
  'When a cooperative offered to lend equipment money to farmer-members, two financing options were presented at the general assembly. The first option charged a lower interest rate but required full repayment within one year, a timeline some members worried was too short given how harvest income fluctuates season to season. The second option spread repayment across three years at a higher interest rate, which meant smaller monthly payments but a larger total amount paid back once interest accumulated over the longer term. A financial literacy volunteer walked the assembly through a simple comparison: for a loan of the same size, the one-year option would cost less overall in interest, but demanded a much larger lump sum that could strain a household if the harvest underperformed that particular year. The three-year option cost more in total but reduced the risk of any single bad season causing a missed payment. Neither option was objectively "better" — the volunteer stressed that the right choice depended on each household''s savings cushion and how much risk they could comfortably absorb, not on which number looked smaller on paper.',
  'informational', 7
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000037','comprehension','11111111-0000-0000-0000-000000000016','Grade 10',7,'multiple_choice',
 'What is the main idea of this passage?',
 '["The three-year loan is always the smarter financial choice","Choosing between the two loan options depends on a household''s risk tolerance and savings, not just the interest rate","The one-year loan should never be considered","Cooperatives should stop offering equipment loans"]',
 'Choosing between the two loan options depends on a household''s risk tolerance and savings, not just the interest rate',
 'The passage explicitly ends by stating the right choice "depended on each household''s savings cushion and how much risk they could comfortably absorb."'),
('21111111-0000-0000-0000-000000000038','comprehension','11111111-0000-0000-0000-000000000016','Grade 10',7,'multiple_choice',
 'Based on the passage, which household would most likely benefit from the three-year option?',
 '["One with a large savings cushion and low risk tolerance","One with little savings, worried a bad harvest could cause a missed payment","One that wants to pay the least total interest possible","One that has no other debts at all"]',
 'One with little savings, worried a bad harvest could cause a missed payment',
 'The three-year option "reduced the risk of any single bad season causing a missed payment," making it a better fit for a lower-savings household.'),
('21111111-0000-0000-0000-000000000039','comprehension','11111111-0000-0000-0000-000000000016','Grade 10',7,'multiple_choice',
 'In the passage, what does "fluctuates" mean, as used about harvest income?',
 '["Stays exactly the same","Changes unpredictably up and down","Always increases","Always decreases"]',
 'Changes unpredictably up and down',
 '"Fluctuates" describes something that varies or changes irregularly — fitting harvest income that rises and falls by season.'),
('21111111-0000-0000-0000-000000000040','comprehension','11111111-0000-0000-0000-000000000016','Grade 10',7,'multiple_choice',
 'What is the volunteer''s likely purpose in stressing that neither option was "objectively better"?',
 '["To avoid answering the members'' questions","To help members make the decision based on their own situation rather than a single correct answer","To confuse the assembly on purpose","To promote the cooperative''s own interests"]',
 'To help members make the decision based on their own situation rather than a single correct answer',
 'The volunteer''s framing pushes decision-making toward each household''s own circumstances, not a one-size-fits-all answer.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000073','vocabulary','Grade 10',7,'multiple_choice','Choose the word that means the SAME as "accumulated" (as used for interest building up).','["disappeared","built up over time","was paid off","was cancelled"]','built up over time','"Accumulated" means gathered or built up gradually over time.'),
('22222222-0000-0000-0000-000000000074','vocabulary','Grade 10',7,'multiple_choice','Choose the word that means the OPPOSITE of "strain" (as used for a lump sum straining a household).','["burden","relieve","pressure","stress"]','relieve','"Strain" means to put pressure or burden on something; its opposite is to relieve.'),
('22222222-0000-0000-0000-000000000075','vocabulary','Grade 10',7,'multiple_choice','"The harvest UNDERPERFORMED that year." UNDERPERFORMED most nearly means:','["did better than expected","did worse than expected","stayed exactly as expected","was cancelled entirely"]','did worse than expected','"Underperformed" means to perform below expectations — a smaller harvest than hoped for.'),
('22222222-0000-0000-0000-000000000076','vocabulary','Grade 10',7,'multiple_choice','The root "fin" in "financing" and "final" relates to:','["end or limit","money","speed","water"]','end or limit','"Fin-" comes from Latin "finis," meaning end or limit; "financing" originally relates to settling a debt/end of an obligation.'),
('22222222-0000-0000-0000-000000000077','vocabulary','Grade 10',7,'multiple_choice','Choose the word that means the SAME as "cushion" (as used for a savings cushion).','["a burden","a financial buffer against hardship","a type of loan","a monthly payment"]','a financial buffer against hardship','A "cushion" here means savings that soften the impact of a financial shock.'),
('22222222-0000-0000-0000-000000000078','vocabulary','Grade 10',7,'multiple_choice','Choose the word that means the OPPOSITE of "absorb" (as used for absorbing risk).','["withstand","reject or be unable to handle","tolerate","accept"]','reject or be unable to handle','To "absorb" risk means to withstand it without major harm; its opposite is being unable to handle it.'),
('22222222-0000-0000-0000-000000000079','vocabulary','Grade 10',7,'multiple_choice','"The comparison was presented at the general ASSEMBLY." ASSEMBLY most nearly means:','["a type of machine","a formal gathering of members","a written report","a private meeting of two people"]','a formal gathering of members','An "assembly" is a formal meeting or gathering, here of the cooperative''s members.'),
('22222222-0000-0000-0000-000000000080','vocabulary','Grade 10',7,'multiple_choice','The suffix "-ive" in "objective" typically forms:','["a noun","an adjective describing a quality or tendency","a verb","a plural noun"]','an adjective describing a quality or tendency','"-ive" commonly forms adjectives, e.g. "object" → "objective" (fair, not influenced by feelings).')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000073','spelling','Grade 10',7,'typed','Spell the word you hear.',null,'cooperative','cooperative',null),
('23333333-0000-0000-0000-000000000074','spelling','Grade 10',7,'typed','Spell the word you hear.',null,'installment','installment',null),
('23333333-0000-0000-0000-000000000075','spelling','Grade 10',7,'typed','Spell the word you hear.',null,'comparison','comparison',null),
('23333333-0000-0000-0000-000000000076','spelling','Grade 10',7,'typed','Spell the word you hear.',null,'household','household',null),
('23333333-0000-0000-0000-000000000077','spelling','Grade 10',7,'multiple_choice','Which sentence uses the correct word? "The volunteer ___ the assembly through the comparison."','["walked","walk","walking","walks"]','walked',null,'The past-tense narrative needs "walked," matching the passage''s other past-tense verbs.'),
('23333333-0000-0000-0000-000000000078','spelling','Grade 10',7,'multiple_choice','Choose the correctly spelled word.','["intrest","interest","interrest","intersst"]','interest',null,'"Interest" is the correct spelling.'),
('23333333-0000-0000-0000-000000000079','spelling','Grade 10',7,'multiple_choice','Which sentence uses the correct word? "Members worried the timeline was too ___."','["short","shourt","shrot","shortt"]','short',null,'"Short" is the correctly spelled word describing the one-year repayment period.'),
('23333333-0000-0000-0000-000000000080','spelling','Grade 10',7,'multiple_choice','Spot the misspelled word: "The reapyment schedule affected every household differently."','["reapyment","schedule","affected","household"]','reapyment',null,'"Reapyment" should be spelled "repayment."')
on conflict (id) do nothing;

-- ============================================================================
-- GRADE 11 — Passage: "The Debate Over Organic Certification" (difficulty 7; base was 5)
-- ============================================================================
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000017', 'Grade 11', 'The Debate Over Organic Certification',
  'Obtaining official organic certification allows a farm to sell its produce at a premium price, often 20 to 30 percent above conventional market rates, but the certification process itself is neither quick nor cheap. It typically requires a multi-year transition period during which the farm must already follow organic practices without yet being allowed to market the produce as organic, effectively absorbing the higher costs of organic farming while still selling at conventional prices. Supporters of certification argue that the eventual price premium, combined with growing consumer demand for verified organic goods, makes the investment worthwhile for farms with the capital to survive the transition period. Critics point out that this transition period effectively excludes smallholder farmers who cannot afford years of reduced income, meaning certification can end up rewarding farms that were already well-capitalized rather than genuinely leveling the playing field for sustainable practices. An alternative gaining attention is participatory guarantee systems, where local farmer networks verify each other''s practices without the cost of formal third-party certification, trading some market credibility for significantly lower barriers to entry. Whether this trade-off is worthwhile likely depends on which problem a given farming community is trying to solve first: trust with distant buyers, or access for farmers who cannot wait years to be paid fairly.',
  'argumentative', 7
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000041','comprehension','11111111-0000-0000-0000-000000000017','Grade 11',7,'multiple_choice',
 'What is the main idea of this passage?',
 '["Organic certification is a scam that benefits no one","Organic certification offers real benefits but also real barriers, and alternatives like participatory guarantee systems trade one problem for another","All farms should pursue organic certification immediately","Participatory guarantee systems are always superior to certification"]',
 'Organic certification offers real benefits but also real barriers, and alternatives like participatory guarantee systems trade one problem for another',
 'The passage lays out certification''s benefits and costs, then presents the alternative as its own trade-off rather than a clear winner.'),
('21111111-0000-0000-0000-000000000042','comprehension','11111111-0000-0000-0000-000000000017','Grade 11',7,'multiple_choice',
 'Based on the passage, why might smallholder farmers be excluded from organic certification even if their farming practices already qualify?',
 '["Organic farming practices are illegal for smallholders","They cannot afford the reduced income during the multi-year transition period","Certification is only available to farms outside their region","They lack access to organic seeds"]',
 'They cannot afford the reduced income during the multi-year transition period',
 'The passage states the transition period "effectively excludes smallholder farmers who cannot afford years of reduced income."'),
('21111111-0000-0000-0000-000000000043','comprehension','11111111-0000-0000-0000-000000000017','Grade 11',7,'multiple_choice',
 'In the passage, what does "capitalized" mean, as used about well-capitalized farms?',
 '["Having enough financial resources to operate","Being located in a capital city","Following organic practices","Having formal certification already"]',
 'Having enough financial resources to operate',
 '"Well-capitalized" describes farms with sufficient financial resources — here, enough to survive the unpaid transition period.'),
('21111111-0000-0000-0000-000000000044','comprehension','11111111-0000-0000-0000-000000000017','Grade 11',8,'multiple_choice',
 'What is the author''s likely purpose in framing the final choice as depending on "which problem a community is trying to solve first"?',
 '["To avoid taking a clear position because the answer genuinely depends on context","To argue that participatory guarantee systems are objectively better","To dismiss the concerns of smallholder farmers","To argue that certification should be abolished entirely"]',
 'To avoid taking a clear position because the answer genuinely depends on context',
 'The passage consistently frames both systems as solving different problems, so the ending reflects that this is a genuine, context-dependent trade-off rather than a simple verdict.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000081','vocabulary','Grade 11',7,'multiple_choice','Choose the word that means the SAME as "premium" (as used for a price premium).','["a discount","an amount above the normal price","a penalty fee","a type of certificate"]','an amount above the normal price','A "premium" price is one set above the standard rate, often due to perceived higher value.'),
('22222222-0000-0000-0000-000000000082','vocabulary','Grade 11',7,'multiple_choice','Choose the word that means the OPPOSITE of "exclude" (as used for certification excluding smallholders).','["reject","include","remove","ignore"]','include','"Exclude" means to leave out; its opposite is to include.'),
('22222222-0000-0000-0000-000000000083','vocabulary','Grade 11',8,'multiple_choice','"The system trades market credibility for lower BARRIERS TO ENTRY." BARRIERS TO ENTRY most nearly means:','["rewards for joining","obstacles that make it harder to start participating","legal requirements only for large farms","advertising costs"]','obstacles that make it harder to start participating','"Barriers to entry" are obstacles that make it difficult to begin participating in a system or market.'),
('22222222-0000-0000-0000-000000000084','vocabulary','Grade 11',7,'multiple_choice','The root "cred" in "credibility" relates to:','["belief or trust","money","law","speed"]','belief or trust','"Cred-" comes from Latin "credere," to believe — credibility means being worthy of belief or trust.'),
('22222222-0000-0000-0000-000000000085','vocabulary','Grade 11',7,'multiple_choice','Choose the word that means the SAME as "verified" (as used for verified organic goods).','["assumed","confirmed as true or accurate","denied","advertised"]','confirmed as true or accurate','"Verified" means confirmed to be true or accurate, typically through some checking process.'),
('22222222-0000-0000-0000-000000000086','vocabulary','Grade 11',8,'multiple_choice','Choose the word that means the OPPOSITE of "genuinely" (as used for "genuinely leveling the playing field").','["truly","falsely or only in appearance","clearly","honestly"]','falsely or only in appearance','"Genuinely" means truly or authentically; its opposite suggests something is only apparent, not real.'),
('22222222-0000-0000-0000-000000000087','vocabulary','Grade 11',7,'multiple_choice','"Farmer networks VERIFY each other''s practices." In this context, VERIFY most nearly means:','["ignore","check and confirm","criticize","advertise"]','check and confirm','"Verify" means to check that something is true or meets a standard.'),
('22222222-0000-0000-0000-000000000088','vocabulary','Grade 11',8,'multiple_choice','The suffix "-ory" in "participatory" typically forms:','["a noun","an adjective related to a process or activity","a verb","an adverb of place"]','an adjective related to a process or activity','"-ory" forms adjectives related to a process, e.g. "participate" → "participatory" (involving participation).')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000081','spelling','Grade 11',7,'typed','Spell the word you hear.',null,'certification','certification',null),
('23333333-0000-0000-0000-000000000082','spelling','Grade 11',7,'typed','Spell the word you hear.',null,'transition','transition',null),
('23333333-0000-0000-0000-000000000083','spelling','Grade 11',8,'typed','Spell the word you hear.',null,'participatory','participatory',null),
('23333333-0000-0000-0000-000000000084','spelling','Grade 11',7,'typed','Spell the word you hear.',null,'smallholder','smallholder',null),
('23333333-0000-0000-0000-000000000085','spelling','Grade 11',7,'multiple_choice','Which sentence uses the correct word? "The premium made the investment ___ for larger farms."','["worthwhile","worthwile","worthwhille","wortwhile"]','worthwhile',null,'"Worthwhile" is the correct spelling, meaning worth the time, money, or effort.'),
('23333333-0000-0000-0000-000000000086','spelling','Grade 11',7,'multiple_choice','Choose the correctly spelled word.','["capitel","capital","capitol","capitl"]','capital',null,'In the financial sense used here, "capital" (funds/resources) is correct — "capitol" refers to a government building.'),
('23333333-0000-0000-0000-000000000087','spelling','Grade 11',8,'multiple_choice','Which sentence uses the correct word? "Local networks ___ each other''s practices instead of using formal certification."','["verify","verafy","verrify","verifie"]','verify',null,'"Verify" is the correctly spelled verb meaning to confirm or check.'),
('23333333-0000-0000-0000-000000000088','spelling','Grade 11',7,'multiple_choice','Spot the misspelled word: "Critics worried the proccess excluded smallholder farmers."','["Critics","proccess","excluded","smallholder"]','proccess',null,'"Proccess" should be spelled "process" — only one "c" before the "e."')
on conflict (id) do nothing;

-- ============================================================================
-- GRADE 12 — Passage: "Reading a Research Abstract Critically" (difficulty 8; base was 6)
-- ============================================================================
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000018', 'Grade 12', 'Reading a Research Abstract Critically',
  'A research abstract circulating among the Practical Research class claimed that a new foliar fertilizer "increased crop yield by 40%," and several students initially treated the number as settled fact. Their teacher asked them to look closer at the study''s actual method before accepting the headline figure. The sample size, it turned out, was six test plots, not a number large enough to rule out the result being due to chance or to some unmeasured difference between plots, such as soil quality or sun exposure, rather than the fertilizer itself. The abstract also did not specify whether the 40% figure represented an average across all six plots or the result from the single best-performing plot, a distinction that matters enormously for how the number should be interpreted. Nor did it mention whether the study included a control group of plots that received no fertilizer at all, information necessary to know whether 40% growth was unusual or simply typical for that crop and season. None of this meant the fertilizer did not work; it meant only that the abstract, on its own, was not enough evidence to know whether it worked, how well, or why. The lesson the teacher wanted students to take away was not skepticism toward research itself, but the habit of asking what a striking number is actually built on before repeating it as fact.',
  'informational', 8
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000045','comprehension','11111111-0000-0000-0000-000000000018','Grade 12',8,'multiple_choice',
 'What is the main idea of this passage?',
 '["The fertilizer definitely does not work as claimed","A striking research claim should be examined for its methodology before being accepted as fact","Research abstracts should never be trusted","Sample size does not matter in agricultural research"]',
 'A striking research claim should be examined for its methodology before being accepted as fact',
 'The passage walks through several methodological gaps in the abstract, then closes on the habit of "asking what a striking number is actually built on."'),
('21111111-0000-0000-0000-000000000046','comprehension','11111111-0000-0000-0000-000000000018','Grade 12',8,'multiple_choice',
 'Based on the passage, why does it matter whether the pilot plots had a control group that received no fertilizer?',
 '["Without one, there is no way to know if 40% growth was unusual or simply typical for that crop and season","Control groups are required by law for all research","A control group would have made the study more expensive","It doesn''t matter; the result would be the same either way"]',
 'Without one, there is no way to know if 40% growth was unusual or simply typical for that crop and season',
 'The passage states directly that a control group is "necessary to know whether 40% growth was unusual or simply typical."'),
('21111111-0000-0000-0000-000000000047','comprehension','11111111-0000-0000-0000-000000000018','Grade 12',8,'multiple_choice',
 'In the passage, what does "methodology" mean, as used about examining the study?',
 '["The final conclusion of a study","The methods and procedures used to conduct a study","The cost of running a study","The people who funded a study"]',
 'The methods and procedures used to conduct a study',
 '"Methodology" refers to the methods and procedures behind a study — what the teacher asked students to look closer at.'),
('21111111-0000-0000-0000-000000000048','comprehension','11111111-0000-0000-0000-000000000018','Grade 12',8,'multiple_choice',
 'What is the teacher''s likely purpose in clarifying that the lesson was not "skepticism toward research itself"?',
 '["To make sure students don''t reject research entirely, but instead evaluate it more carefully","To defend the fertilizer study as accurate after all","To discourage students from ever reading abstracts","To argue that research should not be part of the curriculum"]',
 'To make sure students don''t reject research entirely, but instead evaluate it more carefully',
 'The teacher distinguishes rejecting research outright from critically evaluating it — the passage''s actual point is careful evaluation, not blanket distrust.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000089','vocabulary','Grade 12',8,'multiple_choice','Choose the word that means the SAME as "circulating" (as used for the abstract circulating among students).','["being spread or passed around","being deleted","being written for the first time","being kept secret"]','being spread or passed around','"Circulating" means being passed around or shared among a group.'),
('22222222-0000-0000-0000-000000000090','vocabulary','Grade 12',8,'multiple_choice','Choose the word that means the OPPOSITE of "settled" (as used for treating the figure as settled fact).','["fixed","unresolved or disputed","final","confirmed"]','unresolved or disputed','"Settled" means fixed or resolved; its opposite describes something still unresolved or disputed.'),
('22222222-0000-0000-0000-000000000091','vocabulary','Grade 12',8,'multiple_choice','"The abstract did not SPECIFY which measurement it used." SPECIFY most nearly means:','["hide completely","state precisely and clearly","exaggerate","guess randomly"]','state precisely and clearly','"Specify" means to state something precisely and in detail, rather than leaving it vague.'),
('22222222-0000-0000-0000-000000000092','vocabulary','Grade 12',8,'multiple_choice','The root "cred" in "credible" (as in a credible source) relates to:','["belief or trust","money","speed","measurement"]','belief or trust','"Cred-" comes from Latin "credere," to believe — a credible source is one worthy of belief.'),
('22222222-0000-0000-0000-000000000093','vocabulary','Grade 12',8,'multiple_choice','Choose the word that means the SAME as "enormously" (as used for a distinction mattering enormously).','["slightly","to a very great degree","occasionally","questionably"]','to a very great degree','"Enormously" means to a very great extent or degree.'),
('22222222-0000-0000-0000-000000000094','vocabulary','Grade 12',9,'multiple_choice','Choose the word that means the OPPOSITE of "rule out" (as used for ruling out chance as a cause).','["eliminate as a possibility","confirm as a possibility","measure precisely","ignore completely"]','confirm as a possibility','To "rule out" is to eliminate a possibility; its rough opposite is to confirm it as still possible.'),
('22222222-0000-0000-0000-000000000095','vocabulary','Grade 12',8,'multiple_choice','"The number represented an AGGREGATE across all six plots." AGGREGATE most nearly means:','["a single isolated example","a total or combined result from multiple sources","a random guess","a rejected data point"]','a total or combined result from multiple sources','"Aggregate" refers to a whole formed by combining several separate elements, here, results averaged across plots.'),
('22222222-0000-0000-0000-000000000096','vocabulary','Grade 12',8,'multiple_choice','The suffix "-ism" in "skepticism" typically forms:','["a verb showing action","a noun naming a belief, practice, or state","an adjective describing size","an adverb of manner"]','a noun naming a belief, practice, or state','"-ism" forms nouns naming a belief system, practice, or state — "skepticism" is the state/practice of doubting claims.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000089','spelling','Grade 12',8,'typed','Spell the word you hear.',null,'methodology','methodology',null),
('23333333-0000-0000-0000-000000000090','spelling','Grade 12',8,'typed','Spell the word you hear.',null,'hypothesis','hypothesis',null),
('23333333-0000-0000-0000-000000000091','spelling','Grade 12',9,'typed','Spell the word you hear.',null,'questionnaire','questionnaire',null),
('23333333-0000-0000-0000-000000000092','spelling','Grade 12',8,'typed','Spell the word you hear.',null,'significant','significant',null),
('23333333-0000-0000-0000-000000000093','spelling','Grade 12',8,'multiple_choice','Which sentence uses the correct word? "The teacher asked students to ___ the claim more closely."','["examine","exsamine","examin","exemine"]','examine',null,'"Examine" is correctly spelled and fits the sentence''s meaning of inspecting something closely.'),
('23333333-0000-0000-0000-000000000094','spelling','Grade 12',8,'multiple_choice','Choose the correctly spelled word.','["ocurred","occurred","occured","occurrred"]','occurred',null,'"Occurred" is correctly spelled with double "c" and double "r."'),
('23333333-0000-0000-0000-000000000095','spelling','Grade 12',9,'multiple_choice','Which sentence uses the correct word? "A larger sample size would make the result more ___."','["reliable","relyable","relaible","reliabel"]','reliable',null,'"Reliable" is the correctly spelled adjective meaning trustworthy or consistent.'),
('23333333-0000-0000-0000-000000000096','spelling','Grade 12',8,'multiple_choice','Spot the misspelled word: "The study did not specifiy whether a control group was used."','["study","specifiy","control","used"]','specifiy',null,'"Specifiy" should be spelled "specify."')
on conflict (id) do nothing;

-- ============================================================================
-- Done. 6 new passages, 24 new comprehension questions, 48 new vocabulary
-- questions, 48 new spelling questions (126 new rows). Combined with the two
-- earlier seed files: every grade 7-12 now has 2 passages / 8 comprehension
-- questions, 16 vocabulary items, and 16 spelling items (40 items/grade,
-- 240 total), spread across 3 difficulty values per grade so Easy/Medium/
-- Hard in literacyEngine.js each have real, distinct content.
-- ============================================================================
