# MathConnect v57 — Position dropdown, Class Settings saves, automatic Legendary certificates

**One new migration:** `migration-64-auto-legendary-certificates-and-settings-fix.sql`
(run after migrations 35 and 61; safe to re-run).

## 1. Class Settings
* **Position is now a dropdown:** Teacher I – VII, then Master Teacher I – V. A position already saved that isn't on the list
  (e.g. an old "Subject Teacher") is kept and shown as "(current)" — nothing is lost.
* **Save buttons fixed (all three cards).** What could go wrong before, and what happens now:
  * An update that changed *no rows* (paused/read-only account, expired login) used to say "saved". Now the database must
    confirm exactly one row changed, otherwise you see ❌ with the reason and nothing is shown as saved.
  * A missing column / stale API schema cache (migration-40 skipped) was a 3-second toast. Now a ❌ message stays next to the
    button and names the migration to run (migration-64 re-adds the columns and refreshes the cache).
  * Double-clicks could fire two saves — the button now disables while saving.
  * Every save leaves a visible "✅ Saved 10:32" next to the button. Saving Section Info also updates the section picker label.
* Sections that never had a subject teacher saved are filled in automatically from the teacher's account on login, so report
  cards and certificates never print a blank signature.

## 2. Certificates the teacher couldn't open
* Every **View / Print** in the teacher tab now goes through one safe function: it re-finds the certificate if the page cache
  was cleared, and shows a readable message instead of doing nothing.
* **Root causes found:** (a) certificates that only existed on the student's device (saved when the table/rules weren't ready)
  were invisible to the teacher — they are now uploaded to the database the next time the student opens the app; (b) students
  removed from the current term disappeared from the tab, taking their certificates with them — the tab now lists the whole
  section and labels "(removed from Term N)"; (c) older pet certificates didn't store their artwork — fixed and repaired.
* New **🔄 Refresh** button on the Certificates tab.

## 3. Automatic Legendary Pet certificates
* **The database issues it.** A trigger on `student_pets` creates the certificate the moment growth_points reaches Legendary
  (5000) — whatever caused it, even if the student never reopens the app. One per pet, never duplicated.
  Pets that are already Legendary are covered by a one-time backfill in the migration.
* A certificate problem can never block feeding/evolving a pet (errors are caught; the next feed retries).
* **Teacher Dashboard:** new "🎓 Certificates & Legendary Pets" card — how many Legendary pets are in the section, each with its
  owner and a View / Print button, the latest certificates, and a NEW badge for anything earned in the last 7 days.
* Student side: announced once (even if the database issued it while they were away), and the evolution screen shows that
  exact pet's certificate.

## Files
New: `migration-64-auto-legendary-certificates-and-settings-fix.sql`
Changed: `teacher.js`, `teacher-certificates.js`, `certificateEngine.js`, `petEvolution.js`, `style.css`, `README.md`, `service-worker.js` (cache → v57-1)

## Deploy
1. Supabase → SQL Editor → run `migration-64-auto-legendary-certificates-and-settings-fix.sql`.
2. Redeploy the folder (one refresh for the new cache).
