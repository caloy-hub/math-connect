-- ============================================================================
-- MathConnect — Migration 65: Teaching Notes (Blended Learning) + Google Drive
-- links on the Weekly Check-In (2-min recap and lesson of the week)
--
-- WHAT THIS ADDS
--   1. teaching_notes  — new table behind Blended Learning → "🗒️ Teaching Notes".
--      A note can carry pasted TEXT (long, paged, math-aware), a GOOGLE DRIVE
--      LINK (shown inline to students), or both.
--   2. reteach_notes.link_url — optional Drive/Docs/Slides link attached to the
--      "2-min recap" a teacher posts for a tricky week.
--   3. lessons.material_url — optional Drive link attached to the weekly lesson.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- Safe to re-run. Nothing is dropped or rewritten; existing recaps and lessons
-- keep working exactly as before.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TEACHING NOTES
-- ----------------------------------------------------------------------------
create table if not exists teaching_notes (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references sections(id) on delete cascade,
  term_id uuid references terms(id) on delete cascade,
  week_number int,
  title text not null,
  description text,                          -- optional one-liner under the title
  note_text text,                            -- pasted notes; "---page---" starts a new page
  drive_url text,                            -- Google Drive / Docs / Slides / Sheets link
  render_math boolean not null default true, -- show x^2, 1/2, sqrt(), $$…$$ as proper notation
  auto_page boolean not null default true,   -- split very long text into readable pages
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_teaching_notes_term on teaching_notes(term_id);
create index if not exists idx_teaching_notes_section on teaching_notes(section_id);

alter table teaching_notes enable row level security;

-- Same trust model as "modules": students (anon) read, the section's teacher writes.
drop policy if exists "public read teaching_notes" on teaching_notes;
create policy "public read teaching_notes" on teaching_notes for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "teacher insert teaching_notes" on teaching_notes;
create policy "teacher insert teaching_notes" on teaching_notes for insert with check (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher update teaching_notes" on teaching_notes;
create policy "teacher update teaching_notes" on teaching_notes for update using (
  is_teacher_of_section(section_id)
);
drop policy if exists "teacher delete teaching_notes" on teaching_notes;
create policy "teacher delete teaching_notes" on teaching_notes for delete using (
  is_teacher_of_section(section_id)
);

-- ----------------------------------------------------------------------------
-- 2. 2-MIN RECAP: optional attached link.
--    reteach_notes already exists in your live database (created before the
--    SQL files in this project were split out), so this is guarded: it only
--    touches the table if it is there.
-- ----------------------------------------------------------------------------
do $$
begin
  if to_regclass('public.reteach_notes') is not null then
    alter table reteach_notes add column if not exists link_url text;
    -- A recap may now be "link only", so the text body must be allowed to be empty.
    -- (No-op if the column is already nullable.)
    begin
      alter table reteach_notes alter column content drop not null;
    exception when others then
      null;
    end;
  end if;
end $$;

-- ----------------------------------------------------------------------------
-- 3. LESSON OF THE WEEK: optional attached link.
-- ----------------------------------------------------------------------------
alter table lessons add column if not exists material_url text;

-- ============================================================================
-- Done. Refresh the app — Blended Learning now has a 🗒️ Teaching Notes tab, and
-- the Weekly Check-In recap / lesson cards have a Google Drive link field.
-- ============================================================================
