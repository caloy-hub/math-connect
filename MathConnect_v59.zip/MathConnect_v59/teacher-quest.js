// ============================================================================
// MathConnect — Teacher view of Quest Mode
// Read-only monitoring: which chapter each student has reached, total stars,
// a per-student expandable breakdown of every chapter's level-by-level stars,
// and class-wide participation/progress statistics.
// Depends on: state (teacher.js), escapeHtml (supabase-client.js),
// questEngine.js (QUEST_CHAPTERS, QUEST_MAX_LEVEL, quest helper functions —
// loaded standalone here, mirrors the student-side data, so keep both in
// sync if chapters/levels ever change).
// ============================================================================

var tquestLoadErrors = [];
async function fetchClassQuestStandings(students) {
  const studentIds = students.map((s) => s.id);
  if (studentIds.length === 0) return [];

  // v46: page through EVERY row (a bare select() is silently capped at ~1,000
  // rows, which under-counted "level attempts" for busy classes) and remember
  // load errors so the tab can warn instead of showing quiet zeros.
  tquestLoadErrors = [];
  const [progressRes, attemptsRes] = await Promise.all([
    fetchAllRowsChecked(() => supabase.from("quest_progress").select("*").in("student_id", studentIds)),
    fetchAllRowsChecked(() => supabase.from("quest_attempts").select("student_id, chapter_key, level_num, stars_earned").in("student_id", studentIds)),
  ]);
  if (progressRes.error) tquestLoadErrors.push(`quest progress (${progressRes.error.message})`);
  if (attemptsRes.error) tquestLoadErrors.push(`level attempts (${attemptsRes.error.message})`);
  const progress = progressRes.data;
  const attempts = attemptsRes.data;

  const progressByStudent = {};
  (progress || []).forEach((p) => (progressByStudent[p.student_id] = p));
  const attemptCountByStudent = {};
  studentIds.forEach((id) => (attemptCountByStudent[id] = 0));
  (attempts || []).forEach((a) => { attemptCountByStudent[a.student_id] = (attemptCountByStudent[a.student_id] || 0) + 1; });

  return students
    .map((s) => {
      const p = progressByStudent[s.id];
      const levelStars = p ? (p.level_stars || questDefaultLevelStars()) : questDefaultLevelStars();
      const chapterUnlockedCount = questChaptersUnlockedCount(levelStars);
      const currentChapterIdx = Math.max(0, chapterUnlockedCount - 1);
      const currentChapter = QUEST_CHAPTERS[currentChapterIdx];
      return {
        student: s,
        levelStars,
        totalStars: p ? (p.total_stars || questTotalStars(levelStars)) : 0,
        chaptersUnlocked: chapterUnlockedCount,
        chaptersCompleted: QUEST_CHAPTERS.filter((c) => questChapterComplete(levelStars, c.key)).length,
        runsPlayed: p ? (p.runs_played || 0) : 0,
        totalAttempts: Math.max(attemptCountByStudent[s.id] || 0, p ? (p.runs_played || 0) : 0),
        currentChapter,
        hasStarted: !!p && (p.runs_played || 0) > 0,
      };
    })
    .sort((a, b) => b.totalStars - a.totalStars);
}

function computeClassQuestStats(classRows) {
  const n = classRows.length;
  const participated = classRows.filter((r) => r.hasStarted).length;
  const perChapter = QUEST_CHAPTERS.map((c) => {
    const started = classRows.filter((r) => questChapterStars(r.levelStars, c.key) > 0);
    const completed = classRows.filter((r) => questChapterComplete(r.levelStars, c.key));
    return { chapter: c, started: started.length, completed: completed.length };
  });
  const mostAdvanced = perChapter.slice().sort((a, b) => b.completed - a.completed)[0];
  const avgChaptersUnlocked = n ? (classRows.reduce((sum, r) => sum + r.chaptersUnlocked, 0) / n).toFixed(1) : "0";
  return { n, participated, perChapter, mostAdvanced, avgChaptersUnlocked };
}

function renderQuestClassStatsCard(stats) {
  const participationPct = stats.n ? Math.round((stats.participated / stats.n) * 100) : 0;
  return `
    <div class="card" style="margin-bottom:16px;">
      <h3>📈 Class Statistics — Quest Mode</h3>
      <div class="drill-stat-row" style="justify-content:flex-start;">
        <div class="drill-stat"><div class="num">${stats.participated}/${stats.n}</div><div class="muted">Students who've started (${participationPct}%)</div></div>
        <div class="drill-stat"><div class="num">${stats.avgChaptersUnlocked}</div><div class="muted">Avg. chapters unlocked</div></div>
        <div class="drill-stat"><div class="num">${stats.mostAdvanced ? stats.mostAdvanced.chapter.icon : "—"}</div><div class="muted">Furthest-reached chapter${stats.mostAdvanced ? `: ${escapeHtml(stats.mostAdvanced.chapter.subject)}` : ""}</div></div>
      </div>
      <table style="margin-top:6px;">
        <thead><tr><th>Chapter</th><th class="num">Started</th><th class="num">Completed</th></tr></thead>
        <tbody>
          ${stats.perChapter.map((s) => `
            <tr>
              <td>${s.chapter.icon} ${escapeHtml(s.chapter.subject)}</td>
              <td class="num">${s.started}/${stats.n}</td>
              <td class="num">${s.completed}/${stats.n}</td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
}

function renderStudentQuestDetail(row) {
  return `<table style="margin-top:6px;">
    <thead><tr><th>Chapter</th><th class="num">Levels Cleared</th><th class="num">Stars</th><th>Status</th></tr></thead>
    <tbody>
      ${QUEST_CHAPTERS.map((c) => {
        const stars = row.levelStars[c.key] || new Array(QUEST_MAX_LEVEL).fill(0);
        const cleared = stars.filter((s) => s > 0).length;
        const totalStars = stars.reduce((a, b) => a + b, 0);
        const unlocked = questChapterUnlocked(row.levelStars, QUEST_CHAPTERS.indexOf(c));
        const complete = questChapterComplete(row.levelStars, c.key);
        return `<tr>
          <td>${c.icon} ${escapeHtml(c.subject)}</td>
          <td class="num">${cleared}/${QUEST_MAX_LEVEL}</td>
          <td class="num">⭐ ${totalStars}/${QUEST_MAX_LEVEL * 3}</td>
          <td>${complete ? `<span style="color:#1F9D5C;">✅ Complete</span>` : unlocked ? `<span class="muted">▶ In progress</span>` : `<span class="muted">🔒 Locked</span>`}</td>
        </tr>`;
      }).join("")}
    </tbody>
  </table>`;
}

async function renderTeacherQuest() {
  const el = document.getElementById("tab-quest");
  el.innerHTML = `<div class="empty">Loading Quest Mode standings…</div>`;

  const classRows = await fetchClassQuestStandings(state.students);
  const classStats = computeClassQuestStats(classRows);
  const maxStars = QUEST_CHAPTERS.length * QUEST_MAX_LEVEL * 3;

  el.innerHTML = `
    ${tquestLoadErrors.length ? `<div style="border-left:4px solid var(--clay);background:var(--paper);padding:8px 12px;margin-bottom:12px;border-radius:6px;font-size:.85rem;">⚠️ Some data didn't load: ${tquestLoadErrors.map((e) => escapeHtml(e)).join("; ")}. Numbers below may be incomplete rather than zero — switch tabs and back to retry.</div>` : ""}
    ${renderQuestClassStatsCard(classStats)}
    <div class="card">
      <h3>🗺️ ${escapeHtml(state.section.section_name)} — Quest Mode Standings</h3>
      <p class="muted">Total quest stars and furthest chapter reached per student. Click a row to see a full chapter-by-chapter breakdown for monitoring.</p>
      ${classRows.length === 0 ? `<p class="empty">No students in this section yet.</p>` : classRows.map((r, i) => `
        <details style="border-bottom:1px solid var(--paper-line);padding:8px 0;">
          <summary style="cursor:pointer;display:flex;align-items:center;gap:12px;flex-wrap:wrap;list-style:none;">
            <span style="width:22px;">${i + 1}</span>
            <strong style="min-width:160px;">${escapeHtml(r.student.full_name)}</strong>
            <span class="muted">${r.currentChapter ? `${r.currentChapter.icon} on ${escapeHtml(r.currentChapter.subject)}` : "Not started"}</span>
            <span class="muted">${r.chaptersCompleted}/${QUEST_CHAPTERS.length} chapters complete</span>
            <span class="muted">${r.totalAttempts} level attempt${r.totalAttempts === 1 ? "" : "s"}</span>
            <span style="margin-left:auto;font-weight:700;color:var(--gold);">⭐ ${r.totalStars}/${maxStars}</span>
          </summary>
          ${renderStudentQuestDetail(r)}
        </details>`).join("")}
    </div>`;
}
