# MathConnect v59 — Teaching Notes + Google Drive links on the Weekly Check-In

**One SQL migration to run:** `migration-65-teaching-notes-and-recap-links.sql`
(Supabase → SQL Editor → New query → paste → Run. Safe to re-run. New projects: `supabase-schema.sql` already includes the new table/column,
but the 2-min-recap column (`reteach_notes.link_url`) is only added by the migration, so run it on every project.)

Then deploy the folder as usual. The service-worker cache is bumped to `mathconnect-v59-1`; because assets use stale-while-revalidate, a
device may need **one extra reload** after deploy before it shows the new tab.

## 1. 🗒️ Teaching Notes (Blended Learning)

**Teacher** — *Blended Learning → 🗒️ Teaching Notes → + Add Teaching Notes*

| Field | Notes |
|---|---|
| Week / Title / Short description | Week auto-fills to the next number. |
| **Notes** (big text box) | Paste or type. Any length. |
| Symbol palette + formula buttons | Same palette used in the Exam editor. |
| **➕ Page break** / **$$ Equation line** | Insert helpers at the cursor. |
| **📎 Google Drive link** | Optional. Can be used *instead of* or *together with* the text. A live chip says whether students will see it inside the app. |
| 👁️ What students will see | Live preview, updates as you type (including page count). |
| Options | *Show math notation* and *Split very long text into pages automatically* (both on by default). |

**Student** — *Blended Learning → 🗒️ Teaching Notes* (new sub-tab next to "📄 LAS & Schedule"). One expandable card per note
(newest week first; the first is open). Pages: **◀ Prev / ▶ Next**, a page picker, a progress bar, and **Show all pages** for one long scroll.
Drive files, folders, Docs, Slides and Sheets open inline, with an "Open in new tab ↗" fallback. Like LAS and Exams, notes posted in any
section of the same grade level / subject / school year are visible to all of those sections ("Posted for 8-B" badge).

### Pasting long text without breaking math
* Uses the app's existing **MathText** renderer: `x^2`, `sqrt(b^2-4ac)`, `1/2`, `(a+1)/(b-2)`, `x_1`, `pi`, `<=`, `sum_(i=1)^n`, `lim`,
  `\frac{a}{b}` and pasted Unicode symbols (∠ △ ≤ π √ ² ½ …) all display as real notation.
* `$$ … $$` puts an equation on its own centred line. It may span several lines, and wide equations scroll sideways on phones instead of
  breaking the layout.
* **Paging:** put `---page---` (also `-- new page --`, `[page]`, `[page break]`, or a Word/Docs form-feed) on its own line to start a page.
  Text still longer than ~2,400 characters is split automatically at paragraph boundaries. **An equation is never split across pages**, a
  heading is never left stranded at the bottom of a page, and a single huge paragraph is cut at a sentence end (never inside `3.14`).
* `# Heading`, `## Sub-heading`, `### Small heading` make headings.
* **Web links stay intact.** Links in the text become clickable and are shielded from the math renderer — without this, the `_` in a Drive
  link such as `…/d/1AB_C/…` would have turned into a subscript and broken the URL.
* Everything is HTML-escaped first; pasted `<script>`/HTML is shown as text, never run.
* Plain prose is safe: `km/h`, `and/or`, `10/12/2025` are not turned into fractions.

### Which Google links work
| Paste this | Students see |
|---|---|
| Drive file (`drive.google.com/file/d/…`, `open?id=`, `uc?id=`) — PDF, image, video, etc. | Inline preview |
| Drive **folder** | Inline file list |
| Google **Doc** / **Slides** / **Sheet** (`/edit`, `/view`, `/u/0/`, or "Publish to web") | Inline reader |
| A direct `.pdf` URL | Inline PDF |
| Any other `https://` link (YouTube, Google Form, a website) | "Open link" button (those sites don't allow embedding) |
| `javascript:`, `data:`, `ftp:`… | Rejected |

Only Google hosts and direct PDFs are ever embedded. **Reminder for teachers:** in Drive set *Share → General access → "Anyone with the
link" → Viewer*, otherwise students will see a Google sign-in page instead of the file.

## 2. 📊 Weekly Check-In

* **🔁 2-min recap** is now an **✏️ Edit recap** button that opens the same editor: title, text (math + paging), symbol palette, live
  preview, and a **📎 Google Drive link**. A recap can be text-only, link-only, or both; there's also a *Remove recap* button. The students'
  recap card (This Week tab, and each Previous Week) shows the text with proper math and the attached file inline.
* **Lesson of the week**: the objectives now render math (`x^2 + 5x + 6 = 0`, stacked fractions, roots…) and each lesson has an optional
  **📎 Lesson material link** (set when adding the lesson, or any time on the lesson card). Students see it as "📎 Lesson material — tap to
  view inside the app" under the objectives, on the current week and on Previous Weeks.

## 3. Also
* Excel export gets a **Teaching Notes** sheet and a **Lesson Link** column on the Lessons sheet.
* If the migration hasn't been run yet: teachers see a clear "run migration-65" message (instead of a silent failure); students just see
  "No teaching notes posted yet" and the rest of the app is unaffected.

## Files
* **New:** `teachingNotes.js` (shared by teacher.html and student.html), `migration-65-teaching-notes-and-recap-links.sql`
* **Changed:** `teacher.js`, `student.js`, `teacher.html`, `student.html`, `style.css`, `supabase-schema.sql`, `service-worker.js`, `README.md`

## Note on `reteach_notes`
The `reteach_notes`, `reflections_v2` and `module_faq` tables aren't defined in any `.sql` file inside this project (they were created in
your live database directly). The migration therefore adds `reteach_notes.link_url` inside a guarded block that only runs if the table
exists, and the app stores a link-only recap with an empty-string body so it works whether or not `content` is `NOT NULL`.
