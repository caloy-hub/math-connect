// ============================================================================
// MathConnect — Student Exam Taker (Exam Feature, Core)
// Loaded AFTER student.js (reuses `sstate`, `supabase`, `escapeHtml`, `toast`,
// `showModal`, `closeModal`). Add "exams" to the tab dispatch table in
// student.js's switchStudentTab(), and add a matching tab button + panel
// in student.html — see DEPLOY_NOTES.md.
// ============================================================================

// v53 — teacher-typed math (x^2, sqrt(x), <=, 1/2, pi …) is rendered as real
// notation via mathText.js; falls back to plain escaped text if that file is
// ever missing, so an exam can never fail to load because of it.
function mtx(str) { return (typeof MathText !== "undefined") ? MathText.html(str) : escapeHtml(str); }

var xstate = {
  exams: [], myAttempts: {}, // examId -> latest attempt row
  live: null, // { attempt, exam, questions, answers:{questionId:answer}, index, timerId, violationCount, guard:{...} }
};

// ============================================================================
// Exam integrity guard (migration-42) — deterrents only, not a lockdown
// browser. A normal web page cannot block OS-level screenshots/screen
// recording or stop another app from running alongside it — there's no
// browser API for that. What IS enforced here: fullscreen while the exam is
// live, detection of tab/app switches and fullscreen exits, and blocking of
// copy/right-click/select and common DevTools shortcuts. Every detection
// is logged server-side (log_exam_violation) and, once the exam's configured
// threshold is hit, the attempt auto-submits.
// ============================================================================
var examGuard = {
  active: false,
  lastLoggedAt: 0,
  handlers: null,
};

function startExamGuard() {
  const L = xstate.live;
  stopExamGuard(); // clear any stale listeners first
  examGuard.active = true;
  examGuard.lastLoggedAt = 0;

  if (L.exam.require_fullscreen) enterExamFullscreen();

  const onVisibility = () => { if (document.hidden) reportViolation("tab_switch", "page hidden"); };
  const onBlur = () => { if (!document.hidden) reportViolation("tab_switch", "window blurred"); };
  const onFullscreenChange = () => {
    if (L.exam.require_fullscreen && examGuard.active && !document.fullscreenElement) {
      reportViolation("fullscreen_exit");
    }
  };
  const onContextMenu = (e) => { e.preventDefault(); reportViolation("copy_attempt", "right-click"); };
  const onCopyCut = (e) => { e.preventDefault(); reportViolation("copy_attempt", e.type); };
  const onSelectStart = (e) => { e.preventDefault(); };
  const onKeyDown = (e) => {
    const k = e.key;
    const blockCombo =
      k === "F12" ||
      (e.ctrlKey && e.shiftKey && (k === "I" || k === "i" || k === "J" || k === "j" || k === "C" || k === "c")) ||
      (e.ctrlKey && (k === "u" || k === "U")) ||
      (e.metaKey && e.altKey && (k === "I" || k === "i" || k === "J" || k === "j"));
    if (blockCombo) { e.preventDefault(); reportViolation("devtools_attempt", k); }
  };

  document.addEventListener("visibilitychange", onVisibility);
  window.addEventListener("blur", onBlur);
  document.addEventListener("fullscreenchange", onFullscreenChange);
  document.addEventListener("contextmenu", onContextMenu);
  document.addEventListener("copy", onCopyCut);
  document.addEventListener("cut", onCopyCut);
  document.addEventListener("selectstart", onSelectStart);
  document.addEventListener("keydown", onKeyDown);

  examGuard.handlers = { onVisibility, onBlur, onFullscreenChange, onContextMenu, onCopyCut, onSelectStart, onKeyDown };
}

function stopExamGuard() {
  examGuard.active = false;
  if (examGuard.handlers) {
    const h = examGuard.handlers;
    document.removeEventListener("visibilitychange", h.onVisibility);
    window.removeEventListener("blur", h.onBlur);
    document.removeEventListener("fullscreenchange", h.onFullscreenChange);
    document.removeEventListener("contextmenu", h.onContextMenu);
    document.removeEventListener("copy", h.onCopyCut);
    document.removeEventListener("cut", h.onCopyCut);
    document.removeEventListener("selectstart", h.onSelectStart);
    document.removeEventListener("keydown", h.onKeyDown);
    examGuard.handlers = null;
  }
  exitExamFullscreen();
}

function enterExamFullscreen() {
  const el = document.documentElement;
  const req = el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen;
  if (req) req.call(el).catch(() => {}); // ignore rejection (e.g. iOS Safari has no Fullscreen API)
}

function exitExamFullscreen() {
  if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
}

// Logs one violation with a short per-type cooldown so a single tab-switch
// (which can fire both `blur` and `visibilitychange`) isn't double-counted.
async function reportViolation(type, detail) {
  if (!xstate.live || !examGuard.active) return;
  const now = Date.now();
  if (now - examGuard.lastLoggedAt < 1200) return;
  examGuard.lastLoggedAt = now;

  xstate.live.violationCount = (xstate.live.violationCount || 0) + 1;
  updateViolationBadge();

  const { data, error } = await supabase.rpc("log_exam_violation", {
    p_attempt_id: xstate.live.attempt.id, p_violation_type: type, p_detail: detail || null,
  });
  if (error) return;
  if (typeof data.violation_count === "number") xstate.live.violationCount = data.violation_count;
  updateViolationBadge();

  const max = xstate.live.exam.max_violations || 0;
  if (data.should_auto_submit) {
    toast("Too many exam violations detected — your exam has been submitted automatically.");
    finishExam(true, "violations");
  } else if (max > 0) {
    toast(`⚠️ Exam violation logged (${xstate.live.violationCount}/${max}). Reaching the limit will auto-submit your exam.`);
  } else {
    toast("⚠️ Exam violation logged. Your teacher will be able to review this.");
  }
}

function updateViolationBadge() {
  const badge = document.getElementById("examViolationBadge");
  if (!badge || !xstate.live) return;
  const count = xstate.live.violationCount || 0;
  const max = xstate.live.exam.max_violations || 0;
  if (count === 0) { badge.textContent = ""; return; }
  badge.textContent = max > 0 ? `⚠️ Violations: ${count}/${max}` : `⚠️ Violations: ${count}`;
  badge.style.color = "var(--clay)";
}

// student.html has no showModal/closeModal of its own (those only exist in
// teacher.js, which the student dashboard never loads) — define them here so
// exam confirmation dialogs (Submit, Retake) actually work. Matches teacher.js's
// implementation so styling/behavior stays consistent app-wide.
if (typeof showModal !== "function") {
  window.showModal = function (html) {
    document.getElementById("modalRoot").innerHTML = `<div class="modal-backdrop" onclick="if(event.target===this) closeModal()"><div class="modal">${html}</div></div>`;
  };
}
if (typeof closeModal !== "function") {
  window.closeModal = function () { document.getElementById("modalRoot").innerHTML = ""; };
}

async function renderStudentExams() {
  const el = document.getElementById("tab-exams");
  el.innerHTML = `<p class="muted">Loading exams…</p>`;

  const scope = sstate.gradeScope || { sectionIds: [sstate.section.id], termIds: sstate.term ? [sstate.term.id] : [], sectionNameById: {} };
  const { data: exams, error } = await supabase.from("exams").select("*")
    .in("section_id", scope.sectionIds).in("term_id", scope.termIds)
    .eq("is_published", true).order("created_at", { ascending: false });
  if (error) { el.innerHTML = `<div class="empty">Couldn't load exams — ${escapeHtml(error.message)}</div>`; return; }
  xstate.exams = exams || [];

  const { data: attempts } = await supabase.from("exam_attempts").select("*").eq("student_id", sstate.student.id);
  xstate.myAttempts = {};
  (attempts || []).forEach((a) => {
    const cur = xstate.myAttempts[a.exam_id];
    if (!cur || a.attempt_number > cur.attempt_number) xstate.myAttempts[a.exam_id] = a;
  });

  el.innerHTML = `
    <div class="card">
      <h3 style="margin-top:0;">📝 Exams</h3>
      ${xstate.exams.length === 0 ? `<div class="empty">No exams available right now. Check back later!</div>` :
        xstate.exams.map((e) => {
          const mine = xstate.myAttempts[e.id];
          const attemptsUsed = mine ? mine.attempt_number : 0;
          const attemptsLeft = (e.max_attempts || 1) - attemptsUsed;
          const canRetake = e.allow_multiple_attempts && attemptsLeft > 0;
          let statusHtml, actionHtml;
          // v46: check "already submitted" FIRST. A locked exam used to show only a
          // disabled "Locked" button to everyone — including students who had
          // already finished — so once the teacher locked the exam nobody could open
          // their result or review. Locking now only blocks starting/resuming/retaking.
          if (mine && mine.is_submitted) {
            statusHtml = `<span style="color:var(--forest);">✅ Completed — ${mine.percentage_score}%</span>` +
              (e.is_locked ? ` <span class="muted">· 🔒 exam closed</span>` : "") +
              (e.allow_multiple_attempts ? `<br><span class="muted">Attempt ${attemptsUsed} of ${e.max_attempts}</span>` : "");
            actionHtml = `<button class="btn-outline btn-sm" onclick="viewPastResult('${mine.id}')">${e.allow_review ? "View Result &amp; Review" : "View Result"}</button>` +
              (e.is_locked ? "" : canRetake ? ` <button class="btn-primary btn-sm" onclick="confirmRetakeExam('${e.id}')">🔄 Retake Exam</button>`
                : e.allow_multiple_attempts ? ` <button class="btn-outline btn-sm" disabled>No attempts left</button>` : "");
          } else if (e.is_locked) {
            statusHtml = `<span style="color:var(--clay);">🔒 Locked by teacher</span>`;
            actionHtml = `<button class="btn-outline btn-sm" disabled>Locked</button>`;
          } else if (mine && !mine.is_submitted) {
            statusHtml = `<span style="color:var(--gold-dark, #a67c00);">⏳ In progress</span>`;
            actionHtml = `<button class="btn-primary btn-sm" onclick="beginExam('${e.id}')">Resume</button>`;
          } else {
            statusHtml = `<span class="muted">Not started</span>`;
            actionHtml = `<button class="btn-primary btn-sm" onclick="beginExam('${e.id}')">Start Exam</button>`;
          }
          const otherSectionName = e.section_id !== sstate.section.id ? scope.sectionNameById[e.section_id] : null;
          return `
          <div class="card" style="margin-bottom:10px;background:var(--paper);">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
              <div>
                <strong>${mtx(e.title)}</strong>${otherSectionName ? ` <span class="badge badge-pt" style="font-size:.7rem;">Posted for ${escapeHtml(otherSectionName)}</span>` : ""}<br>
                <span class="muted">${e.total_questions} questions • ${e.duration_minutes} min${e.passing_score ? " • Passing: " + e.passing_score + "%" : ""}</span><br>
                ${e.description ? `<span class="muted">${mtx(e.description)}</span><br>` : ""}
                ${statusHtml}
              </div>
              <div>${actionHtml}</div>
            </div>
          </div>`;
        }).join("")}
    </div>
    <div id="examLivePanel"></div>`;
}

// ---------- Retaking the exam ----------
function confirmRetakeExam(examId) {
  const e = xstate.exams.find((x) => x.id === examId);
  showModal(`
    <h3>Retake Exam?</h3>
    <p>This starts a new attempt${e && e.max_attempts ? ` (you have ${Math.max(0, e.max_attempts - (xstate.myAttempts[examId] ? xstate.myAttempts[examId].attempt_number : 0))} left after this)` : ""}. Your previous score stays on record.</p>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-gold" onclick="closeModal();beginExam('${examId}')">Retake Exam</button>
    </div>`);
}

// ---------- Taking the exam ----------
async function beginExam(examId) {
  const { data, error } = await supabase.rpc("start_exam_attempt", { p_exam_id: examId, p_student_id: sstate.student.id });
  if (error) { toast("Error: " + error.message); return; }
  if (data.error) {
    const msgs = { exam_unavailable: "This exam isn't available right now.", already_attempted: "You've already completed this exam.", max_attempts_reached: "You've used all your attempts for this exam." };
    toast(msgs[data.error] || data.error);
    return;
  }
  xstate.live = {
    attempt: data.attempt, exam: data.exam, questions: data.questions, answers: {}, index: 0, timerId: null,
    violationCount: data.violation_count || 0,
  };
  // Pre-fill any previously saved answers when resuming
  const { data: existing } = await supabase.from("exam_responses").select("question_id, student_answer").eq("attempt_id", data.attempt.id);
  (existing || []).forEach((r) => { xstate.live.answers[r.question_id] = r.student_answer; });

  renderExamTaker();
  startExamTimer();
  startExamGuard();
  if (typeof showPetCheerBubble === "function") showPetCheerBubble();
}

function startExamTimer() {
  clearInterval(xstate.live.timerId);
  xstate.live.timerId = setInterval(() => {
    const remainingMs = new Date(xstate.live.attempt.expected_end_time).getTime() - Date.now();
    const badge = document.getElementById("examTimerBadge");
    if (!badge) return;
    if (remainingMs <= 0) {
      clearInterval(xstate.live.timerId);
      badge.textContent = "⏰ Time's up!";
      finishExam(true, "time_expired");
      return;
    }
    const m = Math.floor(remainingMs / 60000), s = Math.floor((remainingMs % 60000) / 1000);
    badge.textContent = `⏱️ ${m}:${String(s).padStart(2, "0")}`;
    badge.style.color = remainingMs < 60000 ? "var(--clay)" : "";
  }, 1000);
}

function renderExamTaker() {
  const L = xstate.live;
  const el = document.getElementById("examLivePanel");
  const q = L.questions[L.index];
  const answered = L.questions.filter((qq) => L.answers[qq.id] !== undefined && L.answers[qq.id] !== "").length;

  el.innerHTML = `
    <div class="card" style="border:2px solid var(--forest);user-select:none;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:2px;">
        <h3 style="margin:0;">${mtx(L.exam.title)}</h3>
        <span id="examTimerBadge" style="font-weight:700;font-size:1.1rem;"></span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <span class="muted" style="font-size:.78rem;">🔒 Exam mode: stay in this window — switching tabs, exiting fullscreen, or copying is logged.</span>
        <span id="examViolationBadge" style="font-weight:700;font-size:.85rem;"></span>
      </div>
      <div class="muted" style="margin-bottom:14px;">Question ${L.index + 1} of ${L.questions.length} • ${answered} answered</div>

      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;">
        ${L.questions.map((qq, i) => `
          <button class="btn-outline btn-sm" style="min-width:34px;${i === L.index ? "background:var(--forest);color:#fff;" : ""}${L.answers[qq.id] ? "border-color:var(--forest);" : ""}" onclick="jumpToQuestion(${i})">${i + 1}</button>`).join("")}
      </div>

      <div class="field">
        <label>Q${q.question_number}. ${mtx(q.question_text)} <span class="muted">(${q.points} pt${q.points === 1 ? "" : "s"})</span></label>
        <div style="margin-top:8px;">
          ${q.question_type === "true_false"
            ? ["True", "False"].map((opt) => `
              <label style="display:block;padding:8px 10px;border:1px solid var(--paper-line);border-radius:8px;margin-bottom:6px;cursor:pointer;${L.answers[q.id] === opt ? "background:var(--paper);border-color:var(--forest);" : ""}">
                <input type="radio" name="q_answer" value="${opt}" ${L.answers[q.id] === opt ? "checked" : ""} onchange="selectAnswer('${q.id}', '${opt}')"> ${opt}
              </label>`).join("")
            : (q.options || []).map((o, i) => { const L2 = String.fromCharCode(65 + i); return `
              <label style="display:block;padding:8px 10px;border:1px solid var(--paper-line);border-radius:8px;margin-bottom:6px;cursor:pointer;${L.answers[q.id] === L2 ? "background:var(--paper);border-color:var(--forest);" : ""}">
                <input type="radio" name="q_answer" value="${L2}" ${L.answers[q.id] === L2 ? "checked" : ""} onchange="selectAnswer('${q.id}', '${L2}')"> ${L2}) ${mtx(o)}
              </label>`; }).join("")}
        </div>
      </div>

      <div style="display:flex;justify-content:space-between;margin-top:16px;">
        <button class="btn-outline" ${L.index === 0 ? "disabled" : ""} onclick="jumpToQuestion(${L.index - 1})">← Previous</button>
        ${L.index === L.questions.length - 1
          ? `<button class="btn-gold" onclick="confirmSubmitExam()">Submit Exam</button>`
          : `<button class="btn-primary" onclick="jumpToQuestion(${L.index + 1})">Next →</button>`}
      </div>
    </div>`;
  updateViolationBadge();
}

async function selectAnswer(questionId, value) {
  xstate.live.answers[questionId] = value;
  const { data, error } = await supabase.rpc("save_exam_response", { p_attempt_id: xstate.live.attempt.id, p_question_id: questionId, p_student_answer: value });
  if (error || (data && data.error === "time_expired")) { finishExam(true); return; }
  renderExamTaker();
}

function jumpToQuestion(i) {
  if (i < 0 || i >= xstate.live.questions.length) return;
  xstate.live.index = i;
  renderExamTaker();
}

function confirmSubmitExam() {
  const answered = xstate.live.questions.filter((q) => xstate.live.answers[q.id]).length;
  const unanswered = xstate.live.questions.length - answered;
  showModal(`
    <h3>Submit Exam?</h3>
    <p>${unanswered > 0 ? `You have <strong>${unanswered}</strong> unanswered question(s). ` : ""}Once submitted, you can't change your answers.</p>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Keep Working</button>
      <button class="btn-gold" onclick="closeModal();finishExam(false)">Submit</button>
    </div>`);
}

async function finishExam(auto, reason) {
  if (!xstate.live) return;
  clearInterval(xstate.live.timerId);
  stopExamGuard();
  const attemptId = xstate.live.attempt.id;
  const { data, error } = await supabase.rpc("submit_exam_attempt", { p_attempt_id: attemptId, p_reason: reason || null });
  if (error) { toast("Error submitting: " + error.message); return; }
  if (auto && reason === "time_expired") toast("Time's up — your exam was submitted automatically.");
  // Green Points for the Math Pet — a flat reward for completing an exam,
  // regardless of score (finishing it is what counts here). Only fires from
  // an actual submission, not from viewPastResult()'s idempotent re-fetch.
  if (typeof awardGreenPoints === "function") await awardGreenPoints(10);
  renderExamResult(data.attempt, data.review, xstate.live.exam, data.review_pending);
  xstate.live = null;
}

async function viewPastResult(attemptId) {
  const { data, error } = await supabase.rpc("submit_exam_attempt", { p_attempt_id: attemptId }); // idempotent — re-returns existing result + review
  if (error) { toast("Error: " + error.message); return; }
  const { data: attemptRow } = await supabase.from("exam_attempts").select("*, exams(title, passing_score)").eq("id", attemptId).maybeSingle();
  renderExamResult(data.attempt, data.review, attemptRow && attemptRow.exams ? attemptRow.exams : {}, data.review_pending);
}

function renderExamResult(attempt, review, exam, reviewPending) {
  const el = document.getElementById("examLivePanel") || document.getElementById("tab-exams");
  const passed = exam.passing_score ? Number(attempt.percentage_score) >= exam.passing_score : null;
  xstate.review = { items: review || [], filter: "all" };
  el.innerHTML = `
    <div class="card" style="text-align:center;">
      <h3 style="margin-top:0;">${mtx(exam.title || "Exam Result")}</h3>
      <div style="font-size:2.4rem;font-weight:800;color:${passed === false ? "var(--clay)" : "var(--forest)"};">${attempt.percentage_score}%</div>
      <div class="muted">${attempt.total_score} / ${attempt.total_points} points</div>
      ${passed !== null ? `<div style="margin-top:6px;font-weight:700;color:${passed ? "var(--forest)" : "var(--clay)"};">${passed ? "✅ Passed" : "❌ Did not meet passing score"}</div>` : ""}
      <button class="btn-outline btn-sm" style="margin-top:14px;" onclick="renderStudentExams()">Back to Exams</button>
    </div>
    ${reviewPending ? `
    <div class="card" style="margin-top:12px;border-left:4px solid var(--gold);">
      <strong>🔒 Your answer review isn't open yet.</strong>
      <div class="muted" style="margin-top:4px;">Your exam is scored. Your teacher will open the review — the correct answers and an explanation for each item — once the exam closes for the whole class. Come back to <em>Exams → View Result &amp; Review</em> later.</div>
    </div>` : ""}
    ${review ? `<div id="examReviewPanel" style="margin-top:12px;"></div>` : ""}`;
  if (review) renderExamReviewPanel();
}

// ---------- Review: every item with its options, your pick, the key, and the explanation ----------
function examItemStatus(r) {
  const answered = r.student_answer != null && String(r.student_answer).trim() !== "";
  return !answered ? "unanswered" : r.is_correct ? "correct" : "incorrect";
}

function setExamReviewFilter(f) {
  if (!xstate.review) return;
  xstate.review.filter = f;
  renderExamReviewPanel();
}

function renderExamReviewPanel() {
  const panel = document.getElementById("examReviewPanel");
  if (!panel || !xstate.review) return;
  const items = xstate.review.items;
  const counts = { all: items.length, correct: 0, incorrect: 0, unanswered: 0 };
  items.forEach((r) => { counts[examItemStatus(r)]++; });
  const f = xstate.review.filter;
  const shown = f === "all" ? items : items.filter((r) => examItemStatus(r) === f);
  const keyHidden = items.length > 0 && items.every((r) => r.correct_answer == null);
  const anyExplanation = items.some((r) => r.explanation);
  const chip = (key, label) => `<button class="btn-outline btn-sm" style="${f === key ? "background:var(--forest);color:#fff;border-color:var(--forest);" : ""}" onclick="setExamReviewFilter('${key}')">${label} (${counts[key]})</button>`;

  panel.innerHTML = `
    <div class="card">
      <h4 style="margin-top:0;">📖 Review your answers</h4>
      <div class="muted" style="margin-bottom:10px;">${keyHidden ? "Your teacher isn't showing the correct answers for this exam." : "The correct answer is highlighted green. " + (anyExplanation ? "Read the 💡 explanation under each item to see why." : "")}</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">
        ${chip("all", "All")}${chip("correct", "✅ Correct")}${chip("incorrect", "❌ Incorrect")}${chip("unanswered", "⚪ Not answered")}
      </div>
      ${shown.length === 0 ? `<div class="empty">Nothing in this group.</div>` : shown.map((r) => examReviewItemHtml(r, anyExplanation)).join("")}
    </div>`;
}

function examReviewItemHtml(r, anyExplanation) {
  const status = examItemStatus(r);
  const norm = (v) => String(v == null ? "" : v).trim().toUpperCase();
  const isTF = r.question_type === "true_false" || !r.options;
  const opts = isTF
    ? [{ key: "True", text: "True" }, { key: "False", text: "False" }]
    : r.options.map((o, i) => ({ key: String.fromCharCode(65 + i), text: o }));
  const badge = { correct: ["✅ Correct", "var(--forest)"], incorrect: ["❌ Incorrect", "var(--clay)"], unanswered: ["⚪ Not answered", "var(--muted, #888)"] }[status];
  const hasKey = r.correct_answer != null;

  const optRows = opts.map((o) => {
    const isPick = status !== "unanswered" && norm(r.student_answer) === norm(o.key);
    const isKey = hasKey && norm(r.correct_answer) === norm(o.key);
    let style = "border:1px solid var(--paper-line);";
    if (isKey) style = "border:2px solid var(--forest);background:rgba(31,157,92,.12);";
    else if (isPick) style = "border:2px solid var(--clay);background:rgba(200,80,60,.12);";
    const tags = [
      isPick ? `<span style="font-weight:700;color:${!hasKey ? "inherit" : isKey ? "var(--forest)" : "var(--clay)"};">Your answer</span>` : "",
      isKey ? `<span style="font-weight:700;color:var(--forest);">✓ Correct answer</span>` : "",
    ].filter(Boolean).join(" · ");
    const label = isTF ? escapeHtml(o.text) : `${o.key}) ${mtx(o.text)}`;
    return `<div style="display:flex;justify-content:space-between;gap:10px;padding:7px 10px;border-radius:8px;margin-bottom:5px;${style}"><span>${label}</span><span style="font-size:.78rem;white-space:nowrap;">${tags}</span></div>`;
  }).join("");

  let explanationHtml = "";
  if (r.explanation && String(r.explanation).trim()) {
    explanationHtml = `<div style="margin-top:8px;padding:10px 12px;border-radius:8px;background:var(--gold-light, #fff6d6);border-left:4px solid var(--gold, #d4a017);">
      <strong>💡 Why this is the answer</strong>
      <div style="margin-top:3px;white-space:pre-wrap;">${mtx(r.explanation)}</div>
    </div>`;
  } else if (anyExplanation && hasKey) {
    explanationHtml = `<div class="muted" style="margin-top:6px;font-size:.82rem;">No explanation was added for this item.</div>`;
  }

  return `
    <div style="padding:12px 0;border-bottom:1px solid var(--paper-line);">
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline;flex-wrap:wrap;">
        <strong>Q${r.question_number}.</strong>
        <span style="font-size:.82rem;font-weight:700;color:${badge[1]};">${badge[0]}${r.points ? ` <span class="muted" style="font-weight:400;">· ${r.points} pt${r.points === 1 ? "" : "s"}</span>` : ""}</span>
      </div>
      <div style="margin:4px 0 8px;white-space:pre-wrap;">${mtx(r.question_text)}</div>
      ${optRows}
      ${explanationHtml}
    </div>`;
}
