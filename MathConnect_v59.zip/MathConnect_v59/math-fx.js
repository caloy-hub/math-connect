/* ============================================================================
   math-fx.js — MathConnect Math Lab Interactive Engine (v51)
   Zero-dependency. Vanilla JS. No build step. Safe to include on every page.
   Provides: window.MathFX = {
     init(opts), audio, openPalette(), closePalette(), openFormulaHUD(),
     openScratchpad(), countUp(el, target, duration)
   }
   ============================================================================ */
(function () {
  'use strict';

  var REDUCED_MOTION = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var MUTE_KEY = 'mc_mathfx_muted';

  /* ---------------------------------------------------------------------
     1. AUDIO ENGINE — tiny Web Audio oscillator synth, no audio files.
     --------------------------------------------------------------------- */
  var Audio = (function () {
    var ctx = null;
    function getCtx() {
      if (!ctx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
      }
      return ctx;
    }
    function isMuted() {
      try { return localStorage.getItem(MUTE_KEY) === '1'; } catch (e) { return false; }
    }
    function setMuted(v) {
      try { localStorage.setItem(MUTE_KEY, v ? '1' : '0'); } catch (e) {}
    }
    function tone(freq, start, dur, type, gain) {
      var c = getCtx();
      if (!c || isMuted()) return;
      if (c.state === 'suspended') { c.resume(); }
      var osc = c.createOscillator();
      var g = c.createGain();
      osc.type = type || 'sine';
      osc.frequency.value = freq;
      g.gain.setValueAtTime(0, c.currentTime + start);
      g.gain.linearRampToValueAtTime(gain || 0.08, c.currentTime + start + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + start + dur);
      osc.connect(g); g.connect(c.destination);
      osc.start(c.currentTime + start);
      osc.stop(c.currentTime + start + dur + 0.02);
    }
    return {
      click: function () { tone(720, 0, 0.05, 'square', 0.04); },
      correct: function () {
        // harmonic pentatonic chime
        [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { tone(f, i * 0.07, 0.28, 'sine', 0.07); });
      },
      wrong: function () { tone(180, 0, 0.22, 'sawtooth', 0.05); },
      swoosh: function () { tone(300, 0, 0.12, 'triangle', 0.03); },
      fanfare: function () {
        [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach(function (f, i) { tone(f, i * 0.09, 0.4, 'triangle', 0.08); });
      },
      isMuted: isMuted,
      toggleMute: function () { var m = !isMuted(); setMuted(m); return m; }
    };
  })();

  /* ---------------------------------------------------------------------
     2. DOM INJECTION HELPERS
     --------------------------------------------------------------------- */
  function el(html) {
    var d = document.createElement('div');
    d.innerHTML = html.trim();
    return d.firstChild;
  }

  /* ---------------------------------------------------------------------
     3. COMMAND PALETTE — auto-discovers nav targets already on the page
        (.tab[data-tab], .bottom-nav-item[data-bottom-tab], .drawer-item,
        and any [data-cmdk-label]) so it stays in sync with each portal
        without hand-maintained lists.
     --------------------------------------------------------------------- */
  var palette = { overlay: null, input: null, list: null, items: [], activeIdx: 0 };

  function collectPaletteItems() {
    var items = [];
    var seen = {};
    function add(node, label, icon, action) {
      var key = label + '|' + icon;
      if (seen[key]) return;
      seen[key] = true;
      items.push({ label: label, icon: icon || '📐', action: action });
    }
    document.querySelectorAll('.tab[data-tab], .bottom-nav-item[data-bottom-tab], .drawer-item, .sub-nav-pill').forEach(function (node) {
      var span = node.querySelector('span:last-child, .drawer-label, .nav-label');
      var label = (span ? span.textContent : node.textContent).replace(/\s+/g, ' ').trim();
      var iconEl = node.querySelector('.nav-icon, .drawer-icon');
      var icon = iconEl ? iconEl.textContent.trim() : (node.textContent.trim().split(' ')[0] || '📐');
      if (!label) return;
      add(node, label, icon, function () { node.click(); });
    });
    document.querySelectorAll('a.tab[href]').forEach(function (node) {
      var label = node.textContent.replace(/\s+/g, ' ').trim();
      if (!label) return;
      add(node, label, '🖨️', function () { window.open(node.getAttribute('href'), node.getAttribute('target') || '_self'); });
    });
    return items;
  }

  function renderPaletteList(query) {
    var q = (query || '').toLowerCase().trim();
    var filtered = palette.items.filter(function (it) { return !q || it.label.toLowerCase().indexOf(q) !== -1; });
    palette.list.innerHTML = '';
    palette.activeIdx = 0;
    if (!filtered.length) {
      palette.list.appendChild(el('<div class="cmdk-empty">No matches. Try a different search.</div>'));
      return;
    }
    filtered.forEach(function (it, i) {
      var row = el('<div class="cmdk-item' + (i === 0 ? ' active' : '') + '"><span class="icon">' + it.icon + '</span><span>' + it.label + '</span></div>');
      row.addEventListener('click', function () { selectItem(it); });
      row.addEventListener('mouseenter', function () {
        palette.list.querySelectorAll('.cmdk-item').forEach(function (n) { n.classList.remove('active'); });
        row.classList.add('active');
        palette.activeIdx = i;
      });
      palette.list.appendChild(row);
    });
    palette._filtered = filtered;
  }

  function selectItem(it) {
    closePalette();
    Audio.click();
    setTimeout(function () { it.action(); }, 40);
  }

  function openPalette() {
    if (!palette.overlay) buildPalette();
    palette.items = collectPaletteItems();
    palette.overlay.classList.add('open');
    renderPaletteList('');
    palette.input.value = '';
    setTimeout(function () { palette.input.focus(); }, 30);
  }
  function closePalette() {
    if (palette.overlay) palette.overlay.classList.remove('open');
  }

  function buildPalette() {
    var overlay = el(
      '<div class="cmdk-overlay">' +
        '<div class="cmdk-modal">' +
          '<div class="cmdk-input-row">🔍 <input class="cmdk-input" placeholder="Jump to any station, tab, or tool…" /> <span class="cmdk-kbd">Esc</span></div>' +
          '<div class="cmdk-list"></div>' +
        '</div>' +
      '</div>'
    );
    overlay.addEventListener('click', function (e) { if (e.target === overlay) closePalette(); });
    document.body.appendChild(overlay);
    palette.overlay = overlay;
    palette.input = overlay.querySelector('.cmdk-input');
    palette.list = overlay.querySelector('.cmdk-list');
    palette.input.addEventListener('input', function () { renderPaletteList(palette.input.value); });
    palette.input.addEventListener('keydown', function (e) {
      var rows = palette.list.querySelectorAll('.cmdk-item');
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        palette.activeIdx = Math.min(palette.activeIdx + 1, rows.length - 1);
        rows.forEach(function (n, i) { n.classList.toggle('active', i === palette.activeIdx); });
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        palette.activeIdx = Math.max(palette.activeIdx - 1, 0);
        rows.forEach(function (n, i) { n.classList.toggle('active', i === palette.activeIdx); });
      } else if (e.key === 'Enter') {
        e.preventDefault();
        var it = palette._filtered && palette._filtered[palette.activeIdx];
        if (it) selectItem(it);
      } else if (e.key === 'Escape') {
        closePalette();
      }
    });
  }

  function isTypingTarget(node) {
    if (!node) return false;
    var tag = node.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || node.isContentEditable;
  }

  document.addEventListener('keydown', function (e) {
    var cmdK = (e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K');
    var slash = e.key === '/' && !isTypingTarget(e.target);
    if (cmdK || slash) {
      e.preventDefault();
      openPalette();
    }
  });

  /* ---------------------------------------------------------------------
     4. FORMULA HUD — static DepEd JHS math essentials reference card
     --------------------------------------------------------------------- */
  var FORMULAS = [
    { group: 'Geometry', rows: [
      ['Area — circle', 'A = πr²'], ['Area — triangle', 'A = ½bh'], ['Area — rectangle', 'A = lw'],
      ['Perimeter — rectangle', 'P = 2(l+w)'], ['Circumference', 'C = 2πr'],
      ['Volume — cylinder', 'V = πr²h'], ['Volume — box', 'V = lwh'], ['Volume — sphere', 'V = 4/3 πr³']
    ]},
    { group: 'Algebra', rows: [
      ['Quadratic formula', 'x = (-b ± √(b²-4ac)) / 2a'],
      ['Slope', 'm = (y₂-y₁)/(x₂-x₁)'],
      ['Slope-intercept', 'y = mx + b'],
      ['Laws of exponents', 'xᵃ · xᵇ = xᵃ⁺ᵇ']
    ]},
    { group: 'Geometry — Right Triangles', rows: [ ['Pythagorean theorem', 'a² + b² = c²'] ]},
    { group: 'DepEd DO 15, s. 2026 Grading', rows: [
      ['Written Works', '20%'], ['Performance Tasks', '50%'], ['Quarterly Exam', '30%']
    ]}
  ];

  var hud = null;
  function buildHUD() {
    var body = '';
    FORMULAS.forEach(function (g) {
      body += '<div class="formula-group-label">' + g.group + '</div>';
      g.rows.forEach(function (r) {
        body += '<div class="formula-row"><span class="name">' + r[0] + '</span><span class="expr">' + r[1] + '</span></div>';
      });
    });
    hud = el(
      '<div class="formula-hud">' +
        '<div class="formula-hud-head"><span>📐 Formula Reference</span><button type="button" aria-label="Close">✕</button></div>' +
        '<div class="formula-hud-body">' + body + '</div>' +
      '</div>'
    );
    hud.querySelector('button').addEventListener('click', closeFormulaHUD);
    document.body.appendChild(hud);
  }
  function openFormulaHUD() {
    if (!hud) buildHUD();
    hud.classList.add('open');
    Audio.swoosh();
  }
  function closeFormulaHUD() { if (hud) hud.classList.remove('open'); }

  /* ---------------------------------------------------------------------
     5. BLACKBOARD SCRATCHPAD — quick scratch-work canvas (pencil/eraser/
        clear/grid), entirely in-memory, no persistence needed.
     --------------------------------------------------------------------- */
  var pad = null, padCtx = null, drawing = false, tool = 'pencil', showGrid = true;

  function buildScratchpad() {
    pad = el(
      '<div class="scratchpad-overlay">' +
        '<div class="scratchpad-modal">' +
          '<div class="scratchpad-head"><span>✏️ Blackboard Scratchpad</span><button type="button" class="close-x" aria-label="Close">✕</button></div>' +
          '<div class="scratchpad-canvas-wrap"><canvas class="scratchpad-canvas" height="280"></canvas></div>' +
          '<div class="scratchpad-toolbar">' +
            '<button type="button" data-tool="pencil" class="active">✏️ Pencil</button>' +
            '<button type="button" data-tool="eraser">🧹 Eraser</button>' +
            '<button type="button" data-tool="grid" class="active">▦ Grid</button>' +
            '<button type="button" data-tool="clear">🗑️ Clear</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
    document.body.appendChild(pad);
    pad.querySelector('.close-x').addEventListener('click', closeScratchpad);
    pad.addEventListener('click', function (e) { if (e.target === pad) closeScratchpad(); });

    var canvas = pad.querySelector('canvas');
    padCtx = canvas.getContext('2d');

    function resize() {
      var wrap = pad.querySelector('.scratchpad-canvas-wrap');
      canvas.width = wrap.clientWidth;
      drawGrid();
    }
    window.addEventListener('resize', resize);

    function drawGrid() {
      padCtx.fillStyle = '#0A0E1A';
      padCtx.fillRect(0, 0, canvas.width, canvas.height);
      if (!showGrid) return;
      padCtx.strokeStyle = 'rgba(6,182,212,0.14)';
      padCtx.lineWidth = 1;
      for (var x = 0; x < canvas.width; x += 20) { padCtx.beginPath(); padCtx.moveTo(x, 0); padCtx.lineTo(x, canvas.height); padCtx.stroke(); }
      for (var y = 0; y < canvas.height; y += 20) { padCtx.beginPath(); padCtx.moveTo(0, y); padCtx.lineTo(canvas.width, y); padCtx.stroke(); }
    }

    function pos(e) {
      var r = canvas.getBoundingClientRect();
      var t = e.touches ? e.touches[0] : e;
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    }
    function start(e) { drawing = true; draw(e); e.preventDefault(); }
    function stop() { drawing = false; padCtx.beginPath(); }
    function draw(e) {
      if (!drawing) return;
      var p = pos(e);
      padCtx.lineWidth = tool === 'eraser' ? 18 : 2.5;
      padCtx.lineCap = 'round';
      padCtx.strokeStyle = tool === 'eraser' ? '#0A0E1A' : '#F8FAFC';
      padCtx.lineTo(p.x, p.y);
      padCtx.stroke();
      padCtx.beginPath();
      padCtx.moveTo(p.x, p.y);
      e.preventDefault();
    }
    ['mousedown', 'touchstart'].forEach(function (ev) { canvas.addEventListener(ev, start); });
    ['mousemove', 'touchmove'].forEach(function (ev) { canvas.addEventListener(ev, draw); });
    ['mouseup', 'mouseleave', 'touchend'].forEach(function (ev) { canvas.addEventListener(ev, stop); });

    pad.querySelectorAll('.scratchpad-toolbar button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var t = btn.getAttribute('data-tool');
        if (t === 'clear') { drawGrid(); return; }
        if (t === 'grid') { showGrid = !showGrid; btn.classList.toggle('active', showGrid); drawGrid(); return; }
        tool = t;
        pad.querySelectorAll('[data-tool="pencil"],[data-tool="eraser"]').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
      });
    });

    pad._resize = resize;
  }
  function openScratchpad() {
    if (!pad) buildScratchpad();
    pad.classList.add('open');
    setTimeout(function () { pad._resize(); }, 20);
    Audio.swoosh();
  }
  function closeScratchpad() { if (pad) pad.classList.remove('open'); }

  /* ---------------------------------------------------------------------
     6. FLOATING MATH TOOLS BUTTON (FAB)
     --------------------------------------------------------------------- */
  function buildFAB() {
    var muted = Audio.isMuted();
    var wrap = el(
      '<div class="math-fab-wrap">' +
        '<div class="math-fab-menu">' +
          '<button type="button" data-act="palette">🔎 Command Palette <span style="opacity:.5;margin-left:auto;">⌘K</span></button>' +
          '<button type="button" data-act="formula">📐 Formula Sheet</button>' +
          '<button type="button" data-act="scratchpad">✏️ Scratchpad</button>' +
          '<button type="button" data-act="mute">' + (muted ? '🔇 Sound: Off' : '🔊 Sound: On') + '</button>' +
        '</div>' +
        '<button type="button" class="math-fab" aria-label="Math Tools">📐</button>' +
      '</div>'
    );
    document.body.appendChild(wrap);
    var menu = wrap.querySelector('.math-fab-menu');
    var fab = wrap.querySelector('.math-fab');
    fab.addEventListener('click', function () { menu.classList.toggle('open'); Audio.click(); });
    wrap.querySelector('[data-act="palette"]').addEventListener('click', function () { menu.classList.remove('open'); openPalette(); });
    wrap.querySelector('[data-act="formula"]').addEventListener('click', function () { menu.classList.remove('open'); openFormulaHUD(); });
    wrap.querySelector('[data-act="scratchpad"]').addEventListener('click', function () { menu.classList.remove('open'); openScratchpad(); });
    wrap.querySelector('[data-act="mute"]').addEventListener('click', function (e) {
      var m = Audio.toggleMute();
      e.target.textContent = m ? '🔇 Sound: Off' : '🔊 Sound: On';
      if (!m) Audio.click();
    });
    document.addEventListener('click', function (e) {
      if (!wrap.contains(e.target)) menu.classList.remove('open');
    });
  }

  /* ---------------------------------------------------------------------
     7. countUp — rolling number animation for stat cards
     --------------------------------------------------------------------- */
  function countUp(elNode, target, duration) {
    if (!elNode) return;
    target = Number(target) || 0;
    duration = REDUCED_MOTION ? 0 : (duration || 900);
    if (!duration) { elNode.textContent = target; return; }
    var startTime = null;
    var startVal = 0;
    function step(ts) {
      if (!startTime) startTime = ts;
      var progress = Math.min((ts - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      elNode.textContent = Math.round(startVal + (target - startVal) * eased);
      if (progress < 1) requestAnimationFrame(step);
      else elNode.textContent = target;
    }
    requestAnimationFrame(step);
  }

  /* ---------------------------------------------------------------------
     7b. AUTO ROLLING COUNTERS — watches for .stat-value nodes with plain
         numeric text (rendered by student.js/teacher.js template strings)
         and animates them once, without requiring any change to those
         render functions.
     --------------------------------------------------------------------- */
  var countedNodes = (typeof WeakSet !== 'undefined') ? new WeakSet() : null;
  function maybeAnimateStat(node) {
    if (!node || !node.classList || !node.classList.contains('stat-value')) return;
    if (countedNodes && countedNodes.has(node)) return;
    var raw = node.textContent.trim().replace(/,/g, '');
    if (!/^\d+$/.test(raw)) return; // only plain integers, skip labels/names
    var target = parseInt(raw, 10);
    if (countedNodes) countedNodes.add(node);
    countUp(node, target, 800);
  }
  function watchStats() {
    if (!('MutationObserver' in window)) return;
    var obs = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        m.addedNodes && m.addedNodes.forEach(function (n) {
          if (n.nodeType !== 1) return;
          if (n.classList && n.classList.contains('stat-value')) maybeAnimateStat(n);
          n.querySelectorAll && n.querySelectorAll('.stat-value').forEach(maybeAnimateStat);
        });
      });
    });
    obs.observe(document.body, { childList: true, subtree: true });
    document.querySelectorAll('.stat-value').forEach(maybeAnimateStat);
  }

  /* ---------------------------------------------------------------------
     8. INIT — call once per page. Light-touch: adds click-sound
        delegation on existing controls, mounts the FAB, starts stat
        counter observation.
     --------------------------------------------------------------------- */
  function init(opts) {
    opts = opts || {};
    buildFAB();
    if (opts.sounds !== false) {
      document.addEventListener('click', function (e) {
        var t = e.target.closest && e.target.closest('.tab, .bottom-nav-item, .drawer-item, .btn, .btn-outline, .sub-nav-pill');
        if (t) Audio.click();
      });
    }
    if (opts.countUpStats !== false) watchStats();
  }

  window.MathFX = {
    init: init,
    audio: Audio,
    openPalette: openPalette,
    closePalette: closePalette,
    openFormulaHUD: openFormulaHUD,
    closeFormulaHUD: closeFormulaHUD,
    openScratchpad: openScratchpad,
    closeScratchpad: closeScratchpad,
    countUp: countUp
  };
})();
