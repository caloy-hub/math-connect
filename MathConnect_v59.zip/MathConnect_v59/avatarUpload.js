// ============================================================================
// MathConnect — Profile Picture upload (migration-46)
// Shared by teacher.html and student.html. The whole point of this file is
// the compression step: every photo, no matter how large, is resized down
// to a small square and re-encoded as JPEG, shrinking the quality further
// if needed, until it's comfortably under AVATAR_TARGET_BYTES — BEFORE
// anything is uploaded. That's what actually keeps storage small, not just
// the bucket's hard size limit (which is only a backstop).
// ============================================================================

const AVATAR_MAX_SOURCE_BYTES = 15 * 1024 * 1024; // refuse to even try decoding anything absurd
const AVATAR_DIMENSION = 256;                      // final square size, in pixels
const AVATAR_TARGET_BYTES = 45 * 1024;             // ~45KB target after compression
const AVATAR_MIN_QUALITY = 0.35;                   // don't keep degrading forever

function loadImageFromFile(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("That file doesn't look like a valid image.")); };
    img.src = url;
  });
}

function canvasToBlob(canvas, quality) {
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/jpeg", quality));
}

// Resizes to a centered AVATAR_DIMENSION×AVATAR_DIMENSION square, then
// iteratively lowers JPEG quality until the result is under the target size
// (or we hit the quality floor — a 256×256 JPEG at 0.35 quality is
// virtually always well under 45KB regardless of source, so this floor is
// really just a safety net for unusually noisy/busy photos).
async function compressImageToBlob(file) {
  if (!file.type || !file.type.startsWith("image/")) {
    throw new Error("Please choose an image file (JPG, PNG, or WEBP).");
  }
  if (file.size > AVATAR_MAX_SOURCE_BYTES) {
    throw new Error("That photo is too large to process — please choose one under 15MB.");
  }

  const img = await loadImageFromFile(file);
  const side = Math.min(img.naturalWidth, img.naturalHeight);
  const sx = (img.naturalWidth - side) / 2;
  const sy = (img.naturalHeight - side) / 2;

  const canvas = document.createElement("canvas");
  canvas.width = AVATAR_DIMENSION;
  canvas.height = AVATAR_DIMENSION;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, sx, sy, side, side, 0, 0, AVATAR_DIMENSION, AVATAR_DIMENSION);

  let quality = 0.85;
  let blob = await canvasToBlob(canvas, quality);
  while (blob && blob.size > AVATAR_TARGET_BYTES && quality > AVATAR_MIN_QUALITY) {
    quality -= 0.1;
    blob = await canvasToBlob(canvas, quality);
  }
  if (!blob) throw new Error("Couldn't process that image — please try a different photo.");
  return blob;
}

// folderPrefix: "teacher" or "student". id: the teacher's or student's UUID.
// Uploads to a FIXED path (avatars/<prefix>_<id>/avatar.jpg) with upsert, so
// changing your picture overwrites the old one instead of piling up files.
// Returns a cache-busted public URL ready to store in the DB.
async function uploadAvatar(file, folderPrefix, id) {
  const blob = await compressImageToBlob(file);
  const path = `${folderPrefix}_${id}/avatar.jpg`;
  const { error } = await supabase.storage.from("avatars").upload(path, blob, {
    upsert: true, contentType: "image/jpeg", cacheControl: "3600",
  });
  if (error) throw error;
  const { data } = supabase.storage.from("avatars").getPublicUrl(path);
  return `${data.publicUrl}?v=${Date.now()}`; // cache-bust so the new photo shows immediately
}

// Renders either the uploaded photo or a fallback emoji into a `.avatar`
// element — used by both teacher.js and student.js right after they know
// whether an avatar_url is on file.
function renderAvatarInto(el, avatarUrl, fallbackEmoji) {
  if (!el) return;
  el.innerHTML = avatarUrl
    ? `<img src="${avatarUrl}" alt="Profile picture" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`
    : fallbackEmoji;
}

// Shared picker flow: opens a file dialog, compresses + uploads on
// selection, then hands the new URL to onDone(url) so the caller can save
// it to the right table (teachers vs student_preferences) and re-render.
function pickAndUploadAvatar(folderPrefix, id, onDone) {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "image/*";
  input.style.display = "none";
  input.onchange = async () => {
    const file = input.files && input.files[0];
    document.body.removeChild(input);
    if (!file) return;
    toast("Uploading your photo…");
    try {
      const url = await uploadAvatar(file, folderPrefix, id);
      await onDone(url);
      toast("✅ Profile picture updated!");
    } catch (e) {
      toast("Couldn't update your photo: " + (e.message || "please try again."));
    }
  };
  document.body.appendChild(input);
  input.click();
}
