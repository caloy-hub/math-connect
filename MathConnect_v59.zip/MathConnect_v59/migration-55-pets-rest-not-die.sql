-- ============================================================================
-- MathConnect — migration 55
-- Pets no longer die. A neglected pet FALLS ASLEEP, and the student wakes it
-- with a short, gentle "Wake-up Warm-up". A weekly "Care Promise" lets the
-- student choose their own duty and see themselves keep it.
--
-- Run once in Supabase → SQL Editor, AFTER migrations 32–38 (the pet system).
-- Safe to re-run. Old pets that already passed away are NOT touched here —
-- migration-58 (optional) gently brings the ones that are still needed back.
--
-- WHY: a pet that dies when a student is away for a few days punishes
-- exactly the students who have the least reliable internet or the least
-- confidence — and death cannot be repaired. Responsibility is better taught
-- by REPAIR: you notice you let something slide, you own it, you fix it, and
-- you make a plan. So:
--   • Same hunger clock as before (36 h to empty) and the same sickness rule
--     (empty + no vaccine = sick).
--   • Where the old rules killed the pet (sick for 36 h untreated, or empty for
--     108 h), the pet now goes to RESTING instead. Nothing is lost: name,
--     growth, items and mentor links all stay.
--   • A resting pet doesn't grow or need feeding. It is woken with a Wake-up
--     Warm-up: 5 easy questions, get 3 right — unlimited tries, no timer, no
--     penalty. (So coming back is also a small, winnable dose of math.)
--   • On waking the student picks (or skips) what got in the way — forgot /
--     no internet / busy / math felt hard — which the teacher sees as a
--     signal for support, not a grade.
--   • Care Promise: each week the student may promise to visit their pet on
--     2–7 days. It is theirs to set, can only be RAISED once made, and the app
--     shows progress and a lifetime "promises kept" count (a running total,
--     not a streak — a missed week never erases it).
--   • Legendary (peak) pets and Gemstone-shielded pets are unchanged.
-- ============================================================================

alter table student_pets add column if not exists resting boolean not null default false;
alter table student_pets add column if not exists rested_since timestamptz;
alter table student_pets add column if not exists rest_cause text;            -- 'illness' | 'hunger'
alter table student_pets add column if not exists wake_count integer not null default 0;

-- ---------------------------------------------------------------------------
-- Wake-ups: one row each time a pet is woken (teacher-readable, student-write-via-RPC only)
-- ---------------------------------------------------------------------------
create table if not exists pet_wake_log (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  pet_id uuid not null,
  reason text check (reason in ('forgot', 'internet', 'busy', 'hard', 'skip')),
  rest_cause text,
  hours_resting numeric,
  warmup_correct integer,
  warmup_total integer,
  woke_at timestamptz not null default now()
);
create index if not exists pet_wake_log_student_idx on pet_wake_log (student_id, woke_at desc);
alter table pet_wake_log enable row level security;
drop policy if exists "teacher read pet_wake_log" on pet_wake_log;
create policy "teacher read pet_wake_log" on pet_wake_log for select using (is_teacher_of_student(student_id) or is_admin());
drop policy if exists "teacher delete pet_wake_log" on pet_wake_log;
create policy "teacher delete pet_wake_log" on pet_wake_log for delete using (is_teacher_of_student(student_id) or is_admin());

-- ---------------------------------------------------------------------------
-- Care promises (one per student per week; week = Monday–Sunday, Asia/Manila)
-- ---------------------------------------------------------------------------
create table if not exists pet_care_promises (
  student_id uuid not null references students(id) on delete cascade,
  week_start date not null,
  target_days integer not null check (target_days between 2 and 7),
  created_at timestamptz not null default now(),
  primary key (student_id, week_start)
);
alter table pet_care_promises enable row level security;
drop policy if exists "public read pet_care_promises" on pet_care_promises;
create policy "public read pet_care_promises" on pet_care_promises for select using (true);
drop policy if exists "teacher delete pet_care_promises" on pet_care_promises;
create policy "teacher delete pet_care_promises" on pet_care_promises for delete using (is_teacher_of_student(student_id) or is_admin());

-- ---------------------------------------------------------------------------
-- CHECK_PET_WELLBEING — the migration-37 rules, except that where a pet used
-- to DIE it now goes to RESTING. `died` is kept in the result (always false)
-- so older clients keep working; `resting` and `newly_resting` are new.
-- ---------------------------------------------------------------------------
drop function if exists public.check_pet_wellbeing(uuid);
create or replace function public.check_pet_wellbeing(target_student_id uuid)
returns table(pet_id uuid, success boolean, alive boolean, sick boolean, live_hunger integer, died boolean, cause_of_death text, is_peak boolean, resting boolean, newly_resting boolean)
language plpgsql security definer as $$
declare
  pet record;
  hours_since numeric;
  decay_rate numeric := 100.0 / 36.0; -- full drain in 36h, baseline
  discount numeric;
  live_hunger_val integer;
  item_decay integer;
begin
  for pet in select sp.* from student_pets sp where sp.student_id = target_student_id and sp.alive for update loop

    if pet.resting then
      -- Asleep: nothing decays, nothing changes, until the student wakes it.
      return query select pet.id, true, true, false, 0, false, null::text, false, true, false;
      continue;
    end if;

    if is_pet_peak(pet.growth_points) then
      return query select pet.id, true, true, false, pet.hunger, false, null::text, true, false, false;
      continue;
    end if;

    if pet.gem_immune_until is not null and pet.gem_immune_until > now() then
      return query select pet.id, true, true, false, pet.hunger, false, null::text, false, false, false;
      continue;
    end if;

    discount := 0;
    hours_since := greatest(0, extract(epoch from (now() - coalesce(pet.last_fed_at, pet.adopted_at, now()))) / 3600.0);

    if pet.vitamin_boost_until is not null and pet.vitamin_boost_until > now() then
      discount := greatest(discount, 0.5);
    end if;
    if pet.equipped_item is not null then
      select decay_reduction_pct into item_decay from pet_care_items where key = pet.equipped_item and category = 'equipment';
      if item_decay is not null then discount := least(0.9, discount + item_decay / 100.0); end if;
    end if;

    live_hunger_val := greatest(0, least(100, round(pet.hunger - (hours_since * decay_rate * (1 - discount)))));

    if live_hunger_val <= 0 and not pet.sick and (pet.vaccinated_until is null or pet.vaccinated_until < now()) then
      update student_pets set sick = true, sick_since = now(), updated_at = now() where id = pet.id;
      pet.sick := true; pet.sick_since := now();
    end if;

    -- Was: death after 36 h sick and untreated. Now: the pet falls asleep.
    if pet.sick and pet.sick_since is not null and (now() - pet.sick_since) > interval '36 hours'
       and (pet.vaccinated_until is null or pet.vaccinated_until < pet.sick_since) then
      update student_pets set resting = true, rested_since = now(), rest_cause = 'illness', sick = false, sick_since = null,
        hunger = 0, updated_at = now() where id = pet.id;
      return query select pet.id, true, true, false, 0, false, null::text, false, true, true;
      continue;
    end if;

    -- Was: death after 108 h (4.5 days) with an empty tummy. Now: the pet falls asleep.
    if live_hunger_val <= 0 and hours_since > 108 then
      update student_pets set resting = true, rested_since = now(), rest_cause = 'hunger', sick = false, sick_since = null,
        hunger = 0, updated_at = now() where id = pet.id;
      return query select pet.id, true, true, false, 0, false, null::text, false, true, true;
      continue;
    end if;

    return query select pet.id, true, true, pet.sick, live_hunger_val, false, null::text, false, false, false;
  end loop;
  return;
end;
$$;
grant execute on function public.check_pet_wellbeing(uuid) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- WAKE_PET — after a passed Wake-up Warm-up (>= 3 of 5). The warm-up questions
-- are run in the student's browser, like Math Drills; the server enforces the
-- rule (5+ asked, 3+ right) and records what happened.
-- ---------------------------------------------------------------------------
create or replace function public.wake_pet(p_student_id uuid, p_pet_id uuid, p_correct integer, p_total integer, p_reason text default null)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_pet student_pets%rowtype;
  v_reason text;
  v_hours numeric;
begin
  select * into v_pet from student_pets where id = p_pet_id and student_id = p_student_id and alive for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'pet_not_found'); end if;
  if not v_pet.resting then return jsonb_build_object('ok', false, 'error', 'not_resting'); end if;
  if coalesce(p_total, 0) < 5 or coalesce(p_correct, 0) < 3 or p_correct > p_total then
    return jsonb_build_object('ok', false, 'error', 'warmup_not_passed');
  end if;
  v_reason := case when p_reason in ('forgot', 'internet', 'busy', 'hard', 'skip') then p_reason else null end;
  v_hours := round((extract(epoch from (now() - coalesce(v_pet.rested_since, now()))) / 3600.0)::numeric, 1);

  update student_pets set resting = false, hunger = 40, last_fed_at = now(), sick = false, sick_since = null,
    wake_count = wake_count + 1, updated_at = now() where id = v_pet.id;
  insert into pet_wake_log (student_id, pet_id, reason, rest_cause, hours_resting, warmup_correct, warmup_total)
    values (p_student_id, p_pet_id, v_reason, v_pet.rest_cause, v_hours, p_correct, p_total);
  return jsonb_build_object('ok', true, 'hunger', 40, 'wake_count', v_pet.wake_count + 1);
end;
$$;
grant execute on function public.wake_pet(uuid, uuid, integer, integer, text) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- CARE PROMISE
-- ---------------------------------------------------------------------------
create or replace function public._manila_week_start(p_offset_weeks integer default 0) returns date
language sql stable as $$
  select (date_trunc('week', (now() at time zone 'Asia/Manila') - (p_offset_weeks * interval '7 days')))::date;
$$;

create or replace function public.set_care_promise(p_student_id uuid, p_target_days integer) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_week date := public._manila_week_start(0); v_existing integer;
begin
  if p_target_days is null or p_target_days < 2 or p_target_days > 7 then return jsonb_build_object('ok', false, 'error', 'bad_days'); end if;
  if not exists (select 1 from students where id = p_student_id) then return jsonb_build_object('ok', false, 'error', 'student_not_found'); end if;
  select target_days into v_existing from pet_care_promises where student_id = p_student_id and week_start = v_week;
  if v_existing is not null and p_target_days < v_existing then
    return jsonb_build_object('ok', false, 'error', 'cannot_lower', 'target_days', v_existing);
  end if;
  insert into pet_care_promises (student_id, week_start, target_days) values (p_student_id, v_week, p_target_days)
    on conflict (student_id, week_start) do update set target_days = excluded.target_days;
  return jsonb_build_object('ok', true, 'target_days', p_target_days);
end;
$$;
grant execute on function public.set_care_promise(uuid, integer) to anon, authenticated;

-- "Cared" = the student fed a pet that day (green points or food).
create or replace function public.care_promise_status(p_student_id uuid) returns jsonb
language plpgsql security definer stable set search_path = public as $$
declare
  v_week date := public._manila_week_start(0);
  v_target integer; v_days integer; v_kept integer; v_made integer;
begin
  select target_days into v_target from pet_care_promises where student_id = p_student_id and week_start = v_week;
  select count(distinct (fed_at at time zone 'Asia/Manila')::date) into v_days
    from pet_feed_log where student_id = p_student_id and (fed_at at time zone 'Asia/Manila')::date between v_week and v_week + 6;
  select count(*) filter (where cared >= target_days), count(*) into v_kept, v_made from (
    select pp.target_days, (select count(distinct (f.fed_at at time zone 'Asia/Manila')::date) from pet_feed_log f
        where f.student_id = pp.student_id and (f.fed_at at time zone 'Asia/Manila')::date between pp.week_start and pp.week_start + 6) as cared
    from pet_care_promises pp where pp.student_id = p_student_id and pp.week_start < v_week
  ) past;
  return jsonb_build_object('week_start', v_week, 'week_end', v_week + 6, 'target_days', v_target, 'days_cared', coalesce(v_days, 0),
    'kept_total', coalesce(v_kept, 0), 'made_total', coalesce(v_made, 0));
end;
$$;
grant execute on function public.care_promise_status(uuid) to anon, authenticated;
