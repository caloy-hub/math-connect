-- ============================================================================
-- MathConnect — Literacy Arena starter question bank (Grades 7-10)
-- Run AFTER migration-59-literacy-arena.sql.
--
-- What's here (per grade level, 7 through 10):
--   - 1 reading passage + 4 comprehension questions (main idea, inference,
--     vocabulary-in-context, sequence/detail)
--   - 8 vocabulary items (synonym, antonym, word-in-context, prefix/root/suffix)
--   - 8 spelling items (4 typed/audio-prompted, 4 commonly-confused-word or
--     proofreading multiple-choice)
--
-- This is a STARTER set to get the stations playable and let you gauge
-- difficulty/tone — not a full curriculum. Passages lean toward
-- agricultural/technical-vocational themes to fit MCPBAHS, but plain
-- general-literacy topics are mixed in too. Curate, trim, or replace freely;
-- everything here is a normal row in literacy_passages/literacy_questions,
-- editable like any other data.
--
-- Safe to re-run: every insert is idempotent via a fixed id + ON CONFLICT.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- GRADE 7 — Passage: "The Barangay Nursery"
-- ---------------------------------------------------------------------------
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000007', 'Grade 7', 'The Barangay Nursery',
  'Every June, the students of MCPBAHS start seedlings in the school nursery before the rainy season arrives. First, they fill small plastic bags with a mixture of soil, compost, and rice hull. Next, they plant one seed in each bag and water it lightly. The seedlings stay in the shaded nursery for about three weeks, where they are watered every morning. Once the young plants grow their second set of leaves, they are strong enough to be transferred to the open field. Teachers remind students that seedlings moved too early often wilt and die, because their roots are not yet developed enough to survive direct sunlight. Patience, the students learn, is as important to farming as watering and weeding.',
  'informational', 2
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000001','comprehension','11111111-0000-0000-0000-000000000007','Grade 7',2,'multiple_choice',
 'What is the main idea of this passage?',
 '["How to build a school nursery","Why seedlings need patience and the right timing before transplanting","The history of MCPBAHS","How rice hull is made"]',
 'Why seedlings need patience and the right timing before transplanting',
 'The passage centers on the process AND the lesson that rushing the transfer harms the seedlings.'),
('21111111-0000-0000-0000-000000000002','comprehension','11111111-0000-0000-0000-000000000007','Grade 7',2,'multiple_choice',
 'Based on the passage, what would most likely happen if a student transferred a seedling with no second set of leaves yet?',
 '["It would grow faster","It might wilt or die from weak roots","It would need less water","It would flower early"]',
 'It might wilt or die from weak roots',
 'This is an inference from the sentence about roots not yet being developed enough to survive direct sunlight.'),
('21111111-0000-0000-0000-000000000003','comprehension','11111111-0000-0000-0000-000000000007','Grade 7',2,'multiple_choice',
 'In the passage, what does "wilt" most likely mean?',
 '["Grow taller","Droop or weaken","Bloom with flowers","Multiply quickly"]',
 'Droop or weaken',
 'Context clue: it is paired with "die" as a negative outcome of early transplanting.'),
('21111111-0000-0000-0000-000000000004','comprehension','11111111-0000-0000-0000-000000000007','Grade 7',2,'multiple_choice',
 'Which step happens FIRST in the passage?',
 '["Watering every morning","Filling bags with soil, compost, and rice hull","Transferring to the open field","Growing a second set of leaves"]',
 'Filling bags with soil, compost, and rice hull',
 'Sequence check — this is the first step described ("First, they fill small plastic bags...").')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000001','vocabulary','Grade 7',1,'multiple_choice','Choose the word that means the SAME as "huge."','["tiny","enormous","narrow","quiet"]','enormous','"Enormous" is a synonym for "huge."'),
('22222222-0000-0000-0000-000000000002','vocabulary','Grade 7',1,'multiple_choice','Choose the word that means the OPPOSITE of "generous."','["kind","selfish","wealthy","polite"]','selfish','"Selfish" is the antonym of "generous."'),
('22222222-0000-0000-0000-000000000003','vocabulary','Grade 7',2,'multiple_choice','"The farmer was FRUGAL, buying only what he truly needed." FRUGAL most nearly means:','["wasteful","careful with money","careless","generous"]','careful with money','Context clue: buying only what he truly needed suggests carefulness with spending.'),
('22222222-0000-0000-0000-000000000004','vocabulary','Grade 7',2,'multiple_choice','The prefix "un-" in the word "unhappy" means:','["again","not","before","under"]','not','"Un-" is a negation prefix, e.g. unhappy = not happy.'),
('22222222-0000-0000-0000-000000000005','vocabulary','Grade 7',1,'multiple_choice','Choose the word that means the SAME as "assist."','["ignore","help","block","confuse"]','help','"Help" is a synonym for "assist."'),
('22222222-0000-0000-0000-000000000006','vocabulary','Grade 7',1,'multiple_choice','Choose the word that means the OPPOSITE of "rapid."','["quick","slow","sudden","loud"]','slow','"Slow" is the antonym of "rapid."'),
('22222222-0000-0000-0000-000000000007','vocabulary','Grade 7',2,'multiple_choice','The root word "aqua" in "aquatic" relates to:','["fire","water","air","earth"]','water','"Aqua-" is a Latin root meaning water.'),
('22222222-0000-0000-0000-000000000008','vocabulary','Grade 7',2,'multiple_choice','"The teacher gave a BRIEF explanation before the quiz." BRIEF most nearly means:','["long","short","confusing","loud"]','short','Context: it contrasts with a full lesson — a brief explanation is a short one.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000001','spelling','Grade 7',1,'typed','Spell the word you hear.',null,'harvest','harvest',null),
('23333333-0000-0000-0000-000000000002','spelling','Grade 7',1,'typed','Spell the word you hear.',null,'because','because',null),
('23333333-0000-0000-0000-000000000003','spelling','Grade 7',2,'typed','Spell the word you hear.',null,'necessary','necessary',null),
('23333333-0000-0000-0000-000000000004','spelling','Grade 7',2,'typed','Spell the word you hear.',null,'separate','separate',null),
('23333333-0000-0000-0000-000000000005','spelling','Grade 7',1,'multiple_choice','Choose the correctly spelled word.','["recieve","receive","receve","receeve"]','receive',null,'"i before e except after c" — receive follows the "after c" rule.'),
('23333333-0000-0000-0000-000000000006','spelling','Grade 7',1,'multiple_choice','Which sentence uses the correct word? "I would like to go ___ the party."','["too","to","two","toe"]','to',null,'"To" is the preposition used before a destination/purpose.'),
('23333333-0000-0000-0000-000000000007','spelling','Grade 7',2,'multiple_choice','Choose the correctly spelled word.','["definately","definitely","definitly","difinitely"]','definitely',null,'"Definitely" — a commonly misspelled word; remember it contains "finite."'),
('23333333-0000-0000-0000-000000000008','spelling','Grade 7',1,'multiple_choice','Spot the misspelled word: "The studnets finished thier project on time."','["studnets","finished","thier","project"]','studnets',null,'"Studnets" should be "students"; "thier" should also be flagged but this item targets one at a time.')
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- GRADE 8 — Passage: "Reading the Weather Before Planting"
-- ---------------------------------------------------------------------------
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000008', 'Grade 8', 'Reading the Weather Before Planting',
  'Experienced farmers rarely plant a crop without first checking the sky and the calendar. In the Philippines, the southwest monsoon, locally called "habagat," usually brings heavy rains from June to September, while the northeast monsoon, or "amihan," brings cooler and drier air from October to February. Planting rice too early, before the habagat rains stabilize, risks the young plants drying out. Planting too late, after the rains peak, risks flooding the fields and rotting the roots. Modern farmers now supplement traditional knowledge with weather forecasts and rainfall data from PAGASA, but many still rely on generations-old signs, such as the blooming of certain trees or the behavior of local birds, to decide when the season has truly changed. Combining both approaches, farmers argue, gives the most reliable timing.',
  'informational', 3
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000005','comprehension','11111111-0000-0000-0000-000000000008','Grade 8',3,'multiple_choice',
 'What is the main idea of this passage?',
 '["PAGASA is more accurate than traditional weather signs","Farmers combine traditional knowledge and modern forecasts to time planting well","Rice always fails if planted in June","Amihan is more dangerous than habagat"]',
 'Farmers combine traditional knowledge and modern forecasts to time planting well',
 'The last sentence sums up the passage''s point: combining both approaches gives the most reliable timing.'),
('21111111-0000-0000-0000-000000000006','comprehension','11111111-0000-0000-0000-000000000008','Grade 8',3,'multiple_choice',
 'What can you infer would happen if rice were planted right when the rains peak?',
 '["The crop would grow unusually fast","The fields could flood and roots could rot","The plants would need less water","Nothing unusual would happen"]',
 'The fields could flood and roots could rot',
 'This is stated directly as the risk of planting "too late, after the rains peak."'),
('21111111-0000-0000-0000-000000000007','comprehension','11111111-0000-0000-0000-000000000008','Grade 8',3,'multiple_choice',
 'In the passage, what does "supplement" most likely mean?',
 '["Replace completely","Add to or support","Ignore","Delay"]',
 'Add to or support',
 'Context: "supplement traditional knowledge with weather forecasts" means adding modern data alongside, not replacing, tradition.'),
('21111111-0000-0000-0000-000000000008','comprehension','11111111-0000-0000-0000-000000000008','Grade 8',3,'multiple_choice',
 'According to the passage, which monsoon brings cooler, drier air?',
 '["Habagat","Amihan","Both equally","Neither"]',
 'Amihan',
 'Directly stated: "the northeast monsoon, or amihan, brings cooler and drier air."')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000009','vocabulary','Grade 8',2,'multiple_choice','Choose the word that means the SAME as "abundant."','["scarce","plentiful","empty","damaged"]','plentiful','"Plentiful" is a synonym for "abundant."'),
('22222222-0000-0000-0000-000000000010','vocabulary','Grade 8',2,'multiple_choice','Choose the word that means the OPPOSITE of "fragile."','["delicate","sturdy","brittle","weak"]','sturdy','"Sturdy" is the antonym of "fragile."'),
('22222222-0000-0000-0000-000000000011','vocabulary','Grade 8',3,'multiple_choice','"The committee reached a UNANIMOUS decision." UNANIMOUS most nearly means:','["divided","agreed upon by everyone","delayed","secret"]','agreed upon by everyone','A unanimous decision means everyone agreed.'),
('22222222-0000-0000-0000-000000000012','vocabulary','Grade 8',2,'multiple_choice','The suffix "-less" in "harmless" means:','["full of","without","before","again"]','without','"-less" means "without," e.g. harmless = without harm.'),
('22222222-0000-0000-0000-000000000013','vocabulary','Grade 8',2,'multiple_choice','Choose the word that means the SAME as "obtain."','["lose","acquire","reject","hide"]','acquire','"Acquire" is a synonym for "obtain."'),
('22222222-0000-0000-0000-000000000014','vocabulary','Grade 8',2,'multiple_choice','Choose the word that means the OPPOSITE of "expand."','["grow","shrink","stretch","widen"]','shrink','"Shrink" is the antonym of "expand."'),
('22222222-0000-0000-0000-000000000015','vocabulary','Grade 8',3,'multiple_choice','The root "bio" in "biology" relates to:','["life","land","water","light"]','life','"Bio-" is a Greek root meaning life.'),
('22222222-0000-0000-0000-000000000016','vocabulary','Grade 8',3,'multiple_choice','"The results were AMBIGUOUS, so the researchers ran the test again." AMBIGUOUS most nearly means:','["very clear","unclear or open to interpretation","completely wrong","extremely positive"]','unclear or open to interpretation','Context: unclear results are why they had to test again.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000009','spelling','Grade 8',2,'typed','Spell the word you hear.',null,'occurred','occurred',null),
('23333333-0000-0000-0000-000000000010','spelling','Grade 8',2,'typed','Spell the word you hear.',null,'immediately','immediately',null),
('23333333-0000-0000-0000-000000000011','spelling','Grade 8',3,'typed','Spell the word you hear.',null,'environment','environment',null),
('23333333-0000-0000-0000-000000000012','spelling','Grade 8',2,'typed','Spell the word you hear.',null,'existence','existence',null),
('23333333-0000-0000-0000-000000000013','spelling','Grade 8',2,'multiple_choice','Which sentence uses the correct word? "The weather will ___ how much rice we plant."','["affect","effect","affects the","effected"]','affect',null,'"Affect" is usually the verb (to influence); "effect" is usually the noun (a result).'),
('23333333-0000-0000-0000-000000000014','spelling','Grade 8',2,'multiple_choice','Choose the correctly spelled word.','["accomodate","accommodate","acommodate","accommadate"]','accommodate',null,'"Accommodate" has double "c" and double "m" — a commonly misspelled word.'),
('23333333-0000-0000-0000-000000000015','spelling','Grade 8',2,'multiple_choice','Which sentence uses the correct word? "___ going to check the rainfall data tomorrow."','["Their","There","They''re","Thier"]','They''re',null,'"They''re" is the contraction of "they are."'),
('23333333-0000-0000-0000-000000000016','spelling','Grade 8',3,'multiple_choice','Spot the misspelled word: "The farmers recieved the forecast early this morning."','["recieved","forecast","morning","farmers"]','recieved',null,'"Recieved" should be "received" — i before e except after c.')
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- GRADE 9 — Passage: "The Cost of a Shortcut"
-- ---------------------------------------------------------------------------
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000009', 'Grade 9', 'The Cost of a Shortcut',
  'When the irrigation canal near the demonstration farm cracked, two students were assigned to patch it before the afternoon watering schedule. Rather than draining the section and mixing a proper batch of cement, they applied a thin layer of wet soil over the crack, hoping it would hold long enough. It did not. Within an hour, water pressure reopened the crack, flooding a nearby row of vegetable seedlings the class had transplanted only days earlier. Their adviser did not scold them for trying to solve the problem quickly; instead, he pointed out that the shortcut had cost them more time and more seedlings than doing it properly the first time would have. The students spent the rest of the afternoon replanting, this time under a lesson they would not forget: a rushed fix is rarely a real fix.',
  'narrative', 4
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000009','comprehension','11111111-0000-0000-0000-000000000009','Grade 9',4,'multiple_choice',
 'What is the main idea of this passage?',
 '["Irrigation canals are hard to repair","A rushed shortcut often costs more than doing a job properly","The adviser was too harsh on the students","Vegetables should not be planted near canals"]',
 'A rushed shortcut often costs more than doing a job properly',
 'The final line states the lesson directly: "a rushed fix is rarely a real fix."'),
('21111111-0000-0000-0000-000000000010','comprehension','11111111-0000-0000-0000-000000000009','Grade 9',4,'multiple_choice',
 'Why did the adviser NOT scold the students?',
 '["He did not notice the flooding","He wanted them to learn from the natural consequence instead","He agreed the shortcut was a good idea","He was not responsible for the farm"]',
 'He wanted them to learn from the natural consequence instead',
 'Inference: he "pointed out" the cost rather than punishing them, letting the outcome be the lesson.'),
('21111111-0000-0000-0000-000000000011','comprehension','11111111-0000-0000-0000-000000000009','Grade 9',4,'multiple_choice',
 'In the passage, what does "reopened" suggest about the crack?',
 '["It was a brand-new crack","The crack had been closed but broke open again under pressure","The crack healed on its own","The crack moved to a new location"]',
 'The crack had been closed but broke open again under pressure',
 'Context clue: the students had just patched it, so "reopened" means the same crack failed again.'),
('21111111-0000-0000-0000-000000000012','comprehension','11111111-0000-0000-0000-000000000009','Grade 9',4,'multiple_choice',
 'Which event happened LAST in the passage?',
 '["The crack was patched with wet soil","The canal cracked","The students replanted the seedlings","The seedlings were flooded"]',
 'The students replanted the seedlings',
 'Sequence: crack → patch attempt → flooding → replanting, in that order.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000017','vocabulary','Grade 9',3,'multiple_choice','Choose the word that means the SAME as "meticulous."','["careless","careful and precise","fast","confused"]','careful and precise','"Meticulous" means extremely careful and precise.'),
('22222222-0000-0000-0000-000000000018','vocabulary','Grade 9',3,'multiple_choice','Choose the word that means the OPPOSITE of "reluctant."','["hesitant","willing","unsure","afraid"]','willing','"Willing" is the antonym of "reluctant" (unwilling).'),
('22222222-0000-0000-0000-000000000019','vocabulary','Grade 9',4,'multiple_choice','"The engineer''s plan was PRAGMATIC rather than idealistic." PRAGMATIC most nearly means:','["impractical","practical and realistic","expensive","theoretical only"]','practical and realistic','Contrasted with "idealistic," pragmatic means grounded and practical.'),
('22222222-0000-0000-0000-000000000020','vocabulary','Grade 9',3,'multiple_choice','The prefix "mis-" in "misunderstand" means:','["correctly","wrongly","again","before"]','wrongly','"Mis-" means wrongly or badly, e.g. misunderstand = understand wrongly.'),
('22222222-0000-0000-0000-000000000021','vocabulary','Grade 9',3,'multiple_choice','Choose the word that means the SAME as "diminish."','["increase","decrease","remain","multiply"]','decrease','"Diminish" means to decrease or reduce.'),
('22222222-0000-0000-0000-000000000022','vocabulary','Grade 9',3,'multiple_choice','Choose the word that means the OPPOSITE of "transparent."','["clear","obscure","visible","open"]','obscure','"Obscure" (unclear/hidden) is the antonym of "transparent."'),
('22222222-0000-0000-0000-000000000023','vocabulary','Grade 9',4,'multiple_choice','The root "spect" in "inspect" relates to:','["to look","to speak","to build","to move"]','to look','"Spect" is a Latin root meaning to look or see.'),
('22222222-0000-0000-0000-000000000024','vocabulary','Grade 9',4,'multiple_choice','"Her argument was CONCISE, covering the key points in two sentences." CONCISE most nearly means:','["long and detailed","brief and to the point","confusing","repetitive"]','brief and to the point','Context: covering key points in only two sentences implies brevity.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000017','spelling','Grade 9',3,'typed','Spell the word you hear.',null,'conscience','conscience',null),
('23333333-0000-0000-0000-000000000018','spelling','Grade 9',3,'typed','Spell the word you hear.',null,'privilege','privilege',null),
('23333333-0000-0000-0000-000000000019','spelling','Grade 9',4,'typed','Spell the word you hear.',null,'maintenance','maintenance',null),
('23333333-0000-0000-0000-000000000020','spelling','Grade 9',3,'typed','Spell the word you hear.',null,'occasionally','occasionally',null),
('23333333-0000-0000-0000-000000000021','spelling','Grade 9',3,'multiple_choice','Which sentence uses the correct word? "The teacher gave us ___ advice on the project."','["there","their","they''re","thier"]','their',null,'"Their" shows possession — the advice belongs to the teacher.'),
('23333333-0000-0000-0000-000000000022','spelling','Grade 9',3,'multiple_choice','Choose the correctly spelled word.','["embarass","embarrass","embarras","emberrass"]','embarrass',null,'"Embarrass" has double "r" and double "s."'),
('23333333-0000-0000-0000-000000000023','spelling','Grade 9',3,'multiple_choice','Which sentence uses the correct word? "The two farms are far apart, but their yields are ___ the same."','["altogether","all together","alltogether","all-together"]','altogether',null,'"Altogether" means "completely"; "all together" means "in a group" — this sentence needs "completely."'),
('23333333-0000-0000-0000-000000000024','spelling','Grade 9',3,'multiple_choice','Spot the misspelled word: "It is neccessary to check the equipment before every use."','["neccessary","equipment","before","every"]','neccessary',null,'"Neccessary" should be "necessary" — one "c," two "s."')
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- GRADE 10 — Passage: "Automation on the Small Farm"
-- ---------------------------------------------------------------------------
insert into literacy_passages (id, grade_level, title, body, genre, difficulty)
values (
  '11111111-0000-0000-0000-000000000010', 'Grade 10', 'Automation on the Small Farm',
  'Automated drip irrigation systems, once affordable only to large commercial farms, have become increasingly accessible to smallholder farmers in the past decade. A basic setup uses a timer, a water pump, and a network of perforated tubing to deliver water directly to each plant''s roots at scheduled intervals. Proponents argue that the technology reduces water waste by up to 50% compared to flood irrigation, since water is not lost to evaporation or runoff. Critics, however, point out those upfront costs, though lower than before, still represent a significant investment for a farmer already operating on thin margins, and that the system requires basic technical knowledge to install and maintain. Some agricultural extension programs have begun offering subsidized starter kits along with training, arguing that the long-term water savings justify the initial support. Whether the benefits outweigh the barriers, most agree, likely depends on the size of the farm and the reliability of the local water supply.',
  'informational', 5
)
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, passage_id, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('21111111-0000-0000-0000-000000000013','comprehension','11111111-0000-0000-0000-000000000010','Grade 10',5,'multiple_choice',
 'What is the main idea of this passage?',
 '["Drip irrigation is always the best choice for every farm","Drip irrigation offers real water savings but comes with cost and skill barriers worth weighing","Flood irrigation should be banned","Extension programs no longer support small farmers"]',
 'Drip irrigation offers real water savings but comes with cost and skill barriers worth weighing',
 'The passage presents both benefits and drawbacks, concluding it "depends on the size of the farm and the reliability of the local water supply."'),
('21111111-0000-0000-0000-000000000014','comprehension','11111111-0000-0000-0000-000000000010','Grade 10',5,'multiple_choice',
 'What can you infer about a farmer with very little savings and an unreliable water source?',
 '["Drip irrigation would clearly be their best option","They may face more risk adopting the system than a farmer with steady water access","Their water use would automatically decrease by 50%","They would not need any training to use it"]',
 'They may face more risk adopting the system than a farmer with steady water access',
 'The passage''s closing point ties benefit against cost and reliability — thin margins plus unreliable water raises the stakes of the investment.'),
('21111111-0000-0000-0000-000000000015','comprehension','11111111-0000-0000-0000-000000000010','Grade 10',5,'multiple_choice',
 'In the passage, what does "proponents" mean?',
 '["People who oppose something","People who support something","People who study something neutrally","People who invented something"]',
 'People who support something',
 'Contrasted directly with "critics" later in the paragraph — proponents are supporters.'),
('21111111-0000-0000-0000-000000000016','comprehension','11111111-0000-0000-0000-000000000010','Grade 10',5,'multiple_choice',
 'According to the passage, why do some extension programs offer subsidized starter kits?',
 '["To make a profit from farmers","Because they believe long-term water savings justify the initial support","Because the government requires it","To replace flood irrigation entirely by law"]',
 'Because they believe long-term water savings justify the initial support',
 'Directly stated: programs argue "the long-term water savings justify the initial support."')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
('22222222-0000-0000-0000-000000000025','vocabulary','Grade 10',4,'multiple_choice','Choose the word that means the SAME as "feasible."','["impossible","achievable","expensive","risky"]','achievable','"Feasible" means capable of being done — achievable.'),
('22222222-0000-0000-0000-000000000026','vocabulary','Grade 10',4,'multiple_choice','Choose the word that means the OPPOSITE of "abundant."','["plentiful","scarce","overflowing","large"]','scarce','"Scarce" is the antonym of "abundant."'),
('22222222-0000-0000-0000-000000000027','vocabulary','Grade 10',5,'multiple_choice','"The report''s conclusions were SPECULATIVE, based on limited data." SPECULATIVE most nearly means:','["proven and certain","based on guesswork rather than solid evidence","completely false","widely accepted"]','based on guesswork rather than solid evidence','Context: limited data implies the conclusions aren''t solidly proven — they''re speculative.'),
('22222222-0000-0000-0000-000000000028','vocabulary','Grade 10',4,'multiple_choice','The suffix "-ify" in "simplify" means:','["to make or cause","to remove","to study","to oppose"]','to make or cause','"-ify" means to make/cause, e.g. simplify = to make simple.'),
('22222222-0000-0000-0000-000000000029','vocabulary','Grade 10',4,'multiple_choice','Choose the word that means the SAME as "mitigate."','["worsen","lessen or reduce","ignore","celebrate"]','lessen or reduce','"Mitigate" means to make less severe — to lessen or reduce.'),
('22222222-0000-0000-0000-000000000030','vocabulary','Grade 10',4,'multiple_choice','Choose the word that means the OPPOSITE of "sustainable."','["renewable","depletable","efficient","reliable"]','depletable','Something "depletable" runs out, opposite of something that can be sustained long-term.'),
('22222222-0000-0000-0000-000000000031','vocabulary','Grade 10',5,'multiple_choice','The root "cred" in "credible" relates to:','["to believe","to build","to break","to measure"]','to believe','"Cred-" is a Latin root meaning to believe or trust.'),
('22222222-0000-0000-0000-000000000032','vocabulary','Grade 10',5,'multiple_choice','"The two approaches are not mutually exclusive; they can COMPLEMENT each other." COMPLEMENT most nearly means:','["conflict with","go well with and complete","replace entirely","weaken"]','go well with and complete','Context: "not mutually exclusive... can work together" signals complement means to enhance/complete each other.')
on conflict (id) do nothing;

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, audio_word, explanation)
values
('23333333-0000-0000-0000-000000000025','spelling','Grade 10',4,'typed','Spell the word you hear.',null,'entrepreneur','entrepreneur',null),
('23333333-0000-0000-0000-000000000026','spelling','Grade 10',4,'typed','Spell the word you hear.',null,'questionnaire','questionnaire',null),
('23333333-0000-0000-0000-000000000027','spelling','Grade 10',5,'typed','Spell the word you hear.',null,'infrastructure','infrastructure',null),
('23333333-0000-0000-0000-000000000028','spelling','Grade 10',4,'typed','Spell the word you hear.',null,'sufficient','sufficient',null),
('23333333-0000-0000-0000-000000000029','spelling','Grade 10',4,'multiple_choice','Which sentence uses the correct word? "The new system will ___ water waste significantly."','["effect","affect","affects","effected"]','affect',null,'"Affect" as a verb means to influence/change — fits "will affect water waste."'),
('23333333-0000-0000-0000-000000000030','spelling','Grade 10',4,'multiple_choice','Choose the correctly spelled word.','["occurence","occurrence","ocurrence","occurrance"]','occurrence',null,'"Occurrence" has double "c" and double "r."'),
('23333333-0000-0000-0000-000000000031','spelling','Grade 10',4,'multiple_choice','Which sentence uses the correct word? "The farmers had ___ own reasons for choosing drip irrigation."','["there","their","they''re","thier"]','their',null,'"Their" shows possession here.'),
('23333333-0000-0000-0000-000000000032','spelling','Grade 10',5,'multiple_choice','Spot the misspelled word: "The comittee reviewed the proposal for the irrigation grant."','["comittee","reviewed","proposal","irrigation"]','comittee',null,'"Comittee" should be "committee" — double "m," double "t."')
on conflict (id) do nothing;

-- ============================================================================
-- Done. 4 passages, 16 comprehension questions, 32 vocabulary questions,
-- 32 spelling questions (128 items total, 32 per grade level 7-10).
-- All grade_level values are the plain "Grade 7".."Grade 10" strings used
-- elsewhere in the schema (sections.grade_level) — if your sections use a
-- different format (e.g. "7" or "G7"), update grade_level here to match,
-- or adjust fetchLiteracyQuestions() in literacyEngine.js instead.
-- ============================================================================
