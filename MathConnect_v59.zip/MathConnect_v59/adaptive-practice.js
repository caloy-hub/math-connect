// ============================================================================
// MathConnect — Adaptive Practice UI (the combined Drill Screen)
// Renders: the Skill Bar (top), the Adaptive Tier badge, the current
// question, and the live Error Feedback popup — all driven by
// learningEngine.js's processAnswer(). No adaptive/diagnosis/skill MATH
// lives in this file — it only renders state and reacts to it.
// Depends on: learningEngine.js, difficultyEngine.js (tierLabel), sstate
// (student.js), escapeHtml/toast (supabase-client.js).
// ============================================================================

const LE_TIER_COLORS = { 1: "#4CAF7D", 2: "#2F8FD1", 3: "#F0A93B", 4: "#E8632E" };
const LE_SESSION_LENGTH = 8;

var legame = null; // active-session state, created fresh by startPracticeSession()

function leTierBadge(tier, size) {
  const color = LE_TIER_COLORS[tier] || LE_TIER_COLORS[1];
  const pad = size === "small" ? "3px 9px" : "5px 14px";
  const font = size === "small" ? ".72rem" : ".85rem";
  return `<span style="display:inline-flex;align-items:center;gap:5px;background:${color}22;color:${color};border:1px solid ${color}55;padding:${pad};border-radius:20px;font-weight:700;font-size:${font};white-space:nowrap;">Level: ${tierLabel(tier)}</span>`;
}

function leSkillBarHtml(domainMeta, proficiency) {
  return `
    <div style="margin-bottom:4px;display:flex;justify-content:space-between;font-size:.8rem;">
      <span><strong>${domainMeta.icon} ${domainMeta.name}</strong> Mastery</span>
      <span class="muted">${proficiency}%</span>
    </div>
    <div class="le-skillbar-track"><div class="le-skillbar-fill" style="width:${proficiency}%;"></div></div>`;
}

// ============================================================================
// HUB — one card per domain, each showing its own tier badge + skill bar
// ============================================================================
async function renderLearningHub() {
  const el = document.getElementById("tab-learning");
  el.innerHTML = `<div class="empty">Loading your progress…</div>`;
  if (!lestate.loaded) await loadLearningState();
  if (!lockstate.loaded) await loadPracticeDomainLocks();
  const s = lestate.student;

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;flex-wrap:wrap;">
        <h2 style="margin:0 0 4px;">🧠 Intelligent Practice</h2>
        ${typeof certShelfButtonHtml === "function" ? certShelfButtonHtml("practice") : ""}
      </div>
      <p class="muted">Questions get harder or easier automatically based on how you're doing — and if you slip up, you'll get a specific hint, not just "wrong." Complete a station for a certificate: reach <strong>Expert</strong> level, then finish a session with all 8 questions at Expert level answered correctly on the first try (100%).</p>
    </div>
    <div class="drill-grid">
      ${LE_DOMAINS.map((d) => {
        const locked = isPracticeDomainLocked(d.key);
        if (locked) {
          const note = (lockstate.domainLocks[d.key] && lockstate.domainLocks[d.key].note) || "Locked by your admin — check back soon!";
          return `
          <div class="drill-card" style="opacity:.6;">
            <div class="icon">🔒</div>
            <h3 style="margin-top:8px;">${d.icon} ${d.name}</h3>
            <p class="muted" style="font-size:.82rem;min-height:2.4em;">${escapeHtml(note)}</p>
            <button class="btn-outline" style="width:100%;margin-top:6px;" disabled>🔒 Locked</button>
          </div>`;
        }
        const tier = s.adaptiveLevel[d.key] || 1;
        const prof = s.skillProficiency[d.key] || 0;
        return `
        <div class="drill-card">
          <div class="icon">${d.icon}</div>
          <h3 style="margin-top:8px;">${d.name}</h3>
          <div style="margin:8px 0;">${leTierBadge(tier)}</div>
          <div style="text-align:left;">${leSkillBarHtml(d, prof)}</div>
          <button class="btn-primary" style="width:100%;margin-top:14px;" onclick="startPracticeSession('${d.key}')">▶ Practice</button>
        </div>`;
      }).join("")}
    </div>`;
}

// ============================================================================
// GAMEPLAY
// ============================================================================
function startPracticeSession(domain) {
  if (isPracticeDomainLocked(domain)) { toast("🔒 This practice domain is locked by your admin right now."); return; }
  const domainMeta = LE_DOMAINS.find((d) => d.key === domain);
  legame = {
    domain, domainMeta, questionsAnswered: 0, correctCount: 0,
    startProficiency: lestate.student.skillProficiency[domain] || 0,
    startTier: lestate.student.adaptiveLevel[domain] || 1,
    currentQuestion: null, attemptNumber: 1,
    sessionLength: LE_SESSION_LENGTH, answers: [], // v58 — per-question { tier, firstTry, skipped } for the station certificate
  };
  if (typeof showPetCheerBubble === "function") showPetCheerBubble();
  nextPracticeQuestion();
}

function nextPracticeQuestion() {
  const s = lestate.student;
  const tier = s.adaptiveLevel[legame.domain] || 1;
  legame.currentQuestion = generateQuestion(legame.domain, tier);
  legame.attemptNumber = 1;
  renderPracticeScreen();
}

function renderPracticeScreen() {
  const root = document.getElementById("modalRoot");
  const s = lestate.student;
  const tier = s.adaptiveLevel[legame.domain] || 1;
  const prof = s.skillProficiency[legame.domain] || 0;
  const q = legame.currentQuestion;

  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-top-row">
        <div>${legame.domainMeta.icon} <strong>${legame.domainMeta.name}</strong> · Question ${legame.questionsAnswered + 1} of ${LE_SESSION_LENGTH}</div>
        ${leTierBadge(tier)}
        <button class="btn-outline" style="border-color:var(--gold-light);color:var(--gold-light);" onclick="quitPracticeSession()">✕ Quit</button>
      </div>
      <div style="max-width:420px;margin:0 auto 18px;">${leSkillBarHtml(legame.domainMeta, prof)}</div>
      <div class="drill-question-card">
        <div class="drill-question-text">${escapeHtml(q.prompt)}</div>
        ${q.hint ? `<p class="muted" style="margin-top:8px;font-size:.78rem;">${escapeHtml(q.hint)}</p>` : ""}
        <input id="leAnswerInput" class="drill-answer-input" placeholder="${q.type === "fraction" ? "e.g. 3/4" : "your answer"}" autocomplete="off" />
        <div style="margin-top:16px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <button class="btn-primary" onclick="submitPracticeAnswer()">Submit</button>
          ${typeof estate !== "undefined" && estate.loaded && estate.data && estate.data.skip_passes > 0
            ? `<button class="btn-outline" onclick="skipPracticeQuestion()">⏭️ Skip (${estate.data.skip_passes} left)</button>` : ""}
        </div>
        <div id="leFeedback" class="drill-feedback"></div>
      </div>
    </div>`;
  const input = document.getElementById("leAnswerInput");
  if (input) { input.focus(); input.addEventListener("keydown", (e) => { if (e.key === "Enter") submitPracticeAnswer(); }); }
  attachNumericKeypad("leAnswerInput", { type: q.type });
}

/** Spends one Skip Question pass to skip the current question — no penalty, no diagnosis, doesn't affect the adaptive tier. */
async function skipPracticeQuestion() {
  const spent = await consumeSkipPass();
  if (!spent) { toast("No Skip passes left."); return; }
  legame.questionsAnswered++;
  legame.answers.push({ tier: lestate.student.adaptiveLevel[legame.domain] || 1, firstTry: false, skipped: true });
  document.getElementById("leFeedback").innerHTML = "⏭️ Skipped — no penalty!";
  setTimeout(() => {
    if (legame.questionsAnswered >= LE_SESSION_LENGTH) finishPracticeSession();
    else nextPracticeQuestion();
  }, 900);
}

async function submitPracticeAnswer() {
  const input = document.getElementById("leAnswerInput");
  const raw = input ? input.value : "";
  const feedback = document.getElementById("leFeedback");

  const result = processAnswer(lestate.student, legame.currentQuestion, raw, legame.attemptNumber);

  // Double XP: if the buff is running, top up the mastery bar with an equal
  // second helping of the points this answer just earned (net effect: 2x).
  if (result.isCorrect && result.pointsAwarded > 0 && typeof isDoubleXpActive === "function" && isDoubleXpActive()) {
    const domain = legame.domain;
    const bonus = result.pointsAwarded; // doubling = award the same amount again
    const topped = Math.max(0, Math.min(100, (lestate.student.skillProficiency[domain] || 0) + bonus));
    lestate.student.skillProficiency = { ...lestate.student.skillProficiency, [domain]: topped };
    result.skillProficiency = topped;
    result.pointsAwarded = applyDoubleXp(result.pointsAwarded);
  }

  if (result.isCorrect) {
    const coinsEarned = typeof awardAnswerCoins === "function" ? await awardAnswerCoins(true, result.attemptNumber) : 0;
    // Green Points for the Math Pet — 1 per correct answer here too.
    if (typeof awardGreenPoints === "function") await awardGreenPoints(1);
    feedback.className = "drill-feedback correct";
    feedback.innerHTML = `✅ Correct! +${result.pointsAwarded} mastery pts${result.attemptNumber >= 2 ? " (effort credit for correcting it!)" : ""}${coinsEarned ? ` &nbsp;·&nbsp; 🪙 +${coinsEarned}` : ""} &nbsp;·&nbsp; 💚 +1`;
    if (typeof triggerPetEvent === "function") triggerPetEvent("QUESTION_CORRECT");
  } else {
    feedback.className = "drill-feedback wrong";
    feedback.innerHTML = `❌ ${escapeHtml(result.feedback)}`;
    if (typeof triggerPetEvent === "function") triggerPetEvent("QUESTION_WRONG");
  }

  if (result.tierChanged) {
    const dir = result.nextTier > result.tierUsed ? "⬆️ Leveled up" : "⬇️ Stepping back";
    toast(`${dir} in ${legame.domainMeta.name}: now ${tierLabel(result.nextTier)}`);
    if (typeof triggerPetEvent === "function" && result.nextTier > result.tierUsed) triggerPetEvent("LEVEL_UP");
  }

  if (result.allowRetry) {
    // Let the student try the SAME question again — input stays enabled, no advance.
    legame.attemptNumber = 2;
    input.value = "";
    input.focus();
    return;
  }

  // Question is final (correct, or the retry is used up) — log, save, and move on.
  await logAnswer(legame.domain, result.tierUsed, result.attemptNumber, result.isCorrect, result.mistakeType, legame.currentQuestion, raw, result.pointsAwarded);
  await saveLearningState();

  legame.questionsAnswered++;
  if (result.isCorrect) legame.correctCount++;
  legame.answers.push({ tier: result.tierUsed, firstTry: result.isCorrect && result.attemptNumber === 1, skipped: false });
  input.disabled = true;

  if (!result.isCorrect) {
    feedback.innerHTML += ` <br><span class="muted">Correct answer: <strong>${result.correctAnswerDisplay}</strong></span>`;
  }

  setTimeout(() => {
    if (legame.questionsAnswered >= LE_SESSION_LENGTH) finishPracticeSession();
    else nextPracticeQuestion();
  }, 1700);
}

function quitPracticeSession() {
  document.getElementById("modalRoot").innerHTML = "";
  legame = null;
  renderLearningHub();
}

async function finishPracticeSession() {
  const s = lestate.student;
  const endProficiency = s.skillProficiency[legame.domain] || 0;
  const endTier = s.adaptiveLevel[legame.domain] || 1;
  // v58 — certificate per STATION (domain): a perfect session at Expert level (all questions at Expert, every one
  // correct on the first try). Anything less just shows how close the student is.
  let certRec = null, certSum = null;
  if (typeof certCheckPracticeStation === "function") {
    const chk = await certCheckPracticeStation(legame, legame.answers, endProficiency);
    certRec = chk.rec; certSum = chk.sum;
  }
  if (typeof recordDailyActivity === "function") { recordDailyActivity().then(() => renderTopbarStreakBadge()); }
  if (typeof markDailyActivity === "function") markDailyActivity("practice");
  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-question-card" style="max-width:520px;">
        <h2>${legame.domainMeta.icon} Session Complete!</h2>
        <div class="drill-stat-row">
          <div class="drill-stat"><div class="num">${legame.correctCount}/${LE_SESSION_LENGTH}</div><div class="muted">Correct</div></div>
          <div class="drill-stat"><div class="num" style="color:var(--gold);">${endProficiency}%</div><div class="muted">Mastery</div></div>
          <div class="drill-stat">${leTierBadge(endTier)}<div class="muted" style="margin-top:4px;">Current Level</div></div>
        </div>
        <p class="muted">${legame.domainMeta.name} mastery: ${legame.startProficiency}% → ${endProficiency}%${endTier !== legame.startTier ? ` · Level: ${tierLabel(legame.startTier)} → ${tierLabel(endTier)}` : ""}</p>
        ${certEarnedBannerHtml(certRec)}
        ${certRec ? "" : certPracticeProgressHtml(certSum, endTier, legame.domainMeta.name)}
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
          <button class="btn-primary" onclick="startPracticeSession('${legame.domain}')">▶ Practice Again</button>
          <button class="btn-outline" onclick="closePracticeToHub()">Back to Practice Hub</button>
        </div>
      </div>
    </div>`;
  legame = null;
}
function closePracticeToHub() {
  document.getElementById("modalRoot").innerHTML = "";
  renderLearningHub();
}
