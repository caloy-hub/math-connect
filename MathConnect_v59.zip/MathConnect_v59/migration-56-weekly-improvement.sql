-- ============================================================================
-- MathConnect — migration 56
-- "Most Improved" = improvement against YOUR OWN past, plus a personal
-- "My Week" progress summary.
--
-- Run once in Supabase → SQL Editor, AFTER migration 43 (which created
-- student_preferences and the older points-based "Most Improved" board).
-- Safe to re-run. Nothing is deleted; the older board's functions stay in
-- place (the app simply stops using them).
--
-- WHY: the old weekly board ranked points EARNED in the last 7 days — which
-- is really a "who played most" board. A student who is quietly getting better
-- but plays a little never appears. This version measures how much each
-- student has grown compared with their own usual level:
--
--   Progress points (per week, Monday–Sunday, Asia/Manila)
--     + 1 for every percentage point your answer accuracy rose above your
--         usual (capped at +30), when you answered 20+ questions this week
--         and have a usual to compare with;
--     + 5 for every level you climbed in a Drill station (capped at 4 levels).
--   "Your usual" = your accuracy over the previous 28 days; if you weren't
--   playing then, your earlier history (needs 20+ answers either way).
--   Nobody is ever shown a negative number (the student-facing functions clamp
--   the accuracy change at 0; only the teacher's view keeps the raw figure so a
--   dip can prompt support). A board row needs progress > 0.
--
-- Two more ways to be recognised, neither of them scored, so nothing can be
-- gamed: 🌱 "New this week" (first drills ever, 10+ answers) and 🔁 "Welcome
-- back" (returning after 2+ weeks away, 10+ answers).
--
-- Boards show only students who kept "Show me on leaderboards" on
-- (student_preferences, migration 43); a student always sees their own row.
-- The scope is the student's grade level, like the other leaderboards.
-- ============================================================================

create index if not exists idx_drill_attempts_student_played on drill_attempts (student_id, played_at);

-- [start, end) of the Manila calendar week `p_weeks_ago` weeks back (0 = this week so far).
create or replace function public._manila_week_bounds(p_weeks_ago integer default 0)
returns table(ws timestamptz, we timestamptz)
language sql stable as $$
  select (date_trunc('week', (now() at time zone 'Asia/Manila') - (p_weeks_ago * interval '7 days'))) at time zone 'Asia/Manila',
         (date_trunc('week', (now() at time zone 'Asia/Manila') - (p_weeks_ago * interval '7 days')) + interval '7 days') at time zone 'Asia/Manila';
$$;

-- One row per requested student. Everything the boards, the personal card and
-- the teacher view show comes from here, so the three can never disagree.
create or replace function public._weekly_progress(p_student_ids uuid[], p_weeks_ago integer default 0)
returns table(
  student_id uuid, answers integer, correct integer, accuracy numeric, days_active integer, level_ups integer, points_earned integer,
  base_answers integer, base_accuracy numeric, base_kind text, acc_gain numeric, progress_pts integer, tag text
)
language sql stable security definer set search_path = public as $$
  with b as (select ws, we from public._manila_week_bounds(p_weeks_ago)),
  ids as (select unnest(p_student_ids) as student_id),
  wk as (
    select da.student_id, sum(da.total_questions)::integer as answers, sum(da.correct_count)::integer as correct,
           count(distinct (da.played_at at time zone 'Asia/Manila')::date)::integer as days_active,
           (count(*) filter (where da.leveled_up))::integer as level_ups,
           greatest(0, sum(da.points_earned))::integer as points_earned
    from drill_attempts da, b
    where da.student_id = any(p_student_ids) and da.played_at >= b.ws and da.played_at < b.we
    group by da.student_id
  ),
  recent as (
    select da.student_id, sum(da.total_questions)::integer as answers, sum(da.correct_count)::integer as correct
    from drill_attempts da, b
    where da.student_id = any(p_student_ids) and da.played_at >= b.ws - interval '28 days' and da.played_at < b.ws
    group by da.student_id
  ),
  older as (
    select da.student_id, sum(da.total_questions)::integer as answers, sum(da.correct_count)::integer as correct
    from drill_attempts da, b
    where da.student_id = any(p_student_ids) and da.played_at < b.ws
    group by da.student_id
  ),
  gap as (   -- answers in the 14 days before this week began
    select da.student_id, sum(da.total_questions)::integer as answers
    from drill_attempts da, b
    where da.student_id = any(p_student_ids) and da.played_at >= b.ws - interval '14 days' and da.played_at < b.ws
    group by da.student_id
  ),
  joined as (
    select i.student_id,
           coalesce(wk.answers, 0) as answers, coalesce(wk.correct, 0) as correct,
           coalesce(wk.days_active, 0) as days_active, coalesce(wk.level_ups, 0) as level_ups, coalesce(wk.points_earned, 0) as points_earned,
           case when coalesce(recent.answers, 0) >= 20 then recent.answers when coalesce(older.answers, 0) >= 20 then older.answers else coalesce(recent.answers, older.answers, 0) end as base_answers,
           case when coalesce(recent.answers, 0) >= 20 then recent.correct::numeric / recent.answers
                when coalesce(older.answers, 0) >= 20 then older.correct::numeric / older.answers end as base_ratio,
           case when coalesce(recent.answers, 0) >= 20 then 'recent' when coalesce(older.answers, 0) >= 20 then 'history' else 'none' end as base_kind,
           coalesce(older.answers, 0) as older_answers, coalesce(gap.answers, 0) as gap_answers
    from ids i
    left join wk on wk.student_id = i.student_id
    left join recent on recent.student_id = i.student_id
    left join older on older.student_id = i.student_id
    left join gap on gap.student_id = i.student_id
  )
  select j.student_id, j.answers, j.correct,
         case when j.answers > 0 then round(j.correct::numeric / j.answers * 100, 1) end as accuracy,
         j.days_active, j.level_ups, j.points_earned, j.base_answers,
         case when j.base_ratio is not null then round(j.base_ratio * 100, 1) end as base_accuracy,
         j.base_kind,
         case when j.answers >= 20 and j.base_ratio is not null then round((j.correct::numeric / j.answers - j.base_ratio) * 100, 1) end as acc_gain,
         (case when j.answers >= 20 and j.base_ratio is not null then greatest(0, least(30, round((j.correct::numeric / j.answers - j.base_ratio) * 100)::integer)) else 0 end
          + 5 * least(j.level_ups, 4))::integer as progress_pts,
         case when j.answers >= 10 and j.older_answers = 0 then 'new'
              when j.answers >= 10 and j.older_answers >= 20 and j.gap_answers = 0 then 'comeback' end as tag
  from joined j;
$$;

-- The grade-level board, from the caller's point of view.
create or replace function public.weekly_improvement_board(p_student_id uuid, p_weeks_ago integer default 0, p_limit integer default 10)
returns table(kind text, student_id uuid, full_name text, section_name text, answers integer, accuracy numeric, base_accuracy numeric,
              acc_gain numeric, level_ups integer, days_active integer, progress_pts integer, tag text, is_me boolean)
language plpgsql stable security definer set search_path = public as $$
declare v_grade text; v_ids uuid[];
begin
  select se.grade_level into v_grade from students st join sections se on se.id = st.section_id where st.id = p_student_id;
  if v_grade is null then return; end if;
  select array_agg(st.id) into v_ids
    from students st join sections se on se.id = st.section_id
    left join student_preferences sp on sp.student_id = st.id
    where se.grade_level = v_grade and (coalesce(sp.show_on_leaderboard, true) or st.id = p_student_id);
  if v_ids is null then return; end if;

  return query
  with p as (select * from public._weekly_progress(v_ids, p_weeks_ago)),
  named as (select p.*, st.full_name as nm, se.section_name as sn from p join students st on st.id = p.student_id join sections se on se.id = st.section_id),
  ranked as (
    select 'ranked'::text as k, n.* from named n where n.progress_pts > 0
    order by n.progress_pts desc, n.days_active desc, n.answers desc, n.nm limit greatest(1, p_limit)
  ),
  welcome as (
    select 'welcome'::text as k, n.* from named n where n.tag is not null and n.progress_pts = 0 and n.student_id <> p_student_id order by n.answers desc, n.nm limit 12
  )
  select u.k, u.student_id, u.nm, u.sn, u.answers, u.accuracy, u.base_accuracy, (case when u.acc_gain is null then null else greatest(0, u.acc_gain) end), u.level_ups, u.days_active, u.progress_pts, u.tag, (u.student_id = p_student_id)
  from (select * from ranked union all select * from welcome) u;
end;
$$;

-- "My Week": the student's own numbers, framed only as growth. Also returns
-- where they stand on the board (null if hidden or no progress yet).
create or replace function public.my_week_progress(p_student_id uuid, p_weeks_ago integer default 0)
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  me record; prev record; v_ws timestamptz; v_we timestamptz; v_grade text; v_ids uuid[]; v_rank integer; v_total integer;
  v_best jsonb; v_stations integer; v_visible boolean;
begin
  if not exists (select 1 from students where id = p_student_id) then return jsonb_build_object('error', 'student_not_found'); end if;
  select ws, we into v_ws, v_we from public._manila_week_bounds(p_weeks_ago);
  select * into me from public._weekly_progress(array[p_student_id], p_weeks_ago);
  select * into prev from public._weekly_progress(array[p_student_id], p_weeks_ago + 1);

  select coalesce(sp.show_on_leaderboard, true) into v_visible from students st left join student_preferences sp on sp.student_id = st.id where st.id = p_student_id;
  select se.grade_level into v_grade from students st join sections se on se.id = st.section_id where st.id = p_student_id;
  select array_agg(st.id) into v_ids from students st join sections se on se.id = st.section_id left join student_preferences sp on sp.student_id = st.id
    where se.grade_level = v_grade and (coalesce(sp.show_on_leaderboard, true) or st.id = p_student_id);
  select count(*) filter (where pr.progress_pts > 0),
         1 + count(*) filter (where pr.progress_pts > me.progress_pts)
    into v_total, v_rank from public._weekly_progress(v_ids, p_weeks_ago) pr;

  select jsonb_build_object('topic', t.topic, 'accuracy', t.acc, 'answers', t.answers) into v_best from (
    select da.topic, sum(da.total_questions)::integer as answers, round(sum(da.correct_count)::numeric / nullif(sum(da.total_questions), 0) * 100, 1) as acc
    from drill_attempts da where da.student_id = p_student_id and da.played_at >= v_ws and da.played_at < v_we
    group by da.topic having sum(da.total_questions) >= 10 order by acc desc, answers desc limit 1) t;
  select count(distinct da.topic) into v_stations from drill_attempts da where da.student_id = p_student_id and da.played_at >= v_ws and da.played_at < v_we;

  return jsonb_build_object(
    'week_start', (v_ws at time zone 'Asia/Manila')::date, 'week_end', ((v_we at time zone 'Asia/Manila')::date - 1),
    'answers', me.answers, 'correct', me.correct, 'accuracy', me.accuracy, 'days_active', me.days_active, 'level_ups', me.level_ups,
    'points_earned', me.points_earned, 'stations_tried', coalesce(v_stations, 0),
    'base_accuracy', me.base_accuracy, 'base_kind', me.base_kind, 'acc_gain', (case when me.acc_gain is null then null else greatest(0, me.acc_gain) end), 'progress_pts', me.progress_pts, 'tag', me.tag,
    'prev_answers', prev.answers, 'prev_days_active', prev.days_active,
    'best_station', v_best,
    'rank', case when v_visible and me.progress_pts > 0 then v_rank end, 'ranked_total', v_total, 'visible', v_visible
  );
end;
$$;

-- Teacher view: everyone in the section (ignores the students' leaderboard opt-out — it's their teacher).
create or replace function public.section_weekly_progress(p_section_id uuid, p_weeks_ago integer default 0)
returns table(student_id uuid, full_name text, answers integer, accuracy numeric, base_accuracy numeric, acc_gain numeric, level_ups integer,
              days_active integer, points_earned integer, progress_pts integer, tag text, base_kind text)
language plpgsql stable security definer set search_path = public as $$
declare v_ids uuid[];
begin
  if not (public.is_teacher_of_section(p_section_id) or public.is_admin()) then return; end if;
  select array_agg(id) into v_ids from students where section_id = p_section_id;
  if v_ids is null then return; end if;
  return query
    select p.student_id, st.full_name, p.answers, p.accuracy, p.base_accuracy, p.acc_gain, p.level_ups, p.days_active, p.points_earned, p.progress_pts, p.tag, p.base_kind
    from public._weekly_progress(v_ids, p_weeks_ago) p join students st on st.id = p.student_id order by st.full_name;
end;
$$;

grant execute on function public.weekly_improvement_board(uuid, integer, integer) to anon, authenticated;
grant execute on function public.my_week_progress(uuid, integer) to anon, authenticated;
grant execute on function public.section_weekly_progress(uuid, integer) to authenticated;
revoke execute on function public._weekly_progress(uuid[], integer) from public, anon, authenticated;
