// ============================================================================
// MathConnect — MathLegends Rank System
// A Mobile Legends–inspired 15-tier ladder (Warrior → "Eureka") where each
// tier is named after a real mathematician, always paired with its Mobile
// Legends band name so students can map it 1:1 to the ranks they already
// know from the game.
//
// This is a NEW layer on top of the existing per-station drill levels
// (topic_levels, 1-10 per topic — untouched, still drives question
// difficulty). The overall MathLegends rank is driven by STARS, earned from
// three sources: Math Drills, the Daily Challenge, and Math Boss Battles.
// Stars are stored in drill_progress.mastery_tier / drill_progress.mastery_stars
// (see migration-20-mathlegends-ranks.sql).
//
// Loaded by: student.html, teacher.html, admin.html — BEFORE drills.js,
// dailyChallenge.js, raidEngine.js, teacher-drills.js, admin.js, since
// those all call the helpers below. No shared bundler in this project, so
// this file is the single source of truth for rank data — don't duplicate
// the tier list elsewhere.
// ============================================================================

const RANK_MAX_TIER = 15;

// Stars needed to be promoted OUT of a given tier (index = tier level).
// Tier 15 (Eureka) has no "next" tier — stars still accumulate as bragging
// rights but nothing more is required.
const RANK_STARS_TO_PROMOTE = {
  1: 3, 2: 3, 3: 3, 4: 3,          // Warrior → Grandmaster: 3 stars/tier
  5: 4, 6: 4, 7: 4, 8: 4,          // Epic → Legend: 4 stars/tier
  9: 5, 10: 5, 11: 5, 12: 5, 13: 5, 14: 5, // Mythic and up: 5 stars/tier
};
// Below this tier, a Boss Battle loss can never demote a student — keeps
// drills/daily/battles encouraging for the vast majority of the ladder.
// Mirrors Mobile Legends: stakes (and star loss) only start at Mythic.
const RANK_DEMOTION_FLOOR_TIER = 9;

const RANK_TIERS = [
  { level: 1, band: "Warrior", math: "Pythagoras", emoji: "🔺", color: "#9AA5B1" },
  { level: 2, band: "Elite", math: "Euclid", emoji: "📐", color: "#8D9A6E" },
  { level: 3, band: "Master", math: "Al-Khwarizmi", emoji: "🧮", color: "#C08552" },
  { level: 4, band: "Grandmaster", math: "Fibonacci", emoji: "🐚", color: "#B87B3E" },
  { level: 5, band: "Epic I", math: "Descartes", emoji: "🌀", color: "#3AA0C9" },
  { level: 6, band: "Epic II", math: "Pascal", emoji: "🎲", color: "#2E8FBF" },
  { level: 7, band: "Legend I", math: "Newton", emoji: "🍎", color: "#5B6FD8" },
  { level: 8, band: "Legend II", math: "Leibniz", emoji: "➗", color: "#4A5BC0" },
  { level: 9, band: "Mythic I", math: "Euler", emoji: "∑", color: "#8A5DC8" },
  { level: 10, band: "Mythic II", math: "Gauss", emoji: "🔔", color: "#9A5DD8" },
  { level: 11, band: "Mythic III", math: "Riemann", emoji: "🌐", color: "#A55DE0" },
  { level: 12, band: "Mythical Honor", math: "Cantor", emoji: "♾️", color: "#D4AF37" },
  { level: 13, band: "Mythical Glory", math: "Noether", emoji: "🔷", color: "#E0BC3D" },
  { level: 14, band: "Mythical Immortal", math: "Ramanujan", emoji: "🕉️", color: "#E0533D" },
  { level: 15, band: "Eureka", math: "Archimedes", emoji: "👑✨", color: "#F4C95D" },
];
RANK_TIERS.forEach((t) => {
  t.name = `${t.math} (${t.band})`;
  t.short = t.math;
});

// ---------------------------------------------------------------------------
// EUREKA GEM SUB-TIERS — once a student hits tier 15 (Archimedes/Eureka),
// stars keep flowing in from the same sources but now climb a gem ladder
// instead of a numbered tier. Cumulative cost stretches out the higher it
// climbs (same "harder near the top" feel as the Mythic bracket, taken
// further). No demotion — matches Eureka's existing permanence rule.
// Mirrors the thresholds hardcoded into migration-24's championship_score()
// SQL function — if these ever change, update both places.
// ---------------------------------------------------------------------------
const RANK_EUREKA_GEMS = [
  { name: "Bronze", threshold: 0, color: "#B08D57" },
  { name: "Silver", threshold: 5, color: "#B9C0C9" },
  { name: "Gold", threshold: 10, color: "#E0BC3D" },
  { name: "Platinum", threshold: 15, color: "#8FD0D8" },
  { name: "Diamond", threshold: 25, color: "#6EC7F0" },
  { name: "Emerald", threshold: 35, color: "#3FBF7F" },
  { name: "Sapphire", threshold: 50, color: "#3A6FD8" },
  { name: "Ruby", threshold: 70, color: "#D8384F" },
  { name: "Amethyst", threshold: 95, color: "#9B5DE0" },
  { name: "Obsidian", threshold: 125, color: "#2B2B33" },
];
const RANK_EUREKA_GEM_STEP = 30; // stars per level once past Obsidian (uncapped climb)

// Returns { name, color, index, romanSuffix, stars, next, starsToNext }
// romanSuffix is "" for the base Obsidian, "II"/"III"/... beyond it.
function eurekaGemForStars(stars) {
  stars = Math.max(0, stars || 0);
  let idx = 0;
  for (let i = RANK_EUREKA_GEMS.length - 1; i >= 0; i--) {
    if (stars >= RANK_EUREKA_GEMS[i].threshold) { idx = i; break; }
  }
  const base = RANK_EUREKA_GEMS[idx];
  const isObsidian = idx === RANK_EUREKA_GEMS.length - 1;
  let romanSuffix = "";
  let starsIntoObsidian = 0;
  let nextThreshold = idx + 1 < RANK_EUREKA_GEMS.length ? RANK_EUREKA_GEMS[idx + 1].threshold : null;

  if (isObsidian) {
    starsIntoObsidian = stars - base.threshold;
    const level = Math.floor(starsIntoObsidian / RANK_EUREKA_GEM_STEP); // 0 = plain Obsidian, 1 = Obsidian II...
    if (level > 0) romanSuffix = " " + toRoman(level + 1);
    nextThreshold = base.threshold + (level + 1) * RANK_EUREKA_GEM_STEP;
  }

  return {
    name: base.name + romanSuffix,
    color: base.color,
    stars,
    starsToNext: nextThreshold != null ? Math.max(0, nextThreshold - stars) : null,
    nextThreshold,
  };
}

function toRoman(n) {
  const map = [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]];
  let out = "";
  for (const [val, sym] of map) { while (n >= val) { out += sym; n -= val; } }
  return out || "I";
}

function renderEurekaGemBadge(postEurekaStars, opts) {
  opts = opts || {};
  const gem = eurekaGemForStars(postEurekaStars);
  const size = opts.size || "normal";
  const pad = size === "small" ? "3px 9px" : "5px 14px";
  const font = size === "small" ? ".72rem" : ".85rem";
  const badge = `<span style="display:inline-flex;align-items:center;gap:5px;background:${gem.color}22;color:${gem.color};border:1px solid ${gem.color}77;padding:${pad};border-radius:20px;font-weight:700;font-size:${font};white-space:nowrap;">💎 Eureka — ${escapeHtml(gem.name)}</span>`;
  if (!opts.withProgress) return badge;
  const sub = gem.starsToNext != null
    ? `<span class="muted" style="font-size:.68rem;">${gem.starsToNext} more star${gem.starsToNext === 1 ? "" : "s"} to next gem &nbsp;·&nbsp; ${postEurekaStars} career stars</span>`
    : "";
  return `<div style="display:flex;flex-direction:column;gap:4px;">${badge}${sub ? `<div>${sub}</div>` : ""}</div>`;
}

function rankStarsToPromote(tierLevel) { return RANK_STARS_TO_PROMOTE[tierLevel] || null; }

function rankTierByLevel(level) {
  const lvl = Math.max(1, Math.min(RANK_MAX_TIER, level || 1));
  return RANK_TIERS[lvl - 1];
}

// Applies a star delta (positive from winning/playing, negative from a Boss
// Battle loss at Mythic+) and cascades promotions/demotions across tiers.
function applyStarDelta(tier, stars, delta) {
  tier = Math.max(1, Math.min(RANK_MAX_TIER, tier || 1));
  stars = Math.max(0, stars || 0);
  let promoted = false, demoted = false;

  if (delta > 0) {
    stars += delta;
    while (tier < RANK_MAX_TIER) {
      const need = rankStarsToPromote(tier);
      if (need == null || stars < need) break;
      stars -= need;
      tier += 1;
      promoted = true;
    }
  } else if (delta < 0) {
    // Tier 15 (Eureka) is a permanent achievement — no demotion once reached.
    // Below the Mythic floor, losses simply can't cost a star at all.
    if (tier >= RANK_DEMOTION_FLOOR_TIER && tier < RANK_MAX_TIER) {
      stars += delta; // delta is negative
      while (stars < 0) {
        if (tier <= RANK_DEMOTION_FLOOR_TIER) { stars = 0; break; }
        tier -= 1;
        stars += rankStarsToPromote(tier);
        demoted = true;
      }
    }
  }
  return { tier, stars, promoted, demoted };
}

function rankStarPips(stars, needed, color) {
  if (needed == null) return `<span class="muted" style="font-size:.72rem;">MAX RANK</span>`;
  let out = "";
  for (let i = 0; i < needed; i++) {
    out += `<span style="color:${i < stars ? color : "#D8DDE3"};font-size:.85rem;">★</span>`;
  }
  return out;
}

function renderRankBadge(tier, opts) {
  opts = opts || {};
  const size = opts.size || "normal";
  const pad = size === "small" ? "3px 9px" : "5px 14px";
  const font = size === "small" ? ".72rem" : ".85rem";
  const badge = `<span style="display:inline-flex;align-items:center;gap:5px;background:${tier.color}22;color:${tier.color};border:1px solid ${tier.color}55;padding:${pad};border-radius:20px;font-weight:700;font-size:${font};white-space:nowrap;">${tier.emoji} ${escapeHtml(tier.name)}</span>`;
  if (!opts.withStars) return badge;
  const need = rankStarsToPromote(tier.level);
  return `<div style="display:flex;flex-direction:column;gap:4px;">
    ${badge}
    <div style="display:flex;gap:2px;align-items:center;">${rankStarPips(opts.stars || 0, need, tier.color)}${need != null ? `<span class="muted" style="font-size:.68rem;margin-left:4px;">${opts.stars || 0}/${need} to ${rankTierByLevel(tier.level + 1).math}</span>` : ""}</div>
  </div>`;
}

// ---------------------------------------------------------------------------
// PERSISTENCE — read-modify-write against drill_progress. Self-contained so
// it can be called from drills.js, dailyChallenge.js, or raidEngine.js
// regardless of load order or whether that student has played drills yet.
// ---------------------------------------------------------------------------
function rankDefaultTopicLevels() {
  const o = {}; ["basic", "order", "integers", "fractions", "decimals", "algebra"].forEach((k) => (o[k] = 1)); return o;
}
function rankDefaultTopicPoints() {
  const o = {}; ["basic", "order", "integers", "fractions", "decimals", "algebra"].forEach((k) => (o[k] = 0)); return o;
}

/**
 * awardMasteryStars(studentId, delta) — delta can be positive (drill/daily/
 * battle win) or negative (Boss Battle loss, only bites at Mythic+).
 * Returns { oldTier, newTier, oldStars, newStars, promoted, demoted, tierObj }
 * so the caller can show a "Rank Up!" banner.
 */
async function awardMasteryStars(studentId, delta) {
  let { data } = await supabase.from("drill_progress").select("mastery_tier, mastery_stars, post_eureka_stars").eq("student_id", studentId).maybeSingle();
  if (!data) {
    const fresh = {
      student_id: studentId, total_points: 0, games_played: 0, best_streak: 0,
      topic_levels: rankDefaultTopicLevels(), topic_points: rankDefaultTopicPoints(),
      mastery_tier: 1, mastery_stars: 0,
    };
    const { data: inserted } = await supabase.from("drill_progress").insert(fresh).select("mastery_tier, mastery_stars, post_eureka_stars").maybeSingle();
    data = inserted || { mastery_tier: 1, mastery_stars: 0, post_eureka_stars: 0 };
  }
  const oldTier = data.mastery_tier || 1, oldStars = data.mastery_stars || 0;
  const oldPostEureka = data.post_eureka_stars || 0;
  const result = applyStarDelta(oldTier, oldStars, delta);

  // Once at tier 15 (Eureka), any further positive star gain also banks into
  // the gem ladder (post_eureka_stars) — see RANK_EUREKA_GEMS above. This
  // never goes down, mirroring Eureka's own permanence rule.
  const newPostEureka = (result.tier === RANK_MAX_TIER && delta > 0) ? oldPostEureka + delta : oldPostEureka;

  await supabase.from("drill_progress").update({
    mastery_tier: result.tier, mastery_stars: result.stars, post_eureka_stars: newPostEureka,
    updated_at: new Date().toISOString(),
  }).eq("student_id", studentId);
  return {
    oldTier, newTier: result.tier, oldStars, newStars: result.stars,
    oldPostEureka, newPostEureka,
    promoted: result.promoted, demoted: result.demoted, tierObj: rankTierByLevel(result.tier),
  };
}
