-- ============================================================================
-- MathConnect — migration 45: Class Quest topic targeting
--
-- migration-43's Class Quests only checked HOW MANY points a student earned,
-- not WHICH station they earned them in — so a "1,000 points in Ratio &
-- Proportion" quest would have accepted points from any station. This adds
-- an optional target_topic to a quest: when set, only drill runs on that
-- exact station count toward the goal; when left blank, any station counts
-- (the original behavior, unchanged).
--
-- Run this once in Supabase Dashboard → SQL Editor, AFTER
-- migration-43-motivation-cooperation.sql has already been applied.
-- ============================================================================

ALTER TABLE public.class_quests
  ADD COLUMN IF NOT EXISTS target_topic TEXT; -- one of DRILL_TOPICS' keys (e.g. 'ratio'), or NULL = any station

-- ----------------------------------------------------------------------------
-- contribute_to_class_quest — now topic-aware. p_topic is required so the
-- function can check it against the quest's target_topic; existing callers
-- must be updated to pass it (see drills.js). A quest with no target_topic
-- set still accepts points from any station, exactly as before.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.contribute_to_class_quest(p_student_id UUID, p_points INTEGER, p_topic TEXT DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_section_id UUID;
  v_quest class_quests%ROWTYPE;
  v_was_incomplete BOOLEAN;
BEGIN
  IF p_points IS NULL OR p_points <= 0 THEN
    RETURN jsonb_build_object('ok', FALSE, 'reason', 'no_points');
  END IF;

  SELECT section_id INTO v_section_id FROM students WHERE id = p_student_id;
  IF v_section_id IS NULL THEN RETURN jsonb_build_object('ok', FALSE, 'reason', 'student_not_found'); END IF;

  SELECT * INTO v_quest FROM class_quests
    WHERE section_id = v_section_id AND is_active = TRUE
    ORDER BY created_at DESC LIMIT 1;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', FALSE, 'reason', 'no_active_quest'); END IF;

  -- The whole point of this migration: reject contributions from the wrong
  -- station when the quest targets a specific one.
  IF v_quest.target_topic IS NOT NULL AND v_quest.target_topic <> p_topic THEN
    RETURN jsonb_build_object('ok', FALSE, 'reason', 'wrong_topic', 'required_topic', v_quest.target_topic);
  END IF;

  v_was_incomplete := v_quest.completed_at IS NULL;

  UPDATE class_quests SET
    current_points = current_points + p_points,
    completed_at = CASE WHEN v_was_incomplete AND (current_points + p_points) >= goal_points THEN NOW() ELSE completed_at END,
    updated_at = NOW()
  WHERE id = v_quest.id
  RETURNING * INTO v_quest;

  INSERT INTO class_quest_contributions (quest_id, student_id, points_contributed)
  VALUES (v_quest.id, p_student_id, p_points);

  RETURN jsonb_build_object(
    'ok', TRUE,
    'quest', jsonb_build_object('id', v_quest.id, 'title', v_quest.title, 'reward_text', v_quest.reward_text,
      'goal_points', v_quest.goal_points, 'current_points', v_quest.current_points, 'target_topic', v_quest.target_topic),
    'just_completed', v_was_incomplete AND v_quest.completed_at IS NOT NULL
  );
END;
$$;
GRANT EXECUTE ON FUNCTION public.contribute_to_class_quest(UUID, INTEGER, TEXT) TO anon, authenticated;

-- get_active_class_quest / get_class_quest_contributors need NO changes —
-- to_jsonb(q) already includes the new target_topic column automatically.

-- ============================================================================
-- Done. Sanity check:
-- select target_topic from class_quests limit 1;
-- select contribute_to_class_quest('<student-uuid>', 10, 'ratio');
-- ============================================================================
