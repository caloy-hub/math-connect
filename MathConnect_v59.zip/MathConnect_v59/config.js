// ============================================================================
// MathConnect — Supabase Configuration
// ----------------------------------------------------------------------------
// 1. Go to your Supabase project → Settings → API
// 2. Copy the "Project URL" and the "anon public" key
// 3. Paste them below
// 4. Save this file, then redeploy (drag the folder into Netlify again)
// ============================================================================

var SUPABASE_URL = "https://zgauluwtslknnhyzhypn.supabase.co";
var SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpnYXVsdXd0c2xrbm5oeXpoeXBuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI5NDE5ODcsImV4cCI6MjA5ODUxNzk4N30.8DYaa9Kq-dGUO8taudny4IFCoHF95XBIxmF6ymkhu5k";

var APP_NAME = "MathConnect";
var SCHOOL_NAME = "Maria Cristina P. Belcar Agricultural High School";
