-- ============================================================================
-- Migration 17 — Power-Up Shop
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this if supabase-schema.sql was
-- already updated to include it.
--
-- IMPORTANT — this is NOT Firestore. MathConnect is a Supabase (Postgres)
-- app: students authenticate with a login code (not Supabase Auth) and all
-- reads/writes go through the anon Supabase client, same as every other
-- table in this project. So:
--   - There is no `users/{userId}` doc — the per-student "wallet" already
--     exists as `student_engagement` (added in migration-16). This
--     migration adds an `inventory` column to that same row instead of
--     creating a second, disconnected currency store.
--   - There is no Cloud Functions runtime. The equivalent primitive here is
--     a Postgres function marked `security definer`, called from the
--     client via `supabase.rpc(...)`. That's what `purchase_shop_item`
--     below is: it runs with elevated privilege, so it's the one place
--     that's allowed to actually move coins for a purchase, and it does
--     the price lookup + balance check + row lock atomically so a student
--     can't double-click their way into a negative balance or buy
--     something at a stale price.
--
-- What this adds:
--   1. shop_items — the catalog (5 power-ups). A real table (not just
--      constants in JS) so a teacher/admin could retune prices later
--      without a redeploy, and so the RPC has a single source of truth for
--      cost that the client can't override.
--   2. student_engagement.inventory — jsonb, item_id -> owned count.
--   3. purchase_shop_item(student_id, item_id) — the atomic "buy" RPC.
--   4. shop_purchases — append-only purchase log (parallels drill_attempts /
--      daily_challenge_completions — a history + anti-cheat trail).
-- ============================================================================

create table if not exists shop_items (
  id text primary key,                 -- e.g. 'double_xp'
  name text not null,
  description text not null,
  cost integer not null,
  effect_type text not null,           -- 'buff_timed' | 'consumable'
  effect_duration_seconds integer,     -- for timed buffs (Double XP); null for consumables
  active boolean not null default true, -- lets a teacher/admin retire an item without deleting purchase history
  sort_order integer not null default 0
);

insert into shop_items (id, name, description, cost, effect_type, effect_duration_seconds, sort_order) values
  ('double_xp',      'Double XP',      'Doubles skill/mastery points earned for 10 minutes.',                      15, 'buff_timed',  600,  1),
  ('confetti_burst', 'Confetti Burst', 'A fun celebration animation on your screen. Purely for fun!',              10, 'consumable',  null, 2),
  ('time_freeze',    'Time Freeze',    'Pauses the Math Drills timer for 5 seconds.',                              20, 'consumable',  null, 3),
  ('shield',         'Shield',         'Blocks 1 wrong answer in a battle. (Reserved for a future battle mode.)',  25, 'consumable',  null, 4),
  ('profile_title',  'Profile Title',  'Unlocks a new flair title to show off next to your name.',                30, 'collectible', null, 5)
on conflict (id) do update set
  name = excluded.name, description = excluded.description, cost = excluded.cost,
  effect_type = excluded.effect_type, effect_duration_seconds = excluded.effect_duration_seconds,
  sort_order = excluded.sort_order, active = true;

-- Hint Bomb and Lucky Guess were retired (risk: they could distort mastery
-- data — a generic hint / a 50%-guessable multiple choice pick could both
-- get logged as "the student knows this," which isn't reliable). Soft-
-- deprecate rather than delete so any purchases already made against them
-- keep a valid shop_items foreign key; `active = false` hides them from
-- loadShopItems()'s `.eq('active', true)` query, so they simply stop
-- appearing in the shop.
update shop_items set active = false where id in ('hint_bomb', 'lucky_guess');

alter table shop_items enable row level security;
drop policy if exists "public read shop_items" on shop_items;
create policy "public read shop_items" on shop_items for select using (true);

-- ---------- Extend the existing per-student wallet with an inventory ----------
-- (double_xp_expires_at is separate from the existing active_powerup/
-- powerup_expires_at pair used by the 7-day streak reward, so activating a
-- purchased Double XP doesn't clobber an in-progress streak power-up.)
alter table student_engagement add column if not exists inventory jsonb not null default '{}'::jsonb;
alter table student_engagement add column if not exists double_xp_expires_at timestamptz;
-- Purely cosmetic display field for the Profile Title item — a free-text
-- label shown next to the student's name. Client-writable (like the rest
-- of student_engagement) since it has zero bearing on coins, scores, or
-- mastery data; there's nothing to protect here.
alter table student_engagement add column if not exists active_title text;

-- ---------- Purchase log (append-only) ----------
create table if not exists shop_purchases (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  item_id text references shop_items(id),
  cost_paid integer not null,
  purchased_at timestamptz default now()
);
create index if not exists shop_purchases_student_idx on shop_purchases (student_id);

alter table shop_purchases enable row level security;
drop policy if exists "public read shop_purchases" on shop_purchases;
create policy "public read shop_purchases" on shop_purchases for select using (true);
drop policy if exists "teacher delete shop_purchases" on shop_purchases;
create policy "teacher delete shop_purchases" on shop_purchases for delete using (
  is_teacher_of_student(student_id) or is_admin()
);
-- Note: no "anyone insert" policy here on purpose — purchases are only ever
-- written by purchase_shop_item() below, which runs as security definer and
-- so bypasses RLS. This keeps the purchase log itself un-forgeable even
-- though (consistent with the rest of this app's security model) the
-- `coins` and `inventory` columns on student_engagement remain client-
-- writable for reads/other features. See the note at the bottom of this
-- file about that tradeoff.

-- ----------------------------------------------------------------------------
-- purchase_shop_item — the "Cloud Function" equivalent: validates and
-- processes a purchase atomically.
--   1. Row-locks the student's engagement row (`for update`) so two rapid
--      taps can't both read the same balance and both succeed.
--   2. Looks up price from shop_items — the server-side price, never
--      whatever the client sends — so a tampered client can't buy at $0.
--   3. Checks the student can afford it; rejects with a clear error if not.
--   4. Deducts coins, increments inventory[item_id], logs the purchase, and
--      returns the new balance + inventory in one round trip.
-- ----------------------------------------------------------------------------
create or replace function public.purchase_shop_item(target_student_id uuid, target_item_id text)
returns table(success boolean, message text, new_coins integer, new_inventory jsonb)
language plpgsql security definer as $$
declare
  item_cost integer;
  item_active boolean;
  current_coins integer;
  current_inventory jsonb;
  owned_count integer;
begin
  select cost, active into item_cost, item_active from shop_items where id = target_item_id;
  if item_cost is null then
    return query select false, 'That item does not exist.', null::integer, null::jsonb;
    return;
  end if;
  if not item_active then
    return query select false, 'That item is no longer available.', null::integer, null::jsonb;
    return;
  end if;

  -- Lock the row for the duration of this transaction.
  select coins, coalesce(inventory, '{}'::jsonb) into current_coins, current_inventory
  from student_engagement where student_id = target_student_id for update;

  if current_coins is null then
    -- No engagement row yet (brand-new student) — create one so the purchase can proceed from a 0 balance.
    insert into student_engagement (student_id, coins, inventory) values (target_student_id, 0, '{}'::jsonb)
    on conflict (student_id) do nothing;
    current_coins := 0;
    current_inventory := '{}'::jsonb;
  end if;

  if current_coins < item_cost then
    return query select false, format('Not enough coins — need %s, have %s.', item_cost, current_coins), current_coins, current_inventory;
    return;
  end if;

  owned_count := coalesce((current_inventory ->> target_item_id)::integer, 0);
  current_inventory := jsonb_set(current_inventory, array[target_item_id], to_jsonb(owned_count + 1));
  current_coins := current_coins - item_cost;

  update student_engagement
    set coins = current_coins, inventory = current_inventory, updated_at = now()
    where student_id = target_student_id;

  insert into shop_purchases (student_id, item_id, cost_paid) values (target_student_id, target_item_id, item_cost);

  return query select true, 'Purchased!', current_coins, current_inventory;
end;
$$;
grant execute on function public.purchase_shop_item(uuid, text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- consume_shop_item — spends 1 owned unit of a consumable (e.g. activating a
-- Hint Bomb). Separate from purchase so "own 3, use 1" is tracked correctly.
-- Also security definer + row-locked for the same double-tap reason above.
-- ----------------------------------------------------------------------------
create or replace function public.consume_shop_item(target_student_id uuid, target_item_id text)
returns table(success boolean, message text, new_inventory jsonb, new_double_xp_expires_at timestamptz)
language plpgsql security definer as $$
declare
  current_inventory jsonb;
  owned_count integer;
  duration_secs integer;
  new_expiry timestamptz;
begin
  select coalesce(inventory, '{}'::jsonb) into current_inventory
  from student_engagement where student_id = target_student_id for update;

  if current_inventory is null then
    return query select false, 'Nothing owned yet.', '{}'::jsonb, null::timestamptz;
    return;
  end if;

  owned_count := coalesce((current_inventory ->> target_item_id)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that item.', current_inventory, null::timestamptz;
    return;
  end if;

  current_inventory := jsonb_set(current_inventory, array[target_item_id], to_jsonb(owned_count - 1));

  if target_item_id = 'double_xp' then
    select effect_duration_seconds into duration_secs from shop_items where id = 'double_xp';
    new_expiry := now() + make_interval(secs => coalesce(duration_secs, 600));
    update student_engagement set inventory = current_inventory, double_xp_expires_at = new_expiry, updated_at = now()
      where student_id = target_student_id;
  else
    update student_engagement set inventory = current_inventory, updated_at = now() where student_id = target_student_id;
  end if;

  return query select true, 'Activated!', current_inventory, new_expiry;
end;
$$;
grant execute on function public.consume_shop_item(uuid, text) to anon, authenticated;

-- ============================================================================
-- Security note (read this before you trust this system for a real
-- classroom currency):
--
-- This app's existing model lets the anon (student) client write directly
-- to its own rows via "using (true)" RLS policies — total_points,
-- skill_proficiency, coins, etc. are all client-writable today. That means
-- a technically-inclined student COULD open devtools and call
-- `supabase.from('student_engagement').update({coins: 999999})` directly,
-- bypassing the shop entirely — the RPC above only protects the *purchase
-- transaction* (price + balance check + atomicity), not the underlying
-- coins column itself.
--
-- For a low-stakes classroom reward system this is usually an acceptable
-- tradeoff (same trust level as the drill points/leaderboard you already
-- have). If you want coins to be genuinely tamper-proof, the fix is to
-- REVOKE UPDATE on student_engagement.coins / .inventory from anon/
-- authenticated and route ALL coin-earning (not just spending) through
-- security-definer RPCs too (award_coins(student_id, amount, reason) etc.),
-- the same pattern used here for purchase_shop_item. That's a larger change
-- touching streakEngine.js/dailyChallenge.js as well, so it's left as a
-- follow-up rather than bundled into this migration.
-- ============================================================================
