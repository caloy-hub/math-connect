-- ============================================================================
-- MathConnect — migration 37: Resource Sharing + All-Rounder Gemstone
-- ============================================================================
-- Two independent features bundled in one migration since they both touch
-- student_engagement and both need new server-side RPCs. Even though this
-- app's RLS on student_engagement is wide open (see migration-16 — "anyone
-- update", a known tradeoff this codebase already accepts for coins/green
-- points), a resource TRANSFER still needs to be one atomic transaction:
-- two separate client-side updates (debit sender, credit receiver) could
-- leave one side applied and not the other on a dropped connection, and
-- without server-side validation a client could send a negative amount or
-- gift more than it has. Both new RPCs below follow the same "spending goes
-- through an RPC" pattern as feed_pet_food / buy_pet_food / adopt_pet.
--
-- 1) RESOURCE SHARING — a student can gift Coins, Green Points, or (if they
--    have a spare one) an Adoption Chance to a classmate they choose.
-- 2) ALL-ROUNDER GEMSTONE — earned once per calendar day the first time a
--    student completes every activity type that day (Drills, Quest,
--    Practice, a Battle, the Daily Challenge, a Rating, and feeding their
--    pet). Spent on a pet for temporary hunger/sickness immunity — stacks
--    up to 3 uses/pet/day — plus a standing +30% Green Points multiplier
--    account-wide while any pet's immunity is active.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- WALLET COLUMNS
-- ---------------------------------------------------------------------------
alter table student_engagement add column if not exists gemstones integer not null default 0;
-- Net adoption-chance adjustment from gifts: +1 per chance received, -1 per
-- chance given away. A student's lifetime adoption cap is (3 + this value).
alter table student_engagement add column if not exists adoption_chance_adjustment integer not null default 0;

-- ---------------------------------------------------------------------------
-- RESOURCE SHARES — append-only audit log of every gift sent, so both the
-- students involved and the teacher (export) have a record of who shared
-- what with whom and when.
-- ---------------------------------------------------------------------------
create table if not exists resource_shares (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references sections(id) on delete cascade,
  sender_student_id uuid references students(id) on delete cascade,
  receiver_student_id uuid references students(id) on delete cascade,
  resource_type text not null check (resource_type in ('coins', 'green_points', 'adoption_chance')),
  amount integer not null check (amount > 0),
  created_at timestamptz default now()
);
create index if not exists resource_shares_section_idx on resource_shares (section_id);
create index if not exists resource_shares_receiver_idx on resource_shares (receiver_student_id);

alter table resource_shares enable row level security;
drop policy if exists "public read resource_shares" on resource_shares;
create policy "public read resource_shares" on resource_shares for select using (true);
-- No insert/update/delete policy: rows are only ever written inside
-- share_resource() below (security definer), never directly by a client.

-- ---------------------------------------------------------------------------
-- SHARE_RESOURCE — moves Coins, Green Points, or one Adoption Chance from
-- one student to another. Locks both wallet rows in a stable (uuid text)
-- order so two students gifting each other at the same instant can't
-- deadlock one another, validates, transfers, and logs — all one transaction.
-- ---------------------------------------------------------------------------
create or replace function public.share_resource(
  p_sender_id uuid, p_receiver_id uuid, p_resource_type text, p_amount integer
)
returns table(success boolean, message text)
language plpgsql security definer as $$
declare
  sender_section uuid; receiver_section uuid;
  first_id uuid; second_id uuid;
  sender_coins integer; sender_gp integer;
  sender_used integer; sender_adj integer; receiver_used integer; receiver_adj integer;
begin
  if p_sender_id = p_receiver_id then
    return query select false, 'You can''t share with yourself!'; return;
  end if;
  if p_resource_type not in ('coins', 'green_points', 'adoption_chance') then
    return query select false, 'Unknown resource type.'; return;
  end if;
  if p_resource_type = 'adoption_chance' then
    -- Retired: this depended on the flat 3-adoption lifetime cap, which
    -- migration-35 replaced with peak-gating (adopt whenever every pet you
    -- own has reached Legendary — no scarce "chances" to run out of or
    -- gift anymore). Left in the resource_type check-constraint/enum for
    -- backward compatibility with any existing resource_shares rows.
    return query select false, 'Adoption Chances aren''t needed anymore — you can adopt a new pet as soon as every pet you have has reached Legendary.'; return;
  else
    if p_amount is null or p_amount <= 0 then
      return query select false, 'Enter an amount greater than zero.'; return;
    end if;
  end if;

  select section_id into sender_section from students where id = p_sender_id;
  select section_id into receiver_section from students where id = p_receiver_id;
  if sender_section is null or receiver_section is null or sender_section <> receiver_section then
    return query select false, 'You can only share with a classmate in your own section.'; return;
  end if;

  if p_sender_id::text < p_receiver_id::text then first_id := p_sender_id; second_id := p_receiver_id;
  else first_id := p_receiver_id; second_id := p_sender_id; end if;
  perform 1 from student_engagement where student_id = first_id for update;
  perform 1 from student_engagement where student_id = second_id for update;

  -- Make sure both wallet rows exist — a brand-new student who hasn't
  -- played anything yet won't have one until loadEngagement() first
  -- upserts it client-side.
  insert into student_engagement (student_id) values (p_sender_id) on conflict (student_id) do nothing;
  insert into student_engagement (student_id) values (p_receiver_id) on conflict (student_id) do nothing;

  if p_resource_type = 'coins' then
    select coins into sender_coins from student_engagement where student_id = p_sender_id;
    if sender_coins < p_amount then
      return query select false, format('Not enough Coins — need %s, have %s.', p_amount, sender_coins); return;
    end if;
    update student_engagement set coins = coins - p_amount, updated_at = now() where student_id = p_sender_id;
    update student_engagement set coins = coins + p_amount, updated_at = now() where student_id = p_receiver_id;

  elsif p_resource_type = 'green_points' then
    select green_points into sender_gp from student_engagement where student_id = p_sender_id;
    if sender_gp < p_amount then
      return query select false, format('Not enough Green Points — need %s, have %s.', p_amount, sender_gp); return;
    end if;
    update student_engagement set green_points = green_points - p_amount, updated_at = now() where student_id = p_sender_id;
    update student_engagement set green_points = green_points + p_amount, updated_at = now() where student_id = p_receiver_id;

  else
    -- adoption_chance already returned above; nothing else falls through here.
    return query select false, 'Unknown resource type.'; return;
  end if;

  insert into resource_shares (section_id, sender_student_id, receiver_student_id, resource_type, amount)
  values (sender_section, p_sender_id, p_receiver_id, p_resource_type, p_amount);

  return query select true, 'Shared!';
end;
$$;
grant execute on function public.share_resource(uuid, uuid, text, integer) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- ADOPT_PET — NOTE: this "create or replace" was a mistake when this
-- migration was first written — it accidentally reintroduced the OLD
-- migration-33 flat-3-adoption-cap logic, silently undoing the migration-35
-- peak-gating rule (a new pet requires every currently-owned pet to have
-- reached Legendary). That regression is fixed here: this now matches
-- migration-35 exactly (peak-gating only, no flat cap). See
-- migration-38-fix-adopt-pet-peak-gating.sql for the corrective patch that
-- must also be run against any database where this file already executed.
-- adoption_chance_adjustment / the "gift a spare Adoption Chance" resource
-- type is retired below (see share_resource) since it depended on the flat
-- cap that no longer exists.
-- ---------------------------------------------------------------------------
create or replace function public.adopt_pet(target_student_id uuid, target_pet_type_key text, target_pet_name text default null)
returns table(success boolean, message text, pet jsonb)
language plpgsql security definer as $$
declare
  type_active boolean;
  used_count integer;
begin
  select active into type_active from pet_types where key = target_pet_type_key;
  if type_active is null then
    return query select false, 'That pet does not exist.', null::jsonb;
    return;
  end if;
  if not type_active then
    return query select false, 'That pet is not available right now.', null::jsonb;
    return;
  end if;

  perform 1 from student_pets where student_id = target_student_id and alive and not is_pet_peak(growth_points) for update;
  if found then
    return query select false, 'You already have a pet that''s still growing — help it reach Legendary before adopting another!', null::jsonb;
    return;
  end if;

  select count(*) into used_count from student_pets where student_id = target_student_id;

  declare v record;
  begin
    insert into student_pets (
      student_id, pet_type_key, pet_name, hunger, growth_points, food_inventory,
      alive, adoption_number
    ) values (
      target_student_id, target_pet_type_key, nullif(trim(target_pet_name), ''), 100, 0, '{}'::jsonb,
      true, used_count + 1
    ) returning * into v;
    return query select true, 'Adopted!', to_jsonb(v);
  end;
end;
$$;
grant execute on function public.adopt_pet(uuid, text, text) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- DAILY ENGAGEMENT CHECKLIST — one row per student per calendar day, one
-- boolean flag per activity type. mark_daily_activity() flips a single flag
-- on (idempotent — replaying the same activity twice in a day doesn't
-- double-count) and, the instant every flag is true for the first time that
-- day, mints one Gemstone.
-- ---------------------------------------------------------------------------
create table if not exists daily_engagement_checklist (
  student_id uuid references students(id) on delete cascade,
  activity_date date not null default current_date,
  did_drills boolean not null default false,
  did_quest boolean not null default false,
  did_practice boolean not null default false,
  did_battle boolean not null default false,
  did_challenge boolean not null default false,
  did_rating boolean not null default false,
  did_feed_pet boolean not null default false,
  gem_awarded boolean not null default false,
  updated_at timestamptz default now(),
  primary key (student_id, activity_date)
);
alter table daily_engagement_checklist enable row level security;
drop policy if exists "public read daily_engagement_checklist" on daily_engagement_checklist;
create policy "public read daily_engagement_checklist" on daily_engagement_checklist for select using (true);
-- No insert/update policy: rows are only ever written inside
-- mark_daily_activity() below.

create or replace function public.mark_daily_activity(target_student_id uuid, activity_key text)
returns table(success boolean, gem_awarded boolean, checklist jsonb)
language plpgsql security definer as $$
declare
  row_data record;
  col text;
begin
  if activity_key not in ('drills', 'quest', 'practice', 'battle', 'challenge', 'rating', 'feed_pet') then
    return query select false, false, null::jsonb;
    return;
  end if;
  col := 'did_' || activity_key;

  insert into daily_engagement_checklist (student_id, activity_date)
  values (target_student_id, current_date)
  on conflict (student_id, activity_date) do nothing;

  execute format(
    'update daily_engagement_checklist set %I = true, updated_at = now() where student_id = $1 and activity_date = current_date', col
  ) using target_student_id;

  select * into row_data from daily_engagement_checklist
    where student_id = target_student_id and activity_date = current_date for update;

  if row_data.did_drills and row_data.did_quest and row_data.did_practice and row_data.did_battle
     and row_data.did_challenge and row_data.did_rating and row_data.did_feed_pet
     and not row_data.gem_awarded then
    update daily_engagement_checklist set gem_awarded = true
      where student_id = target_student_id and activity_date = current_date;
    insert into student_engagement (student_id) values (target_student_id) on conflict (student_id) do nothing;
    update student_engagement set gemstones = gemstones + 1, updated_at = now() where student_id = target_student_id;
    return query select true, true, to_jsonb(row_data);
    return;
  end if;

  return query select true, false, to_jsonb(row_data);
end;
$$;
grant execute on function public.mark_daily_activity(uuid, text) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- GEMSTONE IMMUNITY — student_pets gets a gem_immune_until timestamp (same
-- shape as the existing vitamin_boost_until). Using a Gemstone extends it by
-- +3 days from whichever is later (now, or the current expiry) — that's the
-- "cumulative" stacking — but only up to 3 uses per pet per calendar day
-- (gem_uses_today/gem_uses_date), so a stockpile of Gemstones can't be spent
-- all at once for weeks of immunity in one sitting.
-- ---------------------------------------------------------------------------
alter table student_pets add column if not exists gem_immune_until timestamptz;
alter table student_pets add column if not exists gem_uses_today integer not null default 0;
alter table student_pets add column if not exists gem_uses_date date;

create or replace function public.use_gemstone_on_pet(target_student_id uuid, target_pet_id uuid)
returns table(success boolean, message text, new_gemstones integer, new_immune_until timestamptz)
language plpgsql security definer as $$
declare
  current_gems integer;
  pet record;
  uses_today integer;
  new_until timestamptz;
begin
  select gemstones into current_gems from student_engagement where student_id = target_student_id for update;
  if current_gems is null or current_gems <= 0 then
    return query select false, 'No Gemstones yet — complete every activity in one day to earn one!', coalesce(current_gems, 0), null::timestamptz;
    return;
  end if;

  select * into pet from student_pets where id = target_pet_id and student_id = target_student_id and alive for update;
  if pet is null then
    return query select false, 'Pet not found.', current_gems, null::timestamptz;
    return;
  end if;

  uses_today := case when pet.gem_uses_date = current_date then pet.gem_uses_today else 0 end;
  if uses_today >= 3 then
    return query select false, 'This pet has already used its 3 Gemstones for today — try again tomorrow!', current_gems, pet.gem_immune_until;
    return;
  end if;

  new_until := greatest(now(), coalesce(pet.gem_immune_until, now())) + interval '3 days';

  update student_pets
    set gem_immune_until = new_until, gem_uses_today = uses_today + 1, gem_uses_date = current_date, updated_at = now()
    where id = target_pet_id;
  update student_engagement set gemstones = gemstones - 1, updated_at = now() where student_id = target_student_id;

  return query select true, 'Gemstone used! Your pet is protected.', current_gems - 1, new_until;
end;
$$;
grant execute on function public.use_gemstone_on_pet(uuid, uuid) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- CHECK_PET_WELLBEING — adds a gem-immunity short-circuit right after the
-- existing peak-pet short-circuit. Otherwise identical to migration-35.
-- ---------------------------------------------------------------------------
drop function if exists public.check_pet_wellbeing(uuid);
create or replace function public.check_pet_wellbeing(target_student_id uuid)
returns table(pet_id uuid, success boolean, alive boolean, sick boolean, live_hunger integer, died boolean, cause_of_death text, is_peak boolean)
language plpgsql security definer as $$
declare
  pet record;
  hours_since numeric;
  decay_rate numeric := 100.0 / 36.0; -- full drain in 36h, baseline
  discount numeric;
  live_hunger_val integer;
  item_decay integer;
begin
  for pet in select sp.* from student_pets sp where sp.student_id = target_student_id and sp.alive for update loop

    if is_pet_peak(pet.growth_points) then
      -- Peak pets are immune: no decay, no sickness, no death.
      return query select pet.id, true, true, false, pet.hunger, false, null::text, true;
      continue;
    end if;

    if pet.gem_immune_until is not null and pet.gem_immune_until > now() then
      -- Gemstone immunity: same full pass as a peak pet, just temporary —
      -- no decay, no sickness, no death while it's active.
      return query select pet.id, true, true, false, pet.hunger, false, null::text, false;
      continue;
    end if;

    discount := 0;
    hours_since := greatest(0, extract(epoch from (now() - coalesce(pet.last_fed_at, pet.adopted_at, now()))) / 3600.0);

    if pet.vitamin_boost_until is not null and pet.vitamin_boost_until > now() then
      discount := greatest(discount, 0.5);
    end if;
    if pet.equipped_item is not null then
      select decay_reduction_pct into item_decay from pet_care_items where key = pet.equipped_item and category = 'equipment';
      if item_decay is not null then discount := least(0.9, discount + item_decay / 100.0); end if;
    end if;

    live_hunger_val := greatest(0, least(100, round(pet.hunger - (hours_since * decay_rate * (1 - discount)))));

    if live_hunger_val <= 0 and not pet.sick and (pet.vaccinated_until is null or pet.vaccinated_until < now()) then
      update student_pets set sick = true, sick_since = now(), updated_at = now() where id = pet.id;
      pet.sick := true; pet.sick_since := now();
    end if;

    if pet.sick and pet.sick_since is not null and (now() - pet.sick_since) > interval '36 hours'
       and (pet.vaccinated_until is null or pet.vaccinated_until < pet.sick_since) then
      update student_pets set alive = false, died_at = now(), cause_of_death = 'untreated_illness', updated_at = now() where id = pet.id;
      return query select pet.id, true, false, true, live_hunger_val, true, 'untreated_illness', false;
      continue;
    end if;

    if live_hunger_val <= 0 and hours_since > 108 then
      update student_pets set alive = false, died_at = now(), cause_of_death = 'starvation', updated_at = now() where id = pet.id;
      return query select pet.id, true, false, pet.sick, live_hunger_val, true, 'starvation', false;
      continue;
    end if;

    return query select pet.id, true, true, pet.sick, live_hunger_val, false, null::text, false;
  end loop;
  return;
end;
$$;
grant execute on function public.check_pet_wellbeing(uuid) to anon, authenticated;
