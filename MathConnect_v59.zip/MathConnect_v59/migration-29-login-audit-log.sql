-- ============================================================================
-- MathConnect — Migration 29: Login audit log for the admin panel
-- ----------------------------------------------------------------------------
-- Adds a school-wide login audit trail — every successful sign-in (admin,
-- teacher, or student) writes one row here with WHO, WHAT ROLE, and WHEN.
-- The admin panel visualizes it as a role-breakdown pie chart + a daily
-- login trend line, plus a plain recent-activity list.
--
-- Design notes:
--   - user_id is intentionally NOT a foreign key. It can point into
--     teachers, students, or admins depending on user_role, and rows must
--     survive an account being deleted later (teachers/students/deleteAccount
--     in admin.js hard-deletes accounts) — an audit trail that vanishes the
--     moment the account it's about is removed defeats the point.
--   - full_name is a SNAPSHOT taken at login time, for the same reason: if
--     an account is later renamed or deleted, the historical log entry
--     still reads correctly.
--   - Rows can only be created through record_login_event() (a SECURITY
--     DEFINER function, same pattern as record_student_login in the base
--     schema) — there is deliberately no insert policy on the table itself,
--     so a client can't forge arbitrary audit rows directly.
--   - Only admins can read this table.
--
-- Safe to run on your existing database — nothing is deleted.
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

create table if not exists login_audit_log (
  id uuid primary key default gen_random_uuid(),
  user_role text not null check (user_role in ('admin', 'teacher', 'student')),
  user_id uuid,                 -- not a FK on purpose — see notes above
  full_name text not null,      -- snapshot at login time
  logged_in_at timestamptz not null default now()
);
create index if not exists login_audit_log_logged_in_at_idx on login_audit_log (logged_in_at desc);
create index if not exists login_audit_log_role_idx on login_audit_log (user_role);

alter table login_audit_log enable row level security;

-- Only admins can read the log. No insert/update/delete policy is defined
-- for anon/authenticated on purpose — the only way in is the function below.
drop policy if exists "admin read login_audit_log" on login_audit_log;
create policy "admin read login_audit_log" on login_audit_log for select using (is_admin());

create or replace function public.record_login_event(p_role text, p_user_id uuid, p_full_name text)
returns void language plpgsql security definer as $$
begin
  if p_role not in ('admin', 'teacher', 'student') then
    raise exception 'invalid role for login audit: %', p_role;
  end if;
  insert into login_audit_log (user_role, user_id, full_name)
  values (p_role, p_user_id, p_full_name);
end;
$$;
grant execute on function public.record_login_event(text, uuid, text) to anon, authenticated;

-- ============================================================================
-- Done. Reload the admin panel — a new "📋 Login Audit Log" card shows a
-- role-breakdown pie chart, a daily login trend line, and a recent-activity
-- list, all filterable by Today / Last 7 days / Last 30 days / All time.
-- Existing logins before this migration are NOT retroactively logged — the
-- trail starts from the first sign-in after you run this.
-- ============================================================================
