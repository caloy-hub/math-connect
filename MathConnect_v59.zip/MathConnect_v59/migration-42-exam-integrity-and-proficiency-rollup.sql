-- ============================================================================
-- MathConnect — migration 42
-- Part A: Exam integrity deterrents (fullscreen lock, tab/blur/copy violation
--         tracking, configurable auto-submit threshold, teacher-visible log)
-- Part B: Class Record — "Proficiency Level" rollup combined across ALL
--         sections that share the same grade level + subject (cross-teacher
--         aggregate, counts only — no other section's raw student data is
--         ever exposed to the client)
--
-- Run this once in Supabase Dashboard → SQL Editor, AFTER exam_schema.sql,
-- migration-28-exam-bulk-and-shuffle.sql, and supabase-schema.sql have
-- already been applied. (start_exam_attempt / submit_exam_attempt below are
-- rebuilt on top of migration-28's shuffle-aware versions — running this
-- without migration-28 already in place will error on missing helper
-- functions like _exam_shuffled_options.)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- PART A.1 — new columns on exams / exam_attempts
-- ----------------------------------------------------------------------------

ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS require_fullscreen BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS max_violations INTEGER NOT NULL DEFAULT 3; -- 0 = log only, never auto-submit

ALTER TABLE public.exam_attempts
  ADD COLUMN IF NOT EXISTS auto_submit_reason TEXT; -- 'time_expired' | 'violations' | NULL (manual submit)

-- ----------------------------------------------------------------------------
-- PART A.2 — exam_violations (the integrity log)
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.exam_violations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID NOT NULL REFERENCES exam_attempts(id) ON DELETE CASCADE,
  exam_id UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,

  violation_type TEXT NOT NULL, -- 'tab_switch' | 'fullscreen_exit' | 'copy_attempt' | 'devtools_attempt'
  detail TEXT,

  occurred_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_exam_violations_attempt ON exam_violations(attempt_id);
CREATE INDEX IF NOT EXISTS idx_exam_violations_exam ON exam_violations(exam_id);

ALTER TABLE exam_violations ENABLE ROW LEVEL SECURITY;

-- Only the owning teacher can read violations for their own exam — students
-- never get a direct SELECT policy (their live count comes back through the
-- RPCs below instead, same pattern as exam_attempts/exam_responses).
DROP POLICY IF EXISTS exam_violations_teacher_select ON exam_violations;
CREATE POLICY exam_violations_teacher_select ON exam_violations
  FOR SELECT USING (EXISTS (SELECT 1 FROM exams e WHERE e.id = exam_violations.exam_id AND e.teacher_id = auth.uid()));

-- No public/anon INSERT policy either — all writes go through
-- log_exam_violation() below, which is SECURITY DEFINER.

-- ----------------------------------------------------------------------------
-- PART A.3 — log_exam_violation RPC
-- Records one violation, then reports back whether the exam's configured
-- threshold has been reached so the client knows to auto-submit.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.log_exam_violation(p_attempt_id UUID, p_violation_type TEXT, p_detail TEXT DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_attempt exam_attempts%ROWTYPE;
  v_exam exams%ROWTYPE;
  v_count INTEGER;
BEGIN
  SELECT * INTO v_attempt FROM exam_attempts WHERE id = p_attempt_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'attempt_not_found'); END IF;
  IF v_attempt.is_submitted THEN RETURN jsonb_build_object('error', 'already_submitted'); END IF;

  SELECT * INTO v_exam FROM exams WHERE id = v_attempt.exam_id;

  INSERT INTO exam_violations (attempt_id, exam_id, student_id, violation_type, detail)
  VALUES (p_attempt_id, v_attempt.exam_id, v_attempt.student_id, p_violation_type, p_detail);

  SELECT COUNT(*) INTO v_count FROM exam_violations WHERE attempt_id = p_attempt_id;

  RETURN jsonb_build_object(
    'violation_count', v_count,
    'max_violations', v_exam.max_violations,
    'should_auto_submit', v_exam.max_violations > 0 AND v_count >= v_exam.max_violations
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.log_exam_violation(UUID, TEXT, TEXT) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PART A.4 — start_exam_attempt: rebuilt on top of migration-28's
-- shuffle-aware version (per-student shuffle_map build + apply via
-- _exam_shuffled_options) — NOT the plain original from exam_schema.sql.
-- Adds require_fullscreen/max_violations to the returned exam object and
-- violation_count so a resumed/reloaded attempt doesn't reset the
-- student's warning count to zero.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.start_exam_attempt(p_exam_id UUID, p_student_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_exam exams%ROWTYPE;
  v_attempt exam_attempts%ROWTYPE;
  v_existing_count INTEGER;
  v_questions JSONB;
  v_shuffle_map JSONB;
  v_violation_count INTEGER;
BEGIN
  SELECT * INTO v_exam FROM exams WHERE id = p_exam_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('error', 'exam_not_found');
  END IF;
  IF NOT v_exam.is_published OR v_exam.is_locked THEN
    RETURN jsonb_build_object('error', 'exam_unavailable');
  END IF;

  -- Resume an in-progress (not yet submitted) attempt if one exists.
  SELECT * INTO v_attempt FROM exam_attempts
    WHERE exam_id = p_exam_id AND student_id = p_student_id AND is_submitted = FALSE
    ORDER BY attempt_number DESC LIMIT 1;

  IF NOT FOUND THEN
    SELECT COUNT(*) INTO v_existing_count FROM exam_attempts
      WHERE exam_id = p_exam_id AND student_id = p_student_id;

    IF v_existing_count > 0 AND NOT v_exam.allow_multiple_attempts THEN
      RETURN jsonb_build_object('error', 'already_attempted');
    END IF;
    IF v_existing_count >= v_exam.max_attempts THEN
      RETURN jsonb_build_object('error', 'max_attempts_reached');
    END IF;

    -- Build a fresh per-attempt shuffle map (one random permutation per
    -- multiple-choice question) so every student sees their own option order.
    IF v_exam.shuffle_options THEN
      SELECT jsonb_object_agg(q.id::text, perm.shuffled)
      INTO v_shuffle_map
      FROM exam_questions q
      CROSS JOIN LATERAL (
        SELECT jsonb_agg(idx ORDER BY random()) AS shuffled
        FROM generate_series(0, jsonb_array_length(q.options) - 1) AS idx
      ) perm
      WHERE q.exam_id = p_exam_id AND q.question_type = 'multiple_choice' AND q.options IS NOT NULL;
    END IF;

    INSERT INTO exam_attempts (exam_id, student_id, attempt_number, start_time, expected_end_time, shuffle_map)
    VALUES (p_exam_id, p_student_id, v_existing_count + 1, NOW(), NOW() + (v_exam.duration_minutes || ' minutes')::INTERVAL, v_shuffle_map)
    RETURNING * INTO v_attempt;
  END IF;

  SELECT COUNT(*) INTO v_violation_count FROM exam_violations WHERE attempt_id = v_attempt.id;

  SELECT jsonb_agg(jsonb_build_object(
    'id', q.id, 'question_number', q.question_number, 'question_text', q.question_text,
    'question_type', q.question_type,
    'options', public._exam_shuffled_options(q.options, v_attempt.shuffle_map, q.id),
    'points', q.points
  ) ORDER BY q.question_number)
  INTO v_questions
  FROM exam_questions q WHERE q.exam_id = p_exam_id;

  RETURN jsonb_build_object(
    'attempt', to_jsonb(v_attempt),
    'exam', jsonb_build_object('id', v_exam.id, 'title', v_exam.title, 'duration_minutes', v_exam.duration_minutes,
      'passing_score', v_exam.passing_score, 'allow_review', v_exam.allow_review, 'show_correct_answers', v_exam.show_correct_answers,
      'require_fullscreen', v_exam.require_fullscreen, 'max_violations', v_exam.max_violations),
    'questions', COALESCE(v_questions, '[]'::jsonb),
    'violation_count', v_violation_count
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.start_exam_attempt(UUID, UUID) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PART A.5 — submit_exam_attempt: rebuilt on top of migration-28's
-- shuffle-aware version (grades against the shuffle-corrected answer via
-- _exam_effective_answer, translates review options/correct_answer back
-- into the student's shuffled order via _exam_shuffled_options /
-- _exam_original_to_shuffled_answer) — NOT the plain original. Adds an
-- optional p_reason so the teacher's results view can show *why* an
-- attempt ended (timer vs. integrity violations vs. manual submit).
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.submit_exam_attempt(p_attempt_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_attempt exam_attempts%ROWTYPE;
  v_exam exams%ROWTYPE;
  v_total_score INTEGER := 0;
  v_total_points INTEGER := 0;
  v_review JSONB;
BEGIN
  SELECT * INTO v_attempt FROM exam_attempts WHERE id = p_attempt_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'attempt_not_found'); END IF;
  SELECT * INTO v_exam FROM exams WHERE id = v_attempt.exam_id;

  IF v_attempt.is_submitted THEN
    NULL; -- idempotent: fall through and just return the existing result below
  ELSE
    UPDATE exam_responses r
    SET is_correct = (
      lower(trim(public._exam_effective_answer(v_attempt.shuffle_map, r.question_id, r.student_answer))) = lower(trim(q.correct_answer))
    )
    FROM exam_questions q
    WHERE r.question_id = q.id AND r.attempt_id = p_attempt_id;

    SELECT COALESCE(SUM(q.points), 0), COALESCE(SUM(CASE WHEN r.is_correct THEN q.points ELSE 0 END), 0)
      INTO v_total_points, v_total_score
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;

    UPDATE exam_attempts SET
      is_submitted = TRUE,
      submission_time = NOW(),
      total_score = v_total_score,
      total_points = v_total_points,
      percentage_score = CASE WHEN v_total_points > 0 THEN ROUND((v_total_score::NUMERIC / v_total_points) * 100, 2) ELSE 0 END,
      time_taken_seconds = GREATEST(0, EXTRACT(EPOCH FROM (LEAST(NOW(), v_attempt.expected_end_time) - v_attempt.start_time))::INTEGER),
      auto_submit_reason = p_reason,
      updated_at = NOW()
    WHERE id = p_attempt_id
    RETURNING * INTO v_attempt;
  END IF;

  IF v_exam.allow_review THEN
    SELECT jsonb_agg(jsonb_build_object(
      'question_number', q.question_number, 'question_text', q.question_text,
      'options', public._exam_shuffled_options(q.options, v_attempt.shuffle_map, q.id),
      'student_answer', r.student_answer, 'is_correct', r.is_correct,
      'correct_answer', CASE WHEN v_exam.show_correct_answers
        THEN public._exam_original_to_shuffled_answer(v_attempt.shuffle_map, q.id, q.correct_answer) ELSE NULL END,
      'explanation', CASE WHEN v_exam.show_correct_answers THEN q.explanation ELSE NULL END
    ) ORDER BY q.question_number)
    INTO v_review
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;
  END IF;

  RETURN jsonb_build_object('attempt', to_jsonb(v_attempt), 'review', v_review);
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_exam_attempt(UUID, TEXT) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PART B — Proficiency Level rollup combined across all sections that share
-- the same grade level + subject (any teacher). Returns raw-but-minimal rows
-- (no student names) so the client can run the SAME computeTermGrade() /
-- gradeDescriptor() logic already used everywhere else in the app — this
-- keeps grading math in exactly one place instead of duplicating DepEd
-- transmutation rules in SQL, where a mismatch could silently misreport.
-- Access is restricted to a teacher who actually teaches a section with this
-- grade level + subject (or an admin) — a teacher can't fish for combined
-- data on a grade/subject they have nothing to do with.
-- ----------------------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_sections_grade_subject ON sections(grade_level, subject);
CREATE INDEX IF NOT EXISTS idx_terms_section_number ON terms(section_id, term_number);

CREATE OR REPLACE FUNCTION public.get_proficiency_breakdown(p_grade_level TEXT, p_subject TEXT, p_term_number INT)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_authorized BOOLEAN;
  v_sections JSONB;
  v_students JSONB;
  v_assessments JSONB;
  v_scores JSONB;
  v_bonus JSONB;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM sections s WHERE s.teacher_id = auth.uid()
      AND s.grade_level = p_grade_level AND s.subject = p_subject
  ) INTO v_authorized;

  IF NOT COALESCE(v_authorized, FALSE) AND NOT is_admin() THEN
    RETURN jsonb_build_object('error', 'not_authorized');
  END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'id', s.id, 'weight_preset', s.weight_preset, 'custom_ww', s.custom_ww, 'custom_pt', s.custom_pt, 'custom_ex', s.custom_ex
  )), '[]'::jsonb)
  INTO v_sections
  FROM sections s WHERE s.grade_level = p_grade_level AND s.subject = p_subject;

  SELECT COALESCE(jsonb_agg(jsonb_build_object('id', st.id, 'section_id', st.section_id)), '[]'::jsonb)
  INTO v_students
  FROM students st JOIN sections s ON s.id = st.section_id
  WHERE s.grade_level = p_grade_level AND s.subject = p_subject;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'id', a.id, 'section_id', a.section_id,
    'component', a.component, 'ex_subtype', a.ex_subtype, 'highest_possible_score', a.highest_possible_score
  )), '[]'::jsonb)
  INTO v_assessments
  FROM assessments a
  JOIN terms t ON t.id = a.term_id
  JOIN sections s ON s.id = a.section_id
  WHERE s.grade_level = p_grade_level AND s.subject = p_subject AND t.term_number = p_term_number;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'assessment_id', sc.assessment_id, 'student_id', sc.student_id, 'raw_score', sc.raw_score, 'status', sc.status
  )), '[]'::jsonb)
  INTO v_scores
  FROM scores sc
  JOIN assessments a ON a.id = sc.assessment_id
  JOIN terms t ON t.id = a.term_id
  JOIN sections s ON s.id = a.section_id
  WHERE s.grade_level = p_grade_level AND s.subject = p_subject AND t.term_number = p_term_number;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'student_id', b.student_id, 'points', b.points
  )), '[]'::jsonb)
  INTO v_bonus
  FROM term_bonus_points b
  JOIN terms t ON t.id = b.term_id
  JOIN sections s ON s.id = t.section_id
  WHERE s.grade_level = p_grade_level AND s.subject = p_subject AND t.term_number = p_term_number;

  RETURN jsonb_build_object(
    'sections', v_sections, 'students', v_students,
    'assessments', v_assessments, 'scores', v_scores, 'bonus', v_bonus
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_proficiency_breakdown(TEXT, TEXT, INT) TO authenticated;

-- ----------------------------------------------------------------------------
-- Done. Sanity check:
-- select require_fullscreen, max_violations from exams limit 1;
-- select * from exam_violations limit 1;
-- ----------------------------------------------------------------------------
