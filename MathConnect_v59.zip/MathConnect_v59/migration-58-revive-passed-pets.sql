-- ============================================================================
-- MathConnect — migration 58 (OPTIONAL)
-- Welcome back the pets that "passed away" before migration 55.
--
-- Before migration 55 a neglected pet could die for good. It no longer can, so
-- it is only fair that students who lost one already get their friend back.
-- For every student who currently has NO living pet, their MOST RECENT pet is
-- brought back — asleep ("resting"), with its name, type and growth intact.
-- The student wakes it with the same short Wake-up Warm-up as any other pet.
--
-- Students who already adopted a new pet after the loss are left alone (their
-- new pet stays their only one; the old one stays in their history). Skip this
-- file if you would rather not change anyone's pets. Safe to re-run.
-- ============================================================================
update student_pets sp set
  alive = true, died_at = null, cause_of_death = null,
  resting = true, rested_since = now(),
  rest_cause = case when sp.cause_of_death = 'untreated_illness' then 'illness' else 'hunger' end,
  hunger = 0, sick = false, sick_since = null, updated_at = now()
from (
  select distinct on (student_id) id, student_id
  from student_pets
  order by student_id, adoption_number desc nulls last, coalesce(died_at, adopted_at) desc
) latest
where sp.id = latest.id
  and not sp.alive
  and not exists (select 1 from student_pets x where x.student_id = sp.student_id and x.alive);
