-- ============================================================================
-- MathConnect — Migration 12: Excused / Unexcused score status
-- ----------------------------------------------------------------------------
-- Lets a teacher mark a specific score as:
--   'scored'    (default) — a normal recorded score
--   'excused'   — student was excused for this item; EXCLUDED from both
--                 their average and the class MPS (same as leaving it blank
--                 was before, but now explicit and clearly labeled)
--   'unexcused' — student missed this item without a valid excuse; COUNTS
--                 AS ZERO in both their average and the class MPS, and is
--                 clearly labeled so it can't be mistaken for a real 0 score
--                 or for "not yet graded"
--
-- Previously, a blank score was always excluded from averages — correct for
-- excused absences, but incorrect for unexcused ones, which should count
-- against the grade. This migration lets you distinguish the two.
--
-- Safe to run on your existing database. All existing scores default to
-- 'scored' — nothing about your current grades changes until you mark an
-- item as excused/unexcused.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

alter table scores add column if not exists status text not null default 'scored'
  check (status in ('scored', 'excused', 'unexcused'));

-- Done. Redeploy grading.js, teacher.js, and student.js — the Enter Scores
-- tab now has "Excused"/"Unexcused" buttons per student per assessment.
