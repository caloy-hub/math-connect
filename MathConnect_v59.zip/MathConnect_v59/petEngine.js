// ============================================================================
// MathConnect — Math Pet Engine
// Owns: the pet catalog, food catalog, the student's pets (now plural — see
// migration-35), and adopt/feed/buy-food/mentor actions (all through the
// RPCs in migration-32/33/35 — see those files for why spending goes
// through RPCs while earning Green Points doesn't, same split as
// coins/shop already use).
// pet-ui.js only renders this state — all the logic lives here, same split
// as shopEngine.js / shop-ui.js.
// Depends on: supabase-client.js (supabase, escapeHtml, toast),
// streakEngine.js (estate, awardGreenPoints), sstate (student.js).
//
// PETS NEVER DIE (migration-55): a neglected pet falls ASLEEP ("resting"). The
// student wakes it with a short, winnable Wake-up Warm-up (5 easy questions,
// 3 right, unlimited tries — see wakeUpQuestions()/wakePet() below), says what
// got in the way, and can make a weekly Care Promise. Responsibility through
// repair, not through loss.
//
// MULTI-PET / MENTOR SYSTEM (migration-35): a student may own more than one
// living pet, but only by earning it — adopt_pet() only allows a new
// adoption once every pet they currently own has reached the Legendary
// (peak) stage. A peaked pet is immune to hunger decay, sickness, and
// death, and can be assigned (assign_pet_mentor) as a mentor to exactly
// one still-growing pet at a time, boosting that pet's Green-Point feeding
// to 1.5x growth. See petIsPeak() below — keep PEAK_GROWTH_THRESHOLD in
// sync with the server's is_pet_peak() SQL function if it ever changes.
// ============================================================================

// Icons + short display copy live client-side (fast to render); price and
// restore amounts are always read from the DB tables so the server stays
// the single source of truth, same convention as SHOP_ITEM_META.
//
// Every pet has a "high evolution" look: at the Champion stage its icon
// gets a sparkle, and at the very top (Legendary) it transforms into a
// mythical figure — Chinese Four Symbols, a Kitsune, Fenrir, Pegasus, etc.
// — with its own title. Purely cosmetic (see PET_GROWTH_STAGES below);
// nothing here is read by any scoring/mastery/DB logic.
//
// legendaryImage points at the full illustrated artwork used once a pet
// reaches Legendary (see petVisualHtml() below) — legendaryIcon is kept as
// the emoji fallback for spots that can't render an <img> (e.g. plain-text
// contexts) and for pet types that ever ship without artwork.
const PET_TYPE_META = {
  numo_fox:     { icon: "🦊", championIcon: "🦊✨", legendaryIcon: "🦊🔥", legendaryTitle: "Kitsune, the Nine-Tailed Fox Spirit", legendaryImage: "assets/pets/legendary/kitsune.png" },
  pico_penguin: { icon: "🐧", championIcon: "🐧✨", legendaryIcon: "🦅🔥", legendaryTitle: "Suzaku, the Vermilion Phoenix", legendaryImage: "assets/pets/legendary/suzaku.png" },
  digit_dragon: { icon: "🐲", championIcon: "🐲✨", legendaryIcon: "🐉💠", legendaryTitle: "Qinglong, the Azure Dragon", legendaryImage: "assets/pets/legendary/qinglong.png" },
  sumi_bunny:   { icon: "🐰", championIcon: "🐰✨", legendaryIcon: "🐇🌕", legendaryTitle: "The Jade Rabbit of the Moon", legendaryImage: "assets/pets/legendary/jaderabbit.png" },
  ari_owl:      { icon: "🦉", championIcon: "🦉✨", legendaryIcon: "🦉👑", legendaryTitle: "The All-Seeing Sage Owl", legendaryImage: "assets/pets/legendary/sageowl.png" },
  tala_turtle:  { icon: "🐢", championIcon: "🐢✨", legendaryIcon: "🐢🌊", legendaryTitle: "Xuanwu, the Black Tortoise", legendaryImage: "assets/pets/legendary/xuanwu.png" },
  byte_cat:     { icon: "🐱", championIcon: "🐱✨", legendaryIcon: "🐱🔥", legendaryTitle: "Bakeneko, the Twin-Tailed Spirit Cat", legendaryImage: "assets/pets/legendary/bakeneko.png" },
  kiri_calf:    { icon: "🐮", championIcon: "🐮✨", legendaryIcon: "🦄👑", legendaryTitle: "Qilin, the Auspicious Beast", legendaryImage: "assets/pets/legendary/qilin.png" },
  vex_wolf:     { icon: "🐺", championIcon: "🐺✨", legendaryIcon: "🐺⚡", legendaryTitle: "Fenrir, the Great Wolf", legendaryImage: "assets/pets/legendary/fenrir.png" },
  zeta_steed:   { icon: "🐴", championIcon: "🐴✨", legendaryIcon: "🐴💫", legendaryTitle: "Pegasus, the Winged Steed", legendaryImage: "assets/pets/legendary/pegasus.png" },
};
const PET_FOOD_META = {
  math_snack:     { icon: "🍪" },
  number_nuggets: { icon: "🍱" },
  equation_cake:  { icon: "🎂" },
};
const PET_CARE_META = {
  growth_vitamins: { icon: "💊" },
  wellness_vaccine: { icon: "💉" },
  cheat_meal:       { icon: "🍔" },
  cozy_bed:         { icon: "🛏️" },
  study_desk:       { icon: "📚" },
};

// Growth stage is purely a display layer on top of cumulative growth_points
// (Green Points ever fed) — nothing here is read by any scoring/mastery code.
//
// Thresholds climb steeply on purpose: Green Points are earned in small
// amounts through everyday play (drills, quest, battles, streaks — see
// awardGreenPoints() in streakEngine.js), so a pet's later evolutions take a
// real, sustained amount of practice to reach rather than a single sitting.
// That's intentional — the pet is meant to pull students back into the app
// day after day to keep leveling it up, not to peak out in a week and lose
// its pull. Each jump roughly doubles-to-triples the one before it.
const PET_GROWTH_STAGES = [
  { min: 0,     label: "Hatchling",   scale: 0.65, glow: null },
  { min: 75,    label: "Growing",     scale: 0.8,  glow: null },
  { min: 200,   label: "Juvenile",    scale: 0.92, glow: null },
  { min: 450,   label: "Thriving",    scale: 1.0,  glow: null },
  { min: 900,   label: "Radiant",     scale: 1.1,  glow: "pet-glow-radiant" },
  { min: 1700,  label: "Ascendant",   scale: 1.2,  glow: "pet-glow-radiant" },
  { min: 3000,  label: "Champion",    scale: 1.3,  glow: "pet-glow-champion" },
  { min: 5000,  label: "Legendary",   scale: 1.4,  glow: "pet-glow-legendary" },
];
// Small badge shown next to the pet's name at the top evolution tiers, purely
// cosmetic flair to make the milestone feel earned.
const PET_STAGE_BADGE = {
  Radiant: "✨", Ascendant: "🌠", Champion: "🏆", Legendary: "👑",
};

// Peak = Legendary stage = growth_points >= this. Once here, a pet is
// immune to hunger/sickness/death and can mentor another pet. MUST match
// the Legendary entry above and the server's is_pet_peak() (migration-35).
const PEAK_GROWTH_THRESHOLD = 5000;
function petIsPeak(pet) {
  return (pet && pet.growth_points || 0) >= PEAK_GROWTH_THRESHOLD;
}

/** True while a pet's All-Rounder Gemstone immunity (migration-37) is active — same full pass on hunger decay/sickness/death as a peak pet, just temporary. */
function petHasGemImmunity(pet) {
  return !!(pet && pet.gem_immune_until && new Date(pet.gem_immune_until) > new Date());
}

/** Recomputes estate.gemBoostActive (streakEngine.js) from the currently-loaded pets — true if ANY of them has active Gemstone immunity right now. Call after loading pets and after using a Gemstone. */
function refreshGemBoostActiveFlag() {
  if (typeof estate === "undefined") return;
  estate.gemBoostActive = (pstate.pets || []).some(petHasGemImmunity);
}

function petGrowthStage(growthPoints) {
  const gp = growthPoints || 0;
  let stage = PET_GROWTH_STAGES[0];
  for (const s of PET_GROWTH_STAGES) { if (gp >= s.min) stage = s; }
  return stage;
}

/** How much more growth is needed to reach the next stage, or null if maxed out. */
function petNextStageProgress(growthPoints) {
  const gp = growthPoints || 0;
  const idx = PET_GROWTH_STAGES.findIndex((s) => s === petGrowthStage(gp));
  const next = PET_GROWTH_STAGES[idx + 1];
  if (!next) return null;
  const prev = PET_GROWTH_STAGES[idx];
  return { needed: next.min - gp, fraction: (gp - prev.min) / (next.min - prev.min), nextLabel: next.label };
}

/** Resolves what to actually SHOW for this pet right now: base icon normally,
 *  a sparkle version at Champion, and a full mythical transformation (icon +
 *  title) at Legendary. Falls back gracefully if the pet type isn't in the
 *  meta table for some reason. */
function petDisplayForm(petTypeKey, stageLabel) {
  const meta = PET_TYPE_META[petTypeKey] || { icon: "🐾" };
  if (stageLabel === "Legendary" && meta.legendaryIcon) {
    return { petTypeKey, stageLabel, icon: meta.legendaryIcon, title: meta.legendaryTitle || null, image: meta.legendaryImage || null };
  }
  if (stageLabel === "Champion" && meta.championIcon) {
    return { petTypeKey, stageLabel, icon: meta.championIcon, title: null, image: null };
  }
  return { petTypeKey, stageLabel, icon: meta.icon, title: null, image: null };
}

/** Renders whatever petDisplayForm() resolved — full-body rigged vector SVG
 *  normally (or full illustrated artwork once Legendary) — inside the same
 *  motion/glow wrapper so callers don't need to branch on which one they got.
 *  `remSize` is the display size scale; falls back to emoji if SVG generator is unavailable.
 *  `extraStyle` lets a caller add its own inline styles (e.g. cursor:pointer). */
function petVisualHtml(form, animClass, glowClass, remSize, extraStyle, onClick) {
  const wrapStyle = `line-height:1;display:inline-block;vertical-align:middle;${extraStyle || ""}`;
  const classes = `pet-visual-wrap ${animClass || ""} ${glowClass || ""}`.trim();
  const clickAttr = onClick ? ` onclick="${onClick}"` : "";

  // 1. Legendary artwork with layered glowing aura
  if (form && form.image) {
    const alt = form.title || "Legendary pet";
    return `<div class="${classes}" style="${wrapStyle}"${clickAttr}><img src="${form.image}" alt="${escapeHtml(alt)}" class="pet-legendary-img" style="height:${(remSize * 1.3).toFixed(2)}rem;width:auto;max-width:${(remSize * 3.4).toFixed(2)}rem;display:block;"></div>`;
  }

  // 2. Full-body living vector (SVG) model
  if (typeof generatePetSvg === "function" && form && form.petTypeKey && remSize >= 1.6) {
    const px = Math.round(remSize * 26);
    const svgHtml = generatePetSvg(form.petTypeKey, form.stageLabel, px, animClass);
    return `<div class="${classes}" style="${wrapStyle}"${clickAttr}>${svgHtml}</div>`;
  }

  // 3. Compact fallback (chips, switcher buttons, text contexts)
  const icon = (form && form.icon) || "🐾";
  return `<div class="${classes}" style="font-size:${remSize}rem;${wrapStyle}"${clickAttr}>${icon}</div>`;
}
function petHungerLabel(hunger) {
  if (hunger >= 70) return { label: "Well fed", color: "var(--forest-dark)" };
  if (hunger >= 35) return { label: "Getting hungry", color: "var(--gold-dark, #B8790E)" };
  return { label: "Starving!", color: "var(--clay)" };
}

// ---------- Live hunger decay ----------
// Hunger isn't just a stored number — it drains on its own over real time
// since the pet was last fed, same spirit as the streak flame decaying if
// attendance breaks. Nothing is written back to the DB for this (purely a
// display-time calculation, like flameTierProgress() in streakEngine.js) —
// the stored `hunger` value only actually changes when feed_pet_green_points
// / feed_pet_food / a used care item runs. Full drain (100 -> 0) takes 24
// real hours unfed, slowed down while Growth Vitamins are active or while
// a decay-reducing piece of Equipment is equipped (mirrors, but does not
// replace, the authoritative version computed server-side in
// check_pet_wellbeing() — that RPC is what actually decides sickness/death).
// A pet that has reached peak (Legendary) is IMMUNE to all of this — its
// hunger simply never decays, so we skip the math entirely below.
//
// Eased on purpose (see migration-35) for students with unreliable home
// internet who can't check in every day: full drain takes 36 real hours
// (was 24), and a sick-but-untreated pet has another 36 hours before it
// dies (was 24) — 3 full days of total neglect before death, up from the
// original 2.
const PET_HUNGER_FULL_DRAIN_HOURS = 36;

function petHoursSinceFed(pet) {
  const since = pet.last_fed_at || pet.adopted_at;
  if (!since) return 0;
  return Math.max(0, (Date.now() - new Date(since).getTime()) / 3600000);
}

/** Same-shape discount as the server's check_pet_wellbeing() — display only. */
function petDecayDiscount(pet) {
  let discount = 0;
  if (pet.vitamin_boost_until && new Date(pet.vitamin_boost_until) > new Date()) discount = Math.max(discount, 0.5);
  if (pet.equipped_item) {
    const item = (pstate.careItems || []).find((i) => i.key === pet.equipped_item);
    if (item && item.decay_reduction_pct) discount = Math.min(0.9, discount + item.decay_reduction_pct / 100);
  }
  return discount;
}

/** The hunger value to actually DISPLAY right now — stored hunger minus time-based decay (peak pets, and pets with active Gemstone immunity, never decay). */
function petLiveHunger(pet) {
  if (pet.resting) return 0; // asleep: nothing decays until it is woken
  if (petIsPeak(pet) || petHasGemImmunity(pet)) return 100;
  const hours = petHoursSinceFed(pet);
  const decay = (hours / PET_HUNGER_FULL_DRAIN_HOURS) * 100 * (1 - petDecayDiscount(pet));
  return Math.max(0, Math.min(100, Math.round((pet.hunger || 0) - decay)));
}

// ---------- Mood: one hunger-driven dimension that covers "hungry" AND
// "lonely" together (the longer it's been since a visit/feed, the hungrier
// AND lonelier the pet reads) — simpler than tracking a second stat, and it
// reads naturally: a pet that hasn't seen you in a day is both. ----------
const PET_MOOD_LINES = {
  happy:   { min: 85, icon: "🌟", anim: "pet-anim-happy-idle", lines: [
    "Best day ever! Thanks for taking care of me!",
    "I feel amazing! Let's go crush some math today!",
    "You're the best owner a math pet could ask for!",
  ]},
  content: { min: 60, icon: "🙂", anim: "pet-anim-idle", lines: [
    "I'm doing great, thanks to you!",
    "Feeling good! Ready whenever you are.",
    "Life's good — got any Green Points to spare later?",
  ]},
  peckish: { min: 35, icon: "😐", anim: "pet-anim-idle", lines: [
    "Getting a little hungry... maybe some food soon? 🍪",
    "My tummy's starting to rumble a bit.",
    "A snack would be nice whenever you get the chance!",
  ]},
  hungry:  { min: 15, icon: "😟", anim: "pet-anim-sad", lines: [
    "My tummy's growling... and I miss playing with you!",
    "Could really use some food right about now. 🥺",
    "I've been waiting for you — got anything to feed me?",
  ]},
  starving:{ min: 0,  icon: "😢", anim: "pet-anim-sad", lines: [
    "I'm starving AND I haven't seen you in forever! Please feed me 💔",
    "Please... I really need food. I've missed you so much.",
    "It's been so long! I'm so hungry and so lonely right now.",
  ]},
};
const PET_MOOD_ORDER = ["happy", "content", "peckish", "hungry", "starving"];

// A peaked (Legendary) pet gets its own proud, mentor-flavored mood instead
// of the hunger ladder above — it's immune, so "hungry"/"starving" would
// never make sense for it.
const PET_MOOD_PEAK_LINES = [
  "I've reached my peak! Let's help a new friend grow.",
  "Legendary and loving it. Assign me as a mentor whenever you're ready!",
  "Nothing can touch me now — I'm always here if you need a mentor.",
];

// A resting pet is never scolded — it just missed you and dozed off.
const PET_MOOD_RESTING_LINES = [
  "Zzz… I fell asleep waiting for you. No worries — a quick warm-up will wake me up! 💤",
  "I'm not upset, I just got sleepy. Wake me up when you're ready!",
  "Zzz… dreaming about numbers. A few easy questions and I'm back!",
];

// A pet under active Gemstone immunity gets its own shielded mood line —
// distinct from Legendary/peak (this is temporary, that's permanent).
const PET_MOOD_GEM_LINES = [
  "Shielded by a Gemstone! Hunger and sickness can't touch me right now.",
  "I'm glowing! This Gemstone protection feels amazing.",
  "Nothing can slow me down while this Gemstone shield lasts!",
];

/** Returns { key, icon, anim, hunger, text } — the pet's current mood + a (stable-per-render) line. */
function petMood(pet) {
  if (pet.resting) {
    const text = PET_MOOD_RESTING_LINES[Math.floor(Math.random() * PET_MOOD_RESTING_LINES.length)];
    return { key: "resting", icon: "😴", anim: "pet-anim-sleep", hunger: 0, text };
  }
  if (petIsPeak(pet)) {
    const text = PET_MOOD_PEAK_LINES[Math.floor(Math.random() * PET_MOOD_PEAK_LINES.length)];
    return { key: "peak", icon: "👑", anim: "pet-anim-happy-idle", hunger: 100, text };
  }
  if (petHasGemImmunity(pet)) {
    const text = PET_MOOD_GEM_LINES[Math.floor(Math.random() * PET_MOOD_GEM_LINES.length)];
    return { key: "gem_shielded", icon: "🛡️", anim: "pet-anim-happy-idle", hunger: 100, text };
  }
  const hunger = petLiveHunger(pet);
  let key = "starving";
  for (const k of PET_MOOD_ORDER) { if (hunger >= PET_MOOD_LINES[k].min) { key = k; break; } }
  const info = PET_MOOD_LINES[key];
  const text = info.lines[Math.floor(Math.random() * info.lines.length)];
  return { key, icon: info.icon, anim: info.anim, hunger, text };
}

// ---------- Cheering during play ----------
// A small, non-blocking encouragement shown once when a student STARTS an
// activity (drills/quest/battle/practice/exam) — not per-question, so it
// never gets spammy. Tone matches current mood: a well-fed pet cheers you
// on; a hungry one still cheers, but slips in a hint that it needs food.
const PET_CHEER_LINES_GOOD = [
  "You've got this! 🐾", "Go show 'em what you know!", "I believe in you!",
  "Math time! Let's gooo! 🎉", "Cheering you on from right here!",
];
const PET_CHEER_LINES_HUNGRY = [
  "Good luck! ...don't forget to feed me after? 🥺", "You focus, I'll wait (hungrily). Go get 'em!",
  "Cheering you on — extra loud if you bring snacks later. 🍪",
];

/**
 * Shows a small floating bubble near the top of the screen with a cheer
 * line from the student's pet, if they have one. Safe to call from any
 * activity's "start" function — no-ops quietly if there's no pet yet, and
 * throttled to once every few minutes so switching activities back-to-back
 * doesn't spam it. Uses whichever pet is currently "active" (see
 * setActivePet()), falling back to the first pet owned.
 */
let _petCheerLastShownAt = 0;
async function showPetCheerBubble() {
  if (!pstate.loaded) { try { await loadMyPets(); } catch (e) { return; } }
  const pet = activePet();
  if (!pet) return;
  const now = Date.now();
  if (now - _petCheerLastShownAt < 2 * 60 * 1000) return; // throttle: at most once per 2 min
  _petCheerLastShownAt = now;

  const hunger = petLiveHunger(pet);
  const pool = (!petIsPeak(pet) && hunger < 35) ? PET_CHEER_LINES_HUNGRY : PET_CHEER_LINES_GOOD;
  const line = pool[Math.floor(Math.random() * pool.length)];
  const meta = PET_TYPE_META[pet.pet_type_key] || { icon: "🐾" };

  const bubble = document.createElement("div");
  bubble.className = "pet-cheer-bubble";
  bubble.innerHTML = `<span class="pet-cheer-icon pet-anim-bounce-once">${meta.icon}</span><span>${escapeHtml(line)}</span>`;
  document.body.appendChild(bubble);
  setTimeout(() => bubble.classList.add("pet-cheer-out"), 3200);
  setTimeout(() => bubble.remove(), 3800);
}

// pets: ALL of the student's currently-living pets. activePetId: which one
// is currently shown/selected on the My Pet tab (see setActivePet()).
var pstate = { pets: [], activePetId: null, petTypes: [], foodItems: [], careItems: [], adoptionsCount: 0, lastDeadPet: null, loaded: false, promise: null };

// ---------- Helpers over the pets array ----------
function activePet() {
  return pstate.pets.find((p) => p.id === pstate.activePetId) || pstate.pets[0] || null;
}
function setActivePet(petId) {
  pstate.activePetId = petId;
}
function findPet(petId) {
  return pstate.pets.find((p) => p.id === petId) || null;
}
function growingPets() {
  return pstate.pets.filter((p) => !petIsPeak(p));
}
function peakPets() {
  return pstate.pets.filter((p) => petIsPeak(p));
}
/** A new pet may only be adopted once every currently-owned pet has peaked. */
function canAdoptNewPet() {
  return pstate.pets.length === 0 || growingPets().length === 0;
}
function petMentor(pet) {
  if (!pet || !pet.assigned_mentor_id) return null;
  return findPet(pet.assigned_mentor_id);
}
/** Which growing pet (if any) this peaked pet is currently mentoring. */
function petMentee(mentorPet) {
  return pstate.pets.find((p) => p.assigned_mentor_id === mentorPet.id) || null;
}

// ---------- Catalog ----------
async function loadPetCatalog() {
  const [{ data: types }, { data: foods }, { data: care }] = await Promise.all([
    supabase.from("pet_types").select("*").eq("active", true).order("sort_order"),
    supabase.from("pet_food_items").select("*").eq("active", true).order("sort_order"),
    supabase.from("pet_care_items").select("*").eq("active", true).order("sort_order"),
  ]);
  pstate.petTypes = types || [];
  pstate.foodItems = foods || [];
  pstate.careItems = care || [];
}

/** Recomputes hunger decay / sickness server-side for every pet the student
 *  owns (see check_pet_wellbeing() in migration-55) and gently tells them if a
 *  pet just fell asleep. Pets never die any more — "resting" is the worst case
 *  and it is always fixable. Safe/no-op if the student has no pets. */
async function checkPetWellbeing() {
  try {
    const { data, error } = await supabase.rpc("check_pet_wellbeing", { target_student_id: sstate.student.id });
    if (error) return [];
    const rows = Array.isArray(data) ? data : (data ? [data] : []);
    for (const row of rows) {
      if (row && row.newly_resting) {
        toast("😴 One of your pets fell asleep while you were away — no worries! Open My Pet and wake it up with a quick warm-up.");
      }
    }
    return rows;
  } catch (e) { return []; }
}

// ---------- Load all of the student's living pets, plus adoption history ----------
async function loadMyPets() {
  await checkPetWellbeing();
  const [{ data: alive }, { data: history }] = await Promise.all([
    supabase.from("student_pets").select("*").eq("student_id", sstate.student.id).eq("alive", true).order("adopted_at"),
    supabase.from("student_pets").select("id, alive, pet_name, pet_type_key, died_at, cause_of_death, adoption_number")
      .eq("student_id", sstate.student.id).order("adoption_number"),
  ]);
  pstate.pets = alive || [];
  if (!pstate.pets.find((p) => p.id === pstate.activePetId)) {
    pstate.activePetId = pstate.pets.length ? pstate.pets[0].id : null;
  }
  pstate.adoptionsCount = (history || []).length;
  pstate.lastDeadPet = (!pstate.pets.length && history && history.length)
    ? [...history].reverse().find((p) => !p.alive) || null
    : null;
  pstate.loaded = true;
  refreshGemBoostActiveFlag();
  // v55 — every Legendary pet earns one certificate; this also back-fills pets that were Legendary before certificates existed.
  if (typeof certSyncLegendaryPets === "function") certSyncLegendaryPets().catch(() => {});
  return pstate.pets;
}

function ownedFoodCount(pet, foodKey) {
  if (!pet) return 0;
  return (pet.food_inventory && pet.food_inventory[foodKey]) || 0;
}
function ownedCareCount(pet, itemKey) {
  if (!pet) return 0;
  return (pet.care_inventory && pet.care_inventory[itemKey]) || 0;
}
function ownsEquipment(pet, itemKey) {
  if (!pet || !pet.owned_equipment) return false;
  return pet.owned_equipment.includes(itemKey);
}

// ---------- Adopt (free — gated on every currently-owned pet having
// reached peak; see migration-35) ----------
async function adoptPet(petTypeKey, petName) {
  const { data, error } = await supabase.rpc("adopt_pet", {
    target_student_id: sstate.student.id, target_pet_type_key: petTypeKey, target_pet_name: petName || null,
  });
  if (error) { toast("Adoption failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  pstate.pets.push(row.pet);
  pstate.activePetId = row.pet.id;
  pstate.adoptionsCount = (pstate.adoptionsCount || 0) + 1;
  pstate.lastDeadPet = null;
  toast(`🎉 Say hello to ${row.pet.pet_name || "your new pet"}!`);
  return row;
}

// ---------- Rename (free, any time) ----------
async function renamePet(petId, newName) {
  const { data, error } = await supabase.rpc("rename_pet", { target_student_id: sstate.student.id, target_pet_id: petId, new_name: newName });
  if (error) { toast("Rename failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  const pet = findPet(petId);
  if (pet) pet.pet_name = row.new_pet_name;
  toast(`✅ Renamed to ${row.new_pet_name}!`);
  return row;
}

// ---------- Feed with Green Points (1.5x growth if mentored — see migration-35) ----------
async function feedPetWithGreenPoints(petId, amount) {
  { const _p = findPet(petId); if (_p && _p.resting) { toast("💤 Your pet is asleep — wake it up with a Wake-up Warm-up first."); return { success: false }; } }
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("feed_pet_green_points", { target_student_id: sstate.student.id, target_pet_id: petId, amount });
  if (error) { toast("Feeding failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.green_points = row.new_green_points;
  const pet = findPet(petId);
  if (pet) {
    pet.hunger = row.new_hunger;
    pet.growth_points = row.new_growth_points;
    if (row.mentor_graduated) pet.assigned_mentor_id = null;
  }
  if (row.mentor_graduated) {
    toast(`🎓 Fed! Mentor boost pushed ${pet ? pet.pet_name || "your pet" : "your pet"} to Legendary — its mentor is free to help another pet now!`);
  } else if (row.growth_gain > amount) {
    toast(`💚 Fed! +${row.growth_gain} growth (1.5x mentor boost) — now ${row.new_growth_points} pts.`);
  } else {
    toast(`💚 Fed! Growth is now ${row.new_growth_points} pts.`);
  }
  if (typeof markDailyActivity === "function") await markDailyActivity("feed_pet");
  if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  return row;
}

// ---------- Buy food (spends coins) ----------
async function purchasePetFood(petId, foodKey) {
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("purchase_pet_food", { target_student_id: sstate.student.id, target_pet_id: petId, target_food_key: foodKey });
  if (error) { toast("Purchase failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.coins = row.new_coins;
  const pet = findPet(petId);
  if (pet) pet.food_inventory = row.new_food_inventory;
  toast(`✅ ${PET_FOOD_META[foodKey]?.icon || ""} Purchased! 🪙 ${row.new_coins} left.`);
  if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  return row;
}

// ---------- Feed with an owned food item ----------
async function feedPetWithFood(petId, foodKey) {
  { const _p = findPet(petId); if (_p && _p.resting) { toast("💤 Your pet is asleep — wake it up with a Wake-up Warm-up first."); return { success: false }; } }
  const { data, error } = await supabase.rpc("feed_pet_food", { target_student_id: sstate.student.id, target_pet_id: petId, target_food_key: foodKey });
  if (error) { toast("Feeding failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  const pet = findPet(petId);
  if (pet) { pet.hunger = row.new_hunger; pet.food_inventory = row.new_food_inventory; }
  toast(`😋 Yum! Hunger restored.`);
  if (typeof markDailyActivity === "function") await markDailyActivity("feed_pet");
  return row;
}

// ---------- Buy a care item: vitamin / vaccine / cheat food / equipment ----------
async function purchaseCareItem(petId, itemKey) {
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("purchase_pet_care_item", { target_student_id: sstate.student.id, target_pet_id: petId, target_item_key: itemKey });
  if (error) { toast("Purchase failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.coins = row.new_coins;
  const pet = findPet(petId);
  if (pet) { pet.care_inventory = row.new_care_inventory; pet.owned_equipment = row.new_owned_equipment; }
  toast(`✅ ${PET_CARE_META[itemKey]?.icon || ""} Purchased! 🪙 ${row.new_coins} left.`);
  if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  return row;
}

// ---------- Use an owned vitamin / vaccine / cheat food ----------
async function useCareItem(petId, itemKey) {
  { const _p = findPet(petId); if (_p && _p.resting) { toast("💤 Your pet is asleep — wake it up with a Wake-up Warm-up first."); return { success: false }; } }
  const { data, error } = await supabase.rpc("use_pet_care_item", { target_student_id: sstate.student.id, target_pet_id: petId, target_item_key: itemKey });
  if (error) { toast("That didn't work — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  toast(row.message);
  if (!row.success) return row;
  const pet = findPet(petId);
  if (pet) {
    pet.hunger = row.new_hunger;
    pet.sick = row.sick;
    pet.care_inventory = row.new_care_inventory;
    const item = (pstate.careItems || []).find((i) => i.key === itemKey);
    if (item && item.category === "vitamin") pet.vitamin_boost_until = new Date(Date.now() + item.effect_hours * 3600000).toISOString();
    if (item && item.category === "vaccine") pet.vaccinated_until = new Date(Date.now() + item.effect_hours * 3600000).toISOString();
  }
  return row;
}

// ---------- Equip / unequip an owned piece of equipment ----------
async function equipPetItem(petId, itemKey) {
  const { data, error } = await supabase.rpc("equip_pet_item", { target_student_id: sstate.student.id, target_pet_id: petId, target_item_key: itemKey || null });
  if (error) { toast("That didn't work — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  const pet = findPet(petId);
  if (pet) pet.equipped_item = row.new_equipped_item;
  toast(row.new_equipped_item ? `✅ Equipped ${PET_CARE_META[row.new_equipped_item]?.icon || ""}!` : "Unequipped.");
  return row;
}

// ---------- Mentor assignment (migration-35) ----------
async function assignMentor(mentorPetId, menteePetId) {
  const { data, error } = await supabase.rpc("assign_pet_mentor", {
    target_student_id: sstate.student.id, mentor_pet_id: mentorPetId, mentee_pet_id: menteePetId,
  });
  if (error) { toast("That didn't work — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  toast(row.message);
  if (!row.success) return row;
  const mentee = findPet(menteePetId);
  if (mentee) mentee.assigned_mentor_id = mentorPetId;
  return row;
}
async function unassignMentor(menteePetId) {
  const { data, error } = await supabase.rpc("unassign_pet_mentor", { target_student_id: sstate.student.id, mentee_pet_id: menteePetId });
  if (error) { toast("That didn't work — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  const mentee = findPet(menteePetId);
  if (mentee) mentee.assigned_mentor_id = null;
  toast("Mentor unassigned.");
  return row;
}

// ---------- All-Rounder Gemstone (migration-37) ----------
// Earned via markDailyActivity() in streakEngine.js the moment a student
// completes every activity type in one day. Spending one on a pet grants
// +3 days of hunger/sickness immunity (stacking on top of any remaining
// immunity, capped server-side at 3 uses/pet/day) and turns on the
// account-wide +30% Green Points multiplier for as long as ANY pet's
// immunity is active (see refreshGemBoostActiveFlag(), awardGreenPoints()
// in streakEngine.js).
async function useGemstoneOnPet(petId) {
  { const _p = findPet(petId); if (_p && _p.resting) { toast("💤 Your pet is asleep — wake it up with a Wake-up Warm-up first."); return { success: false }; } }
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("use_gemstone_on_pet", { target_student_id: sstate.student.id, target_pet_id: petId });
  if (error) { toast("That didn't work — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.gemstones = row.new_gemstones;
  const pet = findPet(petId);
  if (pet) pet.gem_immune_until = row.new_immune_until;
  refreshGemBoostActiveFlag();
  const until = new Date(row.new_immune_until);
  toast(`💎 Gemstone used! ${pet ? pet.pet_name || "Your pet" : "Your pet"} is shielded until ${until.toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}.`);
  if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  return row;
}


// ============================================================================
// WAKE-UP WARM-UP + CARE PROMISE (migration-55)
// ============================================================================
const PET_WAKE_REASONS = [
  { key: "forgot",   icon: "😴", label: "I forgot" },
  { key: "internet", icon: "📶", label: "No internet / no load" },
  { key: "busy",     icon: "📚", label: "Busy with other things" },
  { key: "hard",     icon: "😕", label: "Math felt hard" },
  { key: "skip",     icon: "🤐", label: "I'd rather not say" },
];
const PET_WAKE_QUESTIONS = 5;
const PET_WAKE_PASS = 3;

/** Five gentle questions from five different open stations, always at Level 1–2:
 *  the point is a small win that gets the student (and the pet) moving again. */
async function wakeUpQuestions() {
  if (!dstate.locksLoaded && typeof loadStationLocks === "function") await loadStationLocks();
  if (!dstate.loaded && typeof loadDrillProgress === "function") await loadDrillProgress();
  const levels = (dstate.progress && dstate.progress.topic_levels) || {};
  let pool = DRILL_TOPICS.filter((t) => !isStationLocked(t.key)).map((t) => t.key);
  const gentle = pool.filter((k) => ["basic", "order", "integers", "fractions", "decimals", "percent", "ratio", "geometry", "measurement"].includes(k));
  if (gentle.length >= PET_WAKE_QUESTIONS) pool = gentle;
  if (!pool.length) pool = ["basic"];
  const picks = [];
  const shuffled = pool.slice().sort(() => Math.random() - 0.5);
  for (let i = 0; i < PET_WAKE_QUESTIONS; i++) picks.push(shuffled[i % shuffled.length]);
  return picks.map((topic) => {
    const level = Math.min(2, Math.max(1, levels[topic] || 1));
    const q = generateDrillQuestion(topic, level);
    q._topic = topic;
    return q;
  });
}

async function wakePet(petId, correct, total, reason) {
  const { data, error } = await supabase.rpc("wake_pet", { p_student_id: sstate.student.id, p_pet_id: petId, p_correct: correct, p_total: total, p_reason: reason || null });
  if (error || !data) { toast("Couldn't wake your pet — check your connection and try again."); return { ok: false }; }
  if (!data.ok) { toast(data.error === "warmup_not_passed" ? "Get at least 3 right to wake your pet." : "That pet is already awake."); return data; }
  const pet = findPet(petId);
  if (pet) { pet.resting = false; pet.hunger = data.hunger; pet.last_fed_at = new Date().toISOString(); pet.sick = false; pet.wake_count = data.wake_count; }
  return data;
}

async function loadCarePromise() {
  const { data } = await supabase.rpc("care_promise_status", { p_student_id: sstate.student.id });
  pstate.promise = data || null;
  return pstate.promise;
}
async function setCarePromise(days) {
  const { data, error } = await supabase.rpc("set_care_promise", { p_student_id: sstate.student.id, p_target_days: days });
  if (error || !data) { toast("Couldn't save your promise — please try again."); return { ok: false }; }
  if (!data.ok) { toast(data.error === "cannot_lower" ? `You promised ${data.target_days} days already — you can raise it, but a promise is a promise 🙂` : "Pick 2 to 7 days."); return data; }
  await loadCarePromise();
  return data;
}
