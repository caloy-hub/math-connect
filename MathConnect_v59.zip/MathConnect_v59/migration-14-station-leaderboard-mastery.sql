-- ============================================================================
-- Migration 14 — Per-Station Leaderboards + Cultivation Mastery Ranks
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this — supabase-schema.sql already
-- includes it.
--
-- What this adds:
--   1. Per-station (per-topic) cumulative points, so the Top 10 leaderboard
--      can be scored fairly PER STATION instead of one combined total that
--      rewards whoever grinds the most overall.
--   2. Two new read-only functions teachers/students use to see "Top
--      scorers" for a single station, school-wide within a grade level.
--   3. Everything needed for the Mastery Rank system (Qi Condensation →
--      Heaven Trampling) lives entirely client-side off the existing
--      `topic_levels` column — no schema change needed for that part.
-- ============================================================================

-- ---------- add per-station point totals (one counter per station) ----------
alter table drill_progress
  add column if not exists topic_points jsonb not null
  default '{"basic":0,"order":0,"integers":0,"fractions":0,"decimals":0,"algebra":0}'::jsonb;

-- ---------- backfill existing players from their attempt history ----------
-- Sums each student's logged points_earned per topic (drill_attempts already
-- stores the net score per run, bonuses and penalties included) and clamps
-- each station's running total at 0, matching how the app clamps overall
-- points — a bad run can't push a station leaderboard entry negative.
with sums as (
  select student_id, topic, greatest(0, sum(points_earned))::int as pts
  from drill_attempts
  group by student_id, topic
)
update drill_progress dp
set topic_points = (
  select jsonb_object_agg(t.topic, coalesce(s.pts, 0))
  from (values ('basic'),('order'),('integers'),('fractions'),('decimals'),('algebra')) as t(topic)
  left join sums s on s.student_id = dp.student_id and s.topic = t.topic
)
where exists (select 1 from drill_attempts da where da.student_id = dp.student_id);

-- ----------------------------------------------------------------------------
-- STATION leaderboard — top scorers for ONE station (topic), within a grade
-- level, school-wide across every teacher's sections. This is the fair
-- replacement for the old "cumulative total" Top 10: a student who has
-- barely touched Fractions can't out-rank a Fractions specialist just
-- because they racked up points elsewhere.
-- ----------------------------------------------------------------------------
create or replace function public.station_leaderboard(target_grade_level text, target_topic text, result_limit int default 10)
returns table(student_id uuid, full_name text, section_id uuid, section_name text, topic_points integer, topic_level integer)
language sql security definer stable as $$
  select st.id, st.full_name, se.id, se.section_name,
    coalesce((dp.topic_points ->> target_topic)::int, 0),
    coalesce((dp.topic_levels ->> target_topic)::int, 1)
  from drill_progress dp
  join students st on st.id = dp.student_id
  join sections se on se.id = st.section_id
  where se.grade_level = target_grade_level
    and coalesce((dp.topic_points ->> target_topic)::int, 0) > 0
  order by coalesce((dp.topic_points ->> target_topic)::int, 0) desc
  limit result_limit;
$$;
grant execute on function public.station_leaderboard(text, text, int) to anon, authenticated;

create or replace function public.student_station_rank(target_student_id uuid, target_topic text)
returns table(rnk bigint, topic_points integer, total_students bigint)
language sql security definer stable as $$
  with target_grade as (
    select se.grade_level from students st join sections se on se.id = st.section_id where st.id = target_student_id
  ), board as (
    select dp.student_id, coalesce((dp.topic_points ->> target_topic)::int, 0) as pts,
      row_number() over (order by coalesce((dp.topic_points ->> target_topic)::int, 0) desc) as rnk
    from drill_progress dp
    join students st on st.id = dp.student_id
    join sections se on se.id = st.section_id
    where se.grade_level = (select grade_level from target_grade)
  )
  select b.rnk, b.pts, (select count(*) from board) from board b where b.student_id = target_student_id;
$$;
grant execute on function public.student_station_rank(uuid, text) to anon, authenticated;

-- ============================================================================
-- Done. Existing points are unaffected — total_points / topic_levels keep
-- working exactly as before. Station points simply layer on top so the
-- Math Drills tabs (student + teacher) can offer fair, per-station rankings
-- and each student's Mastery Rank per station and overall.
-- ============================================================================
