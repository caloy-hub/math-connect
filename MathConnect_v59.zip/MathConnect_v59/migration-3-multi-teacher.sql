-- ============================================================================
-- MathConnect — Migration 3: Multi-teacher support
-- ----------------------------------------------------------------------------
-- Safe to run on your EXISTING Supabase project. Adds three things needed to
-- share MathConnect with other (non-Math) teachers at your school:
--   1. Per-subject grading weights (Core / MAPEH-TLE / Custom)
--   2. A shared school-wide student directory, so teachers of the same
--      students don't have to retype names in every subject
--   3. Tightened data access so one teacher can no longer read another
--      teacher's sections/students/grades/attendance through the API
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

-- ---------- 1. Grading weight presets on sections ----------
alter table sections add column if not exists weight_preset text not null default 'core'
  check (weight_preset in ('core','mapeh_tle','custom'));
alter table sections add column if not exists custom_ww numeric;
alter table sections add column if not exists custom_pt numeric;
alter table sections add column if not exists custom_ex numeric;
-- Your existing sections default to 'core' (WW20/PT50/EX30) — correct for
-- Math, so nothing changes for your current sections.

-- ---------- 2. Shared learner directory ----------
create table if not exists learners (
  id uuid primary key default gen_random_uuid(),
  last_name text not null,
  first_name text not null,
  middle_name text,
  full_name text not null,
  lrn text,
  sex text,
  grade_level text,
  created_by uuid references teachers(id),
  created_at timestamptz default now()
);
alter table students add column if not exists learner_id uuid references learners(id) on delete set null;
alter table learners enable row level security;

drop policy if exists "teachers read learners" on learners;
create policy "teachers read learners" on learners for select using (auth.uid() is not null);
drop policy if exists "teachers insert learners" on learners;
create policy "teachers insert learners" on learners for insert with check (auth.uid() is not null);
drop policy if exists "teachers update learners" on learners;
create policy "teachers update learners" on learners for update using (auth.uid() is not null);
drop policy if exists "creator deletes learners" on learners;
create policy "creator deletes learners" on learners for delete using (auth.uid() = created_by);

-- Optional one-time backfill: register your existing students into the
-- shared directory too, so other teachers can find and reuse them. Safe to
-- run even if you don't invite other teachers — it just seeds the directory.
insert into learners (last_name, first_name, middle_name, full_name, lrn, sex, grade_level, created_by)
select s.last_name, s.first_name, s.middle_name, s.full_name, s.lrn, s.sex, sec.grade_level, sec.teacher_id
from students s
join sections sec on sec.id = s.section_id
where s.learner_id is null and s.last_name is not null and s.first_name is not null;

update students s
set learner_id = l.id
from learners l
join sections sec on sec.id = s.section_id
where s.learner_id is null
  and l.created_by = sec.teacher_id
  and l.last_name = s.last_name
  and l.first_name = s.first_name
  and coalesce(l.middle_name,'') = coalesce(s.middle_name,'');

-- ---------- 3. Tighten read access so teachers can't see each other's data ----------
-- Students (anon/public class-code login) keep full read access; a signed-in
-- teacher can now only read rows belonging to their OWN sections.
drop policy if exists "public read sections" on sections;
create policy "public read sections" on sections for select using (
  auth.role() = 'anon' or teacher_id = auth.uid()
);

drop policy if exists "public read students" on students;
create policy "public read students" on students for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read terms" on terms;
create policy "public read terms" on terms for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read assessments" on assessments;
create policy "public read assessments" on assessments for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read scores" on scores;
create policy "public read scores" on scores for select using (
  auth.role() = 'anon' or exists (select 1 from assessments a join sections s on s.id = a.section_id where a.id = assessment_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read attendance" on attendance;
create policy "public read attendance" on attendance for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read lessons" on lessons;
create policy "public read lessons" on lessons for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read tasks" on tasks;
create policy "public read tasks" on tasks for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read modules" on modules;
create policy "public read modules" on modules for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read schedule" on schedule;
create policy "public read schedule" on schedule for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read announcements" on announcements;
create policy "public read announcements" on announcements for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read submissions" on submissions;
create policy "public read submissions" on submissions for select using (
  auth.role() = 'anon' or exists (select 1 from tasks t join sections s on s.id = t.section_id where t.id = task_id and s.teacher_id = auth.uid())
);

drop policy if exists "public read other_concerns" on other_concerns;
create policy "public read other_concerns" on other_concerns for select using (
  auth.role() = 'anon' or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

-- Done. Redeploy the updated app files and other teachers can now safely
-- sign up and use MathConnect for their own subjects, with correct grading
-- weights and full data separation from your sections.
