-- ============================================================================
-- Migration 50 — Fix a chained FK gap that survives migration-49
-- Run this once in Supabase → SQL Editor.
--
-- ROOT CAUSE:
-- migration-49 fixed battles.winner_id and the three tournament_matches
-- participant/winner columns, but missed one more link in the same chain:
--   tournament_matches.battle_id references battles(id)   -- no ON DELETE
-- Deleting a student who was student_a_id/student_b_id in a battles row
-- CASCADEs to delete that battles row — but if that battle was a tournament
-- match, tournament_matches.battle_id has no ON DELETE action, so Postgres
-- rejects the whole delete with a foreign key violation (409 from
-- PostgREST) rather than let the battles row disappear out from under it.
--
-- FIX: same approach as migration-49 — SET NULL instead of blocking, so the
-- tournament_matches row (and the bracket around it) survives, just with
-- battle_id cleared once the underlying battle is gone.
-- ============================================================================

alter table tournament_matches drop constraint if exists tournament_matches_battle_id_fkey;
alter table tournament_matches
  add constraint tournament_matches_battle_id_fkey
  foreign key (battle_id) references battles(id) on delete set null;
