// ============================================================================
// MathConnect — Teacher view of the Intelligent Learning Engine
// Read-only class heatmap: at a glance, which domain/tier each student is
// on, their mastery %, and (color-coded) their most common recent mistake
// type — "Student A is stuck on Carry-over errors and on Easy mode, while
// Student B is a Master in Addition."
// Depends on: state (teacher.js — has state.students for the active
// section), escapeHtml (supabase-client.js), LE_DOMAINS + LE_TIER_COLORS +
// LE_MISTAKE_LIBRARY (shared constants — see note below).
//
// NOTE: LE_DOMAINS/LE_TIER_COLORS/LE_MISTAKE_LIBRARY are also defined in the
// student-side files (learningEngine.js, adaptive-practice.js,
// diagnosisEngine.js). This file is loaded standalone on the teacher
// dashboard and has no shared bundler, so it keeps its own small copies
// below — same pattern already used by teacher-drills.js for DRILL_TOPICS.
// ============================================================================

const TLE_DOMAINS = [
  { key: "addition", icon: "➕", name: "Addition" },
  { key: "subtraction", icon: "➖", name: "Subtraction" },
  { key: "multiplication", icon: "✖️", name: "Multiplication" },
  { key: "division", icon: "➗", name: "Division" },
  { key: "fractions", icon: "🍕", name: "Fractions" },
  { key: "decimals", icon: "💯", name: "Decimals" },
  { key: "ratio", icon: "⚖️", name: "Ratio & Proportion" },
  { key: "percent", icon: "💸", name: "Percent" },
  { key: "geometry", icon: "📐", name: "Geometry" },
  { key: "patterns", icon: "🧩", name: "Patterns & Sequences" },
  { key: "statistics", icon: "📊", name: "Statistics" },
  { key: "probability", icon: "🎡", name: "Probability" },
  { key: "exponents", icon: "⚡", name: "Exponents & Radicals" },
  { key: "equations", icon: "⚖️", name: "Equation Scale" },
  { key: "factoring", icon: "🧩", name: "Factor Vault" },
  { key: "measurement", icon: "🌾", name: "Farm Measure" },
  { key: "coordinates", icon: "📈", name: "Grid Navigator" },
  { key: "pythagoras", icon: "📐", name: "Surveyor's Post" },
];
const TLE_TIER_NAMES = { 1: "Easy", 2: "Medium", 3: "Hard", 4: "Expert" };
const TLE_TIER_COLORS = { 1: "#4CAF7D", 2: "#2F8FD1", 3: "#F0A93B", 4: "#E8632E" };
const TLE_MISTAKE_LABELS = {
  off_by_one: "Off-by-one errors", digit_transposition: "Swapped digits", sign_error: "Sign errors",
  carry_over: "Carry-over errors", borrow_error: "Borrowing errors", operator_confusion: "Operator mix-ups",
  decimal_point_shift: "Decimal point slips", fraction_denominator: "Common-denominator errors",
  order_of_operations: "Order-of-operations slips", rounding_slip: "Rounding slips", generic: "Mixed mistakes",
  exponent_multiplied: "Exponent-rule slips", inverse_operation: "Wrong inverse operation", forgot_square_root: "Forgot the square root",
  unit_conversion: "Unit-conversion slips", rise_run_flip: "Rise/run flipped",
};

async function fetchLearningHeatmap(sectionId) {
  const { data, error } = await supabase.rpc("teacher_learning_heatmap", { target_section_id: sectionId });
  return error ? [] : data || [];
}

function tleProficiencyColor(pct) {
  if (pct >= 80) return "#4CAF7D";
  if (pct >= 50) return "#2F8FD1";
  if (pct >= 20) return "#F0A93B";
  return "#E8632E";
}

async function renderTeacherLearningHeatmap() {
  const el = document.getElementById("tab-learning");
  el.innerHTML = `<div class="empty">Loading class heatmap…</div>`;
  if (!state.section) { el.innerHTML = `<div class="empty">Select a section first.</div>`; return; }
  const rows = await fetchLearningHeatmap(state.section.id);

  if (rows.length === 0) {
    el.innerHTML = `<div class="empty">No practice data yet for this section — once students start Adaptive Practice, their heatmap will appear here.</div>`;
    return;
  }

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <h2 style="margin:0 0 4px;">🧠 Intelligent Learning Heatmap</h2>
      <p class="muted">Each cell is a student's mastery % in that domain — darker/redder means lower. The last column flags their single most common recent mistake, so you know exactly what to reteach.</p>
    </div>
    <div style="overflow-x:auto;">
      <table style="width:100%;border-collapse:collapse;font-size:.85rem;">
        <thead>
          <tr style="text-align:left;border-bottom:2px solid var(--paper-line);">
            <th style="padding:8px;">Student</th>
            ${TLE_DOMAINS.map((d) => `<th style="padding:8px;text-align:center;">${d.icon} ${d.name}</th>`).join("")}
            <th style="padding:8px;">Most Common Mistake</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((r) => `
            <tr style="border-bottom:1px solid var(--paper-line);">
              <td style="padding:8px;font-weight:600;">${escapeHtml(r.full_name)}</td>
              ${TLE_DOMAINS.map((d) => {
                const tier = (r.adaptive_levels && r.adaptive_levels[d.key]) || 1;
                const prof = (r.skill_proficiency && r.skill_proficiency[d.key]) || 0;
                const color = tleProficiencyColor(prof);
                return `<td style="padding:8px;text-align:center;">
                  <div style="background:${color}22;color:${color};border:1px solid ${color}55;border-radius:8px;padding:6px 4px;">
                    <div style="font-weight:700;">${prof}%</div>
                    <div style="font-size:.7rem;">${TLE_TIER_NAMES[tier]}</div>
                  </div>
                </td>`;
              }).join("")}
              <td style="padding:8px;">
                ${r.top_mistake_type
                  ? `<span class="badge" style="background:var(--clay-light);color:var(--clay);">${escapeHtml(TLE_MISTAKE_LABELS[r.top_mistake_type] || r.top_mistake_type)}</span>
                     <div class="muted" style="font-size:.72rem;margin-top:2px;">in ${escapeHtml((TLE_DOMAINS.find((d) => d.key === r.top_mistake_domain) || {}).name || r.top_mistake_domain)} · ${r.top_mistake_count}× recently</div>`
                  : `<span class="muted">No recent misses 🎉</span>`}
              </td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
}
