// ============================================================================
// MathConnect — Shout-outs: the side panel
// A floating 💬 button opens a slide-in panel on the right ("the sideline")
// that stays out of the way of drills and raids. The composer and the feed are
// rendered separately so a live refresh never wipes what someone is typing.
// All logic lives in shoutoutEngine.js.
// ============================================================================

function soTimeAgo(iso) {
  const s = Math.max(0, (Date.now() - Date.parse(iso)) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 172800) return "yesterday";
  return new Date(iso).toLocaleDateString("en-PH", { month: "short", day: "numeric" });
}

function mountShoutoutUI() {
  if (document.getElementById("shoutoutFab")) return;
  const fab = document.createElement("button");
  fab.id = "shoutoutFab"; fab.type = "button"; fab.className = "shoutout-fab";
  fab.setAttribute("aria-label", "Open shout-outs");
  fab.innerHTML = `💬<span id="shoutoutBadge" class="shoutout-badge" hidden></span>`;
  fab.onclick = toggleShoutoutDrawer;

  const drawer = document.createElement("aside");
  drawer.id = "shoutoutDrawer"; drawer.className = "shoutout-drawer";
  drawer.setAttribute("aria-hidden", "true"); drawer.setAttribute("aria-label", "Shout-outs");
  drawer.innerHTML = `
    <div class="so-head">
      <div><strong>🌟 Shout-outs</strong><div class="muted" style="font-size:.75rem;">Say thanks. Cheer someone on. Always your choice 💛</div></div>
      <button type="button" class="so-close" aria-label="Close" onclick="toggleShoutoutDrawer(false)">✕</button>
    </div>
    <div id="shoutoutComposer" class="so-composer"></div>
    <div id="shoutoutFeed" class="so-feed"></div>
    <div class="so-foot-note muted">Be kind — no links or contact details. See something not okay? Tap ⚑ and your teacher will look.</div>`;
  document.body.append(fab, drawer);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && sostate.open) toggleShoutoutDrawer(false); });
  renderShoutoutAll(true);
}

function toggleShoutoutDrawer(force) {
  const drawer = document.getElementById("shoutoutDrawer");
  if (!drawer) return;
  const open = typeof force === "boolean" ? force : !sostate.open;
  sostate.open = open;
  drawer.classList.toggle("open", open);
  drawer.setAttribute("aria-hidden", open ? "false" : "true");
  if (open) { markShoutoutsSeen(); loadShoutoutFeed(); }
  startShoutoutPolling();
}

function renderShoutoutBadge() {
  const b = document.getElementById("shoutoutBadge");
  if (!b) return;
  const n = sostate.open ? 0 : shoutoutUnseenCount();
  b.hidden = n === 0;
  b.textContent = n > 9 ? "9+" : String(n);
  const fab = document.getElementById("shoutoutFab");
  if (fab) fab.classList.toggle("has-new", n > 0);
}

// Called after every feed load. Never rebuilds the composer unless the mode changed.
function renderShoutoutAll(forceComposer) {
  const fab = document.getElementById("shoutoutFab"), drawer = document.getElementById("shoutoutDrawer");
  if (!fab || !drawer) return;
  const off = sostate.mode === "off";
  fab.style.display = off ? "none" : "";
  if (off) { drawer.classList.remove("open"); sostate.open = false; return; }
  if (forceComposer || sostate.composerMode !== sostate.mode) { sostate.composerMode = sostate.mode; renderShoutoutComposer(); }
  else updateShoutoutSentCount();
  renderShoutoutFeed();
  renderShoutoutBadge();
}

function updateShoutoutSentCount() {
  const el = document.getElementById("soSent");
  if (el) el.textContent = `${sostate.sentToday}/${sostate.dailyLimit} sent today`;
}

// ---------------------------------------------------------------------------
// Composer
// ---------------------------------------------------------------------------
function renderShoutoutComposer() {
  const box = document.getElementById("shoutoutComposer");
  if (!box) return;
  if (!sostate.composeOpen) {
    box.innerHTML = `<button type="button" class="btn-primary btn-sm" style="width:100%;" onclick="toggleShoutoutCompose(true)">✍️ Give a shout-out</button>
      <div class="muted" style="font-size:.72rem;margin-top:4px;text-align:center;"><span id="soSent">${sostate.sentToday}/${sostate.dailyLimit} sent today</span></div>`;
    return;
  }
  const kindChips = Object.entries(SHOUTOUT_KINDS).map(([k, v]) =>
    `<button type="button" class="so-chip ${sostate.pickedKind === k ? "on" : ""}" onclick="pickShoutoutKind('${k}')">${v.icon} ${v.label}</button>`).join("");
  box.innerHTML = `
    <label class="so-label" for="soTo">Who do you want to thank?</label>
    <select id="soTo" class="so-input">
      <option value="">Choose a classmate…</option>
      ${sostate.roster.map((r) => `<option value="${r.id}" ${sostate.pickedTo === r.id ? "selected" : ""}>${escapeHtml(r.name)}</option>`).join("")}
    </select>
    <div class="so-label" style="margin-top:8px;">They…</div>
    <div class="so-chips" id="soKinds">${kindChips}</div>
    ${sostate.mode === "short_text" ? `
      <label class="so-label" for="soMsg" style="margin-top:8px;">Add a kind word <span class="muted">(optional)</span></label>
      <textarea id="soMsg" class="so-input so-input-textarea" maxlength="${SHOUTOUT_MAX_MESSAGE}" rows="3" placeholder="e.g. Thanks for explaining factoring! You made it so much clearer for me." oninput="document.getElementById('soCount').textContent = this.value.length + '/${SHOUTOUT_MAX_MESSAGE}'"></textarea>
      <div class="muted" id="soCount" style="font-size:.7rem;text-align:right;">0/${SHOUTOUT_MAX_MESSAGE}</div>` : ""}
    <div style="display:flex;gap:8px;align-items:center;margin-top:10px;">
      <button type="button" class="btn-primary btn-sm" onclick="submitShoutout()">Send 💛</button>
      <button type="button" class="btn-outline btn-sm" onclick="toggleShoutoutCompose(false)">Cancel</button>
      <span class="muted" id="soSent" style="font-size:.72rem;margin-left:auto;">${sostate.sentToday}/${sostate.dailyLimit} sent today</span>
    </div>`;
  const sel = document.getElementById("soTo");
  if (sel) sel.onchange = () => { sostate.pickedTo = sel.value; };
}

function toggleShoutoutCompose(open) {
  sostate.composeOpen = !!open;
  if (!open) { sostate.pickedKind = null; sostate.pickedTo = null; }
  renderShoutoutComposer();
}
function pickShoutoutKind(k) {
  sostate.pickedKind = k;
  document.querySelectorAll("#soKinds .so-chip").forEach((c) => c.classList.toggle("on", c.getAttribute("onclick") === `pickShoutoutKind('${k}')`));
}

async function submitShoutout() {
  if (sostate.sending) return;
  const to = (document.getElementById("soTo") || {}).value;
  const msgEl = document.getElementById("soMsg");
  if (!to) { toast("Pick a classmate to thank first."); return; }
  if (!sostate.pickedKind) { toast("Pick what they did first."); return; }
  sostate.sending = true;
  const res = await sendShoutout(to, sostate.pickedKind, msgEl ? msgEl.value : null);
  sostate.sending = false;
  if (res && res.ok) {
    toast("💛 Shout-out sent!");
    toggleShoutoutCompose(false);
  }
}

// ---------------------------------------------------------------------------
// Feed
// ---------------------------------------------------------------------------
function shoutoutItemHtml(i) {
  const me = shoutoutMe(), toMe = i.to_id === me, fromMe = i.from_id === me;
  const kind = SHOUTOUT_KINDS[i.kind] || { icon: "💛", label: "thank you" };
  const reacts = Object.entries(SHOUTOUT_REACTIONS).map(([k, e]) => {
    const n = (i.reactions && i.reactions[k]) || 0;
    return `<button type="button" class="so-react ${i.my_reaction === k ? "mine" : ""}" aria-label="React ${k}" onclick="reactShoutout('${i.id}','${k}')">${e}${n ? ` ${n}` : ""}</button>`;
  }).join("");
  return `
    <div class="so-item ${toMe ? "to-me" : ""}">
      <div class="so-line"><strong>${escapeHtml(i.from_name)}</strong> ${fromMe ? "<span class=\"muted\">(you)</span> " : ""}→ <strong>${escapeHtml(i.to_name)}</strong>${toMe ? " <span class=\"so-tag\">for you!</span>" : ""}</div>
      <div class="so-kind">${kind.icon} ${kind.label}</div>
      ${i.message ? `<div class="so-msg">“${escapeHtml(i.message)}”</div>` : ""}
      <div class="so-foot">
        <span class="muted" style="font-size:.72rem;">${soTimeAgo(i.created_at)}</span>
        <span class="so-reacts">${reacts}</span>
        ${fromMe ? "" : `<button type="button" class="so-report" title="Report to your teacher" aria-label="Report" onclick="reportShoutout('${i.id}')">⚑</button>`}
      </div>
    </div>`;
}

function renderShoutoutFeed() {
  const box = document.getElementById("shoutoutFeed");
  if (!box) return;
  if (!sostate.items.length) {
    box.innerHTML = `<div class="empty" style="padding:24px 12px;">No shout-outs yet — be the first to say thanks to a classmate! 🌱</div>`;
    return;
  }
  box.innerHTML = sostate.items.map(shoutoutItemHtml).join("");
}
