-- ============================================================================
-- Migration 20 — MathLegends Ranks (replaces the Qi Condensation → Heaven
-- Trampling cultivation ladder with a 15-tier Mobile-Legends-inspired
-- system, each tier named after a mathematician AND its Mobile Legends
-- band, e.g. "Euclid (Elite)". Run this once in Supabase → SQL Editor if
-- MathConnect was set up BEFORE this update. New projects don't need this —
-- supabase-schema.sql already includes it.
--
-- What this adds:
--   1. Two new columns on drill_progress: mastery_tier (1-15) and
--      mastery_stars — the new star-driven OVERALL rank. This is separate
--      from (and does NOT touch) topic_levels / topic_points, which keep
--      controlling per-station drill difficulty exactly as before.
--   2. A one-time backfill that maps every existing student's current
--      overall level (the old "weakest station" 1-10 scale) onto the new
--      1-15 scale, so nobody's rank jumps backward or forward unfairly.
--      NO drill history, points, or topic levels are modified.
--
-- Mapping used (old 1-10 level -> new 1-15 tier): a straight 1:1 carryover
-- — old level N lands on new tier N, unchanged. Old level 10 (the old
-- system's highest) becomes new tier 10 (Gauss / Mythic II), NOT the new
-- top tier — tiers 11-15 (Riemann through Archimedes) are left genuinely
-- unreached, to be earned going forward like any other promotion:
--   old 1 -> Pythagoras (1)        old 6  -> Pascal (6)
--   old 2 -> Euclid (2)            old 7  -> Newton (7)
--   old 3 -> Al-Khwarizmi (3)      old 8  -> Leibniz (8)
--   old 4 -> Fibonacci (4)         old 9  -> Euler (9)
--   old 5 -> Descartes (5)         old 10 -> Gauss (10)
-- Migrated students are seeded with 2 stars already banked toward their next
-- promotion, so nobody appears freshly reset at the very bottom of their
-- new tier.
-- ============================================================================

alter table drill_progress
  add column if not exists mastery_tier int not null default 1
  check (mastery_tier between 1 and 15);

alter table drill_progress
  add column if not exists mastery_stars int not null default 0
  check (mastery_stars >= 0);

-- ---------- backfill: derive old overall level (min across the 6 stations) ----------
with old_level as (
  select
    dp.student_id,
    least(
      coalesce((dp.topic_levels ->> 'basic')::int, 1),
      coalesce((dp.topic_levels ->> 'order')::int, 1),
      coalesce((dp.topic_levels ->> 'integers')::int, 1),
      coalesce((dp.topic_levels ->> 'fractions')::int, 1),
      coalesce((dp.topic_levels ->> 'decimals')::int, 1),
      coalesce((dp.topic_levels ->> 'algebra')::int, 1)
    ) as lvl
  from drill_progress dp
)
update drill_progress dp
set
  mastery_tier = greatest(1, least(15, old_level.lvl)),
  mastery_stars = 2
from old_level
where old_level.student_id = dp.student_id;

-- ============================================================================
-- Done. topic_levels / topic_points / total_points / drill_attempts are all
-- unaffected — this only adds the new overall MathLegends rank layer, seeded
-- fairly from where each student already stood.
-- ============================================================================
