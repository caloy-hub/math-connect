# MathConnect v58 — Whole-station certificates (Math Drills + Quest Mode)

**No new SQL migration.** Uses the existing `station_certificates` table (migration-61/62/64) and the existing
`drill_attempts` / `quest_attempts` logs.

## What changed
Certificates are no longer given per run or per level. A student now earns **one certificate per station**:

| Mode | Station | Certificate earned when |
|---|---|---|
| 🎮 Math Drills | one drill station (e.g. Fractions) | **all levels 1–15 cleared** *and* **≥ 80% overall accuracy** |
| 🗺️ Quest Mode | one chapter (e.g. The Laboratory of Numbers) | **every level of the chapter cleared** *and* **≥ 80% overall accuracy** |
| 🧠 Intelligent Practice | one domain (e.g. Fractions) | a **perfect (100%) session at Expert level**: all 8 questions asked at Expert, every one correct on the **first try** (no retries, no skips) |

* **Overall accuracy** = correct answers ÷ questions, counting the student's **best run on each level**. Replaying a level to improve
  it counts; weaker earlier attempts never hurt.
* A level counts as **cleared** at 7/10 — the same line the games already use to unlock the next level (unchanged).
* **Type by overall accuracy:** 80–89% Certificate of Completion · 90–99% Certificate of Award (High Honors) · 100% Certificate of Award (Perfect Score).
  A better result later **upgrades** the same certificate (never a second one, never a downgrade).
* Calculated from the attempt logs, so students who **already finished a station before v58 get the certificate on their next qualifying run**
  (any run that clears a level re-checks the station).
* **Result screens** now show station progress instead of a per-run nudge: "7 of 15 levels cleared · accuracy so far 86%", or, when every level is
  cleared but accuracy is short: "…your station accuracy is 76% — you need 80%. Replay Levels 3, 5 to lift it."
* Quest **Chapter Champion** is folded into the chapter certificate (no separate award).
* **Intelligent Practice** (100% rule): a practice station is one domain. Its levels are Easy → Medium → Hard → Expert, and the adaptive engine
  only reaches Expert after the student has climbed through the lower ones. The station is complete — and the certificate (Certificate of Award ·
  Perfect Score, one per domain) is issued — when a session of 8 questions is **all at Expert level and all correct on the first try**. A retry-corrected
  answer or a skipped question means 7/8 for this purpose. The result screen shows what is missing ("reach Expert", or "7/8 first-try — you need all 8").
  Practice sessions are not stored, so there is nothing to back-fill: students earn it on their next qualifying session.
* Unchanged: 🐾 Legendary Pet certificates.

## Existing certificates
Per-level, Chapter Champion and per-session practice certificates issued before v58 are **kept** (nothing deleted). Students see them in a collapsed
**"Earlier certificates"** section of 🎓 My Certificates; teachers get a scope filter ("Whole-station only / Earlier per-level") and
a new **Stations completed** count on the Certificates tab.

## Tunable constants (`certificateEngine.js`)
`CERT_STATION_ACCURACY = 0.8` (Drills/Quest overall pass line) · `CERT_PRACTICE_ACCURACY = 1.0` and `CERT_PRACTICE_TOP_TIER = 4` (Practice) · `CERT_LEVEL_CLEAR = 0.7` (level counts as cleared) · `CERT_HONORS_ACCURACY = 0.9`.
Levels per station come from `DRILL_MAX_LEVEL` (15) and `QUEST_MAX_LEVEL` (10).

## Files
Changed: `certificateEngine.js`, `drills.js`, `quest-ui.js`, `adaptive-practice.js`, `teacher-certificates.js`, `style.css`, `service-worker.js` (cache → v58-1), `README.md`

## Deploy
Redeploy the folder (one refresh for the new cache). No SQL to run.
