// ============================================================================
// MathConnect — Power-Up Shop Engine
// Owns: the shop catalog, buying/activating items, and the runtime effect
// state (is Double XP running right now? which titles has the student
// unlocked?). shop-ui.js only renders this state — all the logic lives
// here, same split as streakEngine.js / engagement-ui.js.
//
// Coins themselves still live on student_engagement (streakEngine.js owns
// loading/saving that row) — this file adds inventory + the two RPCs on
// top of it. See migration-17-shop-currency.sql for the schema + the
// purchase_shop_item / consume_shop_item Postgres functions this calls.
// Depends on: supabase-client.js (supabase), streakEngine.js (estate,
// awardCoins, coinMultiplier), sstate (student.js).
// ============================================================================

// Icons + short display copy live client-side (fast to render); price and
// availability are always read from the `shop_items` table below so the
// server stays the single source of truth for cost.
const SHOP_ITEM_META = {
  double_xp:     { icon: "⚡", short: "Doubles skill points for 10 min." },
  confetti_burst:{ icon: "🎉", short: "A celebration burst on your screen." },
  time_freeze:   { icon: "⏱️", short: "Pauses the Drills timer for 5s." },
  shield:        { icon: "🛡️", short: "Absorbs your first wrong answer in a Boss Raid — the boss won't heal." },
  profile_title: { icon: "🏷️", short: "Unlocks a new flair title for your profile." },
  mathematician_name: { icon: "🧮", short: "Unlocks a legendary mathematician's name as your title." },
  // ---- Gameplay Relics (migration-47) ----
  coin_magnet:   { icon: "🧲", short: "Doubles Coins earned for 15 minutes." },
  streak_shield: { icon: "🛡️", short: "Protects your Drills streak from your next 1 miss." },
  genius_pass:   { icon: "💡", short: "A 50/50 assist on demand, any question in Drills." },
};

// Fixed, ordered pool of unlockable titles. Purely cosmetic — a title is
// just a string shown next to the student's name, nothing about it is
// read by drills.js, adaptive-practice.js, or any mastery/scoring code.
const PROFILE_TITLE_POOL = [
  "Fraction Master", "Speed Solver", "Streak Star", "Math Wizard",
  "Number Ninja", "Problem Crusher", "Equation Expert", "Decimal Dynamo",
  // ---- High school pride titles (migration-47) ----
  "Agri-Tech Prodigy", "Master of the Unknown (x)", "Euler's Chosen",
];

// Fixed, ordered pool of mathematician names a student can unlock as a
// display title, pulled straight from MATH_BIOS (mathBios.js) so the name,
// period, and tagline are all consistent with the "Meet Your Rank's
// Mathematician" feature. Roughly chronological so early purchases feel
// approachable and later ones feel like a bigger flex.
const MATHEMATICIAN_NAME_POOL = [
  "Pythagoras", "Euclid", "Archimedes", "Al-Khwarizmi", "Fibonacci",
  "Descartes", "Pascal", "Newton", "Leibniz", "Euler",
  "Gauss", "Riemann", "Cantor", "Noether", "Ramanujan",
];

var shopState = { items: [], loaded: false };

// ---------- Catalog ----------
async function loadShopItems() {
  const { data, error } = await supabase.from("shop_items").select("*").eq("active", true).order("sort_order");
  if (error) { console.warn("Could not load shop items:", error.message); shopState.items = []; }
  else shopState.items = data || [];
  shopState.loaded = true;
  return shopState.items;
}

function ownedCount(itemId) {
  if (!estate.loaded || !estate.data) return 0;
  return (estate.data.inventory && estate.data.inventory[itemId]) || 0;
}

// ---------- Buy / activate (both go through the security-definer RPCs — see migration-17) ----------
async function purchaseShopItem(itemId) {
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("purchase_shop_item", {
    target_student_id: sstate.student.id,
    target_item_id: itemId,
  });
  if (error) { toast("Purchase failed — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.coins = row.new_coins;
  estate.data.inventory = row.new_inventory;
  toast(`✅ ${SHOP_ITEM_META[itemId]?.icon || ""} Purchased! 🪙 ${row.new_coins} left.`);
  if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  return row;
}

async function activateShopItem(itemId) {
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("consume_shop_item", {
    target_student_id: sstate.student.id,
    target_item_id: itemId,
  });
  if (error) { toast("Couldn't activate that item — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.inventory = row.new_inventory;
  if (itemId === "double_xp") estate.data.double_xp_expires_at = row.new_double_xp_expires_at;
  if (itemId === "coin_magnet") estate.data.coin_magnet_expires_at = row.new_coin_magnet_expires_at;
  if (itemId === "shield") shopEffects.shieldArmed = true; // consumed by the first wrong answer in a Boss Raid — see submitRaidAnswer() in raidEngine.js
  if (itemId === "streak_shield") shopEffects.streakShieldArmed = true; // consumed on the student's next wrong Drills answer — see submitDrillAnswer()
  if (itemId === "confetti_burst") playConfettiBurst();
  toast(`${SHOP_ITEM_META[itemId]?.icon || "✨"} Activated!`);
  return row;
}

// ---------- Runtime effect state (per-session, not persisted except double_xp_expires_at / coin_magnet_expires_at) ----------
var shopEffects = { shieldArmed: false, streakShieldArmed: false };

function isDoubleXpActive() {
  return !!(estate.loaded && estate.data && estate.data.double_xp_expires_at && new Date(estate.data.double_xp_expires_at) > new Date());
}

/** 🧲 Coin Magnet (migration-47) — same timed-buff pattern as Double XP, but for Coins instead of skill points. */
function isCoinMagnetActive() {
  return !!(estate.loaded && estate.data && estate.data.coin_magnet_expires_at && new Date(estate.data.coin_magnet_expires_at) > new Date());
}

/** Applies the Double XP multiplier (2x) to a raw points value, if the buff is currently running. */
function applyDoubleXp(points) {
  return isDoubleXpActive() ? points * 2 : points;
}

/** Coins for a single drill/practice answer per the spec: 2 coins on the 1st try, 1 coin on a 2nd try, 0 otherwise. Also respects the existing streak 2x coin power-up AND the shop-bought 🧲 Coin Magnet (migration-47) — the two can stack. */
async function awardAnswerCoins(isCorrect, attemptNumber) {
  if (!isCorrect) return 0;
  const base = attemptNumber >= 2 ? 1 : 2;
  let amount = base * (typeof coinMultiplier === "function" ? coinMultiplier() : 1);
  if (isCoinMagnetActive()) amount *= 2;
  await awardCoins(amount);
  if (typeof renderTopbarStreakBadge === "function") await renderTopbarStreakBadge();
  return amount;
}

// ---------- Confetti Burst ----------
// Purely visual — appends a handful of falling divs to the page for ~1.6s
// and removes itself. Touches no student data at all.
function playConfettiBurst() {
  const colors = ["#F4C95D", "#E07856", "#4C7A5E", "#7BAAF7", "#D96C6C"];
  const layer = document.createElement("div");
  layer.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999;overflow:hidden;";
  for (let i = 0; i < 60; i++) {
    const bit = document.createElement("div");
    const left = Math.random() * 100;
    const delay = Math.random() * 0.3;
    const duration = 1.1 + Math.random() * 0.6;
    const color = colors[i % colors.length];
    bit.style.cssText = `position:absolute;top:-10px;left:${left}vw;width:8px;height:14px;background:${color};
      opacity:.9;transform:rotate(${Math.random() * 360}deg);
      animation:shopConfettiFall ${duration}s ease-in ${delay}s forwards;border-radius:2px;`;
    layer.appendChild(bit);
  }
  document.body.appendChild(layer);
  setTimeout(() => layer.remove(), 2200);
}

// ---------- Profile Title ----------
// A student unlocks one title (in fixed order) per profile_title purchase.
// Picking which unlocked title is "active" is a pure display preference —
// it never touches skillProficiency, drill scores, or logAnswer.
function unlockedTitles() {
  const count = ownedCount("profile_title");
  return PROFILE_TITLE_POOL.slice(0, count);
}

// ---------- Mathematician Names ----------
// Same unlock-in-fixed-order mechanic as unlockedTitles() above, just a
// different pool and a different shop_items row ('mathematician_name').
function unlockedMathematicianNames() {
  const count = ownedCount("mathematician_name");
  return MATHEMATICIAN_NAME_POOL.slice(0, count);
}

/** The next name a purchase would unlock, or null if the whole pool is owned. */
function nextMathematicianName() {
  const count = ownedCount("mathematician_name");
  return MATHEMATICIAN_NAME_POOL[count] || null;
}

async function setActiveTitle(title) {
  const { error } = await supabase.from("student_engagement")
    .update({ active_title: title })
    .eq("student_id", sstate.student.id);
  if (error) { toast("Couldn't set that title — please try again."); return false; }
  estate.data.active_title = title;
  toast(`🏷️ "${title}" is now your active title!`);
  return true;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { SHOP_ITEM_META, applyDoubleXp, isDoubleXpActive, isCoinMagnetActive, unlockedTitles, unlockedMathematicianNames, nextMathematicianName, playConfettiBurst };
}
