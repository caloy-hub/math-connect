// ============================================================================
// Auth helpers
// Teacher & Admin: real Supabase Auth (email + password).
// Student: simple login code (no account, no password of their own) — the
// teacher assigns each student a short code (shown in Roster). Student
// enters Class Code + Login Code, matched against the students table, and
// a lightweight session is kept in this browser's localStorage.
// ============================================================================

const STUDENT_SESSION_KEY = "mc_student_session";

function getStudentSession() {
  const raw = localStorage.getItem(STUDENT_SESSION_KEY);
  return raw ? JSON.parse(raw) : null;
}
function setStudentSession(data) {
  localStorage.setItem(STUDENT_SESSION_KEY, JSON.stringify(data));
}
function clearStudentSession() {
  localStorage.removeItem(STUDENT_SESSION_KEY);
}

async function studentLogin(classCode, loginCode) {
  const { data: section, error: secErr } = await supabase
    .from("sections")
    .select("*")
    .ilike("class_code", classCode.trim())
    .maybeSingle();

  if (secErr || !section) return { error: "Class code not found. Please check with your teacher." };

  const { data: student, error: stuErr } = await supabase
    .from("students")
    .select("*")
    .eq("section_id", section.id)
    .ilike("login_code", loginCode.trim())
    .maybeSingle();

  if (stuErr || !student) return { error: "That login code doesn't match this class. Please check with your teacher." };

  if (student.account_status === "frozen") {
    return { error: "Your account has been paused by the administrator. Please see your teacher." };
  }

  setStudentSession({
    studentId: student.id, sectionId: section.id, name: student.first_name || student.full_name,
    readOnly: student.account_status === "readonly",
  });
  // Record the login (fire-and-forget) — failing to log this shouldn't ever block sign-in itself.
  supabase.rpc("record_student_login", { target_student_id: student.id }).then(({ error }) => {
    if (error) console.warn("Could not record login count:", error.message);
  });
  supabase.rpc("record_login_event", { p_role: "student", p_user_id: student.id, p_full_name: student.full_name }).then(({ error }) => {
    if (error) console.warn("Could not record login audit event:", error.message);
  });
  return { student, section };
}

function requireStudent() {
  const s = getStudentSession();
  if (!s) {
    window.location.href = "login.html";
    return null;
  }
  return s;
}

function studentLogout() {
  clearStudentSession();
  window.location.href = "login.html";
}

// ---------- Teacher auth ----------
async function teacherLogin(email, password) {
  await supabase.auth.signOut();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { data, error };

  const { data: teacherRow } = await supabase.from("teachers").select("full_name, account_status").eq("id", data.session.user.id).maybeSingle();
  if (teacherRow && teacherRow.account_status === "frozen") {
    await supabase.auth.signOut();
    return { error: { message: "Your account has been paused by the administrator. Please contact your school admin." } };
  }
  // Record the login (fire-and-forget) — failing to log this shouldn't ever block sign-in itself.
  supabase.rpc("record_login_event", { p_role: "teacher", p_user_id: data.session.user.id, p_full_name: (teacherRow && teacherRow.full_name) || "Unknown" }).then(({ error }) => {
    if (error) console.warn("Could not record login audit event:", error.message);
  });
  return { data, error, readOnly: teacherRow && teacherRow.account_status === "readonly" };
}

async function teacherSignUp(email, password, fullName) {
  await supabase.auth.signOut();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { full_name: fullName } },
  });
  return { data, error };
}

async function teacherLogout() {
  await supabase.auth.signOut();
  window.location.href = "login.html";
}

async function requireTeacher() {
  const { data } = await supabase.auth.getSession();
  if (!data.session) {
    window.location.href = "login.html";
    return null;
  }
  // Re-check pause status fresh from the DB every load — an admin may have
  // paused this account after the session was already established.
  const { data: teacherRow } = await supabase.from("teachers").select("account_status").eq("id", data.session.user.id).maybeSingle();
  if (teacherRow && teacherRow.account_status === "frozen") {
    await supabase.auth.signOut();
    alert("Your account has been paused by the administrator. Please contact your school admin.");
    window.location.href = "login.html";
    return null;
  }
  const user = data.session.user;
  user.readOnly = !!(teacherRow && teacherRow.account_status === "readonly");
  return user;
}

// ---------- Admin auth ----------
async function adminLogin(email, password) {
  await supabase.auth.signOut();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { error };
  const { data: adminRow } = await supabase.from("admins").select("*").eq("id", data.session.user.id).maybeSingle();
  if (!adminRow) {
    await supabase.auth.signOut();
    return { error: { message: "This account isn't set up as an admin. Ask whoever manages your Supabase project to add you." } };
  }
  // Record the login (fire-and-forget) — failing to log this shouldn't ever block sign-in itself.
  supabase.rpc("record_login_event", { p_role: "admin", p_user_id: adminRow.id, p_full_name: adminRow.full_name }).then(({ error }) => {
    if (error) console.warn("Could not record login audit event:", error.message);
  });
  return { data, admin: adminRow };
}

async function requireAdmin() {
  const { data } = await supabase.auth.getSession();
  if (!data.session) { window.location.href = "login.html"; return null; }
  const { data: adminRow } = await supabase.from("admins").select("*").eq("id", data.session.user.id).maybeSingle();
  if (!adminRow) { window.location.href = "login.html"; return null; }
  return adminRow;
}

async function adminLogout() {
  await supabase.auth.signOut();
  window.location.href = "login.html";
}
