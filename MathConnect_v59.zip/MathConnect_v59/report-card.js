// ============================================================================
// MathConnect — Individual Student Report Card
// ----------------------------------------------------------------------------
// Self-contained, read-only report generator. Reuses grading.js (DepEd grade
// computation) and rankEngine.js (MathLegends rank ladder) from the main app
// so the numbers here always match what the student/teacher sees elsewhere.
// Everything else needed for display (drill topic names, quest chapter
// names, pet growth stages) is kept local to this file on purpose — those
// are cosmetic label tables, not scoring logic, so duplicating them here
// avoids pulling in the interactive drills/quest/pet engines (and their
// student.js-only globals like `sstate`/`pstate`) into a standalone page
// that never runs those interactive features.
//
// Data access: every table this file reads (students, sections, terms,
// assessments, scores, attendance, lessons, topic_ratings, drill_progress,
// drill_attempts, quest_progress, quest_attempts, battles, student_pets,
// student_engagement, pet_types) already has a "public read" RLS policy for
// the anon key — the same policy that lets the student/teacher apps run
// without a backend server. This report tool doesn't need a teacher login
// for the same reason those dashboards don't.
// ============================================================================

// ---------- Local label tables (display-only; NOT used for any scoring) ----------
const REPORT_DRILL_TOPICS = [
  { key: "basic",       name: "Basic Operations" },
  { key: "order",       name: "Order of Operations" },
  { key: "integers",    name: "Integers" },
  { key: "fractions",   name: "Fractions" },
  { key: "decimals",    name: "Decimals" },
  { key: "algebra",     name: "Algebraic Expressions" },
  { key: "ratio",       name: "Ratio & Proportion" },
  { key: "percent",     name: "Percent" },
  { key: "geometry",    name: "Geometry" },
  { key: "patterns",    name: "Patterns & Sequences" },
  { key: "statistics",  name: "Statistics" },
  { key: "probability", name: "Probability" },
  // High-school stations (added in migration-47) — same keys as drills.js so points/levels map straight across.
  { key: "exponents",   name: "Exponents & Radicals" },
  { key: "equations",   name: "Equation Scale" },
  { key: "factoring",   name: "Factor Vault" },
  { key: "measurement", name: "Farm Measure" },
  { key: "coordinates", name: "Grid Navigator" },
  { key: "pythagoras",  name: "Surveyor's Post" },
];

const REPORT_QUEST_CHAPTERS = [
  { key: "science",    subject: "Science" },
  { key: "english",    subject: "English" },
  { key: "filipino",   subject: "Filipino" },
  { key: "ap",         subject: "Araling Panlipunan" },
  { key: "values",     subject: "Values Education" },
  { key: "musicarts",  subject: "Music and Arts" },
  { key: "pe",         subject: "PE and Health" },
  { key: "tve_food",   subject: "TVE — Food Processing" },
  { key: "tve_swine",  subject: "TVE — Swine Production" },
  { key: "tve_crops",  subject: "TVE — Agri Crops Production" },
  { key: "tve_motor",  subject: "TVE — Motorcycle Servicing" },
  { key: "math",       subject: "Math (Finale)" },
];
const REPORT_QUEST_MAX_LEVEL = 10; // levels per chapter, 3 stars max each -> 30 stars/chapter

const REPORT_PET_STAGES = [
  { min: 0,    label: "Hatchling" },
  { min: 75,   label: "Growing" },
  { min: 200,  label: "Juvenile" },
  { min: 450,  label: "Thriving" },
  { min: 900,  label: "Radiant" },
  { min: 1700, label: "Ascendant" },
  { min: 3000, label: "Champion" },
  { min: 5000, label: "Legendary" },
];

const CHART_COLORS = {
  forest: "#1E8449", forestDark: "#0F3D2A", gold: "#F0A93B", clay: "#E8632E",
  blue: "#2F8FD1", purple: "#8A5DC8", grey: "#B8C2BB",
};

let CHART_INSTANCES = [];

// ============================================================================
// INIT — cascading dropdowns
// ============================================================================
let ALL_SECTIONS = [];

document.addEventListener("DOMContentLoaded", async () => {
  try {
    initSupabase();
  } catch (e) {
    setStatus("⚠️ Could not connect — check config.js.");
    return;
  }
  await loadSections();
  wireControls();
  initTeacherIdentityFields();

  // ------------------------------------------------------------------------
  // EMBED MODE — when this page is loaded inside an <iframe> from
  // student.html's "My Report Card" tab (?embed=1&section=..&student=..&term=..),
  // skip the picker entirely: hide the selection controls, lock straight
  // onto the given student/term, and render read-only (no contenteditable
  // signature lines — this is a digital record, not a print-prep session).
  // This is what lets a report card be viewed on the student's side without
  // ever needing to be printed on paper.
  // ------------------------------------------------------------------------
  const params = new URLSearchParams(window.location.search);
  if (params.get("embed") === "1" && params.get("section") && params.get("student") && params.get("term")) {
    await enterEmbedMode(params.get("section"), params.get("student"), params.get("term"));
  } else {
    setStatus("Ready. Choose a section, student, and term.");
  }
});

async function enterEmbedMode(sectionId, studentId, termId) {
  // Hide the picker controls — this instance is locked to one report.
  ["selGrade", "selSection", "selStudent", "selTerm", "inpTeacherName", "inpTeacherPosition"].forEach((id) => {
    const input = document.getElementById(id);
    const wrapper = input && input.closest(".field");
    if (wrapper) wrapper.style.display = "none";
  });
  const genBtn = document.getElementById("btnGenerate");
  if (genBtn) genBtn.style.display = "none";

  fillTeacherFieldsForSection(sectionId);
  await generateReport({ sectionId, studentId, termId });

  // Read-only: this is a digital record being viewed, not a print-prep pass.
  document.querySelectorAll("#reportRoot [contenteditable]").forEach((el) => el.removeAttribute("contenteditable"));
}

// ============================================================================
// SUBJECT TEACHER IDENTITY — pulled straight from the SELECTED SECTION's own
// `subject_teacher_name` / `subject_teacher_position` columns (see
// migration-40). Those are set once per section by the teacher, in
// teacher.html's Class Settings tab, so every report card generated for that
// section automatically carries the correct name — for any teacher on this
// deployment, not just one hardcoded default.
//
// The boxes stay editable here too (e.g. a substitute signing a specific
// printout), but that's a one-off, print-time edit only — it is NOT saved
// back anywhere. To change the default permanently, edit it in Class
// Settings on the section itself.
// ============================================================================
function initTeacherIdentityFields() {
  const nameInput = document.getElementById("inpTeacherName");
  const posInput = document.getElementById("inpTeacherPosition");
  if (!nameInput || !posInput) {
    // report-card.html on this deployment doesn't have the Subject Teacher
    // fields (id="inpTeacherName" / id="inpTeacherPosition"). Auto-fill is
    // skipped rather than crashing.
    console.warn("MathConnect: #inpTeacherName / #inpTeacherPosition not found in report-card.html — subject-teacher auto-fill is disabled.");
    return;
  }
  // Starting default before any section has been picked yet.
  nameInput.value = typeof TEACHER_NAME !== "undefined" ? TEACHER_NAME : "";
  posInput.value = typeof TEACHER_POSITION !== "undefined" ? TEACHER_POSITION : "Subject Teacher";
}

// Called whenever the section dropdown changes: fills the signature fields
// straight from that section's own subject_teacher_name/position.
function fillTeacherFieldsForSection(sectionId) {
  const nameInput = document.getElementById("inpTeacherName");
  const posInput = document.getElementById("inpTeacherPosition");
  if (!nameInput || !posInput) return; // fields not present on this page — see initTeacherIdentityFields
  const section = ALL_SECTIONS.find((s) => s.id === sectionId);
  if (!section || !section.subject_teacher_name) {
    // Not set for this section yet (e.g. migration-40 not run, or the
    // teacher hasn't saved it in Class Settings) — leave the current
    // value in place rather than blanking a field the user may still need.
    return;
  }
  nameInput.value = section.subject_teacher_name;
  posInput.value = section.subject_teacher_position || "Subject Teacher";
}

function getTeacherIdentity() {
  const nameInput = document.getElementById("inpTeacherName");
  const posInput = document.getElementById("inpTeacherPosition");
  const name = nameInput ? nameInput.value.trim() : "";
  const position = posInput ? posInput.value.trim() : "";
  return { name, position: position || "Subject Teacher" };
}

function setStatus(msg) {
  document.getElementById("statusMsg").textContent = msg;
}

async function loadSections() {
  const { data, error } = await supabase
    .from("sections")
    .select("id, section_name, grade_level, subject, school_year, weight_preset, custom_ww, custom_pt, custom_ex, teacher_id, subject_teacher_name, subject_teacher_position")
    .order("grade_level").order("section_name");
  if (error) { setStatus("⚠️ Failed to load sections."); console.error(error); return; }
  ALL_SECTIONS = data || [];

  const gradeSel = document.getElementById("selGrade");
  const grades = Array.from(new Set(ALL_SECTIONS.map((s) => s.grade_level))).sort();
  grades.forEach((g) => gradeSel.insertAdjacentHTML("beforeend", `<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`));

  renderSectionOptions();
}

function renderSectionOptions() {
  const gradeSel = document.getElementById("selGrade");
  const sectionSel = document.getElementById("selSection");
  const chosenGrade = gradeSel.value;
  const filtered = chosenGrade ? ALL_SECTIONS.filter((s) => s.grade_level === chosenGrade) : ALL_SECTIONS;
  sectionSel.innerHTML = `<option value="">Select section…</option>` +
    filtered.map((s) => `<option value="${s.id}">${escapeHtml(s.grade_level)} — ${escapeHtml(s.section_name)}</option>`).join("");
  document.getElementById("selStudent").innerHTML = `<option value="">Select student…</option>`;
  document.getElementById("selTerm").innerHTML = `<option value="">Select term…</option>`;
  document.getElementById("btnGenerate").disabled = true;
}

function wireControls() {
  document.getElementById("selGrade").addEventListener("change", renderSectionOptions);

  document.getElementById("selSection").addEventListener("change", async (e) => {
    const sectionId = e.target.value;
    const studentSel = document.getElementById("selStudent");
    const termSel = document.getElementById("selTerm");
    studentSel.innerHTML = `<option value="">Loading…</option>`;
    termSel.innerHTML = `<option value="">Loading…</option>`;
    document.getElementById("btnGenerate").disabled = true;
    if (!sectionId) {
      studentSel.innerHTML = `<option value="">Select student…</option>`;
      termSel.innerHTML = `<option value="">Select term…</option>`;
      return;
    }
    fillTeacherFieldsForSection(sectionId); // auto-place this section's subject teacher's name
    const [{ data: students }, { data: terms }] = await Promise.all([
      supabase.from("students").select("id, full_name, last_name, first_name, sex, lrn")
        .eq("section_id", sectionId).order("last_name").order("first_name"),
      supabase.from("terms").select("id, term_number, term_name, school_year, start_date, end_date, is_active")
        .eq("section_id", sectionId).order("term_number"),
    ]);
    studentSel.innerHTML = `<option value="">Select student…</option>` +
      (students || []).map((s) => `<option value="${s.id}">${escapeHtml(s.full_name)}</option>`).join("");
    termSel.innerHTML = `<option value="">Select term…</option>` +
      (terms || []).map((t) => `<option value="${t.id}">${escapeHtml(t.term_name)}${t.is_active ? " (current)" : ""}</option>`).join("");
    checkReady();
  });

  document.getElementById("selStudent").addEventListener("change", checkReady);
  document.getElementById("selTerm").addEventListener("change", checkReady);

  document.getElementById("btnGenerate").addEventListener("click", generateReport);
  document.getElementById("btnPrint").addEventListener("click", () => window.print());
}

function checkReady() {
  const ready = document.getElementById("selSection").value &&
    document.getElementById("selStudent").value &&
    document.getElementById("selTerm").value;
  document.getElementById("btnGenerate").disabled = !ready;
}

// ============================================================================
// GENERATE — fetch everything, compute, render
// ============================================================================
async function generateReport(overrideIds) {
  const sectionId = (overrideIds && overrideIds.sectionId) || document.getElementById("selSection").value;
  const studentId = (overrideIds && overrideIds.studentId) || document.getElementById("selStudent").value;
  const termId = (overrideIds && overrideIds.termId) || document.getElementById("selTerm").value;
  const btn = document.getElementById("btnGenerate");
  btn.disabled = true;
  btn.textContent = "⏳ Building report…";
  setStatus("Fetching records from MathConnect…");
  destroyCharts();

  try {
    const [
      { data: section }, { data: student }, { data: term },
    ] = await Promise.all([
      supabase.from("sections").select("*").eq("id", sectionId).single(),
      supabase.from("students").select("*").eq("id", studentId).single(),
      supabase.from("terms").select("*").eq("id", termId).single(),
    ]);

    const [
      { data: assessments }, { data: lessons }, { data: bonusRow },
    ] = await Promise.all([
      supabase.from("assessments").select("*").eq("term_id", termId).order("week_number"),
      supabase.from("lessons").select("*").eq("term_id", termId).order("week_number"),
      supabase.from("term_bonus_points").select("*").eq("student_id", studentId).eq("term_id", termId).maybeSingle(),
    ]);

    const assessmentIds = (assessments || []).map((a) => a.id);
    const lessonIds = (lessons || []).map((l) => l.id);

    const [
      { data: scores }, { data: topicRatings },
      { data: attendance },
      { data: drillProgress }, { data: drillAttempts },
      { data: questProgress }, { data: questAttempts },
      { data: battlesA }, { data: battlesB }, { data: raidMemberRows },
      { data: petRows }, { data: petTypes },
      { data: engagement }, { data: shopPurchases },
      certRes, removalRes,
    ] = await Promise.all([
      assessmentIds.length ? supabase.from("scores").select("*").eq("student_id", studentId).in("assessment_id", assessmentIds) : Promise.resolve({ data: [] }),
      lessonIds.length ? supabase.from("topic_ratings").select("*").eq("student_id", studentId).in("lesson_id", lessonIds) : Promise.resolve({ data: [] }),
      supabase.from("attendance").select("*").eq("student_id", studentId).eq("section_id", sectionId).order("attendance_date"),
      supabase.from("drill_progress").select("*").eq("student_id", studentId).maybeSingle(),
      supabase.from("drill_attempts").select("*").eq("student_id", studentId).order("played_at"),
      supabase.from("quest_progress").select("*").eq("student_id", studentId).maybeSingle(),
      supabase.from("quest_attempts").select("*").eq("student_id", studentId).order("played_at"),
      supabase.from("battles").select("*").eq("student_a_id", studentId).eq("status", "completed"),
      supabase.from("battles").select("*").eq("student_b_id", studentId).eq("status", "completed"),
      // Team Boss Raids (migration-53) — the current Boss Battle format. The 1-v-1 duels above are kept only so terms played before the switch still print.
      supabase.from("boss_raid_members").select("correct_count, wrong_count, damage_dealt, raid:raid_id!inner(id, topic, difficulty, status, team_size, ended_at, created_at)")
        .eq("student_id", studentId).in("raid.status", ["won", "lost"]),
      // A student can own several pets (migration-35), so this must NOT be maybeSingle() — that errors on 2+ rows and the pet vanished from the report.
      supabase.from("student_pets").select("*").eq("student_id", studentId).order("adopted_at"),
      supabase.from("pet_types").select("*"),
      supabase.from("student_engagement").select("*").eq("student_id", studentId).maybeSingle(),
      supabase.from("shop_purchases").select("item_id, purchased_at").eq("student_id", studentId),
      // Certificates (migration-61/62) and per-term removal (migration-63): both fail quietly on older projects.
      supabase.from("station_certificates").select("source, kind").eq("student_id", studentId).then((r) => r, () => ({ data: [] })),
      supabase.from("student_term_status").select("*").eq("student_id", studentId).eq("term_id", termId).maybeSingle().then((r) => r, () => ({ data: null })),
    ]);
    const certRows = (certRes && certRes.data) || [];
    const removal = (removalRes && removalRes.data) || null;

    // Main pet = the most advanced LIVING pet (or the latest one on record if none is alive); the rest are listed alongside it.
    const livingPets = (petRows || []).filter((p) => p.alive !== false);
    const petPool = livingPets.length ? livingPets : (petRows || []).slice(-1);
    const pet = petPool.slice().sort((a, b) => (b.growth_points || 0) - (a.growth_points || 0))[0] || null;
    const otherPets = petPool.filter((p) => pet && p.id !== pet.id);

    // Term date window (may be unset by the teacher — handled gracefully below)
    const termStart = term && term.start_date ? new Date(term.start_date + "T00:00:00") : null;
    const termEnd = term && term.end_date ? new Date(term.end_date + "T23:59:59") : null;
    const inTermWindow = (dateVal) => {
      if (!dateVal) return true;
      if (!termStart && !termEnd) return true;
      const d = new Date(dateVal);
      if (termStart && d < termStart) return false;
      if (termEnd && d > termEnd) return false;
      return true;
    };

    const drillAttemptsThisTerm = (drillAttempts || []).filter((a) => inTermWindow(a.played_at));
    const questAttemptsThisTerm = (questAttempts || []).filter((a) => inTermWindow(a.played_at));
    const battlesAll = [...(battlesA || []).map((b) => ({ ...b, mySide: "a" })), ...(battlesB || []).map((b) => ({ ...b, mySide: "b" }))]
      .filter((b) => inTermWindow(b.completed_at))
      .sort((x, y) => new Date(y.completed_at) - new Date(x.completed_at));

    const raidsAll = (raidMemberRows || []).filter((r) => r.raid && inTermWindow(r.raid.ended_at || r.raid.created_at))
      .sort((x, y) => String(y.raid.ended_at || y.raid.created_at).localeCompare(String(x.raid.ended_at || x.raid.created_at)));

    // Opponent names for (legacy) duels
    const opponentIds = Array.from(new Set(battlesAll.map((b) => (b.mySide === "a" ? b.student_b_id : b.student_a_id))));
    let opponentMap = {};
    if (opponentIds.length) {
      const { data: opponents } = await supabase.from("students").select("id, full_name").in("id", opponentIds);
      (opponents || []).forEach((o) => (opponentMap[o.id] = o.full_name));
    }

    const scoresByAssessment = {};
    (scores || []).forEach((s) => (scoresByAssessment[s.assessment_id] = s));

    const weights = getSectionWeights(section);
    const bonus = bonusRow ? Number(bonusRow.points) || 0 : 0;
    const grade = computeTermGrade(assessments || [], scoresByAssessment, weights, bonus);
    const descriptor = gradeDescriptor(grade.termGrade);

    const model = {
      section, student, term, assessments: assessments || [], scores: scores || [], scoresByAssessment,
      lessons: lessons || [], topicRatings: topicRatings || [],
      attendance: attendance || [],
      drillProgress, drillAttempts: drillAttempts || [], drillAttemptsThisTerm,
      questProgress, questAttempts: questAttempts || [], questAttemptsThisTerm,
      battles: battlesAll, opponentMap, raids: raidsAll,
      pet, otherPets, petTypes: petTypes || [], certRows, removal,
      engagement, shopPurchases: shopPurchases || [],
      weights, bonus, grade, descriptor,
    };

    renderReport(model);
    document.getElementById("placeholder").style.display = "none";
    document.getElementById("btnPrint").style.display = "inline-block";
    setStatus(removal ? `Report ready for ${student.full_name} — note: removed from ${term.term_name}.` : `Report ready for ${student.full_name}.`);
  } catch (err) {
    console.error(err);
    setStatus("⚠️ Something went wrong building the report. Check console.");
  } finally {
    btn.disabled = false;
    btn.textContent = "⚡ Generate Report";
  }
}

function destroyCharts() {
  CHART_INSTANCES.forEach((c) => c.destroy());
  CHART_INSTANCES = [];
}

// ============================================================================
// COMPUTATION HELPERS
// ============================================================================
function computeAttendanceSummary(attendance) {
  const counts = { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0 };
  attendance.forEach((a) => { if (counts[a.status] !== undefined) counts[a.status]++; });
  const total = attendance.length;
  const presentLike = counts.present + counts.late;
  const rate = total ? (presentLike / total) * 100 : null;

  const byMonth = {};
  attendance.forEach((a) => {
    const key = a.attendance_date.slice(0, 7); // YYYY-MM
    if (!byMonth[key]) byMonth[key] = { present: 0, late: 0, absent_excused: 0, absent_unexcused: 0, total: 0 };
    byMonth[key][a.status] = (byMonth[key][a.status] || 0) + 1;
    byMonth[key].total++;
  });
  return { counts, total, rate, byMonth };
}

function monthLabel(ym) {
  const [y, m] = ym.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("en-PH", { month: "long", year: "numeric" });
}

function computeLessonRatingSummary(lessons, topicRatings) {
  const byLesson = {};
  topicRatings.forEach((r) => (byLesson[r.lesson_id] = r));
  const rows = lessons.map((l) => ({
    week: l.week_number, title: l.title,
    rating: byLesson[l.id] ? byLesson[l.id].rating : null,
    comment: byLesson[l.id] ? byLesson[l.id].comment : null,
  }));
  const rated = rows.filter((r) => r.rating !== null);
  const avg = rated.length ? rated.reduce((s, r) => s + r.rating, 0) / rated.length : null;
  return { rows, avg, ratedCount: rated.length, totalCount: rows.length };
}

function computeDrillSummary(drillProgress, attemptsThisTerm) {
  const topicPoints = (drillProgress && drillProgress.topic_points) || {};
  const topicLevels = (drillProgress && drillProgress.topic_levels) || {};
  const perTopic = REPORT_DRILL_TOPICS.map((t) => ({
    key: t.key, name: t.name,
    points: Number(topicPoints[t.key]) || 0,
    level: Number(topicLevels[t.key]) || 1,
  }));
  const termAttempts = attemptsThisTerm.length;
  const termCorrect = attemptsThisTerm.reduce((s, a) => s + (a.correct_count || 0), 0);
  const termTotalQ = attemptsThisTerm.reduce((s, a) => s + (a.total_questions || 0), 0);
  const termPoints = attemptsThisTerm.reduce((s, a) => s + (a.points_earned || 0) + (a.bonus_points || 0) - (a.penalty_points || 0), 0);
  const termAccuracy = termTotalQ ? (termCorrect / termTotalQ) * 100 : null;
  const rankTier = drillProgress ? rankTierByLevel(drillProgress.mastery_tier || 1) : rankTierByLevel(1);
  const rankStars = drillProgress ? drillProgress.mastery_stars || 0 : 0;
  const rankNeed = rankStarsToPromote(rankTier.level);
  return { perTopic, termAttempts, termAccuracy, termPoints, rankTier, rankStars, rankNeed, cumulativePoints: (drillProgress && drillProgress.total_points) || 0, bestStreak: (drillProgress && drillProgress.best_streak) || 0, gamesPlayed: (drillProgress && drillProgress.games_played) || 0 };
}

function computeQuestSummary(questProgress, attemptsThisTerm) {
  const levelStars = (questProgress && questProgress.level_stars) || {};
  const perChapter = REPORT_QUEST_CHAPTERS.map((c) => {
    const stars = (levelStars[c.key] || []).reduce((a, b) => a + b, 0);
    const levelsCleared = (levelStars[c.key] || []).filter((s) => s > 0).length;
    return { key: c.key, subject: c.subject, stars, maxStars: REPORT_QUEST_MAX_LEVEL * 3, levelsCleared, maxLevels: REPORT_QUEST_MAX_LEVEL };
  });
  const totalStars = (questProgress && questProgress.total_stars) || perChapter.reduce((s, c) => s + c.stars, 0);
  const maxTotalStars = REPORT_QUEST_CHAPTERS.length * REPORT_QUEST_MAX_LEVEL * 3;
  const chaptersCompleted = perChapter.filter((c) => c.levelsCleared >= c.maxLevels).length;
  const termRuns = attemptsThisTerm.length;
  const termStars = attemptsThisTerm.reduce((s, a) => s + (a.stars_earned || 0), 0);
  return { perChapter, totalStars, maxTotalStars, chaptersCompleted, chaptersUnlocked: (questProgress && questProgress.chapters_unlocked) || 1, runsPlayed: (questProgress && questProgress.runs_played) || 0, termRuns, termStars };
}

function computeBattleSummary(battles, studentId) {
  let wins = 0, losses = 0, draws = 0;
  const rows = battles.map((b) => {
    const isA = b.mySide === "a";
    const myWins = isA ? b.a_wins : b.b_wins;
    const oppWins = isA ? b.b_wins : b.a_wins;
    const myHealth = isA ? b.a_health : b.b_health;
    const oppHealth = isA ? b.b_health : b.a_health;
    let result;
    if (b.is_draw || (!b.winner_id)) { result = "Draw"; draws++; }
    else if (b.winner_id === studentId) { result = "Win"; wins++; }
    else { result = "Loss"; losses++; }
    return { date: b.completed_at, opponent: b.opponentMap, topic: b.topic, myWins, oppWins, myHealth, oppHealth, result };
  });
  const total = wins + losses + draws;
  const winRate = total ? (wins / total) * 100 : null;
  return { rows, wins, losses, draws, total, winRate };
}

// Boss names for the printed report (same monsters as raidEngine.js).
const REPORT_BOSS_NAMES = {
  basic: "Grumbo the Number Ogre", order: "PEMDAS the Puzzle Dragon", integers: "Negatron", fractions: "Slice-o-saurus",
  decimals: "Dot the Decimal Crab", algebra: "Vex the Variable Viper", ratio: "Boarus the Mix-Master", percent: "Markdown the Kraken",
  geometry: "Sir Perimeter Gator", patterns: "Cipher the Code Owl", statistics: "Median Widow", probability: "Lady Luck the Fox",
  exponents: "Powerhorn the Bull", equations: "Kong-Equal", factoring: "The Vault Golem", measurement: "Scorpio Scale",
  coordinates: "The Grid Wraith", pythagoras: "Hypotenuse the Hydra", mixed: "Omega Mathoid (Grand Boss)",
};
function computeRaidSummary(raids) {
  let wins = 0, losses = 0, correct = 0, wrong = 0, damage = 0;
  const rows = (raids || []).map((r) => {
    const won = r.raid.status === "won";
    if (won) wins++; else losses++;
    correct += r.correct_count || 0; wrong += r.wrong_count || 0; damage += r.damage_dealt || 0;
    return { date: r.raid.ended_at || r.raid.created_at, boss: REPORT_BOSS_NAMES[r.raid.topic] || r.raid.topic, difficulty: r.raid.difficulty, teamSize: r.raid.team_size, hits: r.correct_count || 0, result: won ? "Victory" : "Defeat" };
  });
  const total = wins + losses;
  return { rows, wins, losses, total, winRate: total ? (wins / total) * 100 : null, correct, wrong, damage, accuracy: correct + wrong ? (correct / (correct + wrong)) * 100 : null };
}

function computePetSummary(pet, petTypes) {
  if (!pet) return null;
  const meta = petTypes.find((p) => p.key === pet.pet_type_key) || {};
  let stage = REPORT_PET_STAGES[0];
  for (const s of REPORT_PET_STAGES) { if ((pet.growth_points || 0) >= s.min) stage = s; }
  const isAlive = pet.alive !== false;
  const hunger = typeof pet.hunger === "number" ? pet.hunger : null;
  let hungerLabel = "—";
  if (hunger !== null) hungerLabel = hunger >= 70 ? "Well fed" : hunger >= 35 ? "Getting hungry" : "Hungry";
  return {
    name: pet.pet_name || meta.name || "Unnamed Pet", icon: meta.icon || "🐾",
    typeName: meta.name || pet.pet_type_key, stageLabel: stage.label, growthPoints: pet.growth_points || 0,
    hunger, hungerLabel, isAlive, sick: !!pet.sick, adoptedAt: pet.adopted_at,
  };
}

// ============================================================================
// RENDER
// ============================================================================
function initials(name) {
  return (name || "").split(" ").filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
}

function fmtNum(n, digits) {
  if (n === null || n === undefined || isNaN(n)) return "—";
  return Number(n).toFixed(digits === undefined ? 1 : digits);
}

function renderReport(m) {
  const att = computeAttendanceSummary(m.attendance);
  const lessonSummary = computeLessonRatingSummary(m.lessons, m.topicRatings);
  const drill = computeDrillSummary(m.drillProgress, m.drillAttemptsThisTerm);
  const quest = computeQuestSummary(m.questProgress, m.questAttemptsThisTerm);
  const battle = computeBattleSummary(m.battles, m.student.id); // legacy 1-v-1 duels (terms before Team Raids)
  const raid = computeRaidSummary(m.raids);
  const pet = computePetSummary(m.pet, m.petTypes);
  const otherPets = (m.otherPets || []).map((p) => computePetSummary(p, m.petTypes)).filter(Boolean);
  const petCount = (pet ? 1 : 0) + otherPets.length;
  const legendaryPets = [pet, ...otherPets].filter((p) => p && p.stageLabel === "Legendary").length;
  const certTotal = (m.certRows || []).length;
  const certLegendary = (m.certRows || []).filter((c) => c.kind === "legendary").length;
  const petExtras = { others: otherPets, petCount, legendaryPets, certTotal, certLegendary };
  const eng = m.engagement || {};
  const generatedAt = new Date().toLocaleString("en-PH", { dateStyle: "long", timeStyle: "short" });

  // ---------- Overall performance radar (0-100 per axis) ----------
  const radarAcademic = m.grade.termGrade !== null ? Math.max(0, Math.min(100, m.grade.termGrade)) : 0;
  const radarAttendance = att.rate !== null ? att.rate : 0;
  const radarLessons = lessonSummary.avg !== null ? (lessonSummary.avg / 5) * 100 : 0;
  const radarDrills = drill.rankTier ? (drill.rankTier.level / 15) * 100 : 0;
  const radarQuest = quest.maxTotalStars ? (quest.totalStars / quest.maxTotalStars) * 100 : 0;
  const radarBattles = raid.winRate !== null ? raid.winRate : (battle.winRate !== null ? battle.winRate : 0);

  const html = `
  <div class="report-page" id="reportPage">
    <div class="letterhead">
      <div class="crest">🧮</div>
      <div class="txt">
        <small>Republic of the Philippines · Department of Education · Region XI · Schools Division of Davao City</small>
        <h1>${escapeHtml(typeof SCHOOL_NAME !== "undefined" ? SCHOOL_NAME : "Maria Cristina P. Belcar Agricultural High School")}</h1>
        <div class="app-tag">Generated via MathConnect — Online Math Classroom</div>
      </div>
      <div class="meta">
        S.Y. ${escapeHtml(m.term.school_year || m.section.school_year || "—")}<br>
        Generated: ${escapeHtml(generatedAt)}
      </div>
    </div>

    <div class="report-title">
      <h2>Individual Student Progress &amp; Performance Report</h2>
      <div class="term-tag">${escapeHtml(m.term.term_name)} Summary — ${escapeHtml(m.section.subject || "Mathematics")}</div>
    </div>
    ${m.removal ? `
    <div style="border:1.5px solid #C0392B;background:#FCEBEA;color:#7B241C;border-radius:8px;padding:8px 12px;margin:0 0 12px;font-size:.86rem;">
      <strong>Not enrolled in ${escapeHtml(m.term.term_name)}.</strong>
      Removed from this term's class record${m.removal.removed_at ? " on " + escapeHtml(fmtDatePH(String(m.removal.removed_at).slice(0, 10))) : ""}${m.removal.reason ? " — " + escapeHtml(m.removal.reason) : ""}${m.removal.note ? " (" + escapeHtml(m.removal.note) + ")" : ""}.
      Records from earlier terms are unaffected.
    </div>` : ""}

    <div class="student-card">
      <div class="student-avatar">${escapeHtml(initials(m.student.full_name))}</div>
      <div class="student-grid">
        <div class="item"><small>Student Name</small><div>${escapeHtml(m.student.full_name)}</div></div>
        <div class="item"><small>LRN</small><div>${escapeHtml(m.student.lrn || "—")}</div></div>
        <div class="item"><small>Sex</small><div>${escapeHtml(m.student.sex || "—")}</div></div>
        <div class="item"><small>Grade &amp; Section</small><div>${escapeHtml(m.section.grade_level)} – ${escapeHtml(m.section.section_name)}</div></div>
      </div>
    </div>

    ${sectionAcademics(m)}
    ${sectionAttendance(att)}
    ${sectionLessons(lessonSummary)}
    ${sectionDrills(drill)}
    ${sectionQuest(quest)}
    ${sectionRaids(raid, battle)}
    ${sectionPetAndEngagement(pet, eng, m.shopPurchases, petExtras)}
    ${sectionOverall(radarAcademic, radarAttendance, radarLessons, radarDrills, radarQuest, radarBattles, m.descriptor)}
    ${sectionRemarks()}
    ${sectionSignatories(m.student.full_name, getTeacherIdentity())}

    <div class="report-footer">
      <span>MathConnect · Individual Student Report Card — auto-generated from live class records.</span>
      <span>Page 1</span>
    </div>
  </div>
  `;
  document.getElementById("reportRoot").innerHTML = html;

  // ---------- Charts (after DOM is in place) ----------
  buildAcademicsChart(m.grade);
  buildAttendanceChart(att);
  buildLessonsChart(lessonSummary);
  buildDrillsChart(drill);
  buildQuestChart(quest);
  buildRadarChart({ radarAcademic, radarAttendance, radarLessons, radarDrills, radarQuest, radarBattles });
}

// ---------------------------------------------------------------------------
function sectionAcademics(m) {
  const g = m.grade;
  const rows = m.assessments
    .slice()
    .sort((a, b) => (a.week_number || 0) - (b.week_number || 0) || (a.date_given || "").localeCompare(b.date_given || ""))
    .map((a) => {
      const s = m.scoresByAssessment[a.id];
      const label = a.component === "EX" ? `EX · ${a.ex_subtype || ""}` : a.component;
      let scoreTxt = "—", pctTxt = "—";
      if (s) {
        if (s.status === "excused") scoreTxt = "Excused";
        else if (s.status === "unexcused") { scoreTxt = "0 / " + a.highest_possible_score; pctTxt = "0.0%"; }
        else if (s.raw_score !== null && s.raw_score !== undefined) {
          scoreTxt = `${s.raw_score} / ${a.highest_possible_score}`;
          pctTxt = ((Number(s.raw_score) / Number(a.highest_possible_score)) * 100).toFixed(1) + "%";
        }
      }
      return `<tr><td>${a.week_number || "—"}</td><td>${escapeHtml(label)}</td><td>${escapeHtml(a.title)}</td><td class="center-cell">${escapeHtml(a.date_given ? fmtDatePH(a.date_given) : "—")}</td><td class="num-cell">${scoreTxt}</td><td class="num-cell">${pctTxt}</td></tr>`;
    }).join("");

  return `
  <div class="section-block">
    <div class="section-head"><div class="num">I</div><h3>Class Record — Academic Performance</h3><div class="sub">${escapeHtml(weightsSummaryText(m.section))}</div></div>
    <div class="grid-2">
      <div>
        <table>
          <thead><tr><th>Wk</th><th>Type</th><th>Title</th><th>Date</th><th>Score</th><th>%</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="6" class="empty-note">No assessment records for this term yet.</td></tr>`}</tbody>
        </table>
      </div>
      <div>
        <div class="grid-3" style="margin-bottom:8px;">
          <div class="stat-box"><small>Written Works</small><div class="val small">${g.wwPS !== null ? fmtNum(g.wwPS) + "%" : "—"}</div></div>
          <div class="stat-box"><small>Performance Tasks</small><div class="val small">${g.ptPS !== null ? fmtNum(g.ptPS) + "%" : "—"}</div></div>
          <div class="stat-box"><small>Examinations</small><div class="val small">${g.exPS !== null ? fmtNum(g.exPS) + "%" : "—"}</div></div>
        </div>
        <div class="chart-box short"><canvas id="chartAcademics"></canvas></div>
        <div class="grid-2" style="margin-top:8px;">
          <div class="stat-box"><small>Initial Grade</small><div class="val">${g.initialGrade !== null ? fmtNum(g.initialGrade) : "—"}</div></div>
          <div class="stat-box" style="background:${g.termGrade !== null ? "var(--forest-light)" : "#F7F9F6"};">
            <small>Term Grade${m.bonus ? ` (+${m.bonus} bonus)` : ""}</small>
            <div class="val">${g.termGrade !== null ? g.termGrade : "—"} <span class="badge" style="background:${m.descriptor.color}22;color:${m.descriptor.color};">${escapeHtml(m.descriptor.label)}</span></div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

function buildAcademicsChart(g) {
  const ctx = document.getElementById("chartAcademics");
  if (!ctx) return;
  CHART_INSTANCES.push(new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Written Works", "Performance Tasks", "Examinations"],
      datasets: [{
        label: "% Score",
        data: [g.wwPS, g.ptPS, g.exPS].map((v) => (v === null ? 0 : Math.round(v * 10) / 10)),
        backgroundColor: [CHART_COLORS.blue, CHART_COLORS.gold, CHART_COLORS.forest],
        borderRadius: 5,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, title: { display: true, text: "Component Percentage Scores", font: { size: 11 } } },
      scales: { y: { min: 0, max: 100, ticks: { stepSize: 20 } } },
    },
  }));
}

// ---------------------------------------------------------------------------
function sectionAttendance(att) {
  const monthKeys = Object.keys(att.byMonth).sort();
  const monthRows = monthKeys.map((k) => {
    const r = att.byMonth[k];
    return `<tr><td>${escapeHtml(monthLabel(k))}</td><td class="center-cell">${r.present}</td><td class="center-cell">${r.late}</td><td class="center-cell">${r.absent_excused}</td><td class="center-cell">${r.absent_unexcused}</td><td class="center-cell">${r.total}</td></tr>`;
  }).join("");

  return `
  <div class="section-block">
    <div class="section-head"><div class="num">II</div><h3>Attendance Record</h3><div class="sub">${att.total} school day${att.total === 1 ? "" : "s"} recorded</div></div>
    <div class="grid-2">
      <div>
        <table>
          <thead><tr><th>Month</th><th>Present</th><th>Late</th><th>Excused Abs.</th><th>Unexcused Abs.</th><th>Total</th></tr></thead>
          <tbody>${monthRows || `<tr><td colspan="6" class="empty-note">No attendance records for this class yet.</td></tr>`}</tbody>
          ${att.total ? `<tfoot><tr><td>TOTAL</td><td class="center-cell">${att.counts.present}</td><td class="center-cell">${att.counts.late}</td><td class="center-cell">${att.counts.absent_excused}</td><td class="center-cell">${att.counts.absent_unexcused}</td><td class="center-cell">${att.total}</td></tr></tfoot>` : ""}
        </table>
        <div class="grid-3" style="margin-top:8px;">
          <div class="stat-box"><small>Attendance Rate</small><div class="val">${att.rate !== null ? fmtNum(att.rate) + "%" : "—"}</div></div>
        </div>
      </div>
      <div class="chart-box"><canvas id="chartAttendance"></canvas></div>
    </div>
  </div>`;
}

function buildAttendanceChart(att) {
  const ctx = document.getElementById("chartAttendance");
  if (!ctx || !att.total) return;
  CHART_INSTANCES.push(new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Present", "Late", "Excused Absence", "Unexcused Absence"],
      datasets: [{
        data: [att.counts.present, att.counts.late, att.counts.absent_excused, att.counts.absent_unexcused],
        backgroundColor: [CHART_COLORS.forest, CHART_COLORS.gold, "#9AA5B1", CHART_COLORS.clay],
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 10 } } }, title: { display: true, text: "Attendance Breakdown", font: { size: 11 } } },
    },
  }));
}

// ---------------------------------------------------------------------------
function sectionLessons(ls) {
  const rows = ls.rows.map((r) => {
    const stars = r.rating ? "★".repeat(r.rating) + "☆".repeat(5 - r.rating) : "—";
    return `<tr><td>${r.week ?? "—"}</td><td>${escapeHtml(r.title)}</td><td class="center-cell" style="color:var(--gold-dark);">${stars}</td><td>${escapeHtml(r.comment || "")}</td></tr>`;
  }).join("");
  return `
  <div class="section-block">
    <div class="section-head"><div class="num">III</div><h3>Lessons &amp; Self-Rated Understanding</h3><div class="sub">${ls.ratedCount}/${ls.totalCount} lessons self-rated</div></div>
    <div class="grid-2">
      <div>
        <table>
          <thead><tr><th>Wk</th><th>Lesson</th><th>Rating</th><th>Comment</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="4" class="empty-note">No lessons recorded for this term yet.</td></tr>`}</tbody>
        </table>
      </div>
      <div>
        <div class="stat-box" style="margin-bottom:8px;"><small>Average Self-Rating</small><div class="val">${ls.avg !== null ? fmtNum(ls.avg, 2) + " / 5" : "—"}</div></div>
        <div class="chart-box short"><canvas id="chartLessons"></canvas></div>
      </div>
    </div>
  </div>`;
}

function buildLessonsChart(ls) {
  const ctx = document.getElementById("chartLessons");
  if (!ctx) return;
  const rated = ls.rows.filter((r) => r.rating !== null);
  if (!rated.length) return;
  CHART_INSTANCES.push(new Chart(ctx, {
    type: "line",
    data: {
      labels: rated.map((r) => `Wk ${r.week ?? "—"}`),
      datasets: [{
        label: "Understanding Rating (1–5)",
        data: rated.map((r) => r.rating),
        borderColor: CHART_COLORS.purple, backgroundColor: CHART_COLORS.purple + "33",
        fill: true, tension: 0.3, pointRadius: 3,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, title: { display: true, text: "Understanding Trend by Week", font: { size: 11 } } },
      scales: { y: { min: 0, max: 5, ticks: { stepSize: 1 } } },
    },
  }));
}

// ---------------------------------------------------------------------------
function sectionDrills(d) {
  const topicRows = d.perTopic.filter((t) => t.points > 0 || t.level > 1)
    .map((t) => `<tr><td>${escapeHtml(t.name)}</td><td class="center-cell">Lv. ${t.level}</td><td class="num-cell">${t.points.toLocaleString()}</td></tr>`).join("");
  return `
  <div class="section-block">
    <div class="section-head"><div class="num">IV</div><h3>MathLegends Rank &amp; Math Drills</h3><div class="sub">Cumulative to date</div></div>
    <div class="grid-2">
      <div>
        <div class="pill-row" style="margin-bottom:8px;">
          <span class="pill" style="border-color:${d.rankTier.color};color:${d.rankTier.color};font-weight:700;">${d.rankTier.emoji} ${escapeHtml(d.rankTier.name)}</span>
          <span class="pill">${d.rankNeed ? `${d.rankStars}/${d.rankNeed} ★ to next rank` : "MAX RANK"}</span>
        </div>
        <table>
          <thead><tr><th>Drill Station</th><th>Level</th><th>Points</th></tr></thead>
          <tbody>${topicRows || `<tr><td colspan="3" class="empty-note">No drill activity recorded yet.</td></tr>`}</tbody>
        </table>
        <div class="grid-3" style="margin-top:8px;">
          <div class="stat-box"><small>Total Points</small><div class="val small">${d.cumulativePoints.toLocaleString()}</div></div>
          <div class="stat-box"><small>Games Played</small><div class="val small">${d.gamesPlayed}</div></div>
          <div class="stat-box"><small>Best Streak</small><div class="val small">${d.bestStreak}</div></div>
        </div>
      </div>
      <div>
        <div class="chart-box"><canvas id="chartDrills"></canvas></div>
        <div class="grid-3" style="margin-top:8px;">
          <div class="stat-box"><small>Drill Runs (this term)</small><div class="val small">${d.termAttempts}</div></div>
          <div class="stat-box"><small>Accuracy (this term)</small><div class="val small">${d.termAccuracy !== null ? fmtNum(d.termAccuracy) + "%" : "—"}</div></div>
          <div class="stat-box"><small>Points (this term)</small><div class="val small">${d.termPoints.toLocaleString()}</div></div>
        </div>
      </div>
    </div>
  </div>`;
}

function buildDrillsChart(d) {
  const ctx = document.getElementById("chartDrills");
  if (!ctx) return;
  const active = d.perTopic.filter((t) => t.points > 0);
  const dataset = active.length ? active : d.perTopic.slice(0, 6);
  CHART_INSTANCES.push(new Chart(ctx, {
    type: "bar",
    data: {
      labels: dataset.map((t) => t.name),
      datasets: [{ label: "Points", data: dataset.map((t) => t.points), backgroundColor: CHART_COLORS.forest, borderRadius: 4 }],
    },
    options: {
      indexAxis: "y", responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, title: { display: true, text: "Points per Drill Station", font: { size: 11 } } },
    },
  }));
}

// ---------------------------------------------------------------------------
function sectionQuest(q) {
  const rows = q.perChapter.filter((c) => c.stars > 0 || c.levelsCleared > 0)
    .map((c) => `<tr><td>${escapeHtml(c.subject)}</td><td class="center-cell">${c.levelsCleared}/${c.maxLevels}</td><td class="num-cell">${c.stars}/${c.maxStars} ★</td></tr>`).join("");
  return `
  <div class="section-block">
    <div class="section-head"><div class="num">V</div><h3>Quest Mode — Story Chapters</h3><div class="sub">${q.chaptersCompleted}/${REPORT_QUEST_CHAPTERS.length} chapters completed</div></div>
    <div class="grid-2">
      <div>
        <table>
          <thead><tr><th>Chapter</th><th>Levels Cleared</th><th>Stars</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="3" class="empty-note">No Quest Mode activity recorded yet.</td></tr>`}</tbody>
        </table>
        <div class="grid-3" style="margin-top:8px;">
          <div class="stat-box"><small>Total Stars</small><div class="val small">${q.totalStars}/${q.maxTotalStars}</div></div>
          <div class="stat-box"><small>Chapters Unlocked</small><div class="val small">${q.chaptersUnlocked}</div></div>
          <div class="stat-box"><small>Runs (this term)</small><div class="val small">${q.termRuns}</div></div>
        </div>
      </div>
      <div class="chart-box"><canvas id="chartQuest"></canvas></div>
    </div>
  </div>`;
}

function buildQuestChart(q) {
  const ctx = document.getElementById("chartQuest");
  if (!ctx) return;
  const active = q.perChapter.filter((c) => c.stars > 0);
  const dataset = active.length ? active : q.perChapter.slice(0, 6);
  CHART_INSTANCES.push(new Chart(ctx, {
    type: "bar",
    data: {
      labels: dataset.map((c) => c.subject),
      datasets: [{ label: "Stars", data: dataset.map((c) => c.stars), backgroundColor: CHART_COLORS.gold, borderRadius: 4 }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, title: { display: true, text: "Stars per Chapter", font: { size: 11 } } },
      scales: { y: { min: 0, max: 30 } },
    },
  }));
}

// ---------------------------------------------------------------------------
function sectionRaids(r, legacy) {
  const diff = { easy: "Easy", normal: "Normal", hard: "Hard" };
  const rows = r.rows.slice(0, 10).map((x) => {
    const color = x.result === "Victory" ? "#1E7A34" : "#B3261E";
    return `<tr><td>${x.date ? fmtDatePH(x.date.slice(0, 10)) : "—"}</td><td>${escapeHtml(x.boss)}</td><td class="center-cell">${escapeHtml(diff[x.difficulty] || x.difficulty || "")}</td><td class="center-cell">${x.hits}</td><td class="center-cell" style="color:${color};font-weight:700;">${x.result}</td></tr>`;
  }).join("");
  return `
  <div class="section-block">
    <div class="section-head"><div class="num">VI</div><h3>Boss Raids (Team Fights)</h3><div class="sub">${r.total} completed this term</div></div>
    <div class="grid-2">
      <div>
        <table>
          <thead><tr><th>Date</th><th>Boss</th><th>Level</th><th>My hits</th><th>Result</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="5" class="empty-note">No Boss Raids recorded for this term.</td></tr>`}</tbody>
        </table>
        ${legacy && legacy.total ? `<div class="note-box" style="margin-top:8px;">Earlier this term, before Boss Battles became team raids, this student also played ${legacy.total} one-on-one duel${legacy.total === 1 ? "" : "s"} (${legacy.wins} won, ${legacy.losses} lost, ${legacy.draws} drawn).</div>` : ""}
      </div>
      <div>
        <div class="grid-3">
          <div class="stat-box"><small>Victories</small><div class="val small" style="color:#1E7A34;">${r.wins}</div></div>
          <div class="stat-box"><small>Defeats</small><div class="val small" style="color:#B3261E;">${r.losses}</div></div>
          <div class="stat-box"><small>Answer Accuracy</small><div class="val small">${r.accuracy !== null ? fmtNum(r.accuracy) + "%" : "—"}</div></div>
        </div>
        <div class="stat-box" style="margin-top:8px;"><small>Team Win Rate</small><div class="val">${r.winRate !== null ? fmtNum(r.winRate) + "%" : "—"}</div></div>
      </div>
    </div>
  </div>`;
}

// ---------------------------------------------------------------------------
function sectionPetAndEngagement(pet, eng, purchases, extras) {
  extras = extras || { others: [], petCount: pet ? 1 : 0, legendaryPets: 0, certTotal: 0, certLegendary: 0 };
  const purchaseCounts = {};
  purchases.forEach((p) => (purchaseCounts[p.item_id] = (purchaseCounts[p.item_id] || 0) + 1));
  const purchasePills = Object.keys(purchaseCounts).map((k) => `<span class="pill">${escapeHtml(k)} ×${purchaseCounts[k]}</span>`).join("");

  const petBlock = pet ? `
    <div class="grid-3">
      <div class="stat-box"><small>Pet</small><div class="val small">${pet.icon} ${escapeHtml(pet.name)}</div></div>
      <div class="stat-box"><small>Growth Stage</small><div class="val small">${escapeHtml(pet.stageLabel)}</div></div>
      <div class="stat-box"><small>Status</small><div class="val small">${pet.isAlive ? (pet.sick ? "Sick — needs care" : pet.hungerLabel) : "Passed away"}</div></div>
    </div>
    <div class="grid-3" style="margin-top:8px;">
      <div class="stat-box"><small>Species</small><div class="val small">${escapeHtml(pet.typeName)}</div></div>
      <div class="stat-box"><small>Growth Points</small><div class="val small">${pet.growthPoints.toLocaleString()}</div></div>
      <div class="stat-box"><small>Adopted</small><div class="val small">${pet.adoptedAt ? fmtDatePH(pet.adoptedAt.slice(0, 10)) : "—"}</div></div>
    </div>
    <div class="grid-3" style="margin-top:8px;">
      <div class="stat-box"><small>Pets Owned</small><div class="val small">${extras.petCount}</div></div>
      <div class="stat-box"><small>Legendary Pets</small><div class="val small">👑 ${extras.legendaryPets}</div></div>
      <div class="stat-box"><small>Certificates Earned</small><div class="val small">🎓 ${extras.certTotal}${extras.certLegendary ? ` <span style="font-weight:400;font-size:.72rem;">(${extras.certLegendary} pet)</span>` : ""}</div></div>
    </div>
    ${extras.others.length ? `<div class="pill-row" style="margin-top:8px;">${extras.others.map((o) => `<span class="pill">${o.icon} ${escapeHtml(o.name)} · ${escapeHtml(o.stageLabel)}</span>`).join("")}</div>` : ""}` : `<div class="empty-note">This student has not adopted a Math Pet yet.${extras.certTotal ? ` · 🎓 ${extras.certTotal} certificate${extras.certTotal === 1 ? "" : "s"} earned` : ""}</div>`;

  return `
  <div class="section-block">
    <div class="section-head"><div class="num">VII</div><h3>Math Pet, Coins &amp; Green Points</h3></div>
    <div class="grid-2">
      <div>${petBlock}</div>
      <div>
        <div class="grid-3">
          <div class="stat-box"><small>Coins</small><div class="val small">🪙 ${(eng.coins || 0).toLocaleString()}</div></div>
          <div class="stat-box"><small>Green Points</small><div class="val small">🌿 ${(eng.green_points || 0).toLocaleString()}</div></div>
          <div class="stat-box"><small>Current Streak</small><div class="val small">🔥 ${eng.current_streak || 0}d</div></div>
        </div>
        <div class="stat-box" style="margin-top:8px;"><small>Longest Streak</small><div class="val small">${eng.longest_streak || 0} day${(eng.longest_streak || 0) === 1 ? "" : "s"}</div></div>
        ${purchasePills ? `<div class="pill-row" style="margin-top:8px;">${purchasePills}</div>` : `<div class="empty-note">No Power-Up Shop purchases yet.</div>`}
      </div>
    </div>
  </div>`;
}

// ---------------------------------------------------------------------------
function sectionOverall(academic, attendance, lessons, drills, quest, battles, descriptor) {
  return `
  <div class="section-block">
    <div class="section-head"><div class="num">VIII</div><h3>Overall Performance Snapshot</h3></div>
    <div class="grid-2">
      <div class="chart-box"><canvas id="chartRadar"></canvas></div>
      <div>
        <div class="grid-2" style="row-gap:8px;">
          <div class="stat-box"><small>Academic Grade</small><div class="val small">${fmtNum(academic)}%</div></div>
          <div class="stat-box"><small>Attendance Rate</small><div class="val small">${fmtNum(attendance)}%</div></div>
          <div class="stat-box"><small>Lesson Understanding</small><div class="val small">${fmtNum(lessons)}%</div></div>
          <div class="stat-box"><small>Drill Mastery Progress</small><div class="val small">${fmtNum(drills)}%</div></div>
          <div class="stat-box"><small>Quest Completion</small><div class="val small">${fmtNum(quest)}%</div></div>
          <div class="stat-box"><small>Boss Raid Win Rate</small><div class="val small">${fmtNum(battles)}%</div></div>
        </div>
        <div class="note-box">Overall standing: <b>${escapeHtml(descriptor.label)}</b> based on this term's academic grade. Each axis on the chart is scaled to a 0–100 range for comparison and does not represent a single combined score.</div>
      </div>
    </div>
  </div>`;
}

function buildRadarChart(r) {
  const ctx = document.getElementById("chartRadar");
  if (!ctx) return;
  CHART_INSTANCES.push(new Chart(ctx, {
    type: "radar",
    data: {
      labels: ["Academic", "Attendance", "Lesson Understanding", "Drill Mastery", "Quest Progress", "Raid Win Rate"],
      datasets: [{
        label: "This Student",
        data: [r.radarAcademic, r.radarAttendance, r.radarLessons, r.radarDrills, r.radarQuest, r.radarBattles].map((v) => Math.round(v * 10) / 10),
        backgroundColor: CHART_COLORS.forest + "33", borderColor: CHART_COLORS.forest, pointBackgroundColor: CHART_COLORS.forest,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { r: { min: 0, max: 100, ticks: { stepSize: 25, backdropColor: "transparent", font: { size: 8 } }, pointLabels: { font: { size: 9 } } } },
    },
  }));
}

// ---------------------------------------------------------------------------
function sectionRemarks() {
  return `
  <div class="section-block">
    <div class="section-head"><div class="num">IX</div><h3>Teacher's General Remarks</h3><div class="editable-hint">(click to type before exporting)</div></div>
    <div class="remarks-area" contenteditable="true" data-placeholder="Write general remarks about the student's performance, effort, and conduct this term…"></div>
  </div>`;
}

function sectionSignatories(studentName, teacher) {
  return `
  <div class="sign-section">
    <div class="sign-grid">
      <div class="sign-box">
        <div class="sign-line" contenteditable="true">${escapeHtml(studentName)}</div>
        <div class="sign-caption">Signature over Printed Name</div>
        <div class="sign-role">Student</div>
      </div>
      <div class="sign-box">
        <div class="sign-line" contenteditable="true" data-placeholder="Teacher's Name">${escapeHtml(teacher.name)}</div>
        <div class="sign-caption">Signature over Printed Name</div>
        <div class="sign-role" contenteditable="true">${escapeHtml(teacher.position)}</div>
      </div>
      <div class="sign-box">
        <div class="sign-line" contenteditable="true" data-placeholder="Parent/Guardian's Name"></div>
        <div class="sign-caption">Signature over Printed Name</div>
        <div class="sign-role">Parent / Guardian</div>
      </div>
    </div>
    <div class="sign-date">Date signed: <span contenteditable="true"></span></div>
  </div>`;
}

// ---------------------------------------------------------------------------
function fmtDatePH(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr + "T00:00:00").toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
}
