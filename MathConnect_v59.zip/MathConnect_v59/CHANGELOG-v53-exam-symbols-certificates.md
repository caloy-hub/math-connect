# MathConnect v53 — Exam math symbols + Station Certificates

Additive on top of v52. One new SQL migration (optional but recommended), no
existing tables/RLS/edge functions changed.

## 1. Exam questions now show math symbols properly
**New: `mathText.js`** — turns the way teachers naturally *type* math into how
students expect to *read* it. Applied to exam titles, descriptions, questions,
answer options, explanations and results (student side), and to the question
list, explanations editor, bulk-add preview and results (teacher side).

| Typed | Shown |
|---|---|
| `x^2`, `10^-3`, `4^(n+1)` | x², 10⁻³, 4ⁿ⁺¹ (real superscripts) |
| `H_2O`, `a_n`, `log_2(8)` | real subscripts |
| `sqrt(x+1)`, `cbrt(27)`, `\sqrt[3]{x}` | √ with a proper overbar / index |
| `1/2`, `(x+1)/(x-2)`, `\frac{a}{b}` | stacked fractions |
| `<=  >=  !=  +-  ->  =>  <->  ~=` | ≤ ≥ ≠ ± → ⇒ ↔ ≈ |
| `pi theta alpha … infinity` | π θ α … ∞ |
| `30^o`, `60 deg` | 30°, 60° |
| `3*4`, `\times \div \pm \angle \triangle …` | × ÷ ± ∠ △ … (LaTeX subset + `$…$`) |
| symbols pasted directly (∠ △ ≤ ∛ ℝ ½ …) | unchanged (now with a math-font fallback stack) |

Left alone on purpose: `5 km/h`, `3/5/2024`, `and/or`, `N/A`, `snake_case`, `$5 and $10`.
Everything is HTML-escaped before display (no injection risk).

**Teacher question editor:** new tabbed **symbol palette** (Basic · Compare · Powers &
roots · Greek · Geometry · Sets & logic · Calculus) that inserts real Unicode into
whichever field is focused, plus a live **"What students will see"** preview.
The palette is also in Bulk Add.

## 2. Certificates for every successful station
**New: `certificateEngine.js`** + `migration-61-station-certificates.sql`.

| Mode | Earns a certificate when… | Unique per |
|---|---|---|
| 🎮 Math Drills | run scores 7/10+ | station + level |
| 🗺️ Quest Mode | level cleared (7/10+); **bonus Chapter Champion** award when all 10 levels of a chapter are cleared | chapter + level / chapter |
| 🧠 Intelligent Practice | session scores 6/8+ | domain + tier reached |

Type by accuracy: **70–89% Certificate of Completion**, **90–99% Certificate of Award
(High Honors)**, **100% Certificate of Award (Perfect Score)**, Quest chapter → **Award (Chapter Champion)**.
Replaying a station keeps the *best* result (never downgrades); a better run upgrades it.

Each certificate prints: DepEd header + school name, student name, section/grade,
station name, mode/level line, score · accuracy · points/stars/mastery, date earned,
subject-teacher signature block (from the section's Class Settings), certificate
number, and a tier-coloured seal. A4 landscape, 300 dpi.

**Export:** *Download PDF* (real one-page A4 PDF, generated in-browser, works offline),
*Print* (one-page A4 landscape), *Save as image*. A **🎓 My Certificates** shelf
sits in the Drills, Quest and Practice hubs.

If `migration-61` hasn't been run yet, certificates are kept on the student's
device instead, so nothing breaks; run the migration to make them follow the
student across devices.

## Files
New: `mathText.js`, `certificateEngine.js`, `migration-61-station-certificates.sql`
Changed: `studentExamEngine.js`, `teacherExamEngine.js`, `drills.js`, `quest-ui.js`,
`adaptive-practice.js`, `student.html`, `teacher.html`, `style.css` (2 appended
sections), `service-worker.js` (cache bump to v53-1)

## Deploy
1. Supabase → SQL Editor → run `migration-61-station-certificates.sql`.
2. Redeploy the folder. Students may need one refresh to pick up the new cache.
3. Set each section's *Subject Teacher* name/position in Class Settings so it prints on certificates.
