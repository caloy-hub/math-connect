-- ============================================================================
-- Migration 35 — Math Pet: peak-stage immunity + mentor system.
-- Run this once in Supabase → SQL Editor, AFTER migration-34-pet-rollout-fix.sql.
--
-- WHAT'S NEW (per the agreed plan):
--   - Reaching the Legendary stage (growth_points >= 5000, the same threshold
--     PET_GROWTH_STAGES uses client-side in petEngine.js — keep both in sync
--     if that number ever changes) now means something mechanically, not
--     just cosmetically: the pet becomes IMMUNE to hunger decay, sickness,
--     and death. check_pet_wellbeing() skips a peak pet entirely.
--   - A student may now own MORE THAN ONE living pet at a time — but only by
--     earning it: adopt_pet() only blocks a new adoption while the student
--     has a pet that is still growing (< 5000 growth points). Once every
--     pet they own has peaked, they're free to adopt another and start it
--     from zero. This REPLACES the old flat 3-adoption lifetime cap from
--     migration-33 — growth to Legendary is already a real grind, so it's
--     the natural pacing limiter now.
--   - A peaked pet can be assigned as a MENTOR to exactly one growing pet at
--     a time (assign_pet_mentor / unassign_pet_mentor). While mentoring,
--     the mentee's Green-Point feeding grows it 1.5x as fast. A mentee that
--     itself reaches peak automatically "graduates" and frees its mentor to
--     be reassigned elsewhere.
--   - A peaked pet can still be fed for fun (Green Points / food / care
--     items all keep working on it) — it just no longer NEEDS it.
--
-- DESIGN NOTES:
--   - migration-33 added a PARTIAL UNIQUE INDEX enforcing "at most one
--     living pet per student." That's exactly the constraint this feature
--     needs to relax, so it's dropped here.
--   - Every pet-scoped RPC (feed/purchase/use/equip/rename) previously took
--     just target_student_id and did `where student_id = ... and alive`,
--     which only worked because a student could never have more than one
--     living pet. Now that they can, every one of those RPCs is recreated
--     here to also take target_pet_id, scoped by `id = target_pet_id and
--     student_id = target_student_id` (defense in depth against a tampered
--     client passing someone else's pet id). Old single-arg versions are
--     explicitly DROPPED first — Postgres/PostgREST would otherwise keep
--     both signatures around as overloads, which breaks RPC resolution.
--   - check_pet_wellbeing() used to return a single row for the student's
--     one pet; it now loops every living pet the student owns and returns
--     one row per pet (with a pet_id column added so the client knows which
--     is which), same "computed lazily, written back on next touch" idea.
-- ============================================================================

-- ---------- Relax the one-living-pet-per-student constraint ----------
drop index if exists student_pets_alive_unique;

-- ---------- Mentor assignment ----------
alter table student_pets add column if not exists assigned_mentor_id uuid references student_pets(id) on delete set null;
-- A mentor pet can only mentor ONE pet at a time.
drop index if exists student_pets_mentor_unique;
create unique index student_pets_mentor_unique on student_pets (assigned_mentor_id) where assigned_mentor_id is not null;

-- ---------- Shared "has this pet peaked?" check (keep threshold in sync
-- with the Legendary entry in PET_GROWTH_STAGES, petEngine.js) ----------
create or replace function public.is_pet_peak(gp integer)
returns boolean language sql immutable as $$
  select coalesce(gp, 0) >= 5000;
$$;

-- ============================================================================
-- ADOPT — replaces the migration-33 version. Drops the flat 3-adoption cap;
-- instead gates on "no currently-growing living pet" so a student can only
-- ever be actively raising one pet, but may keep adopting new ones forever
-- as each prior one reaches peak.
-- ============================================================================
create or replace function public.adopt_pet(target_student_id uuid, target_pet_type_key text, target_pet_name text default null)
returns table(success boolean, message text, pet jsonb)
language plpgsql security definer as $$
declare
  type_active boolean;
  used_count integer;
begin
  select active into type_active from pet_types where key = target_pet_type_key;
  if type_active is null then
    return query select false, 'That pet does not exist.', null::jsonb;
    return;
  end if;
  if not type_active then
    return query select false, 'That pet is not available right now.', null::jsonb;
    return;
  end if;

  perform 1 from student_pets where student_id = target_student_id and alive and not is_pet_peak(growth_points) for update;
  if found then
    return query select false, 'You already have a pet that''s still growing — help it reach Legendary before adopting another!', null::jsonb;
    return;
  end if;

  select count(*) into used_count from student_pets where student_id = target_student_id;

  declare v record;
  begin
    insert into student_pets (
      student_id, pet_type_key, pet_name, hunger, growth_points, food_inventory,
      alive, adoption_number
    ) values (
      target_student_id, target_pet_type_key, nullif(trim(target_pet_name), ''), 100, 0, '{}'::jsonb,
      true, used_count + 1
    ) returning * into v;
    return query select true, 'Adopted!', to_jsonb(v);
  end;
end;
$$;
grant execute on function public.adopt_pet(uuid, text, text) to anon, authenticated;

-- ============================================================================
-- ASSIGN / UNASSIGN MENTOR
-- ============================================================================
create or replace function public.assign_pet_mentor(target_student_id uuid, mentor_pet_id uuid, mentee_pet_id uuid)
returns table(success boolean, message text)
language plpgsql security definer as $$
declare
  mentor record;
  mentee record;
  already_mentoring uuid;
begin
  if mentor_pet_id = mentee_pet_id then
    return query select false, 'A pet can''t mentor itself!';
    return;
  end if;

  select * into mentor from student_pets where id = mentor_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That mentor pet was not found.';
    return;
  end if;
  if not is_pet_peak(mentor.growth_points) then
    return query select false, 'Only a pet that has reached Legendary can mentor another.';
    return;
  end if;

  select * into mentee from student_pets where id = mentee_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That pet was not found.';
    return;
  end if;
  if is_pet_peak(mentee.growth_points) then
    return query select false, 'That pet has already reached Legendary — it doesn''t need a mentor.';
    return;
  end if;

  select id into already_mentoring from student_pets where assigned_mentor_id = mentor_pet_id;
  if already_mentoring is not null and already_mentoring <> mentee_pet_id then
    return query select false, 'That mentor is already helping a different pet grow. Unassign it first.';
    return;
  end if;

  update student_pets set assigned_mentor_id = mentor_pet_id, updated_at = now() where id = mentee_pet_id;
  return query select true, format('🎓 %s is now mentoring %s — 1.5x growth while assigned!',
    coalesce(mentor.pet_name, 'Your Legendary pet'), coalesce(mentee.pet_name, 'your new pet'));
end;
$$;
grant execute on function public.assign_pet_mentor(uuid, uuid, uuid) to anon, authenticated;

create or replace function public.unassign_pet_mentor(target_student_id uuid, mentee_pet_id uuid)
returns table(success boolean, message text)
language plpgsql security definer as $$
begin
  update student_pets set assigned_mentor_id = null, updated_at = now()
  where id = mentee_pet_id and student_id = target_student_id;
  if not found then
    return query select false, 'That pet was not found.';
    return;
  end if;
  return query select true, 'Mentor unassigned.';
end;
$$;
grant execute on function public.unassign_pet_mentor(uuid, uuid) to anon, authenticated;

-- ============================================================================
-- WELLBEING CHECK — now loops every living pet the student owns. Peak pets
-- are skipped entirely (immune to hunger decay, sickness, and death).
--
-- Timeline eased for students with unreliable home internet: full hunger
-- drain now takes 36 hours (was 24), and a sick-but-untreated pet has
-- another 36 hours before it dies (was 24) — 3 days of total neglect
-- before death, up from 2. Keep in sync with PET_HUNGER_FULL_DRAIN_HOURS
-- in petEngine.js.
-- ============================================================================
drop function if exists public.check_pet_wellbeing(uuid);
create or replace function public.check_pet_wellbeing(target_student_id uuid)
returns table(pet_id uuid, success boolean, alive boolean, sick boolean, live_hunger integer, died boolean, cause_of_death text, is_peak boolean)
language plpgsql security definer as $$
declare
  pet record;
  hours_since numeric;
  decay_rate numeric := 100.0 / 36.0; -- full drain in 36h, baseline
  discount numeric;
  live_hunger_val integer;
  item_decay integer;
begin
  for pet in select sp.* from student_pets sp where sp.student_id = target_student_id and sp.alive for update loop

    if is_pet_peak(pet.growth_points) then
      -- Peak pets are immune: no decay, no sickness, no death.
      return query select pet.id, true, true, false, pet.hunger, false, null::text, true;
      continue;
    end if;

    discount := 0;
    hours_since := greatest(0, extract(epoch from (now() - coalesce(pet.last_fed_at, pet.adopted_at, now()))) / 3600.0);

    if pet.vitamin_boost_until is not null and pet.vitamin_boost_until > now() then
      discount := greatest(discount, 0.5);
    end if;
    if pet.equipped_item is not null then
      select decay_reduction_pct into item_decay from pet_care_items where key = pet.equipped_item and category = 'equipment';
      if item_decay is not null then discount := least(0.9, discount + item_decay / 100.0); end if;
    end if;

    live_hunger_val := greatest(0, least(100, round(pet.hunger - (hours_since * decay_rate * (1 - discount)))));

    if live_hunger_val <= 0 and not pet.sick and (pet.vaccinated_until is null or pet.vaccinated_until < now()) then
      update student_pets set sick = true, sick_since = now(), updated_at = now() where id = pet.id;
      pet.sick := true; pet.sick_since := now();
    end if;

    if pet.sick and pet.sick_since is not null and (now() - pet.sick_since) > interval '36 hours'
       and (pet.vaccinated_until is null or pet.vaccinated_until < pet.sick_since) then
      update student_pets set alive = false, died_at = now(), cause_of_death = 'untreated_illness', updated_at = now() where id = pet.id;
      return query select pet.id, true, false, true, live_hunger_val, true, 'untreated_illness', false;
      continue;
    end if;

    if live_hunger_val <= 0 and hours_since > 108 then
      update student_pets set alive = false, died_at = now(), cause_of_death = 'starvation', updated_at = now() where id = pet.id;
      return query select pet.id, true, false, pet.sick, live_hunger_val, true, 'starvation', false;
      continue;
    end if;

    return query select pet.id, true, true, pet.sick, live_hunger_val, false, null::text, false;
  end loop;
  return;
end;
$$;
grant execute on function public.check_pet_wellbeing(uuid) to anon, authenticated;

-- ============================================================================
-- FEED WITH GREEN POINTS — now per-pet, applies the 1.5x mentor boost to
-- growth (not to hunger — hunger restore stays 1:1 with amount spent), and
-- auto-graduates a mentee that crosses the peak threshold, freeing its
-- mentor to be reassigned.
-- ============================================================================
drop function if exists public.feed_pet_green_points(uuid, integer);
create or replace function public.feed_pet_green_points(target_student_id uuid, target_pet_id uuid, amount integer)
returns table(success boolean, message text, new_green_points integer, new_hunger integer, new_growth_points integer, growth_gain integer, mentor_graduated boolean)
language plpgsql security definer as $$
declare
  current_gp integer;
  pet record;
  mentor_active boolean := false;
  gain integer;
  new_growth integer;
  graduated boolean := false;
begin
  if amount is null or amount <= 0 then
    return query select false, 'Invalid amount.', null::integer, null::integer, null::integer, null::integer, false;
    return;
  end if;

  select green_points into current_gp from student_engagement where student_id = target_student_id for update;
  if current_gp is null then
    return query select false, 'No Green Points wallet found yet — go play something first!', null::integer, null::integer, null::integer, null::integer, false;
    return;
  end if;
  if current_gp < amount then
    return query select false, format('Not enough Green Points — need %s, have %s.', amount, current_gp), current_gp, null::integer, null::integer, null::integer, false;
    return;
  end if;

  select * into pet from student_pets where id = target_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That pet was not found.', current_gp, null::integer, null::integer, null::integer, false;
    return;
  end if;

  if pet.assigned_mentor_id is not null then
    select true into mentor_active from student_pets
      where id = pet.assigned_mentor_id and student_id = target_student_id and alive and is_pet_peak(growth_points);
  end if;

  gain := case when mentor_active then round(amount * 1.5) else amount end;
  new_growth := pet.growth_points + gain;
  graduated := coalesce(mentor_active, false) and is_pet_peak(new_growth);

  current_gp := current_gp - amount;
  update student_engagement set green_points = current_gp, updated_at = now() where student_id = target_student_id;

  update student_pets
    set growth_points = new_growth,
        hunger = least(100, pet.hunger + amount),
        assigned_mentor_id = case when graduated then null else pet.assigned_mentor_id end,
        last_fed_at = now(), updated_at = now()
    where id = pet.id
    returning hunger, growth_points into pet.hunger, pet.growth_points;

  insert into pet_feed_log (student_id, fed_with, amount) values (target_student_id, 'green_points', amount);

  return query select true, 'Fed!', current_gp, pet.hunger, pet.growth_points, gain, graduated;
end;
$$;
grant execute on function public.feed_pet_green_points(uuid, uuid, integer) to anon, authenticated;

-- ============================================================================
-- PURCHASE / FEED food — now per-pet.
-- ============================================================================
drop function if exists public.purchase_pet_food(uuid, text);
create or replace function public.purchase_pet_food(target_student_id uuid, target_pet_id uuid, target_food_key text)
returns table(success boolean, message text, new_coins integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare
  food_cost integer;
  food_active boolean;
  current_coins integer;
  current_inventory jsonb;
  owned_count integer;
begin
  select cost_coins, active into food_cost, food_active from pet_food_items where key = target_food_key;
  if food_cost is null then
    return query select false, 'That food does not exist.', null::integer, null::jsonb;
    return;
  end if;
  if not food_active then
    return query select false, 'That food is no longer available.', null::integer, null::jsonb;
    return;
  end if;

  if not exists (select 1 from student_pets where id = target_pet_id and student_id = target_student_id) then
    return query select false, 'That pet was not found.', null::integer, null::jsonb;
    return;
  end if;

  select coins into current_coins from student_engagement where student_id = target_student_id for update;
  if current_coins is null then
    return query select false, 'No coin wallet found yet — go play something first!', null::integer, null::jsonb;
    return;
  end if;
  if current_coins < food_cost then
    return query select false, format('Not enough coins — need %s, have %s.', food_cost, current_coins), current_coins, null::jsonb;
    return;
  end if;

  select coalesce(food_inventory, '{}'::jsonb) into current_inventory from student_pets where id = target_pet_id for update;
  owned_count := coalesce((current_inventory ->> target_food_key)::integer, 0);
  current_inventory := jsonb_set(current_inventory, array[target_food_key], to_jsonb(owned_count + 1));
  current_coins := current_coins - food_cost;

  update student_engagement set coins = current_coins, updated_at = now() where student_id = target_student_id;
  update student_pets set food_inventory = current_inventory, updated_at = now() where id = target_pet_id;

  return query select true, 'Purchased!', current_coins, current_inventory;
end;
$$;
grant execute on function public.purchase_pet_food(uuid, uuid, text) to anon, authenticated;

drop function if exists public.feed_pet_food(uuid, text);
create or replace function public.feed_pet_food(target_student_id uuid, target_pet_id uuid, target_food_key text)
returns table(success boolean, message text, new_hunger integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare
  pet record;
  restore_amt integer;
  owned_count integer;
  new_inventory jsonb;
begin
  select restore_amount into restore_amt from pet_food_items where key = target_food_key;
  if restore_amt is null then
    return query select false, 'That food does not exist.', null::integer, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where id = target_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That pet was not found.', null::integer, null::jsonb;
    return;
  end if;

  owned_count := coalesce((pet.food_inventory ->> target_food_key)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that food — buy some in the Shop!', pet.hunger, pet.food_inventory;
    return;
  end if;

  new_inventory := jsonb_set(pet.food_inventory, array[target_food_key], to_jsonb(owned_count - 1));

  update student_pets
    set hunger = least(100, pet.hunger + restore_amt), food_inventory = new_inventory,
        last_fed_at = now(), updated_at = now()
    where id = pet.id
    returning hunger into pet.hunger;

  insert into pet_feed_log (student_id, fed_with, food_key, amount) values (target_student_id, 'food', target_food_key, restore_amt);

  return query select true, 'Fed!', pet.hunger, new_inventory;
end;
$$;
grant execute on function public.feed_pet_food(uuid, uuid, text) to anon, authenticated;

-- ============================================================================
-- PURCHASE / USE care items, EQUIP — now per-pet. Cheat Meal can no longer
-- make a peak (immune) pet sick.
-- ============================================================================
drop function if exists public.purchase_pet_care_item(uuid, text);
create or replace function public.purchase_pet_care_item(target_student_id uuid, target_pet_id uuid, target_item_key text)
returns table(success boolean, message text, new_coins integer, new_care_inventory jsonb, new_owned_equipment jsonb)
language plpgsql security definer as $$
declare
  item record;
  current_coins integer;
  pet record;
  current_inv jsonb;
  owned_count integer;
  already_owned boolean;
begin
  select * into item from pet_care_items where key = target_item_key and active;
  if not found then
    return query select false, 'That item does not exist.', null::integer, null::jsonb, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where id = target_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That pet was not found.', null::integer, null::jsonb, null::jsonb;
    return;
  end if;

  if item.category = 'equipment' then
    already_owned := pet.owned_equipment ? target_item_key;
    if already_owned then
      return query select false, 'You already own that.', null::integer, pet.care_inventory, pet.owned_equipment;
      return;
    end if;
  end if;

  select coins into current_coins from student_engagement where student_id = target_student_id for update;
  if current_coins is null or current_coins < item.cost_coins then
    return query select false, format('Not enough coins — need %s, have %s.', item.cost_coins, coalesce(current_coins, 0)), current_coins, null::jsonb, null::jsonb;
    return;
  end if;
  current_coins := current_coins - item.cost_coins;
  update student_engagement set coins = current_coins, updated_at = now() where student_id = target_student_id;

  if item.category = 'equipment' then
    update student_pets set owned_equipment = owned_equipment || to_jsonb(target_item_key), updated_at = now()
    where id = pet.id returning owned_equipment into current_inv;
    return query select true, 'Purchased!', current_coins, pet.care_inventory, current_inv;
  else
    current_inv := coalesce(pet.care_inventory, '{}'::jsonb);
    owned_count := coalesce((current_inv ->> target_item_key)::integer, 0);
    current_inv := jsonb_set(current_inv, array[target_item_key], to_jsonb(owned_count + 1));
    update student_pets set care_inventory = current_inv, updated_at = now() where id = pet.id;
    return query select true, 'Purchased!', current_coins, current_inv, pet.owned_equipment;
  end if;
end;
$$;
grant execute on function public.purchase_pet_care_item(uuid, uuid, text) to anon, authenticated;

drop function if exists public.use_pet_care_item(uuid, text);
create or replace function public.use_pet_care_item(target_student_id uuid, target_pet_id uuid, target_item_key text)
returns table(success boolean, message text, new_hunger integer, sick boolean, new_care_inventory jsonb)
language plpgsql security definer as $$
declare
  item record;
  pet record;
  owned_count integer;
  new_inv jsonb;
  got_sick boolean := false;
  protected boolean;
begin
  select * into item from pet_care_items where key = target_item_key and active and category in ('vitamin','vaccine','cheat_food');
  if not found then
    return query select false, 'That item can''t be used this way.', null::integer, null::boolean, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where id = target_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That pet was not found.', null::integer, null::boolean, null::jsonb;
    return;
  end if;

  owned_count := coalesce((pet.care_inventory ->> target_item_key)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that — buy some in the Shop!', pet.hunger, pet.sick, pet.care_inventory;
    return;
  end if;
  new_inv := jsonb_set(pet.care_inventory, array[target_item_key], to_jsonb(owned_count - 1));

  if item.category = 'vitamin' then
    update student_pets set
      vitamin_boost_until = greatest(coalesce(vitamin_boost_until, now()), now()) + (item.effect_hours || ' hours')::interval,
      care_inventory = new_inv, updated_at = now()
    where id = pet.id;
    return query select true, format('💊 Vitamins active for the next %s hours — hunger will drain slower.', item.effect_hours), pet.hunger, pet.sick, new_inv;

  elsif item.category = 'vaccine' then
    update student_pets set
      sick = false, sick_since = null,
      vaccinated_until = now() + (item.effect_hours || ' hours')::interval,
      care_inventory = new_inv, updated_at = now()
    where id = pet.id;
    return query select true, '💉 Vaccinated! Your pet is cured and protected for a while.', pet.hunger, false, new_inv;

  else -- cheat_food
    protected := (pet.vaccinated_until is not null and pet.vaccinated_until > now()) or is_pet_peak(pet.growth_points);
    got_sick := (not protected) and (random() * 100 < item.sickness_risk_pct);
    update student_pets set
      hunger = least(100, pet.hunger + item.restore_amount),
      sick = case when got_sick then true else pet.sick end,
      sick_since = case when got_sick and not pet.sick then now() else pet.sick_since end,
      care_inventory = new_inv, last_fed_at = now(), updated_at = now()
    where id = pet.id
    returning student_pets.hunger, student_pets.sick into pet.hunger, pet.sick;
    insert into pet_feed_log (student_id, fed_with, food_key, amount) values (target_student_id, 'food', target_item_key, item.restore_amount);
    return query select true,
      case when got_sick then '🍔 Yum... but that cheat meal made your pet sick! Grab a vaccine soon.' else '🍔 Yum! Hunger restored.' end,
      pet.hunger, pet.sick, new_inv;
  end if;
end;
$$;
grant execute on function public.use_pet_care_item(uuid, uuid, text) to anon, authenticated;

drop function if exists public.equip_pet_item(uuid, text);
create or replace function public.equip_pet_item(target_student_id uuid, target_pet_id uuid, target_item_key text default null)
returns table(success boolean, message text, new_equipped_item text)
language plpgsql security definer as $$
declare
  pet record;
begin
  select * into pet from student_pets where id = target_pet_id and student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'That pet was not found.', null::text;
    return;
  end if;

  if target_item_key is not null and not (pet.owned_equipment ? target_item_key) then
    return query select false, 'You don''t own that yet.', pet.equipped_item;
    return;
  end if;

  update student_pets set equipped_item = target_item_key, updated_at = now() where id = pet.id;
  return query select true, case when target_item_key is null then 'Unequipped.' else 'Equipped!' end, target_item_key;
end;
$$;
grant execute on function public.equip_pet_item(uuid, uuid, text) to anon, authenticated;

-- ============================================================================
-- RENAME — now per-pet.
-- ============================================================================
drop function if exists public.rename_pet(uuid, text);
create or replace function public.rename_pet(target_student_id uuid, target_pet_id uuid, new_name text)
returns table(success boolean, message text, new_pet_name text)
language plpgsql security definer as $$
declare
  cleaned text;
begin
  cleaned := nullif(trim(new_name), '');
  if cleaned is null then
    return query select false, 'Give your pet a name first!', null::text;
    return;
  end if;
  if length(cleaned) > 24 then
    return query select false, 'Keep the name to 24 characters or fewer.', null::text;
    return;
  end if;

  update student_pets set pet_name = cleaned, updated_at = now()
  where id = target_pet_id and student_id = target_student_id and alive
  returning pet_name into cleaned;

  if not found then
    return query select false, 'That pet was not found.', null::text;
    return;
  end if;

  return query select true, 'Renamed!', cleaned;
end;
$$;
grant execute on function public.rename_pet(uuid, uuid, text) to anon, authenticated;
