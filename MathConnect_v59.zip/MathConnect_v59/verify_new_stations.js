// Verification script (per the plan's "Automated Tests" section).
// Loads drills.js in a sandboxed VM context (no DOM/Supabase needed for the
// pure generator functions) and runs each of the 6 new stations through all
// 15 levels, 5 times each (450 total runs) checking for NaN / undefined /
// malformed answers.
const fs = require("fs");
const vm = require("vm");
const path = "/home/claude/mathconnect/MathConnect_v42/drills.js";
const code = fs.readFileSync(path, "utf8");
const sandbox = { console };
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: path });
// `const`-declared bindings (DRILL_GENERATORS, etc.) live in the vm context's
// lexical scope but aren't auto-attached to the context object the way `var`/
// function declarations are — expose what we need via a `var` in the same context.
vm.runInContext(
  "var __EXPORTS__ = { DRILL_GENERATORS, checkDrillAnswer, fmtDrillAnswer };",
  sandbox
);
Object.assign(sandbox, sandbox.__EXPORTS__);

const STATIONS = ["exponents", "equations", "factoring", "measurement", "coordinates", "pythagoras"];
let failures = 0;
let total = 0;

function isValidAnswer(q) {
  if (q == null || typeof q.prompt !== "string" || !q.prompt.length) return "missing/invalid prompt";
  if (!["integer", "decimal", "fraction"].includes(q.type)) return `unknown type: ${q.type}`;
  if (q.type === "fraction") {
    if (!q.answer || typeof q.answer.n !== "number" || typeof q.answer.d !== "number") return "bad fraction answer";
    if (Number.isNaN(q.answer.n) || Number.isNaN(q.answer.d) || q.answer.d === 0) return "NaN/zero-denominator fraction";
  } else {
    if (typeof q.answer !== "number" || Number.isNaN(q.answer) || !Number.isFinite(q.answer)) return "NaN/non-finite numeric answer";
    if (q.type === "integer" && !Number.isInteger(q.answer)) return `integer type but non-integer answer: ${q.answer}`;
  }
  // Round-trip through checkDrillAnswer with the "official" formatted answer.
  const formatted = sandbox.fmtDrillAnswer(q);
  if (!sandbox.checkDrillAnswer(q, formatted)) return `checkDrillAnswer rejected its own formatted answer "${formatted}"`;
  return null;
}

for (const station of STATIONS) {
  const gen = sandbox.DRILL_GENERATORS[station];
  if (typeof gen !== "function") { console.error(`FAIL: no generator registered for "${station}"`); failures++; continue; }
  for (let level = 1; level <= 15; level++) {
    for (let trial = 0; trial < 5; trial++) {
      total++;
      let q;
      try { q = gen(level); } catch (e) { console.error(`FAIL ${station} L${level} trial${trial}: threw ${e.message}`); failures++; continue; }
      const problem = isValidAnswer(q);
      if (problem) { console.error(`FAIL ${station} L${level} trial${trial}: ${problem} — prompt="${q && q.prompt}"`); failures++; }
    }
  }
}

console.log(`\n${total - failures}/${total} generator runs passed across ${STATIONS.length} stations × 15 levels × 5 trials.`);
if (failures > 0) { console.error(`${failures} FAILURES.`); process.exit(1); }
console.log("All checks passed — zero NaN / unhandled edge cases.");
