-- ============================================================================
-- MathConnect — Migration 48: School-wide Term Control
-- ----------------------------------------------------------------------------
-- PROBLEM THIS FIXES:
--   Each section already has its own three `terms` rows (term_number 1/2/3),
--   each with an `is_active` flag (see supabase-schema.sql, teacher.js's
--   ensureTerms()). But nothing ever FLIPS `is_active` after a section's
--   terms are first created — Term 1 is set active forever, section by
--   section, with no single "the whole school is now in Term 2" switch.
--   Admin's own "Term" dropdown (migration-6) only changes which term's
--   figures admin is LOOKING AT — it never touched is_active either.
--
-- WHAT THIS ADDS:
--   1. `school_settings` — one row (`id = 'global'`) holding
--      `current_term_number`, the school's single source of truth for
--      "what term is it right now". Publicly readable (students/teachers/
--      admin all need it), writable only by admins.
--   2. `admin_set_current_term(target_term_number)` — a SECURITY DEFINER
--      RPC, admin-only, that in one atomic call:
--        a) makes sure EVERY section (even ones no teacher has opened yet)
--           has all three Term 1/2/3 rows,
--        b) sets `is_active` on the matching term_number and clears it on
--           the other two, across EVERY section, and
--        c) records the new current_term_number in `school_settings`.
--      This is what makes the toggle "true to all classes" — one admin
--      click updates every section at once, not just the ones a teacher
--      has already visited.
--   3. Adds 'term_change' as a valid admin_action_log action_type so this
--      shows up in the existing Audit Log → Admin Actions tab.
--
--   teacher.js's ensureTerms() (a brand-new section that has no terms yet
--   because no teacher has opened its Class Record before) now reads
--   `school_settings.current_term_number` instead of always defaulting to
--   Term 1, so a class created mid-Term-2 starts in step with the rest of
--   the school. Existing per-class "view Term 1/2/3's past data" dropdowns
--   (teacher.js's #termSelect, admin.js's #termFilterSelect) are untouched
--   by this migration — this only changes which term counts as CURRENT.
--
-- Safe to run on your existing database — nothing is deleted.
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

create table if not exists school_settings (
  id text primary key default 'global',
  current_term_number int not null default 1 check (current_term_number in (1,2,3)),
  updated_at timestamptz default now(),
  updated_by uuid references admins(id) on delete set null
);
insert into school_settings (id, current_term_number) values ('global', 1)
  on conflict (id) do nothing;

alter table school_settings enable row level security;
drop policy if exists "public read school_settings" on school_settings;
create policy "public read school_settings" on school_settings for select using (true);
drop policy if exists "admin write school_settings" on school_settings;
create policy "admin write school_settings" on school_settings for all
  using (is_admin()) with check (is_admin());

-- Atomically: backfill any missing Term 1/2/3 rows for every section, flip
-- is_active across ALL sections' terms to match target_term_number, and
-- record it in school_settings. Re-checks is_admin() itself.
create or replace function public.admin_set_current_term(target_term_number int)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_sections_seeded int := 0;
  v_terms_updated int := 0;
begin
  if not is_admin() then
    raise exception 'only admins can change the current term';
  end if;
  if target_term_number is null or target_term_number not in (1,2,3) then
    return jsonb_build_object('error', 'Term must be 1, 2, or 3.');
  end if;

  -- Backfill: any section that has never had its Term rows created yet
  -- (no teacher has opened its Class Record) gets all three now, so the
  -- is_active flip below covers it too.
  insert into terms (section_id, term_number, term_name, school_year, is_active)
  select s.id, n.term_number, 'Term ' || n.term_number, s.school_year, (n.term_number = target_term_number)
  from sections s
  cross join (select unnest(array[1,2,3]) as term_number) n
  left join terms t on t.section_id = s.id and t.term_number = n.term_number
  where t.id is null;
  get diagnostics v_sections_seeded = row_count;

  update terms set is_active = (term_number = target_term_number)
  where is_active <> (term_number = target_term_number) or is_active is null;
  get diagnostics v_terms_updated = row_count;

  insert into school_settings (id, current_term_number, updated_at, updated_by)
  values ('global', target_term_number, now(), auth.uid())
  on conflict (id) do update set
    current_term_number = excluded.current_term_number,
    updated_at = now(),
    updated_by = excluded.updated_by;

  return jsonb_build_object('ok', true, 'terms_created', v_sections_seeded, 'terms_updated', v_terms_updated);
end;
$$;
-- Admin-only action, only ever called from an authenticated admin session.
grant execute on function public.admin_set_current_term(int) to authenticated;

alter table admin_action_log drop constraint if exists admin_action_log_action_type_check;
alter table admin_action_log add constraint admin_action_log_action_type_check
  check (action_type in (
    'status_change', 'edit_account', 'delete_account',
    'lock_change', 'edit_entry', 'delete_entry', 'finalize_champion',
    'password_reset', 'term_change'
  ));

-- ============================================================================
-- Done. Reload the admin panel — Admin Overview now has a "🗓️ School Term"
-- control (a Term 1 → 2 → 3 tracker you click to switch) that changes the
-- current term for every class at once. Existing per-class "view a past
-- term's data" dropdowns for teachers/students/admin still work exactly as
-- before and are unaffected.
-- ============================================================================
