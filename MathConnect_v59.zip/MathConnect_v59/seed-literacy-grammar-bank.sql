-- ============================================================================
-- MathConnect — Literacy Arena: Grammar Check station starter bank (Grades 7-10)
-- Run AFTER migration-59-literacy-arena.sql (skill_type already allows
-- 'grammar' and literacy_progress.station_points already has a grammar key —
-- no schema change needed here, this is content only).
--
-- Replaces the old Spelling Bee Station's role in the app. Focus is subject-
-- verb agreement (as requested), ramping from basic singular/plural matching
-- in Grade 7 to trickier agreement rules (collective nouns, "a number of" vs
-- "the number of", correlative conjunctions, fractions, inverted sentences)
-- by Grade 10. All multiple_choice — no audio, no typed spelling.
--
-- NOTE: this does not touch the old 'spelling' rows already seeded in
-- seed-literacy-question-bank.sql / seed-literacy-difficulty-expansion.sql.
-- They're simply no longer queried (literacyEngine.js no longer has a
-- 'spelling' station), so they sit harmlessly unused. Delete them later with
--   delete from literacy_questions where skill_type = 'spelling';
-- if you want to clean them up — safe to run any time, nothing reads them.
--
-- Safe to re-run: every insert is idempotent via a fixed id + ON CONFLICT.
-- ============================================================================

insert into literacy_questions (id, skill_type, grade_level, difficulty, question_format, prompt, choices, correct_answer, explanation)
values
-- ---------------------------------------------------------------------------
-- GRADE 7 — basic singular/plural agreement
-- ---------------------------------------------------------------------------
('24444444-0000-0000-0000-000000000001','grammar','Grade 7',1,'multiple_choice','The dog ___ in the yard every morning.','["bark","barks","barking","barked"]','barks','A singular subject ("dog") takes the -s form of the verb in present tense.'),
('24444444-0000-0000-0000-000000000002','grammar','Grade 7',1,'multiple_choice','The students ___ their homework every night.','["do","does","doing","did"]','do','A plural subject ("students") takes the base form, not the -s form.'),
('24444444-0000-0000-0000-000000000003','grammar','Grade 7',1,'multiple_choice','She ___ to school by tricycle.','["go","goes","going","gone"]','goes','Singular subject "she" pairs with the -es form of "go."'),
('24444444-0000-0000-0000-000000000004','grammar','Grade 7',1,'multiple_choice','My parents ___ proud of me.','["is","are","be","being"]','are','"Parents" is plural, so it takes "are," not "is."'),
('24444444-0000-0000-0000-000000000005','grammar','Grade 7',2,'multiple_choice','The teacher, along with her students, ___ preparing for the fair.','["is","are","were","being"]','is','The subject is "the teacher" — the phrase "along with her students" doesn''t change the subject to plural.'),
('24444444-0000-0000-0000-000000000006','grammar','Grade 7',2,'multiple_choice','Neither the boys nor the girl ___ ready.','["is","are","were","be"]','is','With "neither...nor," the verb agrees with the subject closer to it — "the girl" (singular).'),
('24444444-0000-0000-0000-000000000007','grammar','Grade 7',2,'multiple_choice','Everybody ___ excited for the field trip.','["is","are","were","being"]','is','Indefinite pronouns like "everybody," "everyone," and "somebody" are treated as singular.'),
('24444444-0000-0000-0000-000000000008','grammar','Grade 7',2,'multiple_choice','The scissors ___ on the table.','["is","are","was","being"]','are','Tool names like "scissors," "pants," and "glasses" are always treated as plural.'),
('24444444-0000-0000-0000-000000000009','grammar','Grade 7',2,'multiple_choice','Here ___ the answers to the quiz.','["is","are","was","be"]','are','When a sentence starts with "here" or "there," find the real subject after the verb — "answers" is plural.'),
('24444444-0000-0000-0000-000000000010','grammar','Grade 7',2,'multiple_choice','The committee ___ meeting today.','["is","are","were","being"]','is','A collective noun like "committee" is treated as one singular unit when it acts as a group.'),

-- ---------------------------------------------------------------------------
-- GRADE 8 — quantity phrases, collective nouns, either/or
-- ---------------------------------------------------------------------------
('24444444-0000-0000-0000-000000000011','grammar','Grade 8',2,'multiple_choice','Each of the students ___ a project to submit.','["has","have","having","had"]','has','"Each" is always singular, even when followed by "of the students."'),
('24444444-0000-0000-0000-000000000012','grammar','Grade 8',3,'multiple_choice','The number of applicants ___ increasing.','["is","are","was","were"]','is','"The number of" takes a singular verb — the focus is on "the number," a single figure.'),
('24444444-0000-0000-0000-000000000013','grammar','Grade 8',3,'multiple_choice','A number of applicants ___ interested.','["is","are","was","were"]','are','"A number of" takes a plural verb — here the focus shifts to "applicants," several people.'),
('24444444-0000-0000-0000-000000000014','grammar','Grade 8',3,'multiple_choice','Either the manager or the employees ___ responsible for the report.','["is","are","was","were"]','are','With "either...or," the verb agrees with the subject nearest to it — "the employees" (plural).'),
('24444444-0000-0000-0000-000000000015','grammar','Grade 8',2,'multiple_choice','The team ___ practicing for the tournament.','["is","are","were","being"]','is','"Team" is a collective noun acting as one unit here, so it takes a singular verb.'),
('24444444-0000-0000-0000-000000000016','grammar','Grade 8',2,'multiple_choice','Mathematics ___ my favorite subject.','["is","are","was","were"]','is','Subject names ending in -s, like "Mathematics" and "Physics," are treated as singular.'),
('24444444-0000-0000-0000-000000000017','grammar','Grade 8',2,'multiple_choice','The news about the typhoon ___ alarming.','["was","were","is","are"]','is','"News" looks plural but is always treated as singular.'),
('24444444-0000-0000-0000-000000000018','grammar','Grade 8',3,'multiple_choice','Ten kilometers ___ a long distance to walk.','["is","are","was","were"]','is','A measurement, distance, or amount is treated as one single unit and takes a singular verb.'),
('24444444-0000-0000-0000-000000000019','grammar','Grade 8',2,'multiple_choice','One of the machines ___ broken.','["is","are","was","were"]','is','"One of the..." always takes a singular verb — the subject is "one."'),
('24444444-0000-0000-0000-000000000020','grammar','Grade 8',2,'multiple_choice','The pair of shoes ___ too small.','["is","are","was","were"]','is','"Pair" names one unit here, so the verb stays singular.'),

-- ---------------------------------------------------------------------------
-- GRADE 9 — correlative conjunctions, academic subjects, inverted order
-- ---------------------------------------------------------------------------
('24444444-0000-0000-0000-000000000021','grammar','Grade 9',4,'multiple_choice','Not only the teacher but also the students ___ excited about the field trip.','["is","are","was","were"]','are','With "not only...but also," the verb agrees with the nearer subject — "the students" (plural).'),
('24444444-0000-0000-0000-000000000022','grammar','Grade 9',3,'multiple_choice','The economics of the situation ___ complicated.','["is","are","was","were"]','is','As a field of study, "economics" is treated as singular despite its -s ending.'),
('24444444-0000-0000-0000-000000000023','grammar','Grade 9',3,'multiple_choice','Everyone in the class ___ ready for the exam.','["is","are","were","being"]','is','"Everyone" is singular; the phrase "in the class" doesn''t change that.'),
('24444444-0000-0000-0000-000000000024','grammar','Grade 9',4,'multiple_choice','The majority of the voters ___ in favor of the proposal.','["is","are","was","were"]','are','"Majority of" followed by a plural countable noun ("voters") takes a plural verb.'),
('24444444-0000-0000-0000-000000000025','grammar','Grade 9',3,'multiple_choice','Either of the answers ___ correct.','["is","are","was","were"]','is','"Either" (meaning "one or the other") is singular on its own.'),
('24444444-0000-0000-0000-000000000026','grammar','Grade 9',3,'multiple_choice','The committee members ___ arguing among themselves.','["is","are","was","were"]','are','Here the subject is "members" (plural), not the collective "committee" itself.'),
('24444444-0000-0000-0000-000000000027','grammar','Grade 9',3,'multiple_choice','Physics ___ known for being a challenging subject.','["is","are","was","were"]','is','Like "Mathematics," "Physics" is a subject name treated as singular.'),
('24444444-0000-0000-0000-000000000028','grammar','Grade 9',3,'multiple_choice','There ___ several reasons for the delay.','["is","are","was","be"]','are','After "there," find the true subject — "reasons" (plural) — to pick the verb.'),
('24444444-0000-0000-0000-000000000029','grammar','Grade 9',3,'multiple_choice','The flock of birds ___ flying south for the winter.','["is","are","was","were"]','is','"Flock" is the collective-noun subject, acting as one group, so the verb stays singular.'),
('24444444-0000-0000-0000-000000000030','grammar','Grade 9',4,'multiple_choice','Neither of the two boys ___ finished the assignment.','["has","have","having","had"]','has','"Neither" is singular, even when followed by "of the two boys."'),

-- ---------------------------------------------------------------------------
-- GRADE 10 — formal/academic usage, fractions, series, inverted "what" clauses
-- ---------------------------------------------------------------------------
('24444444-0000-0000-0000-000000000031','grammar','Grade 10',5,'multiple_choice','The data ___ inconclusive.','["is","are","was","were"]','are','In formal academic usage, "data" (plural of "datum") takes a plural verb.'),
('24444444-0000-0000-0000-000000000032','grammar','Grade 10',4,'multiple_choice','Statistics ___ a required course for engineering students.','["is","are","was","were"]','is','As the name of a field of study, "Statistics" is treated as singular.'),
('24444444-0000-0000-0000-000000000033','grammar','Grade 10',4,'multiple_choice','A great number of students ___ absent today due to the flood.','["is","are","was","were"]','are','"A number of" + a plural noun ("students") takes a plural verb.'),
('24444444-0000-0000-0000-000000000034','grammar','Grade 10',4,'multiple_choice','The board of directors ___ meeting behind closed doors.','["is","are","were","being"]','is','"Board" is the collective-noun subject, acting as one unit, so the verb is singular.'),
('24444444-0000-0000-0000-000000000035','grammar','Grade 10',5,'multiple_choice','One-third of the harvest ___ damaged by the storm.','["was","were","is","are"]','was','With fractions, the verb agrees with the noun that follows "of" — "harvest" is singular.'),
('24444444-0000-0000-0000-000000000036','grammar','Grade 10',5,'multiple_choice','One-third of the mangoes ___ damaged by the storm.','["was","were","is","are"]','were','Same fraction rule, but "mangoes" is plural, so the verb switches to plural too.'),
('24444444-0000-0000-0000-000000000037','grammar','Grade 10',4,'multiple_choice','Neither the principal nor the teachers ___ available for a meeting today.','["is","are","was","were"]','are','With "neither...nor," the verb agrees with the nearer subject — "the teachers" (plural).'),
('24444444-0000-0000-0000-000000000038','grammar','Grade 10',4,'multiple_choice','The series of workshops ___ scheduled for next month.','["is","are","were","being"]','is','"Series" is the subject and is grammatically singular whether it refers to one item or many.'),
('24444444-0000-0000-0000-000000000039','grammar','Grade 10',5,'multiple_choice','What ___ needed here is more cooperation.','["is","are","was","were"]','is','The clause "what is needed here" functions as a singular subject as a whole.'),
('24444444-0000-0000-0000-000000000040','grammar','Grade 10',4,'multiple_choice','Each student and each teacher ___ expected to attend the assembly.','["is","are","was","were"]','is','When subjects are joined by "each...and each...," the verb stays singular.')
on conflict (id) do nothing;

-- ============================================================================
-- Done. 40 grammar questions (10 per grade level 7-10), all multiple_choice,
-- all subject-verb agreement. grade_level values match the plain "Grade 7"
-- .."Grade 10" strings used elsewhere (sections.grade_level) — if your
-- sections use a different format, update grade_level here to match, or
-- adjust fetchLiteracyQuestions() in literacyEngine.js instead.
-- ============================================================================
