// ============================================================================
// MathConnect — Full-Body Animated Virtual Pet Visuals (petVisuals.js)
//
// Generates lightweight, rigged vector (SVG) full-body models for all 10
// pet species across all growth stages. Each pet features segmented parts
// (body, head, eyes, ears, tail, limbs, shadow) bound to CSS keyframe
// animations for organic breathing, eyelid blinking, ear/tail twitches,
// walking steps, and celebratory hops.
// ============================================================================

const PET_PALETTES = {
  numo_fox: {
    primary: "#F97316",
    secondary: "#EA580C",
    belly: "#FFF7ED",
    earInner: "#FDBA74",
    dark: "#1C1917",
    accents: "#FB923C",
    eyeColor: "#0284C7"
  },
  pico_penguin: {
    primary: "#1E293B",
    secondary: "#0F172A",
    belly: "#F8FAFC",
    earInner: "#38BDF8",
    dark: "#090D16",
    accents: "#F59E0B",
    eyeColor: "#0EA5E9"
  },
  digit_dragon: {
    primary: "#10B981",
    secondary: "#047857",
    belly: "#D1FAE5",
    earInner: "#A7F3D0",
    dark: "#064E3B",
    accents: "#F59E0B",
    eyeColor: "#6366F1"
  },
  sumi_bunny: {
    primary: "#F1F5F9",
    secondary: "#E2E8F0",
    belly: "#FFFFFF",
    earInner: "#FDA4AF",
    dark: "#334155",
    accents: "#FB7185",
    eyeColor: "#E11D48"
  },
  ari_owl: {
    primary: "#8B5CF6",
    secondary: "#6D28D9",
    belly: "#EDE9FE",
    earInner: "#DDD6FE",
    dark: "#2E1065",
    accents: "#F59E0B",
    eyeColor: "#F59E0B"
  },
  tala_turtle: {
    primary: "#14B8A6",
    secondary: "#0F766E",
    belly: "#CCFBF1",
    earInner: "#5EEAD4",
    dark: "#134E4A",
    accents: "#F59E0B",
    eyeColor: "#0369A1"
  },
  byte_cat: {
    primary: "#64748B",
    secondary: "#475569",
    belly: "#F1F5F9",
    earInner: "#F472B6",
    dark: "#1E293B",
    accents: "#38BDF8",
    eyeColor: "#10B981"
  },
  kiri_calf: {
    primary: "#FB923C",
    secondary: "#EA580C",
    belly: "#FFF7ED",
    earInner: "#FECDD3",
    dark: "#431407",
    accents: "#78350F",
    eyeColor: "#475569"
  },
  vex_wolf: {
    primary: "#475569",
    secondary: "#334155",
    belly: "#E2E8F0",
    earInner: "#94A3B8",
    dark: "#0F172A",
    accents: "#38BDF8",
    eyeColor: "#FBBF24"
  },
  zeta_steed: {
    primary: "#6366F1",
    secondary: "#4338CA",
    belly: "#EEF2FF",
    earInner: "#C7D2FE",
    dark: "#1E1B4B",
    accents: "#F59E0B",
    eyeColor: "#818CF8"
  }
};

/**
 * Generates the multi-part rigged SVG string for a pet.
 * @param {string} petTypeKey - e.g. "numo_fox", "sumi_bunny"
 * @param {string} stageLabel - e.g. "Hatchling", "Thriving", "Champion"
 * @param {number} sizePx - rendered size in pixels
 * @param {string} moodState - "idle", "happy", "sleep", "chew", etc.
 */
function generatePetSvg(petTypeKey, stageLabel, sizePx, moodState) {
  const p = PET_PALETTES[petTypeKey] || PET_PALETTES.sumi_bunny;
  const size = sizePx || 120;
  const isSleep = moodState === "sleep" || moodState === "pet-anim-sleep";
  const isHappy = moodState === "happy" || moodState === "pet-anim-happy-idle" || moodState === "celebrate";
  const isBaby = stageLabel === "Hatchling" || stageLabel === "Growing";
  const isChampion = stageLabel === "Champion" || stageLabel === "Radiant" || stageLabel === "Ascendant";

  let specificFeatures = "";
  let ears = "";
  let tail = "";
  let accents = "";

  // Dynamic pet-specific appendages and characteristics
  switch (petTypeKey) {
    case "numo_fox":
      ears = `
        <polygon class="pet-part-ear pet-ear-left" points="36,44 26,14 52,28" fill="${p.primary}" />
        <polygon class="pet-part-ear-inner pet-ear-left" points="37,40 30,20 48,30" fill="${p.earInner}" />
        <polygon class="pet-part-ear pet-ear-right" points="64,44 74,14 48,28" fill="${p.primary}" />
        <polygon class="pet-part-ear-inner pet-ear-right" points="63,40 70,20 52,30" fill="${p.earInner}" />
      `;
      tail = `
        <path class="pet-part-tail" d="M72,74 Q96,68 94,48 Q82,54 74,68 Z" fill="${p.primary}" />
        <path class="pet-part-tail-tip" d="M94,48 Q91,52 86,51 Q89,48 94,48 Z" fill="${p.belly}" />
      `;
      specificFeatures = `
        <!-- Fox cheek tufts & muzzle -->
        <polygon points="34,54 24,56 36,60" fill="${p.belly}" />
        <polygon points="66,54 76,56 64,60" fill="${p.belly}" />
        <polygon points="46,56 54,56 50,60" fill="${p.dark}" />
      `;
      break;

    case "sumi_bunny":
      ears = `
        <g class="pet-part-ear pet-ear-left">
          <ellipse cx="38" cy="20" rx="7" ry="19" transform="rotate(-10 38 20)" fill="${p.primary}" stroke="${p.secondary}" stroke-width="1.5" />
          <ellipse cx="38" cy="20" rx="4" ry="14" transform="rotate(-10 38 20)" fill="${p.earInner}" />
        </g>
        <g class="pet-part-ear pet-ear-right">
          <ellipse cx="62" cy="20" rx="7" ry="19" transform="rotate(10 62 20)" fill="${p.primary}" stroke="${p.secondary}" stroke-width="1.5" />
          <ellipse cx="62" cy="20" rx="4" ry="14" transform="rotate(10 62 20)" fill="${p.earInner}" />
        </g>
      `;
      tail = `<circle class="pet-part-tail" cx="72" cy="74" r="7" fill="${p.belly}" />`;
      specificFeatures = `
        <!-- Bunny nose & whiskers -->
        <ellipse cx="50" cy="57" rx="3" ry="2" fill="${p.accents}" />
        <line x1="33" y1="56" x2="22" y2="54" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
        <line x1="33" y1="59" x2="23" y2="60" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
        <line x1="67" y1="56" x2="78" y2="54" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
        <line x1="67" y1="59" x2="77" y2="60" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
      `;
      break;

    case "pico_penguin":
      ears = ""; // Penguins have sleek heads
      tail = `<ellipse class="pet-part-tail" cx="50" cy="84" rx="10" ry="3" fill="${p.secondary}" />`;
      specificFeatures = `
        <!-- Penguin beak & flippers -->
        <polygon points="46,55 54,55 50,62" fill="${p.accents}" />
        <ellipse class="pet-part-limb pet-arm-left" cx="29" cy="65" rx="5" ry="14" transform="rotate(22 29 65)" fill="${p.primary}" />
        <ellipse class="pet-part-limb pet-arm-right" cx="71" cy="65" rx="5" ry="14" transform="rotate(-22 71 65)" fill="${p.primary}" />
      `;
      break;

    case "digit_dragon":
      ears = `
        <!-- Dragon horns -->
        <polygon class="pet-part-ear pet-ear-left" points="36,40 28,18 42,32" fill="${p.accents}" />
        <polygon class="pet-part-ear pet-ear-right" points="64,40 72,18 58,32" fill="${p.accents}" />
      `;
      tail = `
        <path class="pet-part-tail" d="M70,72 Q92,72 88,56 Q80,62 70,68 Z" fill="${p.primary}" />
        <polygon points="88,56 94,52 90,60" fill="${p.accents}" />
      `;
      specificFeatures = `
        <!-- Dragon wings & snout -->
        <path class="pet-part-wing" d="M30,60 Q14,46 22,34 Q28,48 34,56 Z" fill="${p.secondary}" opacity="0.85" />
        <path class="pet-part-wing" d="M70,60 Q86,46 78,34 Q72,48 66,56 Z" fill="${p.secondary}" opacity="0.85" />
        <ellipse cx="50" cy="58" rx="8" ry="5" fill="${p.belly}" />
        <circle cx="47" cy="58" r="1.2" fill="${p.dark}" />
        <circle cx="53" cy="58" r="1.2" fill="${p.dark}" />
      `;
      break;

    case "ari_owl":
      ears = `
        <!-- Owl ear tufts -->
        <polygon class="pet-part-ear pet-ear-left" points="34,36 28,18 42,28" fill="${p.primary}" />
        <polygon class="pet-part-ear pet-ear-right" points="66,36 72,18 58,28" fill="${p.primary}" />
      `;
      tail = `<path class="pet-part-tail" d="M44,82 L50,88 L56,82 Z" fill="${p.secondary}" />`;
      specificFeatures = `
        <!-- Big round eye rings & beak -->
        <circle cx="41" cy="48" r="11" fill="${p.belly}" />
        <circle cx="59" cy="48" r="11" fill="${p.belly}" />
        <polygon points="48,52 52,52 50,58" fill="${p.accents}" />
        <!-- Wings -->
        <ellipse class="pet-part-limb pet-arm-left" cx="29" cy="64" rx="6" ry="15" transform="rotate(15 29 64)" fill="${p.secondary}" />
        <ellipse class="pet-part-limb pet-arm-right" cx="71" cy="64" rx="6" ry="15" transform="rotate(-15 71 64)" fill="${p.secondary}" />
      `;
      break;

    case "byte_cat":
      ears = `
        <polygon class="pet-part-ear pet-ear-left" points="36,40 28,18 46,30" fill="${p.primary}" />
        <polygon class="pet-part-ear-inner pet-ear-left" points="36,36 31,23 43,29" fill="${p.earInner}" />
        <polygon class="pet-part-ear pet-ear-right" points="64,40 72,18 54,30" fill="${p.primary}" />
        <polygon class="pet-part-ear-inner pet-ear-right" points="64,36 69,23 57,29" fill="${p.earInner}" />
      `;
      tail = `<path class="pet-part-tail" d="M70,72 Q92,70 88,48 Q84,48 83,56 Q80,68 70,70 Z" fill="${p.primary}" />`;
      specificFeatures = `
        <!-- Whiskers & nose -->
        <polygon points="48,56 52,56 50,59" fill="${p.earInner}" />
        <line x1="33" y1="56" x2="22" y2="55" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
        <line x1="33" y1="59" x2="23" y2="61" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
        <line x1="67" y1="56" x2="78" y2="55" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
        <line x1="67" y1="59" x2="77" y2="61" stroke="${p.secondary}" stroke-width="1.2" stroke-linecap="round" />
      `;
      break;

    case "tala_turtle":
      ears = "";
      tail = `<polygon class="pet-part-tail" points="48,80 52,80 50,86" fill="${p.primary}" />`;
      specificFeatures = `
        <!-- Turtle shell plate details -->
        <ellipse cx="50" cy="65" rx="20" ry="16" fill="${p.secondary}" />
        <polygon points="50,55 58,61 55,70 45,70 42,61" fill="${p.primary}" opacity="0.9" />
        <ellipse cx="50" cy="58" rx="6" ry="4" fill="${p.belly}" />
      `;
      break;

    case "kiri_calf":
      ears = `
        <!-- Calf floppy ears & little horns -->
        <polygon points="38,36 32,22 42,32" fill="${p.accents}" />
        <polygon points="62,36 68,22 58,32" fill="${p.accents}" />
        <ellipse class="pet-part-ear pet-ear-left" cx="29" cy="42" rx="9" ry="5" transform="rotate(-15 29 42)" fill="${p.primary}" />
        <ellipse class="pet-part-ear pet-ear-right" cx="71" cy="42" rx="9" ry="5" transform="rotate(15 71 42)" fill="${p.primary}" />
      `;
      tail = `<path class="pet-part-tail" d="M70,72 Q86,72 82,84" stroke="${p.primary}" stroke-width="3" fill="none" />`;
      specificFeatures = `
        <!-- Muzzle -->
        <ellipse cx="50" cy="60" rx="12" ry="7" fill="${p.earInner}" />
        <circle cx="46" cy="60" r="1.5" fill="${p.dark}" />
        <circle cx="54" cy="60" r="1.5" fill="${p.dark}" />
      `;
      break;

    case "vex_wolf":
      ears = `
        <polygon class="pet-part-ear pet-ear-left" points="36,40 28,14 46,28" fill="${p.primary}" />
        <polygon class="pet-part-ear-inner pet-ear-left" points="36,36 30,19 43,27" fill="${p.earInner}" />
        <polygon class="pet-part-ear pet-ear-right" points="64,40 72,14 54,28" fill="${p.primary}" />
        <polygon class="pet-part-ear-inner pet-ear-right" points="64,36 70,19 57,27" fill="${p.earInner}" />
      `;
      tail = `<path class="pet-part-tail" d="M70,72 Q94,66 90,46 Q80,54 72,66 Z" fill="${p.primary}" />`;
      specificFeatures = `
        <!-- Wolf snout & fur ruff -->
        <polygon points="32,54 22,57 34,62" fill="${p.secondary}" />
        <polygon points="68,54 78,57 66,62" fill="${p.secondary}" />
        <polygon points="46,55 54,55 50,60" fill="${p.dark}" />
      `;
      break;

    case "zeta_steed":
      ears = `
        <polygon class="pet-part-ear pet-ear-left" points="38,36 32,18 44,28" fill="${p.primary}" />
        <polygon class="pet-part-ear pet-ear-right" points="62,36 68,18 56,28" fill="${p.primary}" />
      `;
      tail = `<path class="pet-part-tail" d="M70,72 Q92,72 88,88 Q82,80 72,76 Z" fill="${p.accents}" />`;
      specificFeatures = `
        <!-- Flowing mane & horse snout -->
        <path d="M46,22 Q50,14 54,22 Q48,32 52,40" stroke="${p.accents}" stroke-width="4" stroke-linecap="round" fill="none" />
        <ellipse cx="50" cy="59" rx="9" ry="6" fill="${p.secondary}" />
        <circle cx="47" cy="60" r="1.3" fill="${p.dark}" />
        <circle cx="53" cy="60" r="1.3" fill="${p.dark}" />
      `;
      break;
  }

  // Champion / Radiant crown & sparkle accents
  if (isChampion) {
    accents += `
      <g class="pet-part-crown" transform="translate(0, -6)">
        <polygon points="42,22 45,14 50,18 55,14 58,22" fill="#F59E0B" stroke="#B45309" stroke-width="1" />
        <circle cx="50" cy="18" r="1.8" fill="#EF4444" />
      </g>
    `;
  }

  // Dynamic Eyes: blinking eyelids or sleeping arcs
  let eyeMarkup = "";
  if (isSleep) {
    eyeMarkup = `
      <path d="M38,48 Q42,52 46,48" stroke="${p.dark}" stroke-width="2.2" stroke-linecap="round" fill="none" />
      <path d="M54,48 Q58,52 62,48" stroke="${p.dark}" stroke-width="2.2" stroke-linecap="round" fill="none" />
    `;
  } else if (isHappy) {
    eyeMarkup = `
      <path d="M38,50 Q42,44 46,50" stroke="${p.dark}" stroke-width="2.4" stroke-linecap="round" fill="none" />
      <path d="M54,50 Q58,44 62,50" stroke="${p.dark}" stroke-width="2.4" stroke-linecap="round" fill="none" />
      <!-- Cheerful cheek blush -->
      <circle cx="34" cy="54" r="4" fill="#FDA4AF" opacity="0.75" />
      <circle cx="66" cy="54" r="4" fill="#FDA4AF" opacity="0.75" />
    `;
  } else {
    // Normal expressive eyes with pupil, highlight, and CSS blink animation
    eyeMarkup = `
      <g class="pet-part-eyes">
        <g class="pet-eye pet-eye-left">
          <ellipse cx="42" cy="48" rx="4.5" ry="5.5" fill="${p.dark}" />
          <circle cx="41" cy="46" r="2" fill="#FFFFFF" />
          <circle cx="43.5" cy="49.5" r="0.8" fill="#FFFFFF" />
        </g>
        <g class="pet-eye pet-eye-right">
          <ellipse cx="58" cy="48" rx="4.5" ry="5.5" fill="${p.dark}" />
          <circle cx="57" cy="46" r="2" fill="#FFFFFF" />
          <circle cx="59.5" cy="49.5" r="0.8" fill="#FFFFFF" />
        </g>
        <!-- Cheerful cheek blush -->
        <circle cx="34" cy="54" r="3.5" fill="#FDA4AF" opacity="0.6" />
        <circle cx="66" cy="54" r="3.5" fill="#FDA4AF" opacity="0.6" />
      </g>
    `;
  }

  // Baby scaling adjustments
  const headRadiusX = isBaby ? 24 : 22;
  const headRadiusY = isBaby ? 21 : 19;
  const bodyRadiusX = isBaby ? 18 : 21;
  const bodyRadiusY = isBaby ? 17 : 20;

  return `
    <svg class="pet-living-svg pet-${petTypeKey} ${stageLabel ? 'stage-' + stageLabel.toLowerCase() : ''}"
         viewBox="0 0 100 100" width="${size}" height="${size}"
         xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${petTypeKey}">
      <defs>
        <radialGradient id="petGrad-${petTypeKey}" cx="40%" cy="35%" r="65%">
          <stop offset="0%" stop-color="${p.primary}" />
          <stop offset="100%" stop-color="${p.secondary}" />
        </radialGradient>
      </defs>

      <!-- Floor Contact Shadow -->
      <ellipse class="pet-part-shadow" cx="50" cy="85" rx="28" ry="6" fill="rgba(15, 23, 42, 0.16)" />

      <!-- Back Appendages (Tail, Back Wings, etc.) -->
      <g class="pet-part-back">
        ${tail}
      </g>

      <!-- Limbs / Feet -->
      <g class="pet-part-limbs">
        <ellipse class="pet-foot pet-foot-left" cx="37" cy="81" rx="6.5" ry="4" fill="${p.secondary}" />
        <ellipse class="pet-foot pet-foot-right" cx="63" cy="81" rx="6.5" ry="4" fill="${p.secondary}" />
      </g>

      <!-- Breathing Torso / Body -->
      <g class="pet-part-body">
        <ellipse cx="50" cy="67" rx="${bodyRadiusX}" ry="${bodyRadiusY}" fill="url(#petGrad-${petTypeKey})" />
        <!-- Soft Belly Patch -->
        <ellipse class="pet-part-belly" cx="50" cy="69" rx="${bodyRadiusX * 0.65}" ry="${bodyRadiusY * 0.68}" fill="${p.belly}" />
      </g>

      <!-- Head & Facial Features -->
      <g class="pet-part-head">
        <!-- Ears -->
        ${ears}
        <!-- Head Base -->
        <ellipse cx="50" cy="48" rx="${headRadiusX}" ry="${headRadiusY}" fill="url(#petGrad-${petTypeKey})" />
        <!-- Species Accents (Snout, Beak, Horns, Cheek Tufts) -->
        ${specificFeatures}
        <!-- Expressive Eyes -->
        ${eyeMarkup}
        <!-- Crown / Champion Flair -->
        ${accents}
      </g>
    </svg>
  `;
}

// Export for browser and node environments
if (typeof window !== "undefined") {
  window.generatePetSvg = generatePetSvg;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { generatePetSvg, PET_PALETTES };
}
