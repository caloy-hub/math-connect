-- ============================================================================
-- Migration 38 — Corrective patch: restore peak-gated pet adoption.
-- Run this once in Supabase → SQL Editor, AFTER migration-37.
--
-- BUG: migration-37-sharing-and-gemstone.sql did `create or replace function
-- adopt_pet(...)` and, by mistake, pasted in the OLD migration-33 body
-- (flat 3-adoption lifetime cap, blocks on "you have ANY living pet") instead
-- of the migration-35 body (blocks only while a currently-owned pet is still
-- growing — i.e. below Legendary / 5000 growth points). Because
-- "create or replace" overwrites by function name, migration-37's version is
-- what ended up live, so a student whose only pet had already reached
-- Legendary could no longer adopt a second one — adopt_pet() rejected them
-- with "You already have a pet!" or the stale 3-cap message instead.
--
-- This migration re-applies the correct migration-35 body verbatim (same as
-- the fix now baked into migration-37-sharing-and-gemstone.sql for any future
-- fresh deploys) and retires the "gift a spare Adoption Chance" resource type
-- in share_resource(), since it depended on the flat cap that no longer
-- exists under peak-gating. Coins and Green Points sharing are unaffected.
-- ============================================================================

-- ---------- ADOPT_PET: restore migration-35's peak-gating rule ----------
create or replace function public.adopt_pet(target_student_id uuid, target_pet_type_key text, target_pet_name text default null)
returns table(success boolean, message text, pet jsonb)
language plpgsql security definer as $$
declare
  type_active boolean;
  used_count integer;
begin
  select active into type_active from pet_types where key = target_pet_type_key;
  if type_active is null then
    return query select false, 'That pet does not exist.', null::jsonb;
    return;
  end if;
  if not type_active then
    return query select false, 'That pet is not available right now.', null::jsonb;
    return;
  end if;

  perform 1 from student_pets where student_id = target_student_id and alive and not is_pet_peak(growth_points) for update;
  if found then
    return query select false, 'You already have a pet that''s still growing — help it reach Legendary before adopting another!', null::jsonb;
    return;
  end if;

  select count(*) into used_count from student_pets where student_id = target_student_id;

  declare v record;
  begin
    insert into student_pets (
      student_id, pet_type_key, pet_name, hunger, growth_points, food_inventory,
      alive, adoption_number
    ) values (
      target_student_id, target_pet_type_key, nullif(trim(target_pet_name), ''), 100, 0, '{}'::jsonb,
      true, used_count + 1
    ) returning * into v;
    return query select true, 'Adopted!', to_jsonb(v);
  end;
end;
$$;
grant execute on function public.adopt_pet(uuid, text, text) to anon, authenticated;

-- ---------- SHARE_RESOURCE: retire the "adoption_chance" gift type ----------
create or replace function public.share_resource(
  p_sender_id uuid, p_receiver_id uuid, p_resource_type text, p_amount integer
)
returns table(success boolean, message text)
language plpgsql security definer as $$
declare
  sender_section uuid; receiver_section uuid;
  first_id uuid; second_id uuid;
  sender_coins integer; sender_gp integer;
begin
  if p_sender_id = p_receiver_id then
    return query select false, 'You can''t share with yourself!'; return;
  end if;
  if p_resource_type not in ('coins', 'green_points', 'adoption_chance') then
    return query select false, 'Unknown resource type.'; return;
  end if;
  if p_resource_type = 'adoption_chance' then
    -- Retired: depended on the flat 3-adoption cap that migration-35
    -- replaced with peak-gating. Nothing left to gift/receive.
    return query select false, 'Adoption Chances aren''t needed anymore — you can adopt a new pet as soon as every pet you have has reached Legendary.'; return;
  else
    if p_amount is null or p_amount <= 0 then
      return query select false, 'Enter an amount greater than zero.'; return;
    end if;
  end if;

  select section_id into sender_section from students where id = p_sender_id;
  select section_id into receiver_section from students where id = p_receiver_id;
  if sender_section is null or receiver_section is null or sender_section <> receiver_section then
    return query select false, 'You can only share with a classmate in your own section.'; return;
  end if;

  if p_sender_id::text < p_receiver_id::text then first_id := p_sender_id; second_id := p_receiver_id;
  else first_id := p_receiver_id; second_id := p_sender_id; end if;
  perform 1 from student_engagement where student_id = first_id for update;
  perform 1 from student_engagement where student_id = second_id for update;

  insert into student_engagement (student_id) values (p_sender_id) on conflict (student_id) do nothing;
  insert into student_engagement (student_id) values (p_receiver_id) on conflict (student_id) do nothing;

  if p_resource_type = 'coins' then
    select coins into sender_coins from student_engagement where student_id = p_sender_id;
    if sender_coins < p_amount then
      return query select false, format('Not enough Coins — need %s, have %s.', p_amount, sender_coins); return;
    end if;
    update student_engagement set coins = coins - p_amount, updated_at = now() where student_id = p_sender_id;
    update student_engagement set coins = coins + p_amount, updated_at = now() where student_id = p_receiver_id;

  else -- green_points
    select green_points into sender_gp from student_engagement where student_id = p_sender_id;
    if sender_gp < p_amount then
      return query select false, format('Not enough Green Points — need %s, have %s.', p_amount, sender_gp); return;
    end if;
    update student_engagement set green_points = green_points - p_amount, updated_at = now() where student_id = p_sender_id;
    update student_engagement set green_points = green_points + p_amount, updated_at = now() where student_id = p_receiver_id;
  end if;

  insert into resource_shares (section_id, sender_student_id, receiver_student_id, resource_type, amount)
  values (sender_section, p_sender_id, p_receiver_id, p_resource_type, p_amount);

  return query select true, 'Shared!';
end;
$$;
grant execute on function public.share_resource(uuid, uuid, text, integer) to anon, authenticated;
