-- ============================================================================
-- Migration 33 — Math Pet: naming, care items (vitamins/vaccine/cheat food/
-- equipment), neglect → sickness → death, and a 3-adoption lifetime cap.
-- Run this once in Supabase → SQL Editor, AFTER migration-32-math-pet.sql.
--
-- WHAT'S NEW (per the agreed plan):
--   - Students can name their pet at adoption, and rename it later.
--   - The Shop gets a "Pet Care" section: Growth Vitamins (slow hunger decay
--     for a while), a Wellness Vaccine (cures sickness + gives a protection
--     window), Cheat Meals (cheap, big hunger restore, but a real chance of
--     making the pet sick — a deliberate trade-off, not a free lunch), and
--     Equipment (bought once, then equipped — a small PERMANENT decay
--     reduction while equipped, e.g. a Cozy Bed or a Study Desk).
--   - Real neglect has real consequences: a pet that's fully starved and
--     ignored gets sick, and if the sickness goes untreated (no vaccine),
--     the pet dies. Death is permanent — the row stays in student_pets as a
--     memorial (alive = false), it is NEVER revived or auto-replaced.
--   - Each student gets a hard cap of 3 pet adoptions for the school year
--     (counts EVERY adopt_pet call for that student, alive or dead). Once a
--     pet dies, they may adopt again only if they haven't used all 3.
--   - 5 new pet types added (10 total), and every pet type now has a
--     legendary final-evolution form drawn from mythology (Azure Dragon,
--     Phoenix, Kitsune, etc.) — purely cosmetic (icon + title swap at the
--     top growth stage), driven entirely by petEngine.js's existing
--     client-side growth_points math. No schema needed for that part.
--
-- DESIGN NOTES (same trust tier as migration-32 — read that file's notes
-- too):
--   - student_pets used to be keyed student_id PRIMARY KEY (exactly one row,
--     ever, per student). That can't represent "this student's 2nd pet
--     after the 1st one died," so this migration re-keys it to a surrogate
--     `id` primary key, keeps `student_id` as a plain (non-unique) column,
--     and enforces "at most ONE living pet per student" with a PARTIAL
--     UNIQUE INDEX on (student_id) WHERE alive. Dead pets simply stop
--     matching that partial index, so a new adopt_pet() insert is free to
--     succeed once the old row is alive = false.
--   - Every write (adopt/rename/feed/use-item/equip/wellbeing-check) goes
--     through a security-definer RPC, same as migration-32 — still no
--     general "anyone update" policy on student_pets.
--   - Death is decided SERVER-SIDE in check_pet_wellbeing(), recomputing
--     hunger decay from `last_fed_at`/`adopted_at` using the database's own
--     clock — a tampered client can't fake "still fed" to dodge sickness,
--     and can't fake "already dead" either. check_pet_wellbeing() is called
--     opportunistically (every time a student's pet loads, and from the
--     teacher's Status tab) rather than on a cron schedule, since this
--     project has no scheduled-job runner — same "computed lazily, written
--     back on next touch" pattern the app already uses for hunger decay.
-- ============================================================================

-- ---------- student_pets: re-key + new columns ----------
alter table student_pets drop constraint if exists student_pets_pkey;
alter table student_pets add column if not exists id uuid not null default gen_random_uuid();
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'student_pets_pkey') then
    alter table student_pets add primary key (id);
  end if;
end $$;

alter table student_pets add column if not exists alive boolean not null default true;
alter table student_pets add column if not exists died_at timestamptz;
alter table student_pets add column if not exists cause_of_death text; -- 'starvation' | 'untreated_illness'
alter table student_pets add column if not exists sick boolean not null default false;
alter table student_pets add column if not exists sick_since timestamptz;
alter table student_pets add column if not exists vaccinated_until timestamptz;
alter table student_pets add column if not exists vitamin_boost_until timestamptz;
alter table student_pets add column if not exists equipped_item text;
alter table student_pets add column if not exists owned_equipment jsonb not null default '[]'::jsonb;
alter table student_pets add column if not exists care_inventory jsonb not null default '{}'::jsonb; -- vitamin/vaccine/cheat_food key -> owned count
alter table student_pets add column if not exists adoption_number integer not null default 1; -- which of this student's (max 3) adoptions this is

create index if not exists student_pets_student_idx on student_pets (student_id);
drop index if exists student_pets_alive_unique;
create unique index student_pets_alive_unique on student_pets (student_id) where alive;

-- ---------- More pet types (5 new, 10 total) ----------
insert into pet_types (key, name, icon, description, sort_order) values
  ('tala_turtle',  'Tala the Tally Turtle',   '🐢', 'Slow and steady — never miscounts a step.',              6),
  ('byte_cat',     'Byte the Binary Cat',     '🐱', 'Naps in perfect 1s and 0s. Purrs in prime numbers.',      7),
  ('kiri_calf',    'Kiri the Kirin Calf',     '🐮', 'Gentle, lucky, and surprisingly good at geometry.',       8),
  ('vex_wolf',     'Vex the Vector Wolf',     '🐺', 'Runs in straight lines — literally, it studies vectors.', 9),
  ('zeta_steed',   'Zeta the Zeal Steed',     '🐴', 'Races through word problems like they''re a track meet.', 10)
on conflict (key) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  sort_order = excluded.sort_order, active = true;

-- ---------- Pet Care catalog: vitamins, vaccine, cheat food, equipment ----------
create table if not exists pet_care_items (
  key text primary key,
  name text not null,
  icon text not null,
  category text not null check (category in ('vitamin', 'vaccine', 'cheat_food', 'equipment')),
  description text,
  cost_coins integer not null,
  restore_amount integer not null default 0,     -- cheat_food: hunger restored (capped at 100)
  sickness_risk_pct integer not null default 0,  -- cheat_food: % chance of falling sick when used (0 if vaccinated_until is active)
  effect_hours integer not null default 0,       -- vitamin/vaccine: how long the buff/protection lasts
  decay_reduction_pct integer not null default 0,-- vitamin (timed) / equipment (permanent while equipped): % slower hunger decay
  sort_order integer not null default 0,
  active boolean not null default true
);

insert into pet_care_items (key, name, icon, category, description, cost_coins, restore_amount, sickness_risk_pct, effect_hours, decay_reduction_pct, sort_order) values
  ('growth_vitamins', 'Growth Vitamins', '💊', 'vitamin',
    'Slows hunger decay by half for 48 hours. Best used before a long weekend away.', 30, 0, 0, 48, 50, 1),
  ('wellness_vaccine', 'Wellness Vaccine', '💉', 'vaccine',
    'Cures sickness instantly and protects against falling sick again for 72 hours.', 40, 0, 0, 72, 0, 2),
  ('cheat_meal', 'Cheat Meal', '🍔', 'cheat_food',
    'Cheap and restores a LOT of hunger fast — but there''s a real chance it makes your pet sick, unless it''s currently vaccinated.', 8, 60, 25, 0, 0, 3),
  ('cozy_bed', 'Cozy Bed', '🛏️', 'equipment',
    'Equip it (one at a time) for a permanent 15% slower hunger decay, for as long as it''s your pet''s equipped item.', 60, 0, 0, 0, 15, 4),
  ('study_desk', 'Study Desk', '📚', 'equipment',
    'Equip it (one at a time) for a permanent 15% slower hunger decay, for as long as it''s your pet''s equipped item.', 60, 0, 0, 0, 15, 5)
on conflict (key) do update set
  name = excluded.name, icon = excluded.icon, category = excluded.category, description = excluded.description,
  cost_coins = excluded.cost_coins, restore_amount = excluded.restore_amount, sickness_risk_pct = excluded.sickness_risk_pct,
  effect_hours = excluded.effect_hours, decay_reduction_pct = excluded.decay_reduction_pct, sort_order = excluded.sort_order, active = true;

alter table pet_care_items enable row level security;
drop policy if exists "public read pet_care_items" on pet_care_items;
create policy "public read pet_care_items" on pet_care_items for select using (true);

-- pet_feed_log.food_key used to only ever reference pet_food_items — now
-- Cheat Meals (a pet_care_items row) get logged the same way too, so the FK
-- needs to widen to "either catalog" rather than just one. Simplest fix:
-- drop the FK (this table is an append-only activity log, not something
-- referential integrity needs to protect) and keep it as a plain key.
alter table pet_feed_log drop constraint if exists pet_feed_log_food_key_fkey;

-- ============================================================================
-- ADOPT — now enforces the 3-adoption lifetime cap and stamps adoption_number.
-- Replaces the migration-32 version.
-- ============================================================================
create or replace function public.adopt_pet(target_student_id uuid, target_pet_type_key text, target_pet_name text default null)
returns table(success boolean, message text, pet jsonb)
language plpgsql security definer as $$
declare
  type_active boolean;
  used_count integer;
begin
  select active into type_active from pet_types where key = target_pet_type_key;
  if type_active is null then
    return query select false, 'That pet does not exist.', null::jsonb;
    return;
  end if;
  if not type_active then
    return query select false, 'That pet is not available right now.', null::jsonb;
    return;
  end if;

  perform 1 from student_pets where student_id = target_student_id and alive for update;
  if found then
    return query select false, 'You already have a pet!', null::jsonb;
    return;
  end if;

  select count(*) into used_count from student_pets where student_id = target_student_id;
  if used_count >= 3 then
    return query select false, 'You''ve used all 3 pet adoptions for the school year — no more chances left.', null::jsonb;
    return;
  end if;

  declare v record;
  begin
    insert into student_pets (
      student_id, pet_type_key, pet_name, hunger, growth_points, food_inventory,
      alive, adoption_number
    ) values (
      target_student_id, target_pet_type_key, nullif(trim(target_pet_name), ''), 100, 0, '{}'::jsonb,
      true, used_count + 1
    ) returning * into v;
    return query select true, 'Adopted!', to_jsonb(v);
  end;
end;
$$;
grant execute on function public.adopt_pet(uuid, text, text) to anon, authenticated;

-- ============================================================================
-- RENAME — the student can rename their living pet at any time, free.
-- ============================================================================
create or replace function public.rename_pet(target_student_id uuid, new_name text)
returns table(success boolean, message text, new_pet_name text)
language plpgsql security definer as $$
declare
  cleaned text;
begin
  cleaned := nullif(trim(new_name), '');
  if cleaned is null then
    return query select false, 'Give your pet a name first!', null::text;
    return;
  end if;
  if length(cleaned) > 24 then
    return query select false, 'Keep the name to 24 characters or fewer.', null::text;
    return;
  end if;

  update student_pets set pet_name = cleaned, updated_at = now()
  where student_id = target_student_id and alive
  returning pet_name into cleaned;

  if not found then
    return query select false, 'Adopt a pet first!', null::text;
    return;
  end if;

  return query select true, 'Renamed!', cleaned;
end;
$$;
grant execute on function public.rename_pet(uuid, text) to anon, authenticated;

-- ============================================================================
-- WELLBEING CHECK — recomputes hunger decay server-side (mirrors
-- petLiveHunger() in petEngine.js, plus the vitamin/equipment decay discount)
-- and decides sickness / death. Idempotent — safe to call on every pet load.
-- ============================================================================
create or replace function public.check_pet_wellbeing(target_student_id uuid)
returns table(success boolean, alive boolean, sick boolean, live_hunger integer, died boolean, cause_of_death text)
language plpgsql security definer as $$
declare
  pet record;
  hours_since numeric;
  decay_rate numeric := 100.0 / 24.0; -- full drain in 24h, baseline
  discount numeric := 0;
  live_hunger_val integer;
  item_decay integer;
begin
  select sp.* into pet from student_pets sp where sp.student_id = target_student_id and sp.alive for update;
  if not found then
    return query select false, false, false, null::integer, false, null::text;
    return;
  end if;

  hours_since := greatest(0, extract(epoch from (now() - coalesce(pet.last_fed_at, pet.adopted_at, now()))) / 3600.0);

  if pet.vitamin_boost_until is not null and pet.vitamin_boost_until > now() then
    discount := greatest(discount, 0.5); -- growth_vitamins: 50% slower decay
  end if;
  if pet.equipped_item is not null then
    select decay_reduction_pct into item_decay from pet_care_items where key = pet.equipped_item and category = 'equipment';
    if item_decay is not null then discount := least(0.9, discount + item_decay / 100.0); end if;
  end if;

  live_hunger_val := greatest(0, least(100, round(pet.hunger - (hours_since * decay_rate * (1 - discount)))));

  -- Fully starved and neither fed nor vaccinated in a while -> falls sick.
  if live_hunger_val <= 0 and not pet.sick and (pet.vaccinated_until is null or pet.vaccinated_until < now()) then
    update student_pets set sick = true, sick_since = now(), updated_at = now() where id = pet.id;
    pet.sick := true; pet.sick_since := now();
  end if;

  -- Sick and untreated (no vaccine) for 24+ hours -> dies.
  if pet.sick and pet.sick_since is not null and (now() - pet.sick_since) > interval '24 hours'
     and (pet.vaccinated_until is null or pet.vaccinated_until < pet.sick_since) then
    update student_pets set alive = false, died_at = now(), cause_of_death = 'untreated_illness', updated_at = now() where id = pet.id;
    return query select true, false, true, live_hunger_val, true, 'untreated_illness';
    return;
  end if;

  -- Belt-and-suspenders: fully starved for 72+ straight hours with no care at all -> dies even without the sickness step.
  if live_hunger_val <= 0 and hours_since > 72 then
    update student_pets set alive = false, died_at = now(), cause_of_death = 'starvation', updated_at = now() where id = pet.id;
    return query select true, false, pet.sick, live_hunger_val, true, 'starvation';
    return;
  end if;

  return query select true, true, pet.sick, live_hunger_val, false, null::text;
end;
$$;
grant execute on function public.check_pet_wellbeing(uuid) to anon, authenticated;

-- ============================================================================
-- FEED WITH GREEN POINTS — same as migration-32, restricted to a living pet.
-- ============================================================================
create or replace function public.feed_pet_green_points(target_student_id uuid, amount integer)
returns table(success boolean, message text, new_green_points integer, new_hunger integer, new_growth_points integer)
language plpgsql security definer as $$
declare
  current_gp integer;
  pet record;
begin
  if amount is null or amount <= 0 then
    return query select false, 'Invalid amount.', null::integer, null::integer, null::integer;
    return;
  end if;

  select green_points into current_gp from student_engagement where student_id = target_student_id for update;
  if current_gp is null then
    return query select false, 'No Green Points wallet found yet — go play something first!', null::integer, null::integer, null::integer;
    return;
  end if;
  if current_gp < amount then
    return query select false, format('Not enough Green Points — need %s, have %s.', amount, current_gp), current_gp, null::integer, null::integer;
    return;
  end if;

  select * into pet from student_pets where student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'Adopt a pet first!', current_gp, null::integer, null::integer;
    return;
  end if;

  current_gp := current_gp - amount;
  update student_engagement set green_points = current_gp, updated_at = now() where student_id = target_student_id;

  update student_pets
    set growth_points = pet.growth_points + amount,
        hunger = least(100, pet.hunger + amount),
        last_fed_at = now(), updated_at = now()
    where id = pet.id
    returning hunger, growth_points into pet.hunger, pet.growth_points;

  insert into pet_feed_log (student_id, fed_with, amount) values (target_student_id, 'green_points', amount);

  return query select true, 'Fed!', current_gp, pet.hunger, pet.growth_points;
end;
$$;
grant execute on function public.feed_pet_green_points(uuid, integer) to anon, authenticated;

-- ============================================================================
-- PURCHASE / FEED basic food — same as migration-32, restricted to a living pet.
-- ============================================================================
create or replace function public.purchase_pet_food(target_student_id uuid, target_food_key text)
returns table(success boolean, message text, new_coins integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare
  food_cost integer;
  food_active boolean;
  current_coins integer;
  current_inventory jsonb;
  owned_count integer;
  pet_id uuid;
begin
  select cost_coins, active into food_cost, food_active from pet_food_items where key = target_food_key;
  if food_cost is null then
    return query select false, 'That food does not exist.', null::integer, null::jsonb;
    return;
  end if;
  if not food_active then
    return query select false, 'That food is no longer available.', null::integer, null::jsonb;
    return;
  end if;

  select id into pet_id from student_pets where student_id = target_student_id and alive;
  if pet_id is null then
    return query select false, 'Adopt a pet first!', null::integer, null::jsonb;
    return;
  end if;

  select coins into current_coins from student_engagement where student_id = target_student_id for update;
  if current_coins is null then
    return query select false, 'No coin wallet found yet — go play something first!', null::integer, null::jsonb;
    return;
  end if;
  if current_coins < food_cost then
    return query select false, format('Not enough coins — need %s, have %s.', food_cost, current_coins), current_coins, null::jsonb;
    return;
  end if;

  select coalesce(food_inventory, '{}'::jsonb) into current_inventory from student_pets where id = pet_id for update;
  owned_count := coalesce((current_inventory ->> target_food_key)::integer, 0);
  current_inventory := jsonb_set(current_inventory, array[target_food_key], to_jsonb(owned_count + 1));
  current_coins := current_coins - food_cost;

  update student_engagement set coins = current_coins, updated_at = now() where student_id = target_student_id;
  update student_pets set food_inventory = current_inventory, updated_at = now() where id = pet_id;

  return query select true, 'Purchased!', current_coins, current_inventory;
end;
$$;
grant execute on function public.purchase_pet_food(uuid, text) to anon, authenticated;

create or replace function public.feed_pet_food(target_student_id uuid, target_food_key text)
returns table(success boolean, message text, new_hunger integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare
  pet record;
  restore_amt integer;
  owned_count integer;
  new_inventory jsonb;
begin
  select restore_amount into restore_amt from pet_food_items where key = target_food_key;
  if restore_amt is null then
    return query select false, 'That food does not exist.', null::integer, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'Adopt a pet first!', null::integer, null::jsonb;
    return;
  end if;

  owned_count := coalesce((pet.food_inventory ->> target_food_key)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that food — buy some in the Shop!', pet.hunger, pet.food_inventory;
    return;
  end if;

  new_inventory := jsonb_set(pet.food_inventory, array[target_food_key], to_jsonb(owned_count - 1));

  update student_pets
    set hunger = least(100, pet.hunger + restore_amt), food_inventory = new_inventory,
        last_fed_at = now(), updated_at = now()
    where id = pet.id
    returning hunger into pet.hunger;

  insert into pet_feed_log (student_id, fed_with, food_key, amount) values (target_student_id, 'food', target_food_key, restore_amt);

  return query select true, 'Fed!', pet.hunger, new_inventory;
end;
$$;
grant execute on function public.feed_pet_food(uuid, text) to anon, authenticated;

-- ============================================================================
-- PURCHASE a care item (vitamin / vaccine / cheat food / equipment) — spends
-- coins, adds to care_inventory (equipment instead goes into owned_equipment,
-- a one-time unlock rather than a stackable count).
-- ============================================================================
create or replace function public.purchase_pet_care_item(target_student_id uuid, target_item_key text)
returns table(success boolean, message text, new_coins integer, new_care_inventory jsonb, new_owned_equipment jsonb)
language plpgsql security definer as $$
declare
  item record;
  current_coins integer;
  pet record;
  current_inv jsonb;
  owned_count integer;
  already_owned boolean;
begin
  select * into item from pet_care_items where key = target_item_key and active;
  if not found then
    return query select false, 'That item does not exist.', null::integer, null::jsonb, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'Adopt a pet first!', null::integer, null::jsonb, null::jsonb;
    return;
  end if;

  if item.category = 'equipment' then
    already_owned := pet.owned_equipment ? target_item_key;
    if already_owned then
      return query select false, 'You already own that.', null::integer, pet.care_inventory, pet.owned_equipment;
      return;
    end if;
  end if;

  select coins into current_coins from student_engagement where student_id = target_student_id for update;
  if current_coins is null or current_coins < item.cost_coins then
    return query select false, format('Not enough coins — need %s, have %s.', item.cost_coins, coalesce(current_coins, 0)), current_coins, null::jsonb, null::jsonb;
    return;
  end if;
  current_coins := current_coins - item.cost_coins;
  update student_engagement set coins = current_coins, updated_at = now() where student_id = target_student_id;

  if item.category = 'equipment' then
    update student_pets set owned_equipment = owned_equipment || to_jsonb(target_item_key), updated_at = now()
    where id = pet.id returning owned_equipment into current_inv;
    return query select true, 'Purchased!', current_coins, pet.care_inventory, current_inv;
  else
    current_inv := coalesce(pet.care_inventory, '{}'::jsonb);
    owned_count := coalesce((current_inv ->> target_item_key)::integer, 0);
    current_inv := jsonb_set(current_inv, array[target_item_key], to_jsonb(owned_count + 1));
    update student_pets set care_inventory = current_inv, updated_at = now() where id = pet.id;
    return query select true, 'Purchased!', current_coins, current_inv, pet.owned_equipment;
  end if;
end;
$$;
grant execute on function public.purchase_pet_care_item(uuid, text) to anon, authenticated;

-- ============================================================================
-- USE a care item — applies its effect (vitamin buff / vaccine cure /
-- cheat-food gamble). Equipment is never "used" this way — see equip_pet_item.
-- ============================================================================
create or replace function public.use_pet_care_item(target_student_id uuid, target_item_key text)
returns table(success boolean, message text, new_hunger integer, sick boolean, new_care_inventory jsonb)
language plpgsql security definer as $$
declare
  item record;
  pet record;
  owned_count integer;
  new_inv jsonb;
  got_sick boolean := false;
  protected boolean;
begin
  select * into item from pet_care_items where key = target_item_key and active and category in ('vitamin','vaccine','cheat_food');
  if not found then
    return query select false, 'That item can''t be used this way.', null::integer, null::boolean, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'Adopt a pet first!', null::integer, null::boolean, null::jsonb;
    return;
  end if;

  owned_count := coalesce((pet.care_inventory ->> target_item_key)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that — buy some in the Shop!', pet.hunger, pet.sick, pet.care_inventory;
    return;
  end if;
  new_inv := jsonb_set(pet.care_inventory, array[target_item_key], to_jsonb(owned_count - 1));

  if item.category = 'vitamin' then
    update student_pets set
      vitamin_boost_until = greatest(coalesce(vitamin_boost_until, now()), now()) + (item.effect_hours || ' hours')::interval,
      care_inventory = new_inv, updated_at = now()
    where id = pet.id;
    return query select true, format('💊 Vitamins active for the next %s hours — hunger will drain slower.', item.effect_hours), pet.hunger, pet.sick, new_inv;

  elsif item.category = 'vaccine' then
    update student_pets set
      sick = false, sick_since = null,
      vaccinated_until = now() + (item.effect_hours || ' hours')::interval,
      care_inventory = new_inv, updated_at = now()
    where id = pet.id;
    return query select true, '💉 Vaccinated! Your pet is cured and protected for a while.', pet.hunger, false, new_inv;

  else -- cheat_food
    protected := pet.vaccinated_until is not null and pet.vaccinated_until > now();
    got_sick := (not protected) and (random() * 100 < item.sickness_risk_pct);
    update student_pets set
      hunger = least(100, pet.hunger + item.restore_amount),
      sick = case when got_sick then true else pet.sick end,
      sick_since = case when got_sick and not pet.sick then now() else pet.sick_since end,
      care_inventory = new_inv, last_fed_at = now(), updated_at = now()
    where id = pet.id
    returning student_pets.hunger, student_pets.sick into pet.hunger, pet.sick;
    insert into pet_feed_log (student_id, fed_with, food_key, amount) values (target_student_id, 'food', target_item_key, item.restore_amount);
    return query select true,
      case when got_sick then '🍔 Yum... but that cheat meal made your pet sick! Grab a vaccine soon.' else '🍔 Yum! Hunger restored.' end,
      pet.hunger, pet.sick, new_inv;
  end if;
end;
$$;
grant execute on function public.use_pet_care_item(uuid, text) to anon, authenticated;

-- ============================================================================
-- EQUIP an owned piece of equipment (or unequip by passing null).
-- ============================================================================
create or replace function public.equip_pet_item(target_student_id uuid, target_item_key text default null)
returns table(success boolean, message text, new_equipped_item text)
language plpgsql security definer as $$
declare
  pet record;
begin
  select * into pet from student_pets where student_id = target_student_id and alive for update;
  if not found then
    return query select false, 'Adopt a pet first!', null::text;
    return;
  end if;

  if target_item_key is not null and not (pet.owned_equipment ? target_item_key) then
    return query select false, 'You don''t own that yet.', pet.equipped_item;
    return;
  end if;

  update student_pets set equipped_item = target_item_key, updated_at = now() where id = pet.id;
  return query select true, case when target_item_key is null then 'Unequipped.' else 'Equipped!' end, target_item_key;
end;
$$;
grant execute on function public.equip_pet_item(uuid, text) to anon, authenticated;

-- ============================================================================
-- Done. Run migration-32 first if this is a brand-new project, then this
-- file. petEngine.js / pet-ui.js / statusEngine.js already know how to talk
-- to all of the above.
-- ============================================================================
