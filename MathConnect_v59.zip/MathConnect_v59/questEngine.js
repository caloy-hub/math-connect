// ============================================================================
// MathConnect — Quest Mode
// A story-driven map that reorganizes the same Drill Arena question engine
// (drills.js — DRILL_GENERATORS, checkDrillAnswer, fmtDrillAnswer) into 12
// thematic chapters, one per subject the student takes, ending with a Math
// finale. Each chapter has 10 levels; each level is a themed 10-question
// drill run with a short story blurb. Passing a level (7/10+) unlocks the
// next level; clearing all 10 levels of a chapter unlocks the next chapter.
// Stars (0-3 per level, based on accuracy) track mastery and feed a small
// bonus into the existing MathLegends rank (awardMasteryStars, rankEngine.js)
// so Quest Mode plugs into the same progression students already know.
//
// Depends on: supabase-client.js (supabase, escapeHtml), drills.js
// (generateDrillQuestion, checkDrillAnswer, fmtDrillAnswer, starsForDrillRun),
// rankEngine.js (awardMasteryStars). Loaded on student.html before quest-ui.js.
// ============================================================================

const QUEST_RUN_LENGTH = 10;
const QUEST_MAX_LEVEL = 10;
const QUEST_PASS_ACCURACY = 0.7; // 7/10 or better clears a level

// Which drill-arena topic each level number (1-10) draws its questions from.
// Difficulty (the generator's `level` argument) is simply the level number
// itself, so level 10 of every chapter is that topic's hardest tier.
const QUEST_TOPIC_CYCLE = ["basic", "order", "integers", "fractions", "decimals", "algebra", "basic", "fractions", "decimals", "algebra"];

// ============================================================================
// CHAPTERS — one per subject, in play order. `key` must be a short, stable
// slug (used as a JSONB key in quest_progress, so don't rename existing keys
// once students have progress saved).
// ============================================================================
const QUEST_CHAPTERS = [
  {
    key: "science", subject: "Science", icon: "🔬", color: "#2F8FD1",
    title: "The Laboratory of Numbers",
    arcBlurb: "Bell rings, goggles on. Something in the school laboratory only unlocks for students who can solve their way through it — beaker by beaker.",
    levels: [
      { title: "The Locked Cabinet", blurb: "The supply cabinet has a number lock. Solve today's warm-up to see the first digit." },
      { title: "Measuring Right", blurb: "Your group needs exact measurements for the experiment — no rounding allowed." },
      { title: "The Bunsen Burner Timer", blurb: "The burner's safety timer only resets if you clear its calculation first." },
      { title: "Mixing Ratios", blurb: "Too much of one chemical and the reaction fizzles. Get the ratio right." },
      { title: "The Microscope Slide", blurb: "Focus the lens by working out the numbers etched on the slide's calibration card." },
      { title: "Static Electricity", blurb: "The balloon demo only works if your charge count checks out first." },
      { title: "The Weather Station", blurb: "Today's data from the school's rain gauge needs a student to crunch the totals." },
      { title: "Volcano Model", blurb: "Your baking-soda volcano needs the correct proportions to erupt on cue." },
      { title: "The Circuit Board", blurb: "One loose wire, one final calculation — light the bulb before recess ends." },
      { title: "Science Fair Judge", blurb: "The head judge sets one last challenge before awarding your project a ribbon." },
    ],
  },
  {
    key: "english", subject: "English", icon: "📖", color: "#5B6FD8",
    title: "The Whispering Library",
    arcBlurb: "The old library shelves whisper riddles at night. Legend says a hidden reading room only opens for those who can out-think its numbers.",
    levels: [
      { title: "The Card Catalog", blurb: "Find the right shelf by solving the number etched on the catalog drawer." },
      { title: "Chapter One", blurb: "The first page of the mystery novel is blurred until you answer its riddle." },
      { title: "Vocabulary Vault", blurb: "New words wait behind a vault that only a correct answer will open." },
      { title: "The Poetry Corner", blurb: "Count your way through the poem's hidden pattern to find its final line." },
      { title: "Essay Deadline", blurb: "The clock's ticking on your essay — clear this checkpoint to keep writing." },
      { title: "The Debate Stage", blurb: "Your rebuttal needs sharp thinking. Warm up your mind before you speak." },
      { title: "Grammar Ghost", blurb: "A mischievous ghost hides commas around the library until challenged." },
      { title: "The Book Fair", blurb: "Win a free book by solving the fair organizer's puzzle booth." },
      { title: "Storyteller's Trial", blurb: "To tell the final chapter, you must first pass the storyteller's trial." },
      { title: "The Reading Room", blurb: "The whispering stops. The hidden reading room finally creaks open." },
    ],
  },
  {
    key: "filipino", subject: "Filipino", icon: "🇵🇭", color: "#E8632E",
    title: "Ang Kwento ng mga Bilang",
    arcBlurb: "Isang lumang alamat ang nagsasabing may kaharian ng mga bilang na natatago sa ilalim ng paaralan — bukas lamang sa matalinong mag-aaral.",
    levels: [
      { title: "Ang Unang Hakbang", blurb: "Bago pumasok sa kaharian, kailangan mong lutasin ang unang bugtong." },
      { title: "Salawikain at Bilang", blurb: "Ang matandang salawikain ay may kasamang palaisipang pang-matematika." },
      { title: "Ang Mananalaysay", blurb: "Ikwento ng matandang mananalaysay ang alamat — kung malulutas mo ang kanyang tanong." },
      { title: "Awiting Bayan", blurb: "Ang tugtugin ay hindi tatapusin hangga't hindi mo nasasagot ang bilang sa himig." },
      { title: "Ang Palaisipan ng Ninuno", blurb: "Iniwan ng mga ninuno ang isang palaisipan bago ang bawat pagsubok." },
      { title: "Sayaw ng Kaharian", blurb: "Ang mga hakbang sa sayaw ay bilang rin — sundan mo ang tamang ritmo." },
      { title: "Ang Punong-guro", blurb: "Nais malaman ng punong-guro kung handa ka nang tumuloy." },
      { title: "Kwentong Bayan", blurb: "Isang huling kwento bago ang pinakamahalagang bahagi ng alamat." },
      { title: "Ang Matandang Pantas", blurb: "Sinusubok ka ng pantas bago ka payagang makarating sa kaharian." },
      { title: "Ang Kaharian ng mga Bilang", blurb: "Sa wakas, nasa harapan mo na ang pintuan ng kahariang minsan mo lamang naririnig sa kwento." },
    ],
  },
  {
    key: "ap", subject: "Araling Panlipunan", icon: "🗺️", color: "#B87B3E",
    title: "Alamat ng Barangay",
    arcBlurb: "A time-worn map of the barangay shows a trail through history — each landmark needs a number solved before the path reveals the next.",
    levels: [
      { title: "The Old Map", blurb: "The barangay map's compass rose is missing a number — figure it out to begin the trail." },
      { title: "The Plaza Bell", blurb: "The town plaza's bell tower rings only after its clockwork puzzle is solved." },
      { title: "Trade Route Records", blurb: "An old trader's ledger needs its totals checked before the route continues." },
      { title: "The Census Scroll", blurb: "Count the households correctly to move the story of the barangay forward." },
      { title: "The Revolution Timeline", blurb: "Line up the years correctly to keep the historical timeline intact." },
      { title: "The Cartographer's Riddle", blurb: "A cartographer hid a riddle in the map's scale — solve it to measure true distance." },
      { title: "The Council Meeting", blurb: "The barangay council needs your help balancing this year's budget numbers." },
      { title: "Heroes' Monument", blurb: "The monument's plaque only reveals its full inscription to a correct answer." },
      { title: "The Festival Committee", blurb: "Plan the fiesta budget correctly before the whole barangay arrives." },
      { title: "The Historian's Seal", blurb: "The barangay historian stamps your map's final seal — if you've earned it." },
    ],
  },
  {
    key: "values", subject: "Values Education", icon: "🕊️", color: "#8D9A6E",
    title: "The Compass of Character",
    arcBlurb: "An old compass doesn't point north — it points toward good choices, and it only spins true for students willing to think things through.",
    levels: [
      { title: "Honesty's First Test", blurb: "The compass needle wavers — steady your mind with a clear answer first." },
      { title: "Sharing Fairly", blurb: "Divide the day's snacks fairly among your groupmates — the math has to be exact." },
      { title: "Respect in Numbers", blurb: "Count how many kind words your class gave today — every one matters." },
      { title: "The Honest Merchant", blurb: "A merchant in the story always gives correct change — help him check his math." },
      { title: "Patience Pays Off", blurb: "Waiting your turn is hard — solving this while you wait makes it easier." },
      { title: "Helping a Classmate", blurb: "Your seatmate needs help checking their answer — walk through it together." },
      { title: "The Value of Time", blurb: "Budget your study hours correctly and the compass points a little truer." },
      { title: "Standing Up for What's Right", blurb: "Doing the right thing sometimes means doing the harder math too." },
      { title: "Gratitude Journal", blurb: "Tally up this month's small blessings — the count might surprise you." },
      { title: "True North", blurb: "The compass finally settles — character and clear thinking, working together." },
    ],
  },
  {
    key: "musicarts", subject: "Music and Arts", icon: "🎨", color: "#8A5DC8",
    title: "The Gallery of Rhythm and Color",
    arcBlurb: "Every painting in the gallery hums a hidden beat, and every beat hides a number. Solve them and the gallery's final mural reveals itself.",
    levels: [
      { title: "The First Brushstroke", blurb: "Mix the paint in the right proportion before the mural can begin." },
      { title: "Counting the Beat", blurb: "Clap along — but first, work out how many beats fit the measure." },
      { title: "The Color Wheel", blurb: "Blend two colors correctly by solving the ratio on the palette's edge." },
      { title: "Tempo Trouble", blurb: "The metronome's ticking is off — recalculate the tempo to fix it." },
      { title: "Sculptor's Symmetry", blurb: "A clay sculpture needs perfectly even sides — check the measurements." },
      { title: "The Chorus Line", blurb: "Count the singers correctly so every section blends in harmony." },
      { title: "Framing the Canvas", blurb: "Cut the canvas frame to the exact size the painting calls for." },
      { title: "The Recital Program", blurb: "Order the program correctly so every act gets its fair share of time." },
      { title: "The Art Critic", blurb: "A visiting critic poses one sharp question before praising your gallery." },
      { title: "Unveiling the Mural", blurb: "The final mural's hidden number is revealed — and it's the gallery's masterpiece." },
    ],
  },
  {
    key: "pe", subject: "PE and Health", icon: "🏃", color: "#1F9D5C",
    title: "The Arena of Champions",
    arcBlurb: "The whistle blows. Before every game, the coach has one rule: no play until the numbers check out.",
    levels: [
      { title: "Warm-Up Laps", blurb: "Count your laps correctly before the coach lets the real training begin." },
      { title: "The Scoreboard", blurb: "Fix the scoreboard's tally before the next point can be called." },
      { title: "Relay Team Order", blurb: "Work out the fairest running order for your relay team." },
      { title: "Heart Rate Check", blurb: "The school nurse needs your recovery numbers checked before you continue." },
      { title: "The Basketball Bracket", blurb: "Seed the tournament bracket correctly — every team deserves a fair match." },
      { title: "Jump Rope Challenge", blurb: "Beat your personal best by working out the exact count needed." },
      { title: "Nutrition Plate", blurb: "Balance today's meal plate correctly for a proper serving of energy." },
      { title: "The Obstacle Course", blurb: "Time your run against the course record — can your numbers beat it?" },
      { title: "Team Captain's Trial", blurb: "The captain's armband goes to whoever clears this final drill." },
      { title: "Champion's Podium", blurb: "One last challenge stands between you and the top of the podium." },
    ],
  },
  {
    key: "tve_food", subject: "TVE — Food Processing", icon: "🍳", color: "#C08552",
    title: "The Community Kitchen",
    arcBlurb: "The school's food processing lab is prepping a big batch for the barangay — and every recipe here runs on exact numbers.",
    levels: [
      { title: "Reading the Recipe", blurb: "Scale the recipe correctly before the first batch goes into the pot." },
      { title: "Weighing Ingredients", blurb: "The kitchen scale needs your math to measure the right amount of flour." },
      { title: "The Preserving Jars", blurb: "Fill the bottling jars evenly — too much or too little spoils the batch." },
      { title: "Sanitation Check", blurb: "Log the correct sanitation timing before the lab passes inspection." },
      { title: "Labeling for Market", blurb: "Price each jar correctly so the community store can sell it fairly." },
      { title: "The Dehydrator Timer", blurb: "Set the dehydrator's timer using this batch's exact calculation." },
      { title: "Cost and Profit", blurb: "Work out the cost per batch so the kitchen doesn't lose money." },
      { title: "Quality Control", blurb: "Inspect the day's output — the numbers must match the standard exactly." },
      { title: "The Big Order", blurb: "A big barangay order just came in — scale up the whole recipe correctly." },
      { title: "Taste-Test Day", blurb: "The judges are here. One final calculation before the community tasting." },
    ],
  },
  {
    key: "tve_swine", subject: "TVE — Swine Production", icon: "🐖", color: "#B87B3E",
    title: "The Piggery Trail",
    arcBlurb: "Down at the school's piggery project, every feed ration and every peso of profit depends on getting the numbers right.",
    levels: [
      { title: "Morning Feeding", blurb: "Measure today's feed ration correctly before the piglets get restless." },
      { title: "Weighing the Litter", blurb: "Record each piglet's weight gain accurately for the farm log." },
      { title: "The Feed Budget", blurb: "Balance this month's feed budget so supplies last the whole cycle." },
      { title: "Vaccination Schedule", blurb: "Calculate the correct dosage before the vet arrives for vaccination day." },
      { title: "Pen Space Planning", blurb: "Divide the pen space fairly so every hog has room to grow." },
      { title: "Water Trough Check", blurb: "Work out how much water the troughs need refilled with today." },
      { title: "Growth Rate Report", blurb: "Chart the average growth rate for this batch of hogs." },
      { title: "Market Weight", blurb: "Estimate market weight correctly before the buyer arrives." },
      { title: "The Buyer's Offer", blurb: "Negotiate a fair price — but only if your math backs up your number." },
      { title: "Harvest Day", blurb: "The whole project comes down to this final farm-day calculation." },
    ],
  },
  {
    key: "tve_crops", subject: "TVE — Agricultural Crops Production", icon: "🌾", color: "#6E8B3D",
    title: "The Harvest Fields",
    arcBlurb: "Rows of vegetables stretch across the school's demo farm, and the harvest calendar only turns for students who can do the field math.",
    levels: [
      { title: "Planting the Rows", blurb: "Space the seedlings correctly so every row gets room to grow." },
      { title: "Fertilizer Mix", blurb: "Mix the fertilizer solution to the exact ratio the crops need." },
      { title: "Irrigation Schedule", blurb: "Calculate how long to run the irrigation line today." },
      { title: "Pest Count", blurb: "Count the pest traps correctly before deciding on treatment." },
      { title: "Soil pH Log", blurb: "Average this week's soil readings for the farm journal." },
      { title: "Growth Tracking", blurb: "Measure this batch of seedlings and log their average height." },
      { title: "Harvest Yield", blurb: "Estimate the yield per row before the harvest crew arrives." },
      { title: "Sorting for Market", blurb: "Sort the produce by weight class — the buyer pays by the kilo." },
      { title: "Farm Ledger", blurb: "Balance the farm's expenses against this week's sales." },
      { title: "Harvest Festival", blurb: "The whole school farm gathers for one final harvest-day challenge." },
    ],
  },
  {
    key: "tve_motor", subject: "TVE — Motorcycle/Small Engine Servicing", icon: "🏍️", color: "#647266",
    title: "The Motor Workshop",
    arcBlurb: "Grease-stained tools, a row of engines waiting for service — the workshop's logbook only opens for a student who trusts the numbers.",
    levels: [
      { title: "Checking the Oil", blurb: "Measure the correct oil level before the engine can be started." },
      { title: "Tire Pressure", blurb: "Set every tire to the exact pressure spec in the manual." },
      { title: "Torque Spec", blurb: "Tighten the bolts to the exact torque — too loose or too tight both fail." },
      { title: "Fuel Mixture", blurb: "Mix the fuel ratio correctly for this two-stroke engine." },
      { title: "The Diagnostic Log", blurb: "Work through the mechanic's diagnostic numbers before the test ride." },
      { title: "Spare Parts Inventory", blurb: "Count the workshop's spare parts stock before the next order." },
      { title: "Service Pricing", blurb: "Total up today's service bill correctly for the customer." },
      { title: "Engine Timing", blurb: "Calculate the correct timing adjustment for a smoother idle." },
      { title: "The Test Ride", blurb: "One last calculation before the serviced motor goes out for a test ride." },
      { title: "Workshop Certification", blurb: "Pass this final check and the workshop signs off on your training." },
    ],
  },
  {
    key: "math", subject: "Math", icon: "∑", color: "#F4C95D",
    title: "The Sanctuary of Archimedes",
    arcBlurb: "Every road in Quest Mode leads here. The Sanctuary of Archimedes only opens to those who have proven themselves across every subject in school — the final trial is pure math.",
    levels: [
      { title: "The Sanctuary Gate", blurb: "The great gate recognizes your journey so far — but the trial ahead is its own." },
      { title: "Pythagoras' Corridor", blurb: "The first hall bears Pythagoras' name — solve his opening challenge." },
      { title: "Euclid's Chamber", blurb: "Precision matters more here than anywhere else in the sanctuary." },
      { title: "Al-Khwarizmi's Vault", blurb: "The father of algebra left his hardest lock for students like you." },
      { title: "Fibonacci's Spiral Stair", blurb: "Climb the spiral stair — each step numbered by a pattern only you can solve." },
      { title: "Descartes' Reflection Pool", blurb: "The pool only shows your reflection once your answer is correct." },
      { title: "Newton's Observatory", blurb: "From here, the whole school looks small — but the math only gets bigger." },
      { title: "Euler's Bridge", blurb: "Cross Euler's bridge with a calculation worthy of his name." },
      { title: "Gauss' Final Proof", blurb: "One challenge stands between you and the sanctuary's inner chamber." },
      { title: "Archimedes' Eureka", blurb: "The legendary final trial. Solve it, and Quest Mode is complete — Eureka!" },
    ],
  },
];

// ============================================================================
// PROGRESS STATE / HELPERS
// ============================================================================
var qstate = { progress: null, loaded: false };
var qgame = null; // active quest-level run, mirrors dgame in drills.js

function questDefaultLevelStars() {
  const o = {};
  QUEST_CHAPTERS.forEach((c) => (o[c.key] = new Array(QUEST_MAX_LEVEL).fill(0)));
  return o;
}

/** A level is unlocked if it's level 1, or the previous level in this chapter has any stars (was passed). */
function questLevelUnlocked(levelStars, chapterKey, levelIdx) {
  if (levelIdx === 0) return true;
  return (levelStars[chapterKey] || [])[levelIdx - 1] > 0;
}

/** A chapter is unlocked if it's the first chapter, or every level of the previous chapter has been passed. */
function questChapterUnlocked(levelStars, chapterIdx) {
  if (chapterIdx === 0) return true;
  const prev = QUEST_CHAPTERS[chapterIdx - 1];
  const stars = levelStars[prev.key] || new Array(QUEST_MAX_LEVEL).fill(0);
  return stars.every((s) => s > 0);
}

function questChapterComplete(levelStars, chapterKey) {
  const stars = levelStars[chapterKey] || new Array(QUEST_MAX_LEVEL).fill(0);
  return stars.every((s) => s > 0);
}

function questChapterStars(levelStars, chapterKey) {
  return (levelStars[chapterKey] || []).reduce((a, b) => a + b, 0);
}

function questTotalStars(levelStars) {
  return QUEST_CHAPTERS.reduce((sum, c) => sum + questChapterStars(levelStars, c.key), 0);
}

function questChaptersUnlockedCount(levelStars) {
  return QUEST_CHAPTERS.filter((c, i) => questChapterUnlocked(levelStars, i)).length;
}

/** Index of the chapter the player is "standing on" right now — the first chapter
 *  that isn't fully complete yet (i.e. the frontier of their progress), or the
 *  last chapter if every chapter has been cleared. Drives the map's player pin. */
function questCurrentChapterIndex(levelStars) {
  const i = QUEST_CHAPTERS.findIndex((c) => !questChapterComplete(levelStars, c.key));
  return i === -1 ? QUEST_CHAPTERS.length - 1 : i;
}

/** Index of the level the player is "standing on" within a chapter — the first
 *  level with no stars yet, or the last level if the whole chapter is cleared. */
function questCurrentLevelIndex(levelStars, chapterKey) {
  const stars = levelStars[chapterKey] || new Array(QUEST_MAX_LEVEL).fill(0);
  const i = stars.findIndex((s) => s === 0);
  return i === -1 ? stars.length - 1 : i;
}

// ============================================================================
// PATH MAP LAYOUT — lays nodes out along a gentle winding trail (x in %,
// y in px) so the chapter map and the level map can both render as an
// actual scrollable path, like a mobile-game world map, instead of a grid.
// Used by quest-ui.js (renderQuestMapView / renderQuestChapterView).
// ============================================================================
function questPathLayout(count, opts) {
  opts = opts || {};
  const rowGap = opts.rowGap || 128;
  const topPad = opts.topPad || 86;
  const amp = opts.amp != null ? opts.amp : 27; // max swing from center, in %
  const pts = [];
  for (let i = 0; i < count; i++) {
    pts.push({ x: 50 + amp * Math.sin(i * 1.15 + 0.4), y: topPad + i * rowGap });
  }
  return pts;
}

/** Smooths a list of {x,y} points into a curvy SVG path (Catmull-Rom -> cubic Bezier). */
function questPathSmooth(pts) {
  if (!pts.length) return "";
  if (pts.length === 1) return `M ${pts[0].x} ${pts[0].y}`;
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
  }
  return d;
}

/** Stars earned for one level run: 3 for a flawless 10/10, 2 for 8-9/10, 1 for exactly the 7/10 pass mark, 0 below. */
function questStarsForAccuracy(correctCount) {
  if (correctCount >= 10) return 3;
  if (correctCount >= 8) return 2;
  if (correctCount >= 7) return 1;
  return 0;
}

// ============================================================================
// LOAD / SAVE (quest_progress + quest_attempts — see migration-21-quest-mode.sql)
// ============================================================================
async function loadQuestProgress() {
  const { data } = await supabase.from("quest_progress").select("*").eq("student_id", sstate.student.id).maybeSingle();
  if (data) {
    qstate.progress = { ...data, level_stars: data.level_stars || questDefaultLevelStars() };
  } else {
    const fresh = {
      student_id: sstate.student.id, level_stars: questDefaultLevelStars(),
      total_stars: 0, chapters_unlocked: 1, runs_played: 0,
    };
    const { data: inserted } = await supabase.from("quest_progress").insert(fresh).select().maybeSingle();
    qstate.progress = inserted || { ...fresh, id: null };
  }
  qstate.loaded = true;
}

async function saveQuestProgress() {
  const p = qstate.progress;
  p.total_stars = questTotalStars(p.level_stars);
  p.chapters_unlocked = questChaptersUnlockedCount(p.level_stars);
  await supabase.from("quest_progress").update({
    level_stars: p.level_stars, total_stars: p.total_stars,
    chapters_unlocked: p.chapters_unlocked, runs_played: p.runs_played,
    updated_at: new Date().toISOString(),
  }).eq("student_id", sstate.student.id);
}

async function logQuestAttempt(chapterKey, levelNum, correctCount, starsEarned, pointsEarned) {
  await supabase.from("quest_attempts").insert({
    student_id: sstate.student.id, chapter_key: chapterKey, level_num: levelNum,
    correct_count: correctCount, total_questions: QUEST_RUN_LENGTH,
    stars_earned: starsEarned, points_earned: pointsEarned,
  });
}
