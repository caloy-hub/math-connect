// ============================================================================
// MathConnect — Pet Follow-Companion Widget (Phase 1)
//
// Students asked for their pet to "actually move" and "follow us wherever we
// go." The student dashboard has no navigable avatar/world (student.html is
// one page with tab panels toggled by display:none — see MATHCONNECT 2.0
// architecture notes), so a literal follow-the-cursor pet would be more
// gimmick than companion. Instead this mounts ONE small pet visual outside
// the tab panels (so it survives switchStudentTab()'s show/hide), sitting in
// a fixed corner, and plays a short "scurrying to catch up" walk animation
// every time the student changes tabs — the same emotional beat ("my pet is
// coming with me") without pretending there's a world to walk through.
//
// This file owns ONLY the companion widget's mount/visual/lifecycle. The
// actual animation state machine lives in petState.js (reusable, DOM-free).
// Pet data (pstate, activePet(), petGrowthStage(), petDisplayForm(),
// petVisualHtml()) is read from petEngine.js — nothing here duplicates it.
//
// Deliberately NOT wired up yet (later phases):
//   - Reacting to individual questions/streaks/level-ups        (Phase 2)
//   - Evolution ceremony                                        (Phase 3)
//   - Any place besides this fixed corner widget                (Phase 4)
//   - Battle-arena pet visuals                                  (Phase 5)
// ============================================================================

var petCompanion = {
  mounted: false,
  fsm: null,
  reducedMotion: false,
  hiddenOnTab: false,
  el: null,
  visualEl: null,
};

// Tabs where the companion stays hidden: "pet" already shows the full-size
// pet display (no need for a second copy floating on top of it), and
// "battle"/"exams" are focus moments we don't want to add motion on top of.
const PET_COMPANION_HIDDEN_TABS = ["pet", "exams"];

// See the comment inside renderPetCompanionVisual() — glow only composes
// cleanly with the states built on top of the plain idle bob.
const PET_GLOW_COMPATIBLE_STATES = [PET_STATE.IDLE, PET_STATE.FOLLOW, PET_STATE.IDLE_LOOK, PET_STATE.BLINK, PET_STATE.SLEEP];

async function initPetCompanion() {
  if (petCompanion.mounted) return;
  if (!sstate.section || !isMathSubjectStudent(sstate.section.subject)) return; // pet system is math-only, same gate as the Pet tab itself

  if (!pstate.loaded) {
    try { await loadMyPets(); } catch (e) { console.error("Pet companion: couldn't load pets", e); return; }
  }
  if (!activePet()) return; // nothing to show until the student has adopted a pet

  petCompanion.reducedMotion = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  if (window.matchMedia) {
    window.matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", (e) => {
      petCompanion.reducedMotion = e.matches;
    });
  }

  mountPetCompanionDom();
  petCompanion.fsm = createPetStateMachine({
    render: renderPetCompanionVisual,
    reducedMotion: petCompanion.reducedMotion,
    idleVariety: true,
  });
  petCompanion.mounted = true;

  // Greet the student by scurrying into place rather than just appearing.
  petCompanion.fsm.transition(PET_STATE.WALK);
}


const PET_COMPANION_ACTIVITY_CUES = {
  [PET_STATE.IDLE]: "",
  [PET_STATE.FOLLOW]: "👣",
  [PET_STATE.WALK]: "👣",
  [PET_STATE.IDLE_LOOK]: "👀",
  [PET_STATE.BLINK]: "",
  [PET_STATE.SLEEP]: "💤",
  [PET_STATE.OWNER_STUDY]: "📚",
  [PET_STATE.OWNER_FOCUS]: "👀",
  [PET_STATE.OWNER_SHOP]: "✨",
  [PET_STATE.OWNER_CARE]: "💚",
  [PET_STATE.OWNER_FEED]: "🍪",
  [PET_STATE.OWNER_BATTLE]: "⚔️",
  [PET_STATE.HAPPY]: "✨",
  [PET_STATE.EXCITED]: "✨",
  [PET_STATE.CHEER]: "🎉",
  [PET_STATE.CELEBRATE]: "🎊",
  [PET_STATE.THINK]: "💭",
  [PET_STATE.SURPRISED]: "❕",
  [PET_STATE.DISAPPOINTED]: "💡",
  [PET_STATE.VICTORY]: "🏆",
  [PET_STATE.DEFEAT]: "💚",
};

function mountPetCompanionDom() {
  let root = document.getElementById("petCompanionRoot");
  if (!root) {
    // Resilience: build the mount point even if student.html's markup is
    // an older cached copy without it, so the companion never hard-fails.
    root = document.createElement("div");
    root.id = "petCompanionRoot";
    document.body.appendChild(root);
  }
  root.innerHTML = `
    <div class="pet-companion-widget" id="petCompanionWidget" title="Visit your pet" onclick="switchStudentTab('pet')">
      <div id="petCompanionVisual"></div>
    </div>`;
  petCompanion.el = document.getElementById("petCompanionWidget");
  petCompanion.visualEl = document.getElementById("petCompanionVisual");
}

/** The state machine's render callback — rebuilds the pet's markup with the
 *  current animation class every time the state changes. Also called
 *  directly (not just from the fsm) whenever we need to pick up a possibly-
 *  different active pet, e.g. after the student switches or adopts one. */
function renderPetCompanionVisual(animClass, state) {
  if (!petCompanion.visualEl) return;
  const pet = activePet();
  if (!pet) { hidePetCompanion(); return; }
  const stage = petGrowthStage(pet.growth_points);
  const form = petDisplayForm(pet.pet_type_key, stage.label);
  const activityCue = PET_COMPANION_ACTIVITY_CUES[state] || PET_COMPANION_ACTIVITY_CUES[PET_STATE.IDLE];
  // The existing glow classes (pet-glow-radiant/champion/legendary) hard-code
  // their own base bob motion alongside the glow pulse (see style.css) — so
  // they only compose cleanly with the idle bob they were built for. Rather
  // than touch that shared, already-relied-upon CSS, we just pause the glow
  // during a motion state (walk, cheer, etc.) and bring it back once the pet
  // settles back to idle/follow — the glow resumes within a second either way.
  const glowClass = PET_GLOW_COMPATIBLE_STATES.includes(state) ? stage.glow : null;
  const petMarkup = petVisualHtml(form, animClass, glowClass, 2.4 * Math.max(stage.scale, 0.75));
  petCompanion.visualEl.innerHTML = `
    <div class="pet-companion-aura" aria-hidden="true"></div>
    <div class="pet-companion-shadow" aria-hidden="true"></div>
    <div class="pet-companion-character" data-state="${state}">${petMarkup}</div>
    <div class="pet-companion-cue" aria-hidden="true">${activityCue}</div>`;
  if (petCompanion.el) {
    petCompanion.el.classList.toggle("pet-companion-walking", state === PET_STATE.WALK);
    petCompanion.el.dataset.petState = state;
    petCompanion.el.dataset.activityCue = activityCue;
  }
}

function hidePetCompanion() {
  if (petCompanion.el) petCompanion.el.style.display = "none";
}
function showPetCompanion() {
  if (petCompanion.el) petCompanion.el.style.display = "";
}

/** Called from switchStudentTab() on every navigation. Re-syncs the visual
 *  (the active pet may have changed on the Pet tab) and plays the "catching
 *  up to you" walk beat — unless reduced motion is on, in which case the
 *  state machine itself skips the walk's motion and this just resettles
 *  the visual with no animation. */
function onPetCompanionTabChange(tab) {
  if (!petCompanion.mounted) return;

  const shouldHide = PET_COMPANION_HIDDEN_TABS.includes(tab);
  petCompanion.hiddenOnTab = shouldHide;
  if (shouldHide) { hidePetCompanion(); return; }

  showPetCompanion();
  renderPetCompanionVisual(PET_STATE_CLASS[petCompanion.fsm.getState()], petCompanion.fsm.getState()); // pick up an active-pet change immediately
  petCompanion.fsm.transition(PET_STATE.WALK);

  // The pet mirrors the owner's current activity, not just answer outcomes.
  // Let the "catch up" walk finish first, then settle into the activity pose.
  if (typeof triggerPetEvent === "function") {
    const tabEvent = {
      overview: "OWNER_FOCUS",
      grades: "OWNER_FOCUS",
      attendance: "OWNER_ATTENDANCE",
      blended: "OWNER_STUDY",
      status: "OWNER_FOCUS",
      drills: "OWNER_STUDY",
      quest: "OWNER_STUDY",
      learning: "OWNER_STUDY",
      challenges: "OWNER_STUDY",
      shop: "OWNER_SHOP",
      share: "OWNER_FOCUS",
      battle: "OWNER_BATTLE",
      legends: "OWNER_FOCUS",
      report: "OWNER_FOCUS",
    };
    const eventName = tabEvent[tab];
    if (eventName) setTimeout(() => {
      if (petCompanion.mounted && !petCompanion.hiddenOnTab) triggerPetEvent(eventName, { silent: true });
    }, 700);
  }
}
