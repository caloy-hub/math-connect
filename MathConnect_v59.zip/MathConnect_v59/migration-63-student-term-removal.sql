-- ============================================================================
-- MathConnect — Migration 63 (v56): Remove a student PER TERM
-- ----------------------------------------------------------------------------
-- Until now the only way to take a student out of a class was to DELETE them,
-- which erases their scores and attendance in EVERY term (all of it cascades).
-- This adds a non-destructive, per-term alternative:
--
--   * A student can be removed from Term N (and, optionally, every later term).
--   * Terms BEFORE Term N are never touched — their scores, attendance, grades
--     and report cards stay exactly as they were.
--   * Nothing is deleted. The student's scores/attendance for the removed term
--     stay in the database and come back if the student is restored.
--
-- Data model: one row in student_term_status per (student, term) that is
-- removed. No row = the student is enrolled in that term (so every existing
-- student is enrolled in every term, and nothing needs backfilling).
--
-- All writes go through two SECURITY DEFINER functions:
--     remove_student_from_term(student, term, apply_to_later, reason, note)
--     restore_student_to_term(student, term, apply_to_later)
-- Both check that the caller owns the section (or is an admin), that the
-- student and the term belong to the same section, and they only ever change
-- terms whose term_number is >= the chosen term — earlier terms are
-- untouchable from here.
--
-- Run AFTER migration-36 (needs nothing from it, but it shares the same
-- teacher/admin policy helpers). SAFE TO RE-RUN.
-- ============================================================================

create table if not exists student_term_status (
  id          uuid primary key default gen_random_uuid(),
  student_id  uuid not null references students(id) on delete cascade,
  term_id     uuid not null references terms(id)    on delete cascade,
  status      text not null default 'removed' check (status in ('removed')),
  reason      text,                                   -- e.g. 'Transferred to another school'
  note        text,                                   -- free text, optional
  removed_at  timestamptz not null default now(),
  removed_by  uuid,                                   -- auth user id of the teacher/admin
  unique (student_id, term_id)
);

create index if not exists student_term_status_term_idx on student_term_status (term_id);

alter table student_term_status enable row level security;

-- Read: same shape as term_bonus_points — the student/report-card pages run on
-- the anon key, teachers see their own sections, admins see everything.
drop policy if exists "read student_term_status" on student_term_status;
create policy "read student_term_status" on student_term_status for select using (
  auth.role() = 'anon' or is_admin() or exists (
    select 1 from terms t where t.id = student_term_status.term_id and is_teacher_of_section(t.section_id)
  )
);

-- Write: no direct teacher writes on purpose — teachers go through the two
-- functions below, which enforce "never touch earlier terms". Admin may fix
-- a stray row directly.
drop policy if exists "admin write student_term_status" on student_term_status;
create policy "admin write student_term_status" on student_term_status
  for all using (is_admin()) with check (is_admin());

-- ----------------------------------------------------------------------------
-- remove_student_from_term
--   apply_to_later = true  -> the chosen term AND every later term of the section
--   apply_to_later = false -> the chosen term only
-- Returns the number of terms the student is now removed from by this call.
-- A later term that was ALREADY removed keeps its own reason/date.
-- ----------------------------------------------------------------------------
create or replace function public.remove_student_from_term(
  target_student_id uuid,
  target_term_id    uuid,
  apply_to_later    boolean default true,
  removal_reason    text    default null,
  removal_note      text    default null
) returns integer
language plpgsql security definer set search_path = public as $$
declare
  st_section  uuid;
  tm_section  uuid;
  tm_number   int;
  affected    int := 0;
begin
  select section_id into st_section from students where id = target_student_id;
  select section_id, term_number into tm_section, tm_number from terms where id = target_term_id;

  if st_section is null or tm_section is null then
    raise exception 'Student or term not found.';
  end if;
  if st_section is distinct from tm_section then
    raise exception 'That student does not belong to this section.';
  end if;
  if not (is_teacher_of_section(tm_section) or is_admin()) then
    raise exception 'Only the section''s teacher can remove a student from a term.';
  end if;

  -- The chosen term: (re)write reason/note/date.
  insert into student_term_status (student_id, term_id, reason, note, removed_by)
  values (target_student_id, target_term_id, nullif(btrim(removal_reason), ''), nullif(btrim(removal_note), ''), auth.uid())
  on conflict (student_id, term_id) do update
    set reason = excluded.reason, note = excluded.note, removed_at = now(), removed_by = excluded.removed_by;
  affected := 1;

  -- Later terms only (term_number strictly greater). Earlier terms are never
  -- referenced by this function, so they cannot be affected.
  if apply_to_later then
    with ins as (
      insert into student_term_status (student_id, term_id, reason, note, removed_by)
      select target_student_id, t.id, nullif(btrim(removal_reason), ''), nullif(btrim(removal_note), ''), auth.uid()
      from terms t
      where t.section_id = tm_section and t.term_number > tm_number
      on conflict (student_id, term_id) do nothing
      returning 1
    )
    select affected + count(*) into affected from ins;
  end if;

  return affected;
end;
$$;

-- ----------------------------------------------------------------------------
-- restore_student_to_term
--   apply_to_later = true  -> the chosen term AND every later term
--   apply_to_later = false -> the chosen term only
-- Returns how many terms the student was restored to. Earlier terms are never
-- touched (they are only ever changed by a removal made in THAT earlier term).
-- ----------------------------------------------------------------------------
create or replace function public.restore_student_to_term(
  target_student_id uuid,
  target_term_id    uuid,
  apply_to_later    boolean default true
) returns integer
language plpgsql security definer set search_path = public as $$
declare
  st_section uuid;
  tm_section uuid;
  tm_number  int;
  affected   int := 0;
begin
  select section_id into st_section from students where id = target_student_id;
  select section_id, term_number into tm_section, tm_number from terms where id = target_term_id;

  if st_section is null or tm_section is null then
    raise exception 'Student or term not found.';
  end if;
  if st_section is distinct from tm_section then
    raise exception 'That student does not belong to this section.';
  end if;
  if not (is_teacher_of_section(tm_section) or is_admin()) then
    raise exception 'Only the section''s teacher can restore a student to a term.';
  end if;

  with del as (
    delete from student_term_status s
    using terms t
    where s.student_id = target_student_id
      and s.term_id = t.id
      and t.section_id = tm_section
      and (t.id = target_term_id or (apply_to_later and t.term_number > tm_number))
    returning 1
  )
  select count(*) into affected from del;

  return affected;
end;
$$;

-- Only signed-in users may call these (they re-check section ownership anyway).
revoke all on function public.remove_student_from_term(uuid, uuid, boolean, text, text) from public, anon;
revoke all on function public.restore_student_to_term(uuid, uuid, boolean) from public, anon;
grant execute on function public.remove_student_from_term(uuid, uuid, boolean, text, text) to authenticated;
grant execute on function public.restore_student_to_term(uuid, uuid, boolean) to authenticated;

-- ============================================================================
-- Done. Nothing else to configure: teachers get a "Manage students this term"
-- button at the top of Class Record (and a "Removed this term" list in Roster).
-- ============================================================================
