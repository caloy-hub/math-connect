// ============================================================================
// MathConnect — Station Certificates (v53)
// Every successful station completion in Math Drills, Quest Mode and
// Intelligent Practice earns a printable certificate carrying the student's
// name and exactly what they achieved. Certificates open in a preview with
// "Download PDF" and "Print", and stay on a "My Certificates" shelf.
//
//   v58 — WHOLE-STATION CERTIFICATES (Math Drills + Quest Mode)
//     A certificate is no longer given per run or per level. It is given ONCE per
//     station, when the student has finished the WHOLE station:
//       • every level cleared (Math Drills: levels 1–15; Quest Mode: every level of
//         the chapter), AND
//       • overall station accuracy of at least 80% (CERT_STATION_ACCURACY).
//     Overall accuracy = correct answers ÷ questions across the student's BEST run
//     on each level, so replaying a level to improve it counts and retries never
//     hurt. It is computed from the attempt logs (drill_attempts / quest_attempts),
//     so students who already finished a station before v58 are covered too.
//     Type by overall accuracy:  80–89% Completion · 90–99% Award (High Honors)
//                                100% Award (Perfect Score)
//     A better result later only ever upgrades the type (never downgrades).
//   v58 — INTELLIGENT PRACTICE is now whole-station too, but at a stricter 100%:
//     A practice station (= one domain, e.g. Fractions) is COMPLETE when the student
//     finishes a PERFECT session at the top level: all 8 questions at Expert level,
//     every one answered correctly on the FIRST try (no retries, no skips).
//     (Reaching Expert already requires climbing Easy → Medium → Hard.)
//     One certificate per domain — Certificate of Award (Perfect Score).
//     Certificates issued before v58 (per-level, Chapter Champion) are kept and shown
//     under "Earlier certificates".
//   v55 — 🐾 Legendary Pet: ONE Certificate of Award per pet that reaches the
//   Legendary stage (growth_points >= 5000). Issued automatically the moment a
//   pet crosses the line, and also caught up on the next visit for pets that
//   were already Legendary — see certSyncLegendaryPets(). Needs migration-62.
//
// Self-contained: the certificate is drawn on a <canvas> (A4 landscape, 300 dpi)
// and wrapped in a small hand-written PDF — no libraries, works offline.
// Storage: table `station_certificates` (migration-61). If that table isn't
// installed yet, certificates are kept on the student's device instead so
// nothing is ever lost or blocked.
//
// Depends on: supabase-client.js (supabase, escapeHtml, toast), student.js (sstate),
//             difficultyEngine.js (tierLabel, optional), config.js (SCHOOL_NAME).
// ============================================================================

const CERT_PRACTICE_ACCURACY = 1.0;  // v58 — Intelligent Practice station pass line: 100% (first-try) in the Expert-level session
const CERT_PRACTICE_TOP_TIER = 4;    // Expert (LE_MAX_TIER in difficultyEngine.js)
const CERT_STATION_ACCURACY = 0.8;   // v58 — whole-station pass line (Math Drills + Quest Mode): 80% overall
const CERT_LEVEL_CLEAR = 0.7;        // a level counts as "cleared" at 7/10 — same line the games use to unlock the next level
const CERT_HONORS_ACCURACY = 0.9;    // High Honors tier: 90–99% (100% is Perfect Score)
const CERT_KIND_RANK = { completion: 1, excellence: 2, perfect: 3, chapter: 3, legendary: 3 };
const CERT_STATION_LEVEL_KEY = "station"; // level_key of a whole-station certificate
const CERT_SOURCES = {
  drills: { code: "DR", label: "Math Drills", icon: "🎮" },
  quest: { code: "QM", label: "Quest Mode", icon: "🗺️" },
  practice: { code: "IP", label: "Intelligent Practice", icon: "🧠" },
  pet: { code: "PT", label: "Legendary Pets", icon: "🐾" },
};
const CERT_KINDS = {
  completion: { title: "CERTIFICATE", of: "OF COMPLETION", pill: "STATION CLEARED", icon: "🎓", tag: "Certificate of Completion",
    accent: "#237A5F", text: "In recognition of outstanding accuracy and dedication in successfully completing this station. Keep learning, keep growing!" },
  excellence: { title: "CERTIFICATE", of: "OF AWARD", pill: "WITH HIGH HONORS", icon: "🏅", tag: "Certificate of Award · High Honors",
    accent: "#B8861B", text: "In recognition of high mastery and consistent accuracy in this station. Excellent work!" },
  perfect: { title: "CERTIFICATE", of: "OF AWARD", pill: "PERFECT SCORE", icon: "🏆", tag: "Certificate of Award · Perfect Score",
    accent: "#6C3AA8", text: "In recognition of a flawless performance — every single answer correct. A truly outstanding result!" },
  chapter: { title: "CERTIFICATE", of: "OF AWARD", pill: "CHAPTER CHAMPION", icon: "🌟", tag: "Certificate of Award · Chapter Champion",
    accent: "#A82835", text: "In recognition of clearing every level of this chapter with 90% accuracy or better. Well done, champion!" },
  legendary: { title: "CERTIFICATE", of: "OF AWARD", pill: "LEGENDARY PET", icon: "👑", tag: "Certificate of Award · Legendary Pet",
    accent: "#0E6B78", text: "In recognition of exceptional care and dedication in raising a Math Pet to its Legendary form. A true Pet Master!" },
};

var certState = { cache: {}, fontsPromise: null, busy: false };

// ============================================================================
// ISSUING
// ============================================================================
function certKindForAccuracy(acc) { return acc >= 1 - 1e-9 ? "perfect" : acc >= CERT_HONORS_ACCURACY - 1e-9 ? "excellence" : "completion"; }

function certRandomCode(len) {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  const buf = new Uint8Array(len);
  (window.crypto || window.msCrypto).getRandomValues(buf);
  for (let i = 0; i < len; i++) out += A[buf[i] % A.length];
  return out;
}
function certNumber(source, kind) {
  const d = new Date();
  const code = kind === "chapter" ? "QC" : CERT_SOURCES[source].code;
  return `MC-${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, "0")}-${code}-${certRandomCode(6)}`;
}
function certUniqueKey(source, stationKey, levelKey) { return `${source}:${stationKey}:${levelKey}`; }
/** `extra` as an object, whatever shape the row has it in (null, JSON text, or an object). */
function certExtra(rec) {
  let ex = rec && rec.extra;
  if (typeof ex === "string") { try { ex = JSON.parse(ex); } catch (e) { ex = null; } }
  return ex && typeof ex === "object" ? ex : {};
}

function certIdentity() {
  const st = (sstate && sstate.student) || {};
  const sec = (sstate && sstate.section) || {};
  return {
    student_name: (st.full_name || (sstate.session && sstate.session.name) || "Student").trim(),
    section_name: sec.section_name || null,
    grade_level: sec.grade_level || null,
    school_year: sec.school_year || (sstate.term && sstate.term.school_year) || null,
    subject: sec.subject || "Mathematics",
    teacher_name: sec.subject_teacher_name || null,
    teacher_position: sec.subject_teacher_position || "Subject Teacher",
  };
}

// ---- device fallback store (used only when the DB table isn't there yet) ----
function certLocalKey() { return `mc_certs_v1_${sstate.student.id}`; }
function certLocalLoad() { try { return JSON.parse(localStorage.getItem(certLocalKey()) || "[]"); } catch (e) { return []; } }
function certLocalSave(list) { try { localStorage.setItem(certLocalKey(), JSON.stringify(list.slice(-300))); } catch (e) { /* storage blocked/full */ } }

function certRegister(rec) {
  const key = rec.id || `local:${certUniqueKey(rec.source, rec.station_key, rec.level_key)}`;
  rec._key = key;
  certState.cache[key] = rec;
  return key;
}

/**
 * Issue (or refresh) a certificate for a successful station completion.
 * spec: { source, stationKey, levelKey, stationName, levelLabel, correct, total,
 *         kind?, moduleLine, detail?, stats: [{label, value} | {label, stars, of}] }
 * Returns the certificate record with `_status`: "new" | "improved" | "existing" (or null on failure).
 */
async function issueCertificate(spec) {
  try {
    if (!sstate || !sstate.student) return null;
    const accuracy = spec.total > 0 ? Math.round((spec.correct / spec.total) * 100) : null; // pet certificates carry no score
    const kind = spec.kind || certKindForAccuracy(spec.total > 0 ? spec.correct / spec.total : 0);
    const fields = {
      station_name: spec.stationName, level_label: spec.levelLabel || null, kind,
      correct_count: spec.correct != null ? spec.correct : null, total_questions: spec.total != null ? spec.total : null, accuracy,
      extra: {
        moduleLine: spec.moduleLine || "", detail: spec.detail || "", stats: spec.stats || [],
        // Legendary Pet certificates carry their own artwork path + pet type, so ANY page (incl. the teacher's) can draw them.
        ...(spec.petImage ? { petImage: spec.petImage } : {}), ...(spec.petTypeKey ? { petTypeKey: spec.petTypeKey } : {}),
      },
      ...certIdentity(),
    };
    const sid = sstate.student.id;
    const better = (old) => spec.upgradeOnlyByKind
      ? (CERT_KIND_RANK[kind] || 0) > (CERT_KIND_RANK[old.kind] || 0)   // whole-station: only a higher tier re-issues
      : (accuracy != null && accuracy > (old.accuracy || 0)) || (kind === "chapter" && old.kind !== "chapter");

    // ---- 1) database ----
    let dbOk = true, existing = null;
    try {
      const { data, error } = await supabase.from("station_certificates").select("*")
        .eq("student_id", sid).eq("source", spec.source).eq("station_key", spec.stationKey).eq("level_key", spec.levelKey).maybeSingle();
      if (error) throw error;
      existing = data;
    } catch (e) { dbOk = false; console.warn("station_certificates unavailable, using device storage:", e && e.message); }

    if (dbOk) {
      if (existing) {
        if (!better(existing)) { const r = { ...existing, _status: "existing" }; certRegister(r); return r; }
        const { data, error } = await supabase.from("station_certificates")
          .update({ ...fields, earned_at: new Date().toISOString() }).eq("id", existing.id).select().maybeSingle();
        if (!error && data) { const r = { ...data, _status: "improved" }; certRegister(r); return r; }
        console.warn("certificate update failed:", error && error.message);
        const r = { ...existing, _status: "existing" }; certRegister(r); return r;
      }
      const row = { student_id: sid, source: spec.source, station_key: spec.stationKey, level_key: spec.levelKey, cert_no: certNumber(spec.source, kind), earned_at: new Date().toISOString(), ...fields };
      let { data, error } = await supabase.from("station_certificates").insert(row).select().maybeSingle();
      if (error && (error.code === "23505" || /duplicate key/i.test(error.message || ""))) {
        // cert_no collision (astronomically rare) or a double-tap race: try once more with a fresh number
        row.cert_no = certNumber(spec.source, kind);
        ({ data, error } = await supabase.from("station_certificates").insert(row).select().maybeSingle());
        if (error) {
          const again = await supabase.from("station_certificates").select("*").eq("student_id", sid).eq("source", spec.source).eq("station_key", spec.stationKey).eq("level_key", spec.levelKey).maybeSingle();
          if (again.data) { const r = { ...again.data, _status: "existing" }; certRegister(r); return r; }
        }
      }
      if (!error && data) { const r = { ...data, _status: "new" }; certRegister(r); return r; }
      console.warn("certificate insert failed, using device storage:", error && error.message);
    }

    // ---- 2) device fallback ----
    const list = certLocalLoad();
    const uk = certUniqueKey(spec.source, spec.stationKey, spec.levelKey);
    const i = list.findIndex((c) => certUniqueKey(c.source, c.station_key, c.level_key) === uk);
    if (i >= 0) {
      if (!better(list[i])) { const r = { ...list[i], _status: "existing" }; certRegister(r); return r; }
      list[i] = { ...list[i], ...fields, earned_at: new Date().toISOString() };
      certLocalSave(list);
      const r = { ...list[i], _status: "improved" }; certRegister(r); return r;
    }
    const rec = { id: null, student_id: sid, source: spec.source, station_key: spec.stationKey, level_key: spec.levelKey, cert_no: certNumber(spec.source, kind), earned_at: new Date().toISOString(), ...fields };
    list.push(rec); certLocalSave(list);
    const r = { ...rec, _status: "new" }; certRegister(r); return r;
  } catch (e) {
    console.warn("issueCertificate failed:", e);
    return null; // a certificate problem must never break the run-complete screen
  }
}

// ============================================================================
// v58 — WHOLE-STATION CERTIFICATES
// ============================================================================

/**
 * Summarises a station from a list of runs [{level, correct, total}].
 * Uses the BEST run on each level (highest accuracy). A level is "cleared" when its best run is >= CERT_LEVEL_CLEAR.
 * Returns { levels, cleared, clearedLevels[], missing[], correct, total, accuracy (0-1), allCleared, passes, weakest[] }.
 */
function certStationSummary(runs, maxLevel) {
  const best = {};
  (runs || []).forEach((r) => {
    const lv = Number(r.level), total = Number(r.total), correct = Number(r.correct);
    if (!(lv >= 1 && lv <= maxLevel) || !(total > 0) || !(correct >= 0)) return;
    const ratio = correct / total, cur = best[lv];
    if (!cur || ratio > cur.ratio + 1e-9 || (Math.abs(ratio - cur.ratio) < 1e-9 && total > cur.total)) best[lv] = { correct, total, ratio };
  });
  let correct = 0, total = 0;
  const clearedLevels = [], missing = [];
  for (let n = 1; n <= maxLevel; n++) {
    const b = best[n];
    if (b) { correct += b.correct; total += b.total; }
    if (b && b.ratio >= CERT_LEVEL_CLEAR - 1e-9) clearedLevels.push(n); else missing.push(n);
  }
  const accuracy = total > 0 ? correct / total : 0;
  const allCleared = clearedLevels.length === maxLevel;
  // levels whose best run is the lowest — the ones worth replaying to lift the overall accuracy
  const weakest = Object.keys(best).map((n) => ({ n: Number(n), ratio: best[n].ratio })).filter((x) => x.ratio < 1 - 1e-9)
    .sort((x, y) => x.ratio - y.ratio || x.n - y.n).slice(0, 3).map((x) => x.n).sort((x, y) => x - y);
  return {
    levels: maxLevel, cleared: clearedLevels.length, clearedLevels, missing, correct, total, accuracy, allCleared,
    passes: allCleared && accuracy >= CERT_STATION_ACCURACY - 1e-9, weakest,
  };
}

/** Every logged run of one Math Drills station for this student (+ the run just played / any not yet uploaded). */
async function certLoadDrillRuns(topic, extraRun) {
  const runs = [];
  try {
    const res = await fetchAllRowsChecked(() => supabase.from("drill_attempts").select("level,correct_count,total_questions")
      .eq("student_id", sstate.student.id).eq("topic", topic));
    (res.data || []).forEach((r) => runs.push({ level: r.level, correct: r.correct_count, total: r.total_questions }));
  } catch (e) { console.warn("certLoadDrillRuns:", e && e.message); }
  try { // runs a bad connection left waiting on this device
    if (typeof drillPendingLoad === "function") drillPendingLoad().filter((r) => r && r.topic === topic && r.student_id === sstate.student.id)
      .forEach((r) => runs.push({ level: r.level, correct: r.correct_count, total: r.total_questions }));
  } catch (e) { /* optional */ }
  if (extraRun) runs.push(extraRun); // best-of per level makes a duplicate of a saved run harmless
  return runs;
}
/** Every logged run of one Quest chapter for this student (+ the run just played). */
async function certLoadQuestRuns(chapterKey, extraRun) {
  const runs = [];
  try {
    const res = await fetchAllRowsChecked(() => supabase.from("quest_attempts").select("level_num,correct_count,total_questions")
      .eq("student_id", sstate.student.id).eq("chapter_key", chapterKey));
    (res.data || []).forEach((r) => runs.push({ level: r.level_num, correct: r.correct_count, total: r.total_questions }));
  } catch (e) { console.warn("certLoadQuestRuns:", e && e.message); }
  if (extraRun) runs.push(extraRun);
  return runs;
}

function certStationStats(sum, third) {
  return [
    { label: "LEVELS CLEARED", value: `${sum.cleared} / ${sum.levels}` },
    { label: "STATION ACCURACY", value: `${Math.round(sum.accuracy * 100)}%` },
    third || { label: "QUESTIONS CORRECT", value: `${sum.correct} / ${sum.total}` },
  ];
}
function certSpecForDrillStation(topicMeta, topicKey, sum) {
  return {
    source: "drills", stationKey: topicKey, levelKey: CERT_STATION_LEVEL_KEY, upgradeOnlyByKind: true,
    stationName: topicMeta.name, levelLabel: `All ${sum.levels} levels`,
    correct: sum.correct, total: sum.total,
    moduleLine: `MATH DRILLS  ·  ALL ${sum.levels} LEVELS COMPLETED`,
    detail: `Levels 1–${sum.levels} cleared with ${Math.round(sum.accuracy * 100)}% overall accuracy`,
    stats: certStationStats(sum),
  };
}
function certSpecForQuestStation(chapter, sum, levelStars) {
  const idx = QUEST_CHAPTERS.indexOf(chapter);
  const got = typeof questChapterStars === "function" ? questChapterStars(levelStars || {}, chapter.key) : 0;
  return {
    source: "quest", stationKey: chapter.key, levelKey: CERT_STATION_LEVEL_KEY, upgradeOnlyByKind: true,
    stationName: chapter.title, levelLabel: `All ${sum.levels} levels`,
    correct: sum.correct, total: sum.total,
    moduleLine: `QUEST MODE  ·  CHAPTER ${idx + 1}  ·  ${chapter.subject.toUpperCase()}`,
    detail: `All ${sum.levels} levels cleared with ${Math.round(sum.accuracy * 100)}% overall accuracy`,
    stats: certStationStats(sum, { label: "STARS EARNED", value: `${got} / ${sum.levels * 3}` }),
  };
}

/**
 * Called after every Math Drills run that cleared its level. Issues (or upgrades) the whole-station certificate
 * once levels 1..DRILL_MAX_LEVEL are all cleared with >= 80% overall accuracy.
 * Returns { sum, rec } — rec is null unless a certificate was newly issued / upgraded by this run.
 */
async function certCheckDrillStation(game) {
  try {
    const maxLevel = typeof DRILL_MAX_LEVEL !== "undefined" ? DRILL_MAX_LEVEL : 15;
    const runs = await certLoadDrillRuns(game.topic, { level: game.level, correct: game.correct, total: DRILL_RUN_LENGTH });
    const sum = certStationSummary(runs, maxLevel);
    if (!sum.passes) return { sum, rec: null };
    const rec = await issueCertificate(certSpecForDrillStation(game.topicMeta, game.topic, sum));
    return { sum, rec: rec && rec._status !== "existing" ? rec : null };
  } catch (e) { console.warn("certCheckDrillStation:", e); return { sum: null, rec: null }; }
}
/** Same for a Quest chapter (every level of the chapter cleared, >= 80% overall). */
async function certCheckQuestStation(game, levelStars) {
  try {
    const runs = await certLoadQuestRuns(game.chapter.key, { level: game.levelNum, correct: game.correct, total: QUEST_RUN_LENGTH });
    const sum = certStationSummary(runs, QUEST_MAX_LEVEL);
    if (!sum.passes) return { sum, rec: null };
    const rec = await issueCertificate(certSpecForQuestStation(game.chapter, sum, levelStars));
    return { sum, rec: rec && rec._status !== "existing" ? rec : null };
  } catch (e) { console.warn("certCheckQuestStation:", e); return { sum: null, rec: null }; }
}

/** Result-screen strip: how close the student is to this station's certificate (shown when no certificate was just earned). */
function certStationProgressHtml(sum, stationLabel) {
  if (!sum) return "";
  const need = Math.round(CERT_STATION_ACCURACY * 100), acc = Math.round(sum.accuracy * 100);
  let msg;
  if (sum.passes) {
    msg = `✅ ${stationLabel} is complete — all ${sum.levels} levels cleared at ${acc}%. Your certificate is on 🎓 My Certificates.`;
  } else if (sum.allCleared) {
    const lv = sum.weakest.length ? ` Replay ${sum.weakest.length === 1 ? "Level" : "Levels"} ${sum.weakest.join(", ")} to lift it.` : "";
    msg = `All ${sum.levels} levels cleared, but your station accuracy is ${acc}% — you need ${need}% for the certificate.${lv}`;
  } else {
    msg = `Station certificate: ${sum.cleared} of ${sum.levels} levels cleared · accuracy so far ${sum.total ? acc + "%" : "—"}. Clear all ${sum.levels} levels with ${need}% overall accuracy to earn it.`;
  }
  const pct = Math.round((sum.cleared / sum.levels) * 100);
  return `<div class="cert-progress"><div class="cert-progress-bar"><span style="width:${pct}%"></span></div><div class="muted" style="font-size:.8rem;margin-top:6px;">🎓 ${msg}</div></div>`;
}

/** Certificates issued before v58 (one per level / Chapter Champion / practice session) — kept, but shown apart from the whole-station ones. */
function certIsLegacy(c) { return (c.source === "drills" || c.source === "quest" || c.source === "practice") && c.level_key !== CERT_STATION_LEVEL_KEY; }

// ----------------------------------------------------------------------------
// v58 — INTELLIGENT PRACTICE station certificates (100%)
// ----------------------------------------------------------------------------
/**
 * Summarises one finished practice session. `answers` = one entry per question of the session:
 *   { tier: 1-4 (the level the question was asked at), firstTry: true when answered correctly on the 1st attempt,
 *     skipped?: true }
 * A session earns the station certificate only when it is PERFECT: every question at the top (Expert) level,
 * every one correct on the first try, nothing skipped.
 */
function certPracticeSummary(answers, expectedLength) {
  const list = Array.isArray(answers) ? answers : [];
  const total = expectedLength || list.length;
  const firstTry = list.filter((a) => a && a.firstTry && !a.skipped).length;
  const atTop = list.filter((a) => a && a.tier >= CERT_PRACTICE_TOP_TIER).length;
  const accuracy = total > 0 ? firstTry / total : 0;
  return {
    total, firstTry, atTop, accuracy,
    flawless: total > 0 && list.length >= total && firstTry === total,
    passes: total > 0 && list.length >= total && accuracy >= CERT_PRACTICE_ACCURACY - 1e-9 && atTop === total,
  };
}
function certSpecForPracticeStation(game, sum, mastery) {
  const top = typeof tierLabel === "function" ? tierLabel(CERT_PRACTICE_TOP_TIER) : "Expert";
  return {
    source: "practice", stationKey: game.domain, levelKey: CERT_STATION_LEVEL_KEY, upgradeOnlyByKind: true, kind: "perfect",
    stationName: game.domainMeta.name, levelLabel: `${top} level mastered`,
    correct: sum.firstTry, total: sum.total,
    moduleLine: `INTELLIGENT PRACTICE  ·  ${top.toUpperCase()} LEVEL  ·  STATION COMPLETED`,
    detail: `A perfect ${sum.total}/${sum.total} session at ${top} level — every answer right the first time`,
    stats: [
      { label: "LEVEL REACHED", value: top },
      { label: "SESSION SCORE", value: `${sum.firstTry} / ${sum.total}` },
      { label: "SKILL MASTERY", value: `${mastery}%` },
    ],
  };
}
/** Issues the practice station certificate when this session was perfect at Expert level. Returns { sum, rec }. */
async function certCheckPracticeStation(game, answers, mastery) {
  try {
    const sum = certPracticeSummary(answers, game.sessionLength);
    if (!sum.passes) return { sum, rec: null };
    const rec = await issueCertificate(certSpecForPracticeStation(game, sum, mastery));
    return { sum, rec: rec && rec._status !== "existing" ? rec : null };
  } catch (e) { console.warn("certCheckPracticeStation:", e); return { sum: null, rec: null }; }
}
/** Result-screen strip: what stands between the student and this domain's certificate. */
function certPracticeProgressHtml(sum, endTier, domainName) {
  if (!sum) return "";
  const topName = typeof tierLabel === "function" ? tierLabel(CERT_PRACTICE_TOP_TIER) : "Expert";
  let msg;
  if (sum.passes) msg = `✅ ${domainName} is complete — a perfect session at ${topName} level. Your certificate is on 🎓 My Certificates.`;
  else if (sum.atTop < sum.total) msg = `Station certificate: reach ${topName} level, then finish a session with all ${sum.total} questions at ${topName} level answered correctly on the first try. ${endTier >= CERT_PRACTICE_TOP_TIER ? `You're at ${topName} now — go for it!` : `You're at ${typeof tierLabel === "function" ? tierLabel(endTier) : "level " + endTier} now — keep climbing.`}`;
  else msg = `Station certificate: you're at ${topName} level! This session had ${sum.firstTry}/${sum.total} right on the first try — you need all ${sum.total} (no retries or skips) to earn it.`;
  const pct = Math.round((Math.max(1, Math.min(endTier || 1, CERT_PRACTICE_TOP_TIER)) / CERT_PRACTICE_TOP_TIER) * 100);
  return `<div class="cert-progress"><div class="cert-progress-bar"><span style="width:${pct}%"></span></div><div class="muted" style="font-size:.8rem;margin-top:6px;">🎓 ${msg}</div></div>`;
}

// ============================================================================
// 🐾 LEGENDARY PET CERTIFICATES (v55)
// One certificate per pet (unique key = student + "pet" + pet id + "legendary"),
// so a student who raises a second Legendary pet earns a second certificate.
// certSyncLegendaryPets() is idempotent — safe to call on every pet load: it
// reads the student's shelf once and only issues for Legendary pets that have
// no certificate yet (which also back-fills pets that were Legendary before
// this feature shipped).
// ============================================================================
function certPetShortForm(title) {
  return String(title || "").split(",")[0].replace(/^The\s+/i, "").replace(/\s+of the .*$/i, "").trim() || "Legendary";
}
function certSpecForPet(pet) {
  const meta = (typeof PET_TYPE_META !== "undefined" && PET_TYPE_META[pet.pet_type_key]) || {};
  const petName = String(pet.pet_name || "").trim() || "Math Pet";
  const formTitle = meta.legendaryTitle || "Legendary form";
  const gp = pet.growth_points || 0;
  const adopted = pet.adopted_at ? new Date(pet.adopted_at).toLocaleDateString("en-PH", { year: "numeric", month: "short" }) : "—";
  return {
    source: "pet", stationKey: String(pet.id), levelKey: "legendary", kind: "legendary",
    stationName: petName, levelLabel: "Legendary",
    moduleLine: `LEGENDARY PET  ·  ${formTitle.toUpperCase()}`,
    detail: "Raised from a hatchling to the Legendary stage",
    petImage: meta.legendaryImage || "", petTypeKey: pet.pet_type_key,
    stats: [
      { label: "LEGENDARY FORM", value: certPetShortForm(formTitle) },
      { label: "GROWTH POINTS", value: gp.toLocaleString("en-US") },
      { label: "ADOPTED", value: adopted },
    ],
  };
}

var certPetSync = { running: false, done: {} };

// Which certificates this student has already been told about (per device) — so the "you earned a certificate"
// toast appears once, even though the DATABASE (migration-64 trigger) may have issued it while they were away.
function certSeenKey() { return `mc_cert_seen_v1_${sstate.student.id}`; }
function certSeenLoad() { try { return new Set(JSON.parse(localStorage.getItem(certSeenKey()) || "[]")); } catch (e) { return new Set(); } }
function certSeenSave(set) { try { localStorage.setItem(certSeenKey(), JSON.stringify([...set].slice(-300))); } catch (e) { /* storage blocked/full */ } }

/** The Legendary certificate of one specific pet (whether the database trigger or this device issued it). */
async function certFindPetCertificate(petId) {
  try {
    const all = await loadCertificates();
    const rec = all.find((c) => c.source === "pet" && c.level_key === "legendary" && String(c.station_key) === String(petId));
    if (rec) { rec._status = "new"; certRegister(rec); }
    return rec || null;
  } catch (e) { return null; }
}

/** Older certificates (issued before v57) may lack the pet artwork inside the row — add it so every viewer can draw it. */
async function certRepairPetImage(rec, pet) {
  try {
    const meta = (typeof PET_TYPE_META !== "undefined" && PET_TYPE_META[pet.pet_type_key]) || {};
    if (!meta.legendaryImage) return;
    const extra = { ...certExtra(rec), petImage: meta.legendaryImage, petTypeKey: pet.pet_type_key };
    const { error } = await supabase.from("station_certificates").update({ extra }).eq("id", rec.id);
    if (!error) rec.extra = extra;
  } catch (e) { /* cosmetic only */ }
}

/**
 * Makes sure every Legendary pet the student owns has its certificate, and announces new ones once.
 * The DATABASE normally issues the certificate the instant the pet reaches Legendary (migration-64 trigger);
 * this is the safety net for projects that haven't run it yet and the place the student gets told.
 * Returns the certificates the student hadn't been told about yet.
 * opts.silent = true suppresses the toast (the evolution ceremony shows its own banner).
 */
async function certSyncLegendaryPets(opts) {
  try {
    if (certPetSync.running) return [];
    if (!sstate || !sstate.student || typeof pstate === "undefined" || typeof petIsPeak !== "function") return [];
    const todo = (pstate.pets || []).filter((p) => p && p.id && petIsPeak(p) && !certPetSync.done[p.id]);
    if (!todo.length) return [];
    certPetSync.running = true;
    const fresh = [];
    try {
      const all = await loadCertificates();
      const mine = new Map(all.filter((c) => c.source === "pet" && c.level_key === "legendary").map((c) => [String(c.station_key), c]));
      const seen = certSeenLoad();
      for (const pet of todo) {
        let rec = mine.get(String(pet.id));
        if (!rec) rec = await issueCertificate(certSpecForPet(pet)); // safety net: trigger not installed yet
        if (!rec) continue;
        if (rec.id && !certExtra(rec).petImage) await certRepairPetImage(rec, pet);
        certPetSync.done[pet.id] = true;
        const key = rec.id || `local:${certUniqueKey(rec.source, rec.station_key, rec.level_key)}`;
        if (!seen.has(key)) { seen.add(key); rec._status = "new"; certRegister(rec); fresh.push(rec); }
      }
      certSeenSave(seen);
    } finally { certPetSync.running = false; }
    if (fresh.length && !(opts && opts.silent) && typeof toast === "function") {
      toast(`👑 Legendary Pet certificate earned for ${fresh.map((r) => r.station_name).join(", ")}! Open 🎓 My Certificates to view or print it.`);
    }
    return fresh;
  } catch (e) { console.warn("certSyncLegendaryPets failed:", e); certPetSync.running = false; return []; }
}

/** The "🎓 Certificate earned" strip shown on each run-complete screen. */
function certEarnedBannerHtml(rec) {
  if (!rec) return "";
  const k = CERT_KINDS[rec.kind] || CERT_KINDS.completion;
  const key = rec._key || certRegister(rec);
  const note = rec.kind === "legendary" ? (rec._status === "new" ? "Your Legendary pet earned you a certificate!" : "Your Legendary pet certificate.")
    : rec._status === "existing" ? "You already hold this one — your best result is kept." : rec._status === "improved" ? "Upgraded with your better station accuracy!"
      : (rec.level_key === CERT_STATION_LEVEL_KEY ? "You completed the whole station — certificate earned!" : "You earned a certificate!");
  return `
    <div class="cert-earned">
      <div class="cert-earned-icon">${k.icon}</div>
      <div class="cert-earned-text">
        <strong>${escapeHtml(k.tag)}</strong>
        <div class="muted" style="font-size:.8rem;">${escapeHtml(rec.station_name)}${rec.level_label ? " · " + escapeHtml(rec.level_label) : ""} — ${note}</div>
      </div>
      <button class="btn-gold btn-sm" onclick="openCertificate('${escapeHtml(key).replace(/'/g, "\\'")}')">View &amp; Print</button>
    </div>`;
}

// ============================================================================
// LOADING THE SHELF
// ============================================================================
/** Certificates that only exist on this device (saved while the table or its rules weren't ready) are pushed to the
 *  database so the TEACHER can see them too. Returns the ones that still couldn't be uploaded. */
async function certUploadLocalRows(local) {
  const remaining = []; let moved = 0;
  for (const c of local) {
    const row = { ...c }; delete row.id; delete row._key; delete row._status;
    row.student_id = sstate.student.id;
    const { error } = await supabase.from("station_certificates").insert(row);
    if (!error || error.code === "23505" || /duplicate key/i.test((error && error.message) || "")) moved++;
    else remaining.push(c);
  }
  if (moved) certLocalSave(remaining);
  return remaining;
}

async function loadCertificates() {
  let dbRows = [], dbOk = false;
  const fetchDb = async () => {
    const { data, error } = await supabase.from("station_certificates").select("*").eq("student_id", sstate.student.id).order("earned_at", { ascending: false }).limit(500);
    if (error) throw error;
    return data || [];
  };
  try { dbRows = await fetchDb(); dbOk = true; } catch (e) { /* table not installed yet — device copies below still show */ }
  const seenKeys = () => new Set(dbRows.map((c) => certUniqueKey(c.source, c.station_key, c.level_key)));
  let local = certLocalLoad().filter((c) => !seenKeys().has(certUniqueKey(c.source, c.station_key, c.level_key)));
  if (dbOk && local.length && !certState.uploading) {
    certState.uploading = true;
    try {
      const before = local.length;
      local = await certUploadLocalRows(local);
      if (local.length < before) { try { dbRows = await fetchDb(); } catch (e) { /* keep what we had */ } }
    } catch (e) { console.warn("uploading device certificates failed:", e && e.message); }
    finally { certState.uploading = false; }
  }
  const all = dbRows.concat(local).sort((a, b) => new Date(b.earned_at) - new Date(a.earned_at));
  all.forEach(certRegister);
  return all;
}

// ============================================================================
// DRAWING — A4 landscape, designed on a 1000 x 707 grid and scaled to the canvas
// ============================================================================
const CERT_W = 1000, CERT_H = 707;
const CERT_C = { navy: "#10294F", navy2: "#1E4079", gold: "#C79A2B", goldLt: "#EBCB6E", cream: "#FFFCF3", ink: "#1B1F2B", muted: "#5B6577" };
const CERT_F = {
  display: (px, w, it) => `${it ? "italic " : ""}${w || 700} ${px}px 'Playfair Display','Lora','Georgia','Times New Roman',serif`,
  sans: (px, w) => `${w || 600} ${px}px 'Poppins','Inter','Segoe UI',Arial,sans-serif`,
  math: (px) => `400 ${px}px 'Cambria Math','STIX Two Math','Noto Serif','DejaVu Serif','Times New Roman',serif`,
};

function certFontAvailable(ctx, name) {
  const probe = "mmmmmmmmmmlli 0123";
  const w = (fam) => { ctx.font = `40px ${fam}`; return ctx.measureText(probe).width; };
  return w(`"${name}", monospace`) !== w("monospace") || w(`"${name}", serif`) !== w("serif");
}
function certEnsureFonts() {
  if (certState.fontsPromise) return certState.fontsPromise;
  certState.fontsPromise = (async () => {
    try {
      if (!document.getElementById("certFontLink")) {
        const link = document.createElement("link");
        link.id = "certFontLink"; link.rel = "stylesheet";
        link.href = "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,500&family=Great+Vibes&family=Poppins:wght@500;600;700&display=swap";
        document.head.appendChild(link);
        await new Promise((res) => { link.onload = res; link.onerror = res; setTimeout(res, 3000); });
      }
      if (document.fonts && document.fonts.load) {
        await Promise.race([
          Promise.all([
            document.fonts.load("700 40px 'Playfair Display'"), document.fonts.load("italic 500 20px 'Playfair Display'"),
            document.fonts.load("40px 'Great Vibes'"), document.fonts.load("600 20px 'Poppins'"),
          ]),
          new Promise((res) => setTimeout(res, 3500)),
        ]);
      }
    } catch (e) { /* offline: the system-font fallbacks in CERT_F still look good */ }
  })();
  return certState.fontsPromise;
}

function cSpaced(ctx, text, x, y, spacing, align) {
  const chars = Array.from(text);
  const widths = chars.map((ch) => ctx.measureText(ch).width);
  const total = widths.reduce((a, b) => a + b, 0) + spacing * Math.max(0, chars.length - 1);
  let cx = align === "center" ? x - total / 2 : align === "right" ? x - total : x;
  const prev = ctx.textAlign; ctx.textAlign = "left";
  chars.forEach((ch, i) => { ctx.fillText(ch, cx, y); cx += widths[i] + spacing; });
  ctx.textAlign = prev;
  return total;
}
function cFit(ctx, text, maxW, size, minSize, fontFn) {
  let s = size;
  ctx.font = fontFn(s);
  while (s > minSize && ctx.measureText(text).width > maxW) { s -= 1; ctx.font = fontFn(s); }
  return s;
}
function cWrap(ctx, text, maxW) {
  const words = String(text).split(/\s+/); const lines = []; let cur = "";
  words.forEach((w) => { const t = cur ? cur + " " + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
  if (cur) lines.push(cur);
  return lines;
}
function cStar(ctx, cx, cy, r, fill, stroke) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5, rr = i % 2 === 0 ? r : r * 0.42;
    const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
    i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
  }
  ctx.closePath();
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
}
function cDiamond(ctx, cx, cy, r, fill) {
  ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx + r, cy); ctx.lineTo(cx, cy + r); ctx.lineTo(cx - r, cy); ctx.closePath();
  ctx.fillStyle = fill; ctx.fill();
}
function cRoundRect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

function certDrawBackground(ctx, accent) {
  ctx.fillStyle = CERT_C.cream; ctx.fillRect(0, 0, CERT_W, CERT_H);

  // millimetre graph-paper texture (the Math Lab motif), kept very light for printing
  ctx.save();
  ctx.beginPath(); ctx.rect(30, 30, CERT_W - 60, CERT_H - 60); ctx.clip();
  for (let x = 30; x <= CERT_W - 30; x += 10) { ctx.strokeStyle = (x - 30) % 50 === 0 ? "rgba(16,41,79,.075)" : "rgba(16,41,79,.035)"; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(x, 30); ctx.lineTo(x, CERT_H - 30); ctx.stroke(); }
  for (let y = 30; y <= CERT_H - 30; y += 10) { ctx.strokeStyle = (y - 30) % 50 === 0 ? "rgba(16,41,79,.075)" : "rgba(16,41,79,.035)"; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(30, y); ctx.lineTo(CERT_W - 30, y); ctx.stroke(); }
  // soft glow behind the centre so the text area stays clean
  const g = ctx.createRadialGradient(CERT_W / 2, CERT_H / 2, 60, CERT_W / 2, CERT_H / 2, 470);
  g.addColorStop(0, "rgba(255,252,243,.94)"); g.addColorStop(1, "rgba(255,252,243,0)");
  ctx.fillStyle = g; ctx.fillRect(30, 30, CERT_W - 60, CERT_H - 60);
  // faint math glyphs in the corners
  ctx.fillStyle = "rgba(16,41,79,.05)"; ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
  ctx.font = CERT_F.math(170); ctx.fillText("∞", 130, 250);
  ctx.font = CERT_F.math(150); ctx.fillText("∑", 872, 262);
  ctx.font = CERT_F.math(120); ctx.fillText("√", 120, 600);
  ctx.font = CERT_F.math(120); ctx.fillText("∫", 884, 610);
  ctx.restore();

  // triple border
  ctx.strokeStyle = CERT_C.navy; ctx.lineWidth = 7; ctx.strokeRect(14, 14, CERT_W - 28, CERT_H - 28);
  ctx.strokeStyle = CERT_C.gold; ctx.lineWidth = 1.8; ctx.strokeRect(24, 24, CERT_W - 48, CERT_H - 48);
  ctx.strokeStyle = CERT_C.navy2; ctx.lineWidth = 0.8; ctx.strokeRect(30, 30, CERT_W - 60, CERT_H - 60);

  // corner ornaments: quarter-circle rings + accent diamond
  [[30, 30, 1, 1], [CERT_W - 30, 30, -1, 1], [30, CERT_H - 30, 1, -1], [CERT_W - 30, CERT_H - 30, -1, -1]].forEach(([x, y, sx, sy]) => {
    ctx.save(); ctx.translate(x, y); ctx.scale(sx, sy);
    ctx.strokeStyle = CERT_C.gold; ctx.lineWidth = 1.4;
    [16, 24, 32].forEach((r) => { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI / 2); ctx.stroke(); });
    cDiamond(ctx, 9, 9, 4.2, accent);
    ctx.restore();
  });
}

function certDrawLogo(ctx, cx, cy, size) {
  const x = cx - size / 2, y = cy - size / 2;
  ctx.fillStyle = CERT_C.navy; cRoundRect(ctx, x, y, size, size, size * 0.24); ctx.fill();
  const p = (a, b) => [x + (a / 100) * size, y + (b / 100) * size];
  ctx.strokeStyle = "#fff"; ctx.lineWidth = size * 0.09; ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.beginPath(); [[14, 74], [32, 26], [50, 58], [68, 26], [86, 74]].forEach((pt, i) => { const [px, py] = p(pt[0], pt[1]); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }); ctx.stroke();
  const [gx, gy] = p(32, 26); ctx.fillStyle = "#F59E0B"; ctx.beginPath(); ctx.arc(gx, gy, size * 0.075, 0, Math.PI * 2); ctx.fill();
}

function certDrawSeal(ctx, cx, cy, r, accent) {
  // ribbon tails
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.moveTo(cx - r * 0.62, cy + r * 0.5); ctx.lineTo(cx - r * 0.98, cy + r * 1.62); ctx.lineTo(cx - r * 0.58, cy + r * 1.36); ctx.lineTo(cx - r * 0.28, cy + r * 1.66); ctx.lineTo(cx - r * 0.06, cy + r * 0.72); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(cx + r * 0.62, cy + r * 0.5); ctx.lineTo(cx + r * 0.98, cy + r * 1.62); ctx.lineTo(cx + r * 0.58, cy + r * 1.36); ctx.lineTo(cx + r * 0.28, cy + r * 1.66); ctx.lineTo(cx + r * 0.06, cy + r * 0.72); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "rgba(0,0,0,.12)";
  ctx.beginPath(); ctx.moveTo(cx - r * 0.06, cy + r * 0.72); ctx.lineTo(cx - r * 0.28, cy + r * 1.66); ctx.lineTo(cx - r * 0.2, cy + r * 1.66); ctx.lineTo(cx + r * 0.02, cy + r * 0.72); ctx.closePath(); ctx.fill();
  // scalloped rosette
  const N = 30, grad = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
  grad.addColorStop(0, CERT_C.goldLt); grad.addColorStop(0.5, CERT_C.gold); grad.addColorStop(1, "#9C7418");
  ctx.fillStyle = grad;
  for (let i = 0; i < N; i++) { const a = (i / N) * Math.PI * 2; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r * 0.93, cy + Math.sin(a) * r * 0.93, r * 0.115, 0, Math.PI * 2); ctx.fill(); }
  ctx.beginPath(); ctx.arc(cx, cy, r * 0.93, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.55)"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, r * 0.8, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = accent; ctx.beginPath(); ctx.arc(cx, cy, r * 0.68, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = CERT_C.goldLt; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(cx, cy, r * 0.68, 0, Math.PI * 2); ctx.stroke();
  cStar(ctx, cx, cy + r * 0.03, r * 0.44, "#fff");
}

function certDrawStats(ctx, stats, accent) {
  const n = Math.max(1, Math.min(3, stats.length)), bw = 178, gap = 16, bh = 56;
  const total = n * bw + (n - 1) * gap, x0 = (CERT_W - total) / 2, y0 = 474;
  stats.slice(0, 3).forEach((s, i) => {
    const x = x0 + i * (bw + gap);
    ctx.fillStyle = "rgba(255,255,255,.92)"; cRoundRect(ctx, x, y0, bw, bh, 9); ctx.fill();
    ctx.strokeStyle = "rgba(16,41,79,.22)"; ctx.lineWidth = 1; cRoundRect(ctx, x, y0, bw, bh, 9); ctx.stroke();
    ctx.fillStyle = accent; cRoundRect(ctx, x, y0 + 9, 3.5, bh - 18, 2); ctx.fill();
    ctx.fillStyle = CERT_C.muted; ctx.textAlign = "center"; ctx.font = CERT_F.sans(8.6, 600);
    cSpaced(ctx, s.label, x + bw / 2, y0 + 17, 1.5, "center");
    if (s.stars != null) {
      const of = s.of || 3, sp = 26, sx = x + bw / 2 - ((of - 1) * sp) / 2;
      for (let k = 0; k < of; k++) cStar(ctx, sx + k * sp, y0 + 37, 10.5, k < s.stars ? CERT_C.gold : "rgba(16,41,79,.08)", k < s.stars ? "#9C7418" : "rgba(16,41,79,.3)");
    } else {
      ctx.fillStyle = CERT_C.navy; ctx.font = CERT_F.display(fitStat(ctx, s.value, bw - 24), 700);
      ctx.fillText(String(s.value), x + bw / 2, y0 + 44);
    }
  });
}
function fitStat(ctx, text, maxW) { return cFit(ctx, String(text), maxW, 23, 14, (px) => CERT_F.display(px, 700)); }

/** Legendary Pet certificates: the pet's artwork as a soft watermark behind the text (any aspect ratio). */
function certDrawPetWatermark(ctx, img) {
  try {
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    if (!iw || !ih) return;
    const boxW = 600, boxH = 300, k = Math.min(boxW / iw, boxH / ih), w = iw * k, h = ih * k;
    ctx.save(); ctx.globalAlpha = 0.17;
    ctx.drawImage(img, CERT_W / 2 - w / 2, 428 - h / 2, w, h);
    ctx.restore();
  } catch (e) { /* artwork is decoration only */ }
}
function certLoadImage(src) {
  return new Promise((resolve) => {
    if (!src) return resolve(null);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

/** Draws the certificate onto ctx (already scaled to the 1000 x 707 design grid). */
function certDraw(ctx, rec, opts) {
  const kind = CERT_KINDS[rec.kind] || CERT_KINDS.completion;
  const accent = kind.accent, ex = rec.extra || {};
  certDrawBackground(ctx, accent);
  ctx.textBaseline = "alphabetic"; ctx.textAlign = "center";
  if (opts && opts.petImg) certDrawPetWatermark(ctx, opts.petImg);

  // ---- header ----
  certDrawLogo(ctx, CERT_W / 2, 62, 26);
  ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.sans(7.6, 500);
  cSpaced(ctx, "REPUBLIC OF THE PHILIPPINES  ·  DEPARTMENT OF EDUCATION  ·  REGION XI", CERT_W / 2, 88, 1.3, "center");
  const school = (typeof SCHOOL_NAME !== "undefined" && SCHOOL_NAME) ? SCHOOL_NAME : "MathConnect";
  ctx.fillStyle = CERT_C.navy; ctx.font = CERT_F.sans(13.5, 700);
  cSpaced(ctx, school.toUpperCase(), CERT_W / 2, 106, 2.1, "center");
  ctx.textAlign = "left"; ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.sans(8.4, 500);
  cSpaced(ctx, `${(rec.subject || "Mathematics").toUpperCase()}${rec.school_year ? "  ·  S.Y. " + rec.school_year : ""}`, 78, 60, 1.2, "left");
  ctx.textAlign = "right"; cSpaced(ctx, "CERTIFICATE NO.", CERT_W - 78, 54, 1.2, "right");
  ctx.fillStyle = CERT_C.navy; ctx.font = "600 10.5px 'IBM Plex Mono','Courier New',monospace";
  ctx.fillText(rec.cert_no || "", CERT_W - 78, 68);

  // ---- title ----
  ctx.textAlign = "center"; ctx.fillStyle = CERT_C.navy; ctx.font = CERT_F.display(56, 700);
  cSpaced(ctx, kind.title, CERT_W / 2, 174, 9, "center");
  ctx.fillStyle = accent; ctx.font = CERT_F.sans(19, 600);
  cSpaced(ctx, kind.of, CERT_W / 2, 204, 7, "center");
  ctx.strokeStyle = CERT_C.gold; ctx.lineWidth = 1.3;
  [[262, 372], [628, 738]].forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(a, 197); ctx.lineTo(b, 197); ctx.stroke(); });
  cDiamond(ctx, 254, 197, 3.4, CERT_C.gold); cDiamond(ctx, 746, 197, 3.4, CERT_C.gold);

  // ---- pill ----
  ctx.font = CERT_F.sans(9.4, 700);
  const pw = (() => { const t = Array.from(kind.pill).reduce((s, ch) => s + ctx.measureText(ch).width, 0) + 2.4 * (kind.pill.length - 1); return t + 58; })();
  ctx.fillStyle = accent; cRoundRect(ctx, CERT_W / 2 - pw / 2, 213, pw, 20, 10); ctx.fill();
  cStar(ctx, CERT_W / 2 - pw / 2 + 15, 223, 4.6, "#fff"); cStar(ctx, CERT_W / 2 + pw / 2 - 15, 223, 4.6, "#fff");
  ctx.fillStyle = "#fff"; cSpaced(ctx, kind.pill, CERT_W / 2, 226.6, 2.4, "center");

  // ---- presented to ----
  ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.display(14.5, 500, true);
  ctx.fillText("This certificate is proudly presented to", CERT_W / 2, 262);

  const name = (rec.student_name || "Student").trim();
  const scriptOk = opts && opts.scriptFont;
  const nameFont = (px) => (scriptOk ? `400 ${px * 1.18}px 'Great Vibes','Snell Roundhand',cursive` : CERT_F.display(px * 0.92, 600, true));
  cFit(ctx, name, 700, 54, 26, nameFont);
  ctx.fillStyle = CERT_C.navy; ctx.fillText(name, CERT_W / 2, 322);
  ctx.strokeStyle = CERT_C.gold; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(240, 335); ctx.lineTo(760, 335); ctx.stroke();
  cDiamond(ctx, CERT_W / 2, 335, 3.6, CERT_C.gold);

  const grade = rec.grade_level ? (/^\d+$/.test(String(rec.grade_level).trim()) ? `Grade ${String(rec.grade_level).trim()}` : String(rec.grade_level)) : "";
  const secName = (rec.section_name || "").trim();
  const secHasGrade = /grade|\bg\d|\d/i.test(secName) && grade && secName.toLowerCase().includes(String(rec.grade_level).replace(/\D/g, "") || "\u0000");
  const classLine = secName
    ? (/^grade\b/i.test(secName) ? secName : `${grade && !secHasGrade ? grade + "  ·  " : ""}Section ${secName}`)
    : grade;
  if (classLine) { ctx.fillStyle = CERT_C.ink; ctx.font = CERT_F.sans(12.5, 500); ctx.fillText(classLine, CERT_W / 2, 356); }

  // ---- achievement ----
  ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.display(14, 500, true);
  ctx.fillText(rec.kind === "chapter" ? "for successfully completing the chapter" : rec.kind === "legendary" ? "for raising a Math Pet to its Legendary form" : "for successfully completing the station", CERT_W / 2, 384);

  ctx.fillStyle = CERT_C.navy;
  let sz = cFit(ctx, rec.station_name, 780, 34, 20, (px) => CERT_F.display(px, 700));
  let stationLines = [rec.station_name];
  if (ctx.measureText(rec.station_name).width > 780) { ctx.font = CERT_F.display(24, 700); stationLines = cWrap(ctx, rec.station_name, 780).slice(0, 2); sz = 24; }
  const stY = stationLines.length === 1 ? 425 : 418;
  stationLines.forEach((ln, i) => { ctx.font = CERT_F.display(sz, 700); ctx.fillText(ln, CERT_W / 2, stY + i * (sz + 2)); });
  const afterY = stY + (stationLines.length - 1) * (sz + 2);

  ctx.fillStyle = accent; ctx.font = CERT_F.sans(11.5, 700);
  cSpaced(ctx, ex.moduleLine || "", CERT_W / 2, afterY + 22, 1.8, "center");
  if (ex.detail) { ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.sans(10.5, 500); ctx.fillText(ex.detail, CERT_W / 2, afterY + 39); }

  // ---- stat boxes ----
  certDrawStats(ctx, ex.stats || [], accent);

  // ---- recognition line ----
  ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.display(12.6, 500, true);
  cWrap(ctx, kind.text, 720).slice(0, 2).forEach((ln, i) => ctx.fillText(ln, CERT_W / 2, 560 + i * 16));

  // ---- footer: date · seal · signature ----
  const dateStr = new Date(rec.earned_at || Date.now()).toLocaleDateString("en-PH", { year: "numeric", month: "long", day: "numeric" });
  ctx.strokeStyle = CERT_C.navy; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(96, 640); ctx.lineTo(306, 640); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(694, 640); ctx.lineTo(904, 640); ctx.stroke();
  ctx.fillStyle = CERT_C.navy; ctx.font = CERT_F.sans(14, 600); ctx.fillText(dateStr, 201, 633);
  ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.sans(8.2, 600); cSpaced(ctx, "DATE EARNED", 201, 655, 1.8, "center");

  const tname = (rec.teacher_name || "").trim();
  if (tname) {
    ctx.fillStyle = CERT_C.navy2;
    ctx.font = scriptOk ? `400 ${cFit(ctx, tname, 200, 27, 15, (px) => `400 ${px}px 'Great Vibes',cursive`)}px 'Great Vibes',cursive` : CERT_F.display(cFit(ctx, tname, 200, 18, 11, (px) => CERT_F.display(px, 500, true)), 500, true);
    ctx.fillText(tname, 799, 633);
    ctx.fillStyle = CERT_C.ink; ctx.font = CERT_F.sans(9.6, 700); cSpaced(ctx, tname.toUpperCase(), 799, 654, 0.8, "center");
    ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.sans(8.4, 500); ctx.fillText(rec.teacher_position || "Subject Teacher", 799, 667);
  } else {
    ctx.fillStyle = CERT_C.muted; ctx.font = CERT_F.sans(8.2, 600); cSpaced(ctx, (rec.teacher_position || "SUBJECT TEACHER").toUpperCase(), 799, 655, 1.8, "center");
  }
  certDrawSeal(ctx, CERT_W / 2, 626, 31, accent);
}

/** Renders the certificate to a new canvas `widthPx` wide (A4 landscape ratio). */
async function renderCertificateCanvas(rec, widthPx) {
  await certEnsureFonts();
  const w = Math.round(widthPx), h = Math.round(widthPx / 1.414286);
  const canvas = document.createElement("canvas");
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx.scale(w / CERT_W, h / CERT_H);
  const ex = certExtra(rec);
  const petSrc = rec.kind === "legendary"
    ? (ex.petImage || (ex.petTypeKey && typeof PET_TYPE_META !== "undefined" && PET_TYPE_META[ex.petTypeKey] ? PET_TYPE_META[ex.petTypeKey].legendaryImage : "") || "")
    : "";
  const petImg = petSrc ? await certLoadImage(petSrc) : null;
  certDraw(ctx, rec, { scriptFont: certFontAvailable(ctx, "Great Vibes"), petImg });
  return canvas;
}

// ============================================================================
// PDF — a one-page A4-landscape PDF that wraps the certificate image.
// Hand-written (no library): catalog → pages → page → content → JPEG image.
// ============================================================================
function certPdfFromJpeg(jpeg, wPx, hPx, title) {
  const PW = 841.89, PH = 595.28;
  const enc = new TextEncoder();
  const parts = [], offsets = [];
  let pos = 0;
  const push = (u8) => { parts.push(u8); pos += u8.length; };
  const str = (s) => push(enc.encode(s));
  const safeTitle = String(title || "Certificate").replace(/[^\x20-\x7E]/g, "").replace(/[()\\]/g, "").slice(0, 120) || "Certificate";

  push(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34, 0x0a, 0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a])); // %PDF-1.4 + binary marker
  const obj = (n, body) => { offsets[n] = pos; str(`${n} 0 obj\n${body}\nendobj\n`); };
  obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
  obj(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
  obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /XObject << /Im0 5 0 R >> /ProcSet [/PDF /ImageC] >> /Contents 4 0 R >>`);
  const content = `q\n${PW} 0 0 ${PH} 0 0 cm\n/Im0 Do\nQ\n`;
  obj(4, `<< /Length ${content.length} >>\nstream\n${content}endstream`);
  offsets[5] = pos;
  str(`5 0 obj\n<< /Type /XObject /Subtype /Image /Width ${wPx} /Height ${hPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);
  push(jpeg); str("\nendstream\nendobj\n");
  obj(6, `<< /Title (${safeTitle}) /Creator (MathConnect) /Producer (MathConnect) >>`);
  const xref = pos;
  let x = "xref\n0 7\n0000000000 65535 f \n";
  for (let i = 1; i <= 6; i++) x += String(offsets[i]).padStart(10, "0") + " 00000 n \n";
  str(x + `trailer\n<< /Size 7 /Root 1 0 R /Info 6 0 R >>\nstartxref\n${xref}\n%%EOF`);
  return new Blob(parts, { type: "application/pdf" });
}

function certFileName(rec, ext) {
  const clean = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return `MathConnect-Certificate_${clean(rec.student_name)}_${clean(rec.station_name)}${rec.level_key && rec.level_key !== "chapter" && rec.level_key !== CERT_STATION_LEVEL_KEY ? "_" + clean(rec.level_label || rec.level_key) : ""}.${ext}`.replace(/-+/g, "-").replace(/_-/g, "_");
}
function certBlobFromCanvas(canvas, type, q) { return new Promise((res) => canvas.toBlob(res, type, q)); }
function certSaveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

async function certExportBlobs(rec) {
  const canvas = await renderCertificateCanvas(rec, 3508); // 300 dpi on A4 landscape
  const jpeg = await certBlobFromCanvas(canvas, "image/jpeg", 0.93);
  if (!jpeg) throw new Error("Your browser couldn't build the image.");
  const bytes = new Uint8Array(await jpeg.arrayBuffer());
  return { jpeg, pdf: certPdfFromJpeg(bytes, canvas.width, canvas.height, `${rec.student_name} - ${rec.station_name} Certificate`) };
}

async function certWithBusy(btnId, label, fn) {
  if (certState.busy) return;
  certState.busy = true;
  const btn = document.getElementById(btnId), old = btn ? btn.innerHTML : "";
  if (btn) { btn.disabled = true; btn.innerHTML = label; }
  try { await fn(); }
  catch (e) { console.warn(e); toast("⚠️ Couldn't prepare the certificate: " + (e && e.message ? e.message : "please try again.")); }
  finally { certState.busy = false; if (btn) { btn.disabled = false; btn.innerHTML = old; } }
}

function certDownloadPdf(key) {
  const rec = certState.cache[key]; if (!rec) return;
  certWithBusy("certBtnPdf", "⏳ Preparing PDF…", async () => {
    const { pdf } = await certExportBlobs(rec);
    certSaveBlob(pdf, certFileName(rec, "pdf"));
    toast("📄 Certificate saved as PDF — open it to print.");
  });
}
function certDownloadImage(key) {
  const rec = certState.cache[key]; if (!rec) return;
  certWithBusy("certBtnImg", "⏳ Preparing…", async () => {
    const { jpeg } = await certExportBlobs(rec);
    certSaveBlob(jpeg, certFileName(rec, "jpg"));
  });
}
function certPrint(key) {
  const rec = certState.cache[key]; if (!rec) return;
  certWithBusy("certBtnPrint", "⏳ Preparing…", async () => {
    const { jpeg } = await certExportBlobs(rec);
    const url = URL.createObjectURL(jpeg);
    const frame = document.createElement("iframe");
    frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;";
    document.body.appendChild(frame);
    const doc = frame.contentWindow.document;
    doc.open();
    doc.write(`<!doctype html><html><head><title>${escapeHtml(rec.student_name)} — Certificate</title><style>@page{size:A4 landscape;margin:0}html,body{margin:0;padding:0;background:#fff}img{display:block;width:297mm;height:210mm}</style></head><body><img id="c" src="${url}"></body></html>`);
    doc.close();
    const img = doc.getElementById("c");
    const go = () => { try { frame.contentWindow.focus(); frame.contentWindow.print(); } catch (e) { certDownloadPdf(key); } };
    if (img.complete) go(); else img.onload = go;
    setTimeout(() => { frame.remove(); URL.revokeObjectURL(url); }, 120000);
  });
}

// ============================================================================
// VIEWER MODAL
// ============================================================================
function certCloseOverlay() { const o = document.getElementById("certOverlay"); if (o) o.remove(); document.removeEventListener("keydown", certEscClose); }
function certEscClose(e) { if (e.key === "Escape") certCloseOverlay(); }
function certMountOverlay(inner) {
  certCloseOverlay();
  const o = document.createElement("div");
  o.id = "certOverlay"; o.className = "cert-overlay";
  o.innerHTML = `<div class="cert-modal" role="dialog" aria-modal="true">${inner}</div>`;
  o.addEventListener("click", (e) => { if (e.target === o) certCloseOverlay(); });
  document.body.appendChild(o);
  document.addEventListener("keydown", certEscClose);
  return o;
}

async function openCertificate(key) {
  const rec = certState.cache[key];
  if (!rec) { toast("Couldn't find that certificate."); return; }
  const k = CERT_KINDS[rec.kind] || CERT_KINDS.completion;
  const q = String(key).replace(/'/g, "\\'");
  certMountOverlay(`
    <div class="cert-modal-head">
      <div><h3 style="margin:0;">${k.icon} ${escapeHtml(k.tag)}</h3>
      <div class="muted" style="font-size:.82rem;">${escapeHtml(rec.station_name)}${rec.level_label ? " · " + escapeHtml(rec.level_label) : ""} · No. ${escapeHtml(rec.cert_no || "")}</div></div>
      <button class="btn-outline btn-sm" onclick="certCloseOverlay()" aria-label="Close">✕</button>
    </div>
    <div class="cert-preview" id="certPreview"><div class="cert-loading">Preparing your certificate…</div></div>
    <div class="cert-actions">
      <button class="btn-primary" id="certBtnPdf" onclick="certDownloadPdf('${q}')">⬇️ Download PDF</button>
      <button class="btn-gold" id="certBtnPrint" onclick="certPrint('${q}')">🖨️ Print</button>
      <button class="btn-outline" id="certBtnImg" onclick="certDownloadImage('${q}')">🖼️ Save as image</button>
      <button class="btn-outline" onclick="certCloseOverlay()">Close</button>
    </div>
    <p class="muted" style="font-size:.76rem;margin:10px 0 0;text-align:center;">Prints on one A4 page (landscape). In the print window, choose “Save as PDF” to keep a copy, or send it to your printer.</p>`);
  try {
    const canvas = await renderCertificateCanvas(rec, 1500);
    canvas.className = "cert-canvas";
    const box = document.getElementById("certPreview");
    if (box) { box.innerHTML = ""; box.appendChild(canvas); }
  } catch (e) {
    const box = document.getElementById("certPreview");
    if (box) box.innerHTML = `<div class="cert-loading">Couldn't draw the certificate preview — you can still try Download PDF.</div>`;
  }
}

// ============================================================================
// "MY CERTIFICATES" SHELF
// ============================================================================
async function openCertificateGallery(filter) {
  certMountOverlay(`<div class="cert-loading">Loading your certificates…</div>`);
  const all = await loadCertificates();
  renderCertificateGallery(all, filter || "all");
}
function renderCertificateGallery(all, filter) {
  const current = all.filter((c) => !certIsLegacy(c));   // whole-station, practice and pet certificates
  const legacy = all.filter(certIsLegacy);                // issued before v58 (per level / chapter champion)
  const inFilter = (c) => filter === "all" || c.source === filter;
  const shown = current.filter(inFilter), shownLegacy = legacy.filter(inFilter);
  const count = (f) => (f === "all" ? current.length : current.filter((c) => c.source === f).length);
  const chip = (f, label) => `<button class="cert-chip ${filter === f ? "active" : ""}" onclick="certGalleryFilter('${f}')">${label} <span>${count(f)}</span></button>`;
  window._certAll = all;
  const overlay = document.getElementById("certOverlay");
  if (!overlay) return;
  const item = (c) => {
    const k = CERT_KINDS[c.kind] || CERT_KINDS.completion, src = CERT_SOURCES[c.source] || CERT_SOURCES.drills, key = (c._key || certRegister(c)).replace(/'/g, "\\'");
    return `
        <div class="cert-item" style="--cert-accent:${k.accent};">
          <div class="cert-item-icon">${k.icon}</div>
          <div class="cert-item-body">
            <div class="cert-item-title">${escapeHtml(c.station_name)}</div>
            <div class="muted" style="font-size:.78rem;">${src.icon} ${src.label}${c.level_label ? " · " + escapeHtml(c.level_label) : ""}${c.accuracy != null ? " · " + c.accuracy + "% accuracy" : ""}</div>
            <div class="muted" style="font-size:.74rem;">${escapeHtml(k.tag)} · ${new Date(c.earned_at).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" })}</div>
          </div>
          <button class="btn-primary btn-sm" onclick="openCertificate('${key}')">View / Print</button>
        </div>`;
  };
  const pct = Math.round(CERT_STATION_ACCURACY * 100);
  overlay.querySelector(".cert-modal").innerHTML = `
    <div class="cert-modal-head">
      <div><h3 style="margin:0;">🎓 My Certificates</h3>
      <div class="muted" style="font-size:.82rem;">Finish a whole station to earn its certificate: Math Drills and Quest Mode need every level cleared with ${pct}% overall accuracy; Intelligent Practice needs a perfect session at Expert level. Every pet that reaches Legendary earns one too. Open any to print or save it as a PDF.</div></div>
      <button class="btn-outline btn-sm" onclick="certCloseOverlay()" aria-label="Close">✕</button>
    </div>
    <div class="cert-chips">${chip("all", "All")}${chip("drills", "🎮 Math Drills")}${chip("quest", "🗺️ Quest Mode")}${chip("practice", "🧠 Practice")}${chip("pet", "🐾 Legendary Pets")}</div>
    <div class="cert-list">
      ${shown.length ? shown.map(item).join("") : `<div class="empty">${current.length ? "No certificates in this category yet." : `No certificates yet — complete a whole station (Drills/Quest: all levels at ${pct}%+ overall; Practice: a perfect Expert-level session) or raise a pet to Legendary and your first one appears here! 🎓`}</div>`}
    </div>
    ${shownLegacy.length ? `
    <details class="cert-legacy">
      <summary>Earlier certificates (${shownLegacy.length}) — earned per level before whole-station certificates</summary>
      <div class="cert-list" style="margin-top:8px;">${shownLegacy.map(item).join("")}</div>
    </details>` : ""}`;
}
function certGalleryFilter(f) { renderCertificateGallery(window._certAll || [], f); }

/** Small button used in each hub's header. */
function certShelfButtonHtml(source) {
  return `<button class="btn-outline" onclick="openCertificateGallery('${source}')">🎓 My Certificates</button>`;
}
