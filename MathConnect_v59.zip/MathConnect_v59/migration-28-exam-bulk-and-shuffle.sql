-- ============================================================================
-- Migration 28 — Exam bulk-add & per-student option shuffling
-- Run this once in Supabase Dashboard → SQL Editor (after exam_schema.sql).
-- Safe to re-run.
--
-- 1) Bulk-add questions needs NO schema change — exam_questions already
--    accepts a plain insert per row, so teacherExamEngine.js just inserts
--    many rows in one call instead of one at a time. Nothing to migrate here.
--
-- 2) Per-student shuffle:
--    - exams.shuffle_options (new) — teacher-level on/off toggle, default ON.
--    - exam_attempts.shuffle_map (new) — JSONB generated ONCE when an
--      attempt is first created: { "<question_id>": [origIdx0, origIdx1, …] }
--      i.e. for each multiple-choice question, the array says "displayed
--      position i shows the option that was originally at origIdx". It's
--      stored on the attempt (not regenerated on resume) so a student's
--      options never re-shuffle mid-attempt, and grading/review always
--      reference the same mapping that was shown.
--    - start_exam_attempt / submit_exam_attempt are replaced to build and
--      apply that map. Two small SECURITY-DEFINER-safe helper functions do
--      the letter<->position translation. True/False questions are never
--      shuffled (only two fixed options).
-- ============================================================================

ALTER TABLE public.exams ADD COLUMN IF NOT EXISTS shuffle_options BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE public.exam_attempts ADD COLUMN IF NOT EXISTS shuffle_map JSONB;

-- ----------------------------------------------------------------------------
-- Helpers
-- ----------------------------------------------------------------------------

-- Reorders an options array for display according to an attempt's shuffle_map.
-- Passes options through untouched if there's no map entry for this question.
CREATE OR REPLACE FUNCTION public._exam_shuffled_options(p_options JSONB, p_shuffle_map JSONB, p_question_id UUID)
RETURNS JSONB
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT CASE
    WHEN p_options IS NULL OR p_shuffle_map IS NULL OR NOT (p_shuffle_map ? p_question_id::text)
    THEN p_options
    ELSE (
      SELECT jsonb_agg(p_options -> (elem.idx)::int ORDER BY elem.ord)
      FROM jsonb_array_elements_text(p_shuffle_map -> p_question_id::text) WITH ORDINALITY AS elem(idx, ord)
    )
  END;
$$;

-- Translates a student's submitted letter (position in the SHUFFLED/displayed
-- options) back into the letter that matches exam_questions.correct_answer
-- (position in the ORIGINAL options order), so grading is correct regardless
-- of shuffle. True/False answers and anything that isn't a single letter
-- pass through unchanged.
CREATE OR REPLACE FUNCTION public._exam_effective_answer(p_shuffle_map JSONB, p_question_id UUID, p_student_answer TEXT)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
  v_positions JSONB;
  v_pos INTEGER;
  v_orig_idx INTEGER;
BEGIN
  IF p_student_answer IS NULL OR length(trim(p_student_answer)) <> 1 THEN
    RETURN p_student_answer;
  END IF;
  IF p_shuffle_map IS NULL OR NOT (p_shuffle_map ? p_question_id::text) THEN
    RETURN p_student_answer;
  END IF;
  v_pos := ascii(upper(trim(p_student_answer))) - 65;
  IF v_pos < 0 OR v_pos > 25 THEN RETURN p_student_answer; END IF;
  v_positions := p_shuffle_map -> p_question_id::text;
  IF v_positions IS NULL OR v_pos >= jsonb_array_length(v_positions) THEN RETURN p_student_answer; END IF;
  v_orig_idx := (v_positions -> v_pos)::text::int;
  RETURN chr(65 + v_orig_idx);
END;
$$;

-- Inverse of the above: given the ORIGINAL correct_answer letter, returns
-- the letter it appears as in this attempt's SHUFFLED/displayed options —
-- used only for the post-submit review screen, so "correct answer: B" lines
-- up with the options the student actually saw.
CREATE OR REPLACE FUNCTION public._exam_original_to_shuffled_answer(p_shuffle_map JSONB, p_question_id UUID, p_original_answer TEXT)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
  v_positions JSONB;
  v_orig_idx INTEGER;
  i INTEGER;
BEGIN
  IF p_original_answer IS NULL OR length(trim(p_original_answer)) <> 1 THEN
    RETURN p_original_answer;
  END IF;
  IF p_shuffle_map IS NULL OR NOT (p_shuffle_map ? p_question_id::text) THEN
    RETURN p_original_answer;
  END IF;
  v_orig_idx := ascii(upper(trim(p_original_answer))) - 65;
  v_positions := p_shuffle_map -> p_question_id::text;
  IF v_positions IS NULL THEN RETURN p_original_answer; END IF;
  FOR i IN 0 .. jsonb_array_length(v_positions) - 1 LOOP
    IF (v_positions -> i)::text::int = v_orig_idx THEN
      RETURN chr(65 + i);
    END IF;
  END LOOP;
  RETURN p_original_answer;
END;
$$;

-- ----------------------------------------------------------------------------
-- start_exam_attempt — now builds (once) and applies the shuffle map
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.start_exam_attempt(p_exam_id UUID, p_student_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_exam exams%ROWTYPE;
  v_attempt exam_attempts%ROWTYPE;
  v_existing_count INTEGER;
  v_questions JSONB;
  v_shuffle_map JSONB;
BEGIN
  SELECT * INTO v_exam FROM exams WHERE id = p_exam_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('error', 'exam_not_found');
  END IF;
  IF NOT v_exam.is_published OR v_exam.is_locked THEN
    RETURN jsonb_build_object('error', 'exam_unavailable');
  END IF;

  -- Resume an in-progress (not yet submitted) attempt if one exists.
  SELECT * INTO v_attempt FROM exam_attempts
    WHERE exam_id = p_exam_id AND student_id = p_student_id AND is_submitted = FALSE
    ORDER BY attempt_number DESC LIMIT 1;

  IF NOT FOUND THEN
    SELECT COUNT(*) INTO v_existing_count FROM exam_attempts
      WHERE exam_id = p_exam_id AND student_id = p_student_id;

    IF v_existing_count > 0 AND NOT v_exam.allow_multiple_attempts THEN
      RETURN jsonb_build_object('error', 'already_attempted');
    END IF;
    IF v_existing_count >= v_exam.max_attempts THEN
      RETURN jsonb_build_object('error', 'max_attempts_reached');
    END IF;

    -- Build a fresh per-attempt shuffle map (one random permutation per
    -- multiple-choice question) so every student sees their own option order.
    IF v_exam.shuffle_options THEN
      SELECT jsonb_object_agg(q.id::text, perm.shuffled)
      INTO v_shuffle_map
      FROM exam_questions q
      CROSS JOIN LATERAL (
        SELECT jsonb_agg(idx ORDER BY random()) AS shuffled
        FROM generate_series(0, jsonb_array_length(q.options) - 1) AS idx
      ) perm
      WHERE q.exam_id = p_exam_id AND q.question_type = 'multiple_choice' AND q.options IS NOT NULL;
    END IF;

    INSERT INTO exam_attempts (exam_id, student_id, attempt_number, start_time, expected_end_time, shuffle_map)
    VALUES (p_exam_id, p_student_id, v_existing_count + 1, NOW(), NOW() + (v_exam.duration_minutes || ' minutes')::INTERVAL, v_shuffle_map)
    RETURNING * INTO v_attempt;
  END IF;

  SELECT jsonb_agg(jsonb_build_object(
    'id', q.id, 'question_number', q.question_number, 'question_text', q.question_text,
    'question_type', q.question_type,
    'options', public._exam_shuffled_options(q.options, v_attempt.shuffle_map, q.id),
    'points', q.points
  ) ORDER BY q.question_number)
  INTO v_questions
  FROM exam_questions q WHERE q.exam_id = p_exam_id;

  RETURN jsonb_build_object(
    'attempt', to_jsonb(v_attempt),
    'exam', jsonb_build_object('id', v_exam.id, 'title', v_exam.title, 'duration_minutes', v_exam.duration_minutes,
      'passing_score', v_exam.passing_score, 'allow_review', v_exam.allow_review, 'show_correct_answers', v_exam.show_correct_answers),
    'questions', COALESCE(v_questions, '[]'::jsonb)
  );
END;
$$;

-- ----------------------------------------------------------------------------
-- submit_exam_attempt — grades against the shuffle-corrected answer, and
-- returns review options/correct_answer already translated into the
-- student's shuffled order.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.submit_exam_attempt(p_attempt_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_attempt exam_attempts%ROWTYPE;
  v_exam exams%ROWTYPE;
  v_total_score INTEGER := 0;
  v_total_points INTEGER := 0;
  v_review JSONB;
BEGIN
  SELECT * INTO v_attempt FROM exam_attempts WHERE id = p_attempt_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('error', 'attempt_not_found'); END IF;
  SELECT * INTO v_exam FROM exams WHERE id = v_attempt.exam_id;

  IF v_attempt.is_submitted THEN
    NULL; -- idempotent: fall through and just return the existing result below
  ELSE
    UPDATE exam_responses r
    SET is_correct = (
      lower(trim(public._exam_effective_answer(v_attempt.shuffle_map, r.question_id, r.student_answer))) = lower(trim(q.correct_answer))
    )
    FROM exam_questions q
    WHERE r.question_id = q.id AND r.attempt_id = p_attempt_id;

    SELECT COALESCE(SUM(q.points), 0), COALESCE(SUM(CASE WHEN r.is_correct THEN q.points ELSE 0 END), 0)
      INTO v_total_points, v_total_score
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;

    UPDATE exam_attempts SET
      is_submitted = TRUE,
      submission_time = NOW(),
      total_score = v_total_score,
      total_points = v_total_points,
      percentage_score = CASE WHEN v_total_points > 0 THEN ROUND((v_total_score::NUMERIC / v_total_points) * 100, 2) ELSE 0 END,
      time_taken_seconds = GREATEST(0, EXTRACT(EPOCH FROM (LEAST(NOW(), v_attempt.expected_end_time) - v_attempt.start_time))::INTEGER),
      updated_at = NOW()
    WHERE id = p_attempt_id
    RETURNING * INTO v_attempt;
  END IF;

  IF v_exam.allow_review THEN
    SELECT jsonb_agg(jsonb_build_object(
      'question_number', q.question_number, 'question_text', q.question_text,
      'options', public._exam_shuffled_options(q.options, v_attempt.shuffle_map, q.id),
      'student_answer', r.student_answer, 'is_correct', r.is_correct,
      'correct_answer', CASE WHEN v_exam.show_correct_answers
        THEN public._exam_original_to_shuffled_answer(v_attempt.shuffle_map, q.id, q.correct_answer) ELSE NULL END,
      'explanation', CASE WHEN v_exam.show_correct_answers THEN q.explanation ELSE NULL END
    ) ORDER BY q.question_number)
    INTO v_review
    FROM exam_questions q LEFT JOIN exam_responses r ON r.question_id = q.id AND r.attempt_id = p_attempt_id
    WHERE q.exam_id = v_attempt.exam_id;
  END IF;

  RETURN jsonb_build_object('attempt', to_jsonb(v_attempt), 'review', v_review);
END;
$$;

GRANT EXECUTE ON FUNCTION public.start_exam_attempt(UUID, UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.submit_exam_attempt(UUID) TO anon, authenticated;
-- Belt-and-suspenders: these are only ever called from inside the two
-- SECURITY DEFINER functions above, but grant directly too in case that
-- ever changes.
GRANT EXECUTE ON FUNCTION public._exam_shuffled_options(JSONB, JSONB, UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public._exam_effective_answer(JSONB, UUID, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public._exam_original_to_shuffled_answer(JSONB, UUID, TEXT) TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- Done. Sanity check:
-- select shuffle_options from exams limit 5;
-- select shuffle_map from exam_attempts where shuffle_map is not null limit 5;
-- ----------------------------------------------------------------------------
