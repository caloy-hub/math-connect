# MathConnect v56 — per-term student removal + report card data

**One new migration:** `migration-63-student-term-removal.sql` (safe to re-run).

## 1. Remove a student per term (previous terms untouched)
* **Class Record → 👥 Manage students this term** — search enrolled students, *Remove*, or *Restore*. Also
  **Roster → Remove from term**, and a "removed from Term N" panel under the roster.
* Choose **this term only** or **this term and later terms** (hidden on the last term). Reason + optional note are kept.
* **Nothing is deleted.** A new table `student_term_status` marks the term; scores/attendance stay in the database, so restoring
  brings everything back. Terms *before* the chosen one are never read or written by the removal functions
  (`remove_student_from_term` / `restore_student_to_term`, which also verify the teacher owns the section).
* A removed student disappears from that term's Class Record, Enter Scores, Full Record, Grade Summary, Attendance, Status, Groups,
  Drills/Quest/Raids class views and Dashboard counts. **Final Grades** shows "Removed" for that term and averages only the terms
  they were enrolled in (removed terms are excluded, not counted as 0, and flagged "partial").
* **Excel export:** every term keeps its own enrollment (Term 1 still lists the student), Roster gets a "Removed From Term(s)"
  column, and a "Term Removals" sheet lists who/why/when.
* **Admin overview:** term averages, attendance % and exam counts skip a student only in the terms they were removed from.
* **Delete** is now clearly worded as permanent and all-terms, pointing teachers to "Remove from term" instead.
* Tested in PostgreSQL (rules, permissions, RLS, re-runs) and with a mock-database harness (Term 1 export identical before/after
  removing a student from Term 2).

## 2. Report card data
* All **18 Math Drill stations** now appear (six high-school stations added: Exponents & Radicals, Equation Scale, Factor Vault,
  Farm Measure, Grid Navigator, Surveyor's Post) — table and "Points per Drill Station" chart.
* **Pet section fixed:** it used a single-row query that failed for students with more than one pet (migration 35), so the pet
  disappeared. It now loads all pets, shows the most advanced living pet plus the others, **Pets Owned, 👑 Legendary Pets, and
  🎓 Certificates Earned** (with how many are pet certificates).
* A removed student's report card for that term shows a clear "Not enrolled in Term N" banner (with reason/date); earlier terms'
  report cards are unchanged.

## Files
New: `migration-63-student-term-removal.sql`
Changed: `teacher.js`, `admin.js`, `report-card.js`, `README.md`, `service-worker.js` (cache → v56-1)

## Deploy
1. Supabase → SQL Editor → run `migration-63-student-term-removal.sql`.
2. Redeploy the folder (one refresh for the new cache).
