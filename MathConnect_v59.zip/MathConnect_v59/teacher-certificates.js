// ============================================================================
// MathConnect — Teacher view of Student Certificates (v53)
// Every certificate a student in the selected section has earned: whole-station
// certificates in Math Drills and Quest Mode (v58: all levels cleared, 80%+ overall
// accuracy), Intelligent Practice stations (a perfect session at Expert level), plus Legendary Pet
// awards (v55), with filters, a
// class summary, a "no certificate yet" list, and View / Download PDF / Print
// for any certificate (the same viewer students use — certificateEngine.js).
// Depends on: state (teacher.js), escapeHtml, fetchAllRowsChecked
// (supabase-client.js), certificateEngine.js (certRegister, openCertificate,
// CERT_KINDS, CERT_SOURCES). Data: station_certificates (migration-61/64).
//
// v57: certificates belong to the student, not to a term — so this tab lists
// EVERY student in the section (including ones removed from the current term),
// every "View / Print" button goes through tcertView() (which can never fail
// silently), Legendary Pet certificates are issued by the database the moment a
// pet reaches Legendary (migration-64), and the Dashboard shows the latest ones
// via tcertDashboardCardHtml().
// ============================================================================

var tcert = { rows: [], source: "all", studentId: "all", kind: "all", scope: "all", error: null, loadedFor: null };

/** Everyone in the section (a certificate is never "removed" with a term). Falls back to the enrolled list. */
function tcertRoster() { return (state.allStudents && state.allStudents.length) ? state.allStudents : (state.students || []); }
function tcertEnrolledIds() { return new Set((state.students || []).map((s) => s.id)); }
function tcertRemovedNote(studentId) {
  try { return typeof isRemovedInTerm === "function" && state.term && isRemovedInTerm(studentId, state.term.id) ? ` <span class="muted" style="font-size:.72rem;">(removed from ${escapeHtml(state.term.term_name)})</span>` : ""; }
  catch (e) { return ""; }
}

/**
 * The ONE way any certificate button on the teacher side opens a certificate.
 * Looks the row up by id (re-registering it if the cache was cleared), and reports
 * a readable problem instead of doing nothing.
 */
function tcertView(id) {
  try {
    let rec = (typeof certState !== "undefined" && certState.cache && certState.cache[id]) || null;
    if (!rec) rec = (tcert.rows || []).find((r) => String(r.id) === String(id)) || (tcert.dash || {})[id] || null;
    if (!rec) { toast("Couldn't find that certificate — refreshing the list."); renderTeacherCertificates(); return; }
    certRegister(rec);
    const p = openCertificate(rec._key);
    if (p && typeof p.catch === "function") return p.catch((e) => { console.warn(e); toast("Couldn't open this certificate: " + ((e && e.message) || "please try again.")); });
    return p;
  } catch (e) {
    console.warn("tcertView failed:", e);
    toast("Couldn't open this certificate: " + ((e && e.message) || "please try again."));
  }
}

async function renderTeacherCertificates() {
  const el = document.getElementById("tab-certificates");
  if (!el) return;
  el.innerHTML = `<div class="empty">Loading certificates…</div>`;

  const students = tcertRoster();
  tcert.error = null;
  tcert.rows = [];
  if (students.length) {
    const ids = students.map((s) => s.id);
    const res = await fetchAllRowsChecked(() => supabase.from("station_certificates").select("*").in("student_id", ids));
    if (res.error) tcert.error = res.error.message || "couldn't load";
    tcert.rows = (res.data || []).slice().sort((a, b) => new Date(b.earned_at) - new Date(a.earned_at));
    tcert.rows.forEach(certRegister);
  }
  tcert.loadedFor = state.section && state.section.id;
  if (!students.some((s) => s.id === tcert.studentId)) tcert.studentId = "all";
  tcertRender();
}

function tcertFiltered() {
  return tcert.rows.filter((r) =>
    (tcert.source === "all" || r.source === tcert.source) &&
    (tcert.studentId === "all" || r.student_id === tcert.studentId) &&
    (tcert.scope === "all" || (tcert.scope === "legacy" ? certIsLegacy(r) : !certIsLegacy(r))) &&
    (tcert.kind === "all" || (tcert.kind === "award" ? r.kind !== "completion" : r.kind === tcert.kind)));
}

function tcertRender() {
  const el = document.getElementById("tab-certificates");
  if (!el) return;
  const students = tcertRoster();
  const enrolled = tcertEnrolledIds();
  const nameOf = (id) => { const s = students.find((x) => x.id === id); return s ? s.full_name : "—"; };
  const rows = tcertFiltered();

  const total = tcert.rows.length;
  const withCert = new Set(tcert.rows.map((r) => r.student_id));
  const enrolledCount = students.filter((s) => enrolled.has(s.id)).length;
  const enrolledWithCert = students.filter((s) => enrolled.has(s.id) && withCert.has(s.id)).length;
  const perfect = tcert.rows.filter((r) => r.kind === "perfect").length;
  const stationsDone = tcert.rows.filter((r) => (r.source === "drills" || r.source === "quest" || r.source === "practice") && !certIsLegacy(r)).length;
  const legacyCount = tcert.rows.filter(certIsLegacy).length;
  const legendaryPets = tcert.rows.filter((r) => r.kind === "legendary").length;
  const bySrc = (k) => tcert.rows.filter((r) => r.source === k).length;
  const without = students.filter((s) => enrolled.has(s.id) && !withCert.has(s.id)); // "nudge" list = students currently enrolled

  const chip = (key, label, n) => `<button class="cert-chip ${tcert.source === key ? "active" : ""}" onclick="tcertSet('source','${key}')">${label} <span>${n}</span></button>`;
  const stat = (num, label) => `<div><div class="stat-value">${num}</div><div class="stat-label">${label}</div></div>`;

  el.innerHTML = `
    ${tcert.error ? `<div style="border-left:4px solid var(--clay);background:var(--paper);padding:8px 12px;margin-bottom:12px;border-radius:6px;font-size:.85rem;">⚠️ Couldn't load certificates (${escapeHtml(tcert.error)}). Have you run <code>migration-61-station-certificates.sql</code> (and <code>migration-62</code> for Legendary Pet certificates) yet? Certificates earned before then are stored only on each student's own device and can't be listed here.</div>` : ""}
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
        <h3 style="margin:0;">🎓 ${escapeHtml(state.section.section_name)} — Certificates</h3>
        <button class="btn-outline btn-sm" onclick="renderTeacherCertificates()" title="Reload from the database">🔄 Refresh</button>
      </div>
      <p class="muted" style="margin-top:6px;">Students earn one printable certificate for every <strong>whole station</strong> they complete — not per round. <strong>Math Drills</strong> (levels 1–15) and <strong>Quest Mode</strong> (every level of the chapter): all levels cleared with <strong>80% overall accuracy or better</strong>. <strong>Intelligent Practice</strong>: a <strong>100%</strong> session at Expert level (all questions right on the first try). Every pet that reaches <strong>Legendary</strong> also earns one (issued the moment it gets there).${legacyCount ? ` <span class="muted">(${legacyCount} earlier per-level or per-session certificate${legacyCount === 1 ? "" : "s"} from before this change ${legacyCount === 1 ? "is" : "are"} kept — use the “Earlier per-level/session” filter.)</span>` : ""} Open any one to view, download as PDF, or print it — for example for recognition, portfolios or a class awarding.</p>
      <div class="stat-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:14px;margin-top:10px;">
        ${stat(total, "Certificates issued")}
        ${stat(`${enrolledWithCert}/${enrolledCount}`, "Students with ≥ 1")}
        ${stat(perfect, "Perfect scores")}
        ${stat(stationsDone, "Stations completed")}
        ${stat(legendaryPets, "Legendary pets")}
      </div>
    </div>

    <div class="card">
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <div class="cert-chips" style="margin:0;">
          ${chip("all", "All", total)}${chip("drills", "🎮 Math Drills", bySrc("drills"))}${chip("quest", "🗺️ Quest Mode", bySrc("quest"))}${chip("practice", "🧠 Practice", bySrc("practice"))}${chip("pet", "🐾 Legendary Pets", bySrc("pet"))}
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <select style="width:auto;" onchange="tcertSet('scope', this.value)" aria-label="Certificate scope">
            ${[["all", "Whole-station + earlier"], ["current", "Whole-station only"], ["legacy", "Earlier per-level/session"]].map(([v, l]) => `<option value="${v}" ${tcert.scope === v ? "selected" : ""}>${l}</option>`).join("")}
          </select>
          <select style="width:auto;" onchange="tcertSet('kind', this.value)" aria-label="Certificate type">
            ${[["all", "All types"], ["completion", "Completion"], ["award", "Any Award"], ["perfect", "Perfect Score"], ["chapter", "Chapter Champion (earlier)"], ["legendary", "Legendary Pet"]].map(([v, l]) => `<option value="${v}" ${tcert.kind === v ? "selected" : ""}>${l}</option>`).join("")}
          </select>
          <select style="width:auto;" onchange="tcertSet('studentId', this.value)" aria-label="Student">
            <option value="all">All students</option>
            ${students.map((s) => `<option value="${s.id}" ${tcert.studentId === s.id ? "selected" : ""}>${escapeHtml(s.full_name)}</option>`).join("")}
          </select>
        </div>
      </div>
      ${rows.length === 0
        ? `<div class="empty">${total ? "No certificates match these filters." : "No certificates earned yet in this section. They appear here as soon as a student completes a whole station (Drills/Quest: all levels at 80%+ overall; Practice: a perfect Expert-level session)."}</div>`
        : `<div style="overflow-x:auto;"><table>
            <thead><tr><th>Date</th><th>Student</th><th>Certificate</th><th>Station</th><th>Score</th><th></th></tr></thead>
            <tbody>
              ${rows.map((r) => {
                const k = CERT_KINDS[r.kind] || CERT_KINDS.completion, src = CERT_SOURCES[r.source] || CERT_SOURCES.drills;
                certRegister(r);
                const vid = escapeHtml(String(r.id || r._key || ""));
                return `<tr>
                  <td style="white-space:nowrap;">${new Date(r.earned_at).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric" })}</td>
                  <td><strong>${escapeHtml(nameOf(r.student_id))}</strong>${tcertRemovedNote(r.student_id)}</td>
                  <td>${k.icon} ${escapeHtml(k.tag.replace("Certificate of ", ""))}<div class="muted" style="font-size:.72rem;">No. ${escapeHtml(r.cert_no || "")}</div></td>
                  <td>${escapeHtml(r.station_name)}<div class="muted" style="font-size:.74rem;">${src.icon} ${src.label}${r.level_label ? " · " + escapeHtml(r.level_label) : ""}</div></td>
                  <td style="white-space:nowrap;">${r.correct_count != null ? `${r.correct_count}/${r.total_questions}` : "—"}${r.accuracy != null ? ` <span class="muted">· ${r.accuracy}%</span>` : ""}</td>
                  <td style="white-space:nowrap;"><button class="btn-outline btn-sm" onclick="tcertView('${vid}')">View / Print</button></td>
                </tr>`;
              }).join("")}
            </tbody></table></div>
            <div class="muted" style="margin-top:8px;font-size:.8rem;">Showing ${rows.length} of ${total}.</div>`}
    </div>

    ${without.length && students.length ? `
    <details class="card" style="margin-top:16px;">
      <summary style="cursor:pointer;font-weight:700;">${without.length} student${without.length === 1 ? "" : "s"} without a certificate yet</summary>
      <p class="muted" style="margin:8px 0;">Good candidates for a nudge or a little extra practice time.</p>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">${without.map((s) => `<span class="badge" style="background:var(--paper);border:1px solid var(--paper-line);padding:3px 10px;border-radius:999px;font-size:.8rem;">${escapeHtml(s.full_name)}</span>`).join("")}</div>
    </details>` : ""}`;
}

function tcertSet(field, value) { tcert[field] = value; tcertRender(); }

// ============================================================================
// DASHBOARD CARD (v57) — latest certificates + Legendary pets for this section.
// Returns "" (shows nothing) for non-Math sections, empty sections, or when the
// certificates table isn't installed, so it can never break the dashboard.
// ============================================================================
async function tcertDashboardCardHtml() {
  try {
    if (!state.section || (typeof isMathSubject === "function" && !isMathSubject(state.section.subject))) return "";
    const roster = tcertRoster();
    if (!roster.length) return "";
    const ids = roster.map((s) => s.id);
    const nameOf = (id) => { const s = roster.find((x) => x.id === id); return s ? s.full_name : "—"; };

    const [recent, legendary, countRes] = await Promise.all([
      supabase.from("station_certificates").select("*").in("student_id", ids).order("earned_at", { ascending: false }).limit(6),
      supabase.from("station_certificates").select("*").in("student_id", ids).eq("kind", "legendary").order("earned_at", { ascending: false }).limit(200),
      supabase.from("station_certificates").select("id", { count: "exact", head: true }).in("student_id", ids),
    ]);
    if (recent.error || legendary.error) return ""; // table not installed on this project: stay quiet here (the Certificates tab explains)

    tcert.dash = {};
    const reg = (r) => { certRegister(r); tcert.dash[r.id] = r; return r; };
    const recentRows = (recent.data || []).map(reg);
    const legRows = (legendary.data || []).map(reg);
    const total = typeof countRes.count === "number" ? countRes.count : recentRows.length;
    const weekAgo = Date.now() - 7 * 24 * 3600 * 1000;
    const isNew = (r) => new Date(r.earned_at).getTime() >= weekAgo;
    const fmt = (iso) => new Date(iso).toLocaleDateString("en-PH", { month: "short", day: "numeric" });
    const btn = (r) => `<button class="btn-outline btn-sm" onclick="tcertView('${escapeHtml(String(r.id))}')">View / Print</button>`;
    const newBadge = `<span style="background:var(--gold);color:#3a2a00;font-size:.66rem;font-weight:700;border-radius:999px;padding:1px 7px;margin-left:6px;">NEW</span>`;

    const legHtml = legRows.length ? `
      <div style="border:1px solid var(--paper-line);background:linear-gradient(180deg,#FFFDF3,#FFF8E1);border-radius:10px;padding:10px 12px;margin:10px 0;">
        <div style="font-weight:700;margin-bottom:6px;">👑 ${legRows.length} Legendary pet${legRows.length === 1 ? "" : "s"} in ${escapeHtml(state.section.section_name)}</div>
        ${legRows.slice(0, 4).map((r) => {
          const form = (certExtra(r).stats || []).find((x) => x.label === "LEGENDARY FORM");
          return `<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:4px 0;">
            <div><strong>${escapeHtml(nameOf(r.student_id))}</strong> — ${escapeHtml(r.station_name)}${form ? ` <span class="muted">(${escapeHtml(form.value)})</span>` : ""}${isNew(r) ? newBadge : ""}
              <div class="muted" style="font-size:.74rem;">Became Legendary ${fmt(r.earned_at)}</div></div>
            ${btn(r)}
          </div>`;
        }).join("")}
        ${legRows.length > 4 ? `<div class="muted" style="font-size:.78rem;margin-top:4px;">+ ${legRows.length - 4} more in the Certificates tab</div>` : ""}
      </div>` : "";

    const recentHtml = recentRows.length ? `
      <table><tbody>
        ${recentRows.map((r) => {
          const k = CERT_KINDS[r.kind] || CERT_KINDS.completion;
          return `<tr>
            <td style="white-space:nowrap;">${fmt(r.earned_at)}</td>
            <td><strong>${escapeHtml(nameOf(r.student_id))}</strong>${isNew(r) ? newBadge : ""}</td>
            <td>${k.icon} ${escapeHtml(r.station_name)}${r.level_label ? ` <span class="muted">· ${escapeHtml(r.level_label)}</span>` : ""}</td>
            <td style="text-align:right;">${btn(r)}</td>
          </tr>`;
        }).join("")}
      </tbody></table>` : `<p class="muted">No certificates yet — they appear here the moment a student completes a whole station or a pet reaches Legendary.</p>`;

    return `
    <div class="card">
      <div class="section-title-row"><h3 style="margin:0;">🎓 Certificates &amp; Legendary Pets</h3>
        <span class="link-btn" onclick="switchTab('certificates')">View all (${total}) →</span>
      </div>
      ${legHtml}
      ${recentHtml}
    </div>`;
  } catch (e) {
    console.warn("certificates dashboard card skipped:", e);
    return "";
  }
}
