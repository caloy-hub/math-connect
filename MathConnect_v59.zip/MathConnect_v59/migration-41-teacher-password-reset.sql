-- ============================================================================
-- MathConnect — Migration 41: Admin teacher-password reset + exam oversight
-- ----------------------------------------------------------------------------
-- Adds two independent admin capabilities to the Admin Overview panel:
--
-- 1. PASSWORD RESET FOR TEACHER ACCOUNTS
--    Teachers sign in with real Supabase Auth (email+password — see auth.js).
--    This app has no backend server and no Edge Functions, only the Supabase
--    client + Postgres, so we can't call Supabase's Admin API (that needs a
--    service_role key, which must never be shipped to the browser). Instead,
--    `admin_reset_teacher_password()` below is a SECURITY DEFINER Postgres
--    function that writes the new password's hash straight into
--    `auth.users.encrypted_password` using pgcrypto (already enabled by
--    supabase-schema.sql) — the same hashing Supabase Auth itself checks
--    against on login. It re-checks is_admin() itself, so the RLS-style
--    protection is enforced in the database, not just hidden in the UI.
--    `admin_get_teacher_emails()` lets the admin panel show each teacher's
--    sign-in email (not stored in the `teachers` table itself) so the admin
--    can tell accounts apart before resetting one.
--
--    ⚠️ KNOWN LIMITATION: this changes the password a teacher needs for their
--    NEXT sign-in, but does not revoke any session/JWT already issued to
--    them — doing that requires the Admin API's "sign out all sessions" call,
--    which needs the service_role key this app deliberately never exposes.
--    For a classroom app this is an acceptable, but real, limitation — same
--    spirit as the student-side note in migration-19.
--
-- 2. EXAMINATIONS ON THE ADMIN DASHBOARD
--    "Examinations" here means the Class Record's EX component (Summative
--    Test 1, Summative Test 2, Term Examination — see grading.js), NOT the
--    separate 📝 Exams feature (exam_schema.sql). No new tables or RLS are
--    needed for this: `assessments` and `scores` are already fully
--    readable by the admin role (migration-6-admin-panel.sql), so admin.js
--    simply filters assessments where component = 'EX' and computes each
--    class's exam list + exam-only average client-side from data it
--    already loads. See admin.js's classRows / examItems / examGeneralAverage.
--
-- Safe to run on your existing database — nothing is deleted.
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. Teacher password reset
-- ----------------------------------------------------------------------------

-- Lets the admin panel show each teacher's sign-in email (join target for
-- resets). Restricted to admins; only ever selects teachers, never students
-- or other admins.
create or replace function public.admin_get_teacher_emails()
returns table(id uuid, email text)
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if not is_admin() then
    raise exception 'only admins can view teacher emails';
  end if;
  return query
    select u.id, u.email::text
    from auth.users u
    join teachers t on t.id = u.id;
end;
$$;
grant execute on function public.admin_get_teacher_emails() to authenticated;

-- Directly sets a teacher's Supabase Auth password. Admin-only, and only
-- ever touches an id that already exists in `teachers` (never an arbitrary
-- auth.users row, e.g. another admin or a student's linked account).
create or replace function public.admin_reset_teacher_password(target_teacher_id uuid, new_password text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if not is_admin() then
    raise exception 'only admins can reset teacher passwords';
  end if;
  if new_password is null or length(new_password) < 6 then
    return jsonb_build_object('error', 'Password must be at least 6 characters.');
  end if;
  if not exists (select 1 from teachers where id = target_teacher_id) then
    return jsonb_build_object('error', 'That teacher account no longer exists.');
  end if;

  update auth.users
  set encrypted_password = crypt(new_password, gen_salt('bf')),
      updated_at = now()
  where id = target_teacher_id;

  return jsonb_build_object('ok', true);
end;
$$;
-- Admin-only action, only ever called from an authenticated admin session.
grant execute on function public.admin_reset_teacher_password(uuid, text) to authenticated;

-- Add "password_reset" as a valid admin_action_log entry (migration-30's
-- table already exists — this just widens its CHECK constraint).
alter table admin_action_log drop constraint if exists admin_action_log_action_type_check;
alter table admin_action_log add constraint admin_action_log_action_type_check
  check (action_type in (
    'status_change', 'edit_account', 'delete_account',
    'lock_change', 'edit_entry', 'delete_entry', 'finalize_champion',
    'password_reset'
  ));

-- ============================================================================
-- Done. Reload the admin panel:
--   - Teacher Accounts now shows each teacher's email and a "🔑 Reset
--     Password" button.
--   - The "All Classes" table now has an "Examinations" column — click it
--     to expand every EX-component item (Summative Test 1/2, Term
--     Examination) recorded for that class, its class average, and the
--     class's overall Exam-only average (Final + per term), alongside the
--     existing General Average / Proficiency / Attendance figures. This
--     reads data that was already admin-readable, so no SQL is needed for
--     that half of this update — it's pure admin.js/admin.html.
-- ============================================================================
