# MathConnect — Migration 47 Changelog
## Expansion: 6 New High School Drill Stations, Expanded Shop & Game Surprises

## 1. Six new Drill Arena stations (drills.js, teacher-drills.js)
All 15-level, keypad-compatible (integer/decimal/fraction answers), agri-themed where natural:

| Key | Station | Focus |
|---|---|---|
| `exponents` | ⚡ Exponent Matrix | Laws of exponents, roots, scientific notation |
| `equations` | ⚖️ Equation Scale | 1-variable linear equations, distributive property |
| `factoring` | 🧩 Factor Vault | GCF, difference of squares, perfect square trinomials, quadratic factoring |
| `measurement` | 🌾 Farm Measure | Metric conversions, hectares, farm application rates |
| `coordinates` | 📈 Grid Navigator | Cartesian plane, slope, y-intercepts |
| `pythagoras` | 📐 Surveyor's Post | Pythagorean Theorem, farm boundary fencing |

- Registered in `DRILL_TOPICS` / `DRILL_GENERATORS` (drills.js) and `TDRILL_TOPICS` (teacher-drills.js) — teacher analytics, dropdowns, heatmaps, and per-station leaderboards pick these up automatically since those views already iterate the topic list generically.
- No database schema changes were needed for the stations themselves — `drill_attempts` / `skill_proficiency` are keyed by topic string already.
- **Verified**: `verify_new_stations.js` (included) runs all 6 stations × 15 levels × 5 trials (450 runs) in a sandboxed Node VM, confirming valid prompts, no `NaN`/non-finite/non-integer-typed answers, and that every generated answer round-trips through `checkDrillAnswer`. All 450 passed.

## 2. In-game surprises (drills.js, style.css, petReactions.js)
- **✨ Golden Question** — questions #5/#8 each get a 25% roll; a Golden Question pays 3× points, shows a glowing gold card + banner, fires a golden particle burst (`playGoldenBurst()`), and triggers a bigger pet cheer (new `GOLDEN_CORRECT` reaction in petReactions.js).
- **🐾 Pet Assist** — after 15s on one question, the pet offers a narrowed "50/50" choice (the correct answer + 1 plausible distractor) as tappable buttons. Also purchasable on demand via the new Genius Pass relic (`useGeniusPassOnDrill()`).
- **🔥 Fever Rush Combo** — 3 consecutive correct answers solved in under 5s activates Fever Mode: pulsing border, 2× point multiplier, until a slow or wrong answer resets it.
- **🎁 Enhanced Mystery Box** — on top of the original Bonus/Jackpot/Bokya/Empty outcomes, boxes can now drop a free pet Snack, a real Coin bonus, or a rare Gemstone shard — each persisted immediately (not just added to the session score).
- **🎡 Wheel of Archimedes** — a perfect 10/10 run unlocks one spin: weighted prizes are Coins (small/jackpot), Green Points, a Skip Pass, or a rare Gemstone.

## 3. Expanded Rewards Shop (shopEngine.js, shop-ui.js, pet-ui.js, migration-47-shop-expansion.sql)
- **New Gameplay Relics**: 🧲 Coin Magnet (doubles Coins for 15 min, same timed-buff pattern as Double XP), 🛡️ Streak Shield (protects the Drills streak from 1 miss), 💡 Genius Pass (on-demand 50/50 in Drills).
- **New Pet Superfoods** (`pet_food_items`): 🍕 Polynomial Pizza, 🍎 Golden Apple, 🧃 Geometry Gelato.
- **New Pet Accessories** (`pet_care_items`, category `equipment`): 🎓 Scholar's Cap, 🌾 Harvester Hat, 🕶️ Neon Visor, 👑 Royal Ribbon (golden ribbon) — each also gives a small permanent hunger-decay perk while equipped, consistent with existing equipment items.
- **New profile titles**: "Agri-Tech Prodigy", "Master of the Unknown (x)", "Euler's Chosen".
- **Shop UI reorganized into 4 tabs**: ⚡ Boosters & Relics · 🍕 Pet Treats & Superfoods · 👒 Pet Accessories · 🏷️ Titles. Pet food/care items render generically from their DB tables via the existing `renderShopPetSections()`, so the new catalog rows above appear automatically once the migration is run — no further code changes needed.

### Database migration
Run `migration-47-shop-expansion.sql` once in the Supabase SQL Editor. It adds:
1. `student_engagement.coin_magnet_expires_at` (timed-buff column, mirrors `double_xp_expires_at`).
2. 3 new `shop_items` rows (coin_magnet, streak_shield, genius_pass).
3. A re-created `consume_shop_item(...)` (return columns changed to include the new expiry) with a `coin_magnet` branch; `streak_shield`/`genius_pass` use the existing generic "decrement inventory" path since they're client-armed one-shot consumables.
4. `award_gemstone(...)` — small RPC so the Wheel and Mystery Box can grant a Gemstone safely/atomically.
5. `grant_pet_food(...)` — a **free** food grant (no coin charge) for the Mystery Box's Snack drop; mirrors `purchase_pet_food`'s inventory bump but skips the coin deduction.
6. 3 new `pet_food_items` rows + 4 new `pet_care_items` (equipment) rows.

## Verification performed
- `node -c` syntax check on every touched JS file: `drills.js`, `teacher-drills.js`, `shopEngine.js`, `shop-ui.js`, `pet-ui.js`, `petReactions.js` — all pass.
- `verify_new_stations.js` — 450/450 generator runs passed (see above).
- SQL migration was written to mirror the exact patterns of the existing `migration-17/32/33/37` (same security-definer + `for update` row-locking style) but **has not been run against a live Supabase project** — please run it in a staging environment first and confirm the Shop/Pet tabs render the new items before deploying to production.

## Not automated
- Manual gameplay verification (Golden Question glow, Fever Mode pulsing border, Wheel of Archimedes spin animation, Shop tab switching) — please click through these once in the browser, since they weren't scriptable in this environment.
