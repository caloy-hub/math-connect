-- ============================================================================
-- Migration 16 — Daily Streaks, Power-Ups & the Real-World Daily Challenge
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this if supabase-schema.sql was
-- already updated to include it.
--
-- What this adds:
--   1. student_engagement — ONE row per student: their current/longest
--      streak, last active date, coin balance, currently active power-up
--      (if any) + its expiry, and how many "Skip Question" passes they have.
--   2. daily_challenge_completions — one row per student PER DAY they
--      complete the Daily Challenge. The unique constraint on
--      (student_id, challenge_date) is what stops a student from farming
--      infinite coins by resubmitting the same day's challenge.
-- ============================================================================

create table if not exists student_engagement (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade unique,
  coins integer not null default 0,
  current_streak integer not null default 0,
  longest_streak integer not null default 0,
  last_active_date date,
  active_powerup text,                 -- e.g. '2x_coins', null when none active
  powerup_expires_at timestamptz,
  skip_passes integer not null default 0,
  updated_at timestamptz default now()
);

create table if not exists daily_challenge_completions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  challenge_date date not null,
  is_correct boolean not null default true,
  coins_awarded integer not null default 0,
  answered_at timestamptz default now(),
  unique (student_id, challenge_date)
);
create index if not exists daily_challenge_completions_student_idx on daily_challenge_completions (student_id);

-- ---------- RLS — same open client-side model as the rest of the drill/learning tables ----------
alter table student_engagement enable row level security;
alter table daily_challenge_completions enable row level security;

drop policy if exists "public read student_engagement" on student_engagement;
create policy "public read student_engagement" on student_engagement for select using (true);
drop policy if exists "anyone insert student_engagement" on student_engagement;
create policy "anyone insert student_engagement" on student_engagement for insert with check (true);
drop policy if exists "anyone update student_engagement" on student_engagement;
create policy "anyone update student_engagement" on student_engagement for update using (true);
drop policy if exists "teacher delete student_engagement" on student_engagement;
create policy "teacher delete student_engagement" on student_engagement for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read daily_challenge_completions" on daily_challenge_completions;
create policy "public read daily_challenge_completions" on daily_challenge_completions for select using (true);
drop policy if exists "anyone insert daily_challenge_completions" on daily_challenge_completions;
create policy "anyone insert daily_challenge_completions" on daily_challenge_completions for insert with check (true);
drop policy if exists "teacher delete daily_challenge_completions" on daily_challenge_completions;
create policy "teacher delete daily_challenge_completions" on daily_challenge_completions for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ============================================================================
-- Done. Load streakEngine.js + dailyChallenge.js + engagement-ui.js on
-- student.html to enable the new "🎯 Challenges" tab.
-- ============================================================================
