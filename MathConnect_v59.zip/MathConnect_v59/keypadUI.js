// ============================================================================
// Shared on-screen numeric keypad for answer inputs (Math Drills, Boss
// Battles, Quest Mode, Intelligent Practice, Daily Challenge).
// ----------------------------------------------------------------------------
// The answer <input> is set readonly + inputmode="none" so the device's own
// keyboard never appears (no autocorrect, no device-keyboard glitches). This
// in-app keypad becomes the only way to type an answer. It supports three
// layouts depending on the expected answer format:
//   "integer"  -> digits + backspace/clear/enter
//   "decimal"  -> digits + "." + backspace/clear/enter
//   "fraction" -> digits + "/" + backspace/clear/enter
// Call attachNumericKeypad("someAnswerInputId", { type: q.type }) right after
// the input is rendered into the DOM — same spot the existing
// `input.focus()` / Enter-key wiring already happens.
// ============================================================================

/**
 * Wires a custom numeric keypad to the given answer <input>, blocking the
 * device's native keyboard entirely.
 * @param {string} inputId - id of the target <input>
 * @param {{type?: "integer"|"decimal"|"fraction"}} opts
 */
function attachNumericKeypad(inputId, opts) {
  opts = opts || {};
  const type = opts.type === "integer" || opts.type === "fraction" ? opts.type : "decimal";
  const input = document.getElementById(inputId);
  if (!input) return;

  // Block the device's own on-screen keyboard. readonly + inputmode="none"
  // is honored by iOS Safari and Chrome/Android alike, while still letting
  // the field receive focus, show a caret, and be styled as active.
  input.setAttribute("readonly", "readonly");
  input.setAttribute("inputmode", "none");
  input.classList.add("numkeypad-target");
  // Prevent the blinking caret from implying a text-select/copy menu on long-press.
  input.style.webkitUserSelect = "none";
  input.style.userSelect = "none";

  // If this input was already re-rendered (new question, next round, etc.),
  // remove any keypad left over from before so they don't stack up.
  const existing = input.parentElement.querySelector(".numkeypad");
  if (existing) existing.remove();

  const symbolKey = type === "integer" ? null : type === "fraction" ? "/" : ".";
  const symbolLabel = type === "fraction" ? "/" : ".";

  // Row 1-3: digits. Row 4: minus sign, 0, and the type's symbol (if any —
  // integer questions leave that slot blank so the grid stays aligned).
  const mainKeys = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "-", "0", symbolKey];

  const pad = document.createElement("div");
  pad.className = "numkeypad";
  pad.innerHTML = `
    <div class="numkeypad-grid">
      ${mainKeys.map((k) => numkeypadButtonHtml(k, symbolLabel)).join("")}
    </div>
    <div class="numkeypad-utility-row">
      <button type="button" class="numkeypad-key numkeypad-key-utility numkeypad-key-back" data-key="back">⌫</button>
      <button type="button" class="numkeypad-key numkeypad-key-utility" data-key="clear">Clear</button>
      <button type="button" class="numkeypad-key numkeypad-key-utility numkeypad-key-enter" data-key="enter">Enter ↵</button>
    </div>`;
  input.insertAdjacentElement("afterend", pad);

  pad.addEventListener("click", (ev) => {
    const btn = ev.target.closest(".numkeypad-key");
    if (!btn) return;
    const key = btn.getAttribute("data-key");

    if (key === "back") {
      input.value = input.value.slice(0, -1);
    } else if (key === "clear") {
      input.value = "";
    } else if (key === "enter") {
      // Every screen that uses this keypad already listens for an Enter
      // keydown on the input to trigger its own submit function, so just
      // replay that instead of duplicating submit logic here.
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      return;
    } else {
      input.value += key;
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

function numkeypadButtonHtml(key, symbolLabel) {
  if (!key) return `<span class="numkeypad-key numkeypad-key-spacer" aria-hidden="true"></span>`; // keeps the grid aligned for integer questions
  if (key === "-") return `<button type="button" class="numkeypad-key numkeypad-key-minus" data-key="-">−</button>`;
  const label = key === "." || key === "/" ? symbolLabel : key;
  return `<button type="button" class="numkeypad-key" data-key="${key}">${label}</button>`;
}
