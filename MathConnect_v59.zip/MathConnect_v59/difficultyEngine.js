// ============================================================================
// MathConnect — Adaptive Difficulty Engine
// Pure logic, no Supabase/DOM calls in this file on purpose (easy to unit
// test, easy to reuse from a future non-web client). Owns ONE decision:
// given a domain's recent answer history, what tier should the NEXT
// question be?
//
// Tiers: 1 = Easy, 2 = Medium, 3 = Hard, 4 = Expert
// ============================================================================

const LE_TIERS = ["Easy", "Medium", "Hard", "Expert"];
const LE_MIN_TIER = 1;
const LE_MAX_TIER = 4;
const LE_HISTORY_SIZE = 5;

function tierLabel(tier) {
  return LE_TIERS[Math.max(LE_MIN_TIER, Math.min(LE_MAX_TIER, tier || 1)) - 1];
}

/**
 * Push the latest outcome onto a domain's rolling history, keeping only the
 * last LE_HISTORY_SIZE entries (oldest first). 1 = unassisted correct,
 * 0 = missed (includes "corrected on 2nd try" — see learningEngine.js).
 */
function pushRecentAnswer(recentAnswersForDomain, outcome) {
  const arr = Array.isArray(recentAnswersForDomain) ? recentAnswersForDomain.slice() : [];
  arr.push(outcome ? 1 : 0);
  while (arr.length > LE_HISTORY_SIZE) arr.shift();
  return arr;
}

/**
 * calculateNextTier(recentAnswersForDomain, currentTier)
 * Looks at up to the last 5 answers for ONE domain and returns the tier the
 * student's NEXT question in that domain should use.
 *
 * Rules (deliberately simple + explainable to a teacher, not a black box):
 *  - Needs at least 3 data points before it will move at all — avoids
 *    over-reacting to a single lucky/unlucky question.
 *  - 4 or 5 correct out of the last 5 (or 3/3 correct with fewer than 5
 *    logged yet) -> climb one tier, capped at Expert (4).
 *  - 0 or 1 correct out of the last 5 (or 0/3 with fewer than 5 logged)
 *    -> drop one tier, floored at Easy (1).
 *  - Anything in between (a mixed run) -> hold the current tier.
 */
function calculateNextTier(recentAnswersForDomain, currentTier) {
  const history = Array.isArray(recentAnswersForDomain) ? recentAnswersForDomain : [];
  const tier = Math.max(LE_MIN_TIER, Math.min(LE_MAX_TIER, currentTier || 1));
  if (history.length < 3) return tier;

  const correctCount = history.reduce((sum, v) => sum + (v ? 1 : 0), 0);
  const n = history.length;

  const promoteThreshold = n >= 5 ? 4 : n; // 4/5, or a clean sweep on a shorter run
  const demoteThreshold = n >= 5 ? 1 : 0; // 1/5, or a total whiff on a shorter run

  if (correctCount >= promoteThreshold && tier < LE_MAX_TIER) return tier + 1;
  if (correctCount <= demoteThreshold && tier > LE_MIN_TIER) return tier - 1;
  return tier;
}

// Node/CommonJS export for testing, ignored harmlessly by the browser <script> include.
if (typeof module !== "undefined" && module.exports) {
  module.exports = { LE_TIERS, LE_MIN_TIER, LE_MAX_TIER, LE_HISTORY_SIZE, tierLabel, pushRecentAnswer, calculateNextTier };
}
