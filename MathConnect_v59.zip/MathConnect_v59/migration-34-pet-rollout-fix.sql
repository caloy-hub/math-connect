-- ============================================================================
-- Migration 34 — one-time fix for the v34.3 mass-death rollout bug.
-- Run this once in Supabase → SQL Editor, AFTER migration-33.
--
-- WHAT HAPPENED:
--   migration-33 turned on real, clock-based neglect (check_pet_wellbeing())
--   with no backfill/grace period for pets that already existed under
--   migration-32/v34.1/v34.2 — versions that had no feeding urgency at all.
--   The very first wellbeing check after deploy judged already-elapsed
--   real time retroactively, so pets that simply hadn't needed feeding
--   yet were marked sick and, in many cases, killed in that same call.
--   Every pet currently marked dead is a casualty of that one-time bug,
--   not genuine neglect under the new rules (which have only existed for
--   minutes/hours at most) — so it's safe to revive all of them in bulk,
--   this once.
--
-- WHAT THIS DOES:
--   1. Revives every currently-dead pet for a student who doesn't already
--      have a replacement living pet (picks their most recent dead row).
--      Clears sickness/death fields, restores hunger to 100.
--   2. Resets last_fed_at = now() for every alive pet (revived or not),
--      so hunger decay starts counting from this moment forward instead
--      of from before the feature existed. This does NOT touch the 3-
--      adoption cap or adoption_number — revived pets keep their original
--      row/adoption slot, so no one loses (or gains) an adoption chance.
--
-- This does not change any function logic — check_pet_wellbeing() itself
-- is fine going forward now that every pet has a fresh, fair baseline.
-- ============================================================================

with latest_dead as (
  select distinct on (student_id) id, student_id
  from student_pets
  where alive = false
  order by student_id, adoption_number desc
)
update student_pets sp
set alive = true,
    died_at = null,
    cause_of_death = null,
    sick = false,
    sick_since = null,
    hunger = 100,
    last_fed_at = now(),
    updated_at = now()
from latest_dead ld
where sp.id = ld.id
  and not exists (
    select 1 from student_pets a
    where a.student_id = ld.student_id and a.alive = true
  );

-- Give every currently-alive pet (revived above, or pets that survived
-- the bug) a clean decay baseline starting now.
update student_pets
set last_fed_at = now(),
    updated_at = now()
where alive = true;
