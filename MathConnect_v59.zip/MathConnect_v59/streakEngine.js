// ============================================================================
// MathConnect — Streak & Power-Up Engine
// Owns: the attendance-driven daily streak (TikTok-style flame), unlocking
// power-ups every 7-day streak, the "Skip Question" pass economy, and the
// coin wallet. Used by drills.js, adaptive-practice.js, dailyChallenge.js,
// streak-ui.js, shopEngine.js.
//
// IMPORTANT — where the streak actually comes from (changed in migration-23):
// current_streak / longest_streak / streak_off* are no longer advanced by
// this file. They're computed server-side by recompute_attendance_streak()
// (a Postgres trigger on the `attendance` table — see
// migration-23-attendance-streak.sql) every time a teacher marks a student
// present/late/absent. This file just READS that state and lets the student
// spend coins to restore a broken ("off") streak via the restore_streak()
// RPC. recordDailyActivity() is kept as a read-only compatibility shim so
// drills.js/dailyChallenge.js/adaptive-practice.js/quest-ui.js (which still
// call it after a student finishes something) don't need to change — it no
// longer mutates the streak itself.
//
// Depends on: supabase-client.js (supabase), sstate (student.js).
// ============================================================================

const LE_STREAK_MILESTONE = 7; // every 7 consecutive attendance days -> a new power-up (kept in sync with the SQL trigger)
const LE_POWERUP_DURATION_MS = 24 * 60 * 60 * 1000; // a power-up lasts 24h once unlocked

// Mirrors the pricing inside restore_streak() in migration-23-attendance-streak.sql.
// Shown to the student before they spend coins — the SQL function is still the
// source of truth and re-checks the balance server-side.
const STREAK_RESTORE_COST = { absent_excused: 10, absent_unexcused: 25 };

// ---------- Flame tiers: color + "capacity" (visual size) change with the streak length ----------
// idx 0 is the "never started" state; the rest map min-day thresholds to a look,
// same spirit as a TikTok streak flame changing color/style at milestones.
const FLAME_TIERS = [
  { key: "unlit",  min: 0,   max: 0,        label: "Start your streak",  color: "#B9C0C6", glow: null,      scale: 0.55, sparkle: false },
  { key: "spark",  min: 1,   max: 2,        label: "Spark",              color: "#FFB74D", glow: "#FFD9A0", scale: 0.68, sparkle: false },
  { key: "ember",  min: 3,   max: 6,        label: "Ember",              color: "#FF8A3D", glow: "#FFC08A", scale: 0.78, sparkle: false },
  { key: "blaze",  min: 7,   max: 13,       label: "Blaze",              color: "#F4511E", glow: "#FF8A65", scale: 0.88, sparkle: false },
  { key: "inferno",min: 14,  max: 29,       label: "Inferno",            color: "#E53935", glow: "#FF6F60", scale: 0.98, sparkle: false },
  { key: "azure",  min: 30,  max: 49,       label: "Azure Flame",        color: "#2F8FD1", glow: "#7BC0F2", scale: 1.08, sparkle: true  },
  { key: "violet", min: 50,  max: 99,       label: "Violet Flame",       color: "#8E44AD", glow: "#C58AE0", scale: 1.18, sparkle: true  },
  { key: "legend", min: 100, max: Infinity, label: "Legendary Flame",    color: "#F4C95D", glow: "#FFE29A", scale: 1.3,  sparkle: true, rainbow: true },
];

function getFlameTier(streak) {
  const s = Math.max(0, streak || 0);
  let tier = FLAME_TIERS[0];
  let idx = 0;
  for (let i = 0; i < FLAME_TIERS.length; i++) {
    if (s >= FLAME_TIERS[i].min) { tier = FLAME_TIERS[i]; idx = i; }
  }
  return { tier, idx };
}

/** Days into the current tier / days needed to reach the next tier — for the progress fill inside the flame. */
function flameTierProgress(streak) {
  const { tier, idx } = getFlameTier(streak);
  const next = FLAME_TIERS[idx + 1];
  if (!next) return { tier, idx, fraction: 1, next: null };
  const span = next.min - tier.min;
  const into = Math.max(0, (streak || 0) - tier.min);
  return { tier, idx, fraction: span > 0 ? Math.min(1, into / span) : 1, next };
}

var estate = { data: null, loaded: false, gemBoostActive: false };

// Philippine-local calendar date (school is in the Philippines).
function phDateString(offsetDays) {
  const d = new Date();
  if (offsetDays) d.setDate(d.getDate() + offsetDays);
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Manila" }); // "en-CA" -> YYYY-MM-DD
}

function leDefaultEngagement() {
  return {
    coins: 0, green_points: 0, current_streak: 0, longest_streak: 0, last_active_date: null,
    active_powerup: null, powerup_expires_at: null, skip_passes: 0,
    streak_off: false, streak_off_value: 0, streak_off_reason: null, streak_off_date: null,
    gemstones: 0, adoption_chance_adjustment: 0,
  };
}

async function loadEngagement() {
  const { data } = await supabase.from("student_engagement").select("*").eq("student_id", sstate.student.id).maybeSingle();
  if (data) {
    estate.data = data;
  } else {
    estate.data = { student_id: sstate.student.id, ...leDefaultEngagement() };
    const { data: inserted } = await supabase.from("student_engagement").insert(estate.data).select().maybeSingle();
    estate.data = inserted || estate.data;
  }
  leExpirePowerupIfNeeded();
  estate.loaded = true;
}

// Persists ONLY the fields this client is allowed to be the source of truth
// for (coins, active power-up/skip passes). current_streak / longest_streak /
// last_active_date / streak_off* are intentionally NOT written here — those
// are owned server-side by recompute_attendance_streak() (migration-23).
// Writing them back from a stale client cache would risk undoing a streak
// break/restore that happened while this tab was open (e.g. a teacher marks
// the student absent, then the student answers a drill question in an
// already-open tab).
async function saveEngagement() {
  const e = estate.data;
  await supabase.from("student_engagement").update({
    coins: e.coins, green_points: e.green_points, active_powerup: e.active_powerup, powerup_expires_at: e.powerup_expires_at,
    skip_passes: e.skip_passes, updated_at: new Date().toISOString(),
  }).eq("student_id", sstate.student.id);
}

function leExpirePowerupIfNeeded() {
  const e = estate.data;
  if (e.active_powerup && e.powerup_expires_at && new Date(e.powerup_expires_at) < new Date()) {
    e.active_powerup = null;
    e.powerup_expires_at = null;
  }
}

function isPowerupActive() {
  if (!estate.loaded || !estate.data) return false;
  leExpirePowerupIfNeeded();
  return !!estate.data.active_powerup;
}

/** Coin multiplier to apply to any coin reward RIGHT NOW (1 normally, 2 while "2x_coins" is active). */
function coinMultiplier() {
  return isPowerupActive() && estate.data.active_powerup === "2x_coins" ? 2 : 1;
}

/**
 * recordDailyActivity()
 * Compatibility shim — kept so drills.js / dailyChallenge.js /
 * adaptive-practice.js / quest-ui.js don't need to change. The streak itself
 * no longer moves here (see file header); this just reports its current
 * value so those callers' "bonus star at a 3+ day streak" style logic still
 * works, driven by the attendance streak instead.
 */
async function recordDailyActivity() {
  if (!estate.loaded) await loadEngagement();
  const e = estate.data;
  return { streakChanged: false, streak: e.current_streak, newPowerup: false };
}

/** Spend one Skip Question pass. Returns true if one was available and spent. */
async function consumeSkipPass() {
  if (!estate.loaded) await loadEngagement();
  if ((estate.data.skip_passes || 0) <= 0) return false;
  estate.data.skip_passes -= 1;
  await saveEngagement();
  return true;
}

/** Award coins (already multiplier-adjusted by the caller, or call coinMultiplier() yourself). */
async function awardCoins(amount) {
  if (!estate.loaded) await loadEngagement();
  estate.data.coins = (estate.data.coins || 0) + amount;
  await saveEngagement();
  return estate.data.coins;
}

/**
 * Award Green Points — the currency fed to a student's Math Pet. Earned from
 * playing pretty much anywhere (drills, quest, battles, exams, ratings...),
 * same "client-writable earning, RPC-gated spending" trust tier Coins use
 * (see migration-32). Not multiplier-adjusted by streak/rank the way coins
 * are — Green Points is a separate economy from coins/2x-coins on purpose.
 *
 * GREEN_POINTS_BOOST applies a flat +40% on top of the amount passed in,
 * but ONLY when `boosted` (2nd arg) is left true (the default). This is for
 * the sources whose award logic isn't otherwise specified per-activity —
 * currently Math Drills, Adaptive Practice, the Daily Challenge, and Exams —
 * so those four keep scaling together from one spot without touching each
 * call site. Rounds to the nearest whole point, so very small base amounts
 * (e.g. the +1 per correct drill answer) may round back down to themselves.
 *
 * Quest Mode, Boss Raids, and Ratings now have their own
 * explicit point values baked into their call sites (see questGreenPointsEarned
 * in quest-ui.js, the Boss Raid reward claim in raidEngine.js (claimRaidRewards),
 * and submitRating in student.js) —
 * those call awardGreenPoints(amount, false) so their numbers are awarded
 * exactly as passed, without this general boost stacking on top.
 *
 * On top of ALL of the above (regardless of `boosted`), a further flat +30%
 * applies whenever estate.gemBoostActive is true — that flag is maintained
 * by petEngine.js, true whenever any of the student's pets currently has
 * active All-Rounder Gemstone immunity (see migration-37,
 * refreshGemBoostActiveFlag() in petEngine.js). This is the Gemstone's
 * "+30% Green Points" perk, and it applies to every source, not just Quest.
 */
const GREEN_POINTS_BOOST = 1.4;
const GEM_GREEN_POINTS_BOOST = 1.3;
async function awardGreenPoints(amount, boosted = true) {
  if (!estate.loaded) await loadEngagement();
  let finalAmount = boosted ? Math.round((amount || 0) * GREEN_POINTS_BOOST) : Math.round(amount || 0);
  if (estate.gemBoostActive) finalAmount = Math.round(finalAmount * GEM_GREEN_POINTS_BOOST);
  estate.data.green_points = (estate.data.green_points || 0) + finalAmount;
  await saveEngagement();
  return estate.data.green_points;
}

/**
 * markDailyActivity(activityKey)
 * Thin wrapper around the mark_daily_activity RPC (migration-37) — call this
 * once from each activity's completion point (drills, quest, practice,
 * battle, challenge, rating, feed_pet). Idempotent server-side (flipping an
 * already-true flag is harmless), and the moment all 7 flags are true for
 * the first time in a calendar day, the RPC mints one Gemstone and this
 * function surfaces that with a toast so the student notices.
 */
async function markDailyActivity(activityKey) {
  try {
    const { data, error } = await supabase.rpc("mark_daily_activity", { target_student_id: sstate.student.id, activity_key: activityKey });
    if (error || !data || !data[0]) return;
    const row = data[0];
    if (row.gem_awarded) {
      if (!estate.loaded) await loadEngagement();
      estate.data.gemstones = (estate.data.gemstones || 0) + 1;
      toast("💎 All-Rounder Gemstone earned! You did every activity today!");
    }
  } catch (e) { /* best-effort — never blocks the activity it's called from */ }
}

/** What restoring the CURRENT off streak would cost, or null if the streak isn't off. */
function currentRestoreCost() {
  if (!estate.loaded || !estate.data || !estate.data.streak_off) return null;
  return STREAK_RESTORE_COST[estate.data.streak_off_reason] || STREAK_RESTORE_COST.absent_excused;
}

/**
 * restoreStreak() — spends coins via the restore_streak() RPC to turn the
 * flame back on at its pre-absence value. Returns the RPC row so the UI can
 * show the result (and play the level-up animation, since a restore can jump
 * the flame back up several tiers at once).
 */
async function restoreStreak() {
  if (!estate.loaded) await loadEngagement();
  const { data, error } = await supabase.rpc("restore_streak", { target_student_id: sstate.student.id });
  if (error) { toast("Couldn't restore your streak — please try again."); return { success: false }; }
  const row = Array.isArray(data) ? data[0] : data;
  if (!row.success) { toast(row.message); return row; }
  estate.data.coins = row.new_coins;
  estate.data.current_streak = row.new_current_streak;
  estate.data.longest_streak = row.new_longest_streak;
  estate.data.streak_off = false;
  estate.data.streak_off_value = 0;
  estate.data.streak_off_reason = null;
  estate.data.streak_off_date = null;
  toast(`🔥 ${row.message}`);
  return row;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { FLAME_TIERS, getFlameTier, flameTierProgress, STREAK_RESTORE_COST };
}
