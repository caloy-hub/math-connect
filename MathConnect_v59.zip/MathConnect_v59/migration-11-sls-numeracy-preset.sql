-- ============================================================================
-- MathConnect — Migration 11: SLS Numeracy Intervention grading preset
-- ----------------------------------------------------------------------------
-- Adds a new grading weight option specifically for the Success Learning
-- Stations (SLS) Numeracy program: WW 35% / PT 35% / EX 30%, using its own
-- adjusted transmutation table (floor 50 / cap 90) instead of the standard
-- one — per the school-provided "SLS Numeracy Transmutation Table"
-- (Transmuted Grade = 50 + (Initial Grade / 100) x 40, rounded).
--
-- This only widens which values are allowed in sections.weight_preset —
-- nothing existing changes unless you specifically choose this preset for
-- a section.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

alter table sections drop constraint if exists sections_weight_preset_check;
alter table sections add constraint sections_weight_preset_check
  check (weight_preset in ('core', 'mapeh_tle', 'sls_numeracy', 'custom'));

-- Done. Redeploy grading.js and teacher.js — "SLS Numeracy Intervention"
-- will then appear as a choice when creating a new section.
