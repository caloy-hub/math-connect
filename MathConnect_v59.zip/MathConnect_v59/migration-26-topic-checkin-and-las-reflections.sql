-- ============================================================================
-- MathConnect — Migration 26: Weekly Topic Check-In + Blended Learning
-- Reflections (Learning Activity Sheet mode)
--
-- WHAT THIS CHANGES
--   The old "Lessons & Tasks" tab (teacher) / "Task of the Week" card
--   (student) is being replaced with a weekly UNDERSTANDING CHECK-IN:
--   students rate (1-5) how well they understood each week's lesson and can
--   leave an optional comment. The teacher's tab now surfaces a ranked
--   "Least Understood Topics" list computed from those ratings, so it
--   doubles as a built-in formative-assessment signal instead of a mostly
--   ignored to-do list.
--
--   The Blended Learning tab's old "Submissions" sub-tab (a file-link
--   dropbox) is being replaced with REFLECTIONS: when classes shift to
--   blended mode (DepEd-declared suspension/emergency), the teacher posts
--   the week's Learning Activity Sheet (LAS) as a PDF under "Modules" (now
--   viewable in-page, not just an outbound link), and instead of submitting
--   an output file — which only happens once face-to-face classes resume —
--   students type a short plain-text reflection on what they learned that
--   day. The teacher can reply with feedback on the same panel.
--
--   The old "tasks" / "submissions" tables are left in place untouched (no
--   data loss, nothing dropped) but are no longer written to by the app —
--   they're fully superseded by topic_ratings and reflections below.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file →
-- Run. Safe to re-run. New projects don't need this — supabase-schema.sql
-- already includes it.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. WEEKLY TOPIC RATINGS — one rating per student per lesson, upsertable so
--    a student can revise their answer while the lesson is still current.
-- ----------------------------------------------------------------------------
create table if not exists topic_ratings (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references lessons(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  section_id uuid not null references sections(id) on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (lesson_id, student_id)
);
create index if not exists idx_topic_ratings_lesson on topic_ratings(lesson_id);
create index if not exists idx_topic_ratings_section on topic_ratings(section_id);

-- ----------------------------------------------------------------------------
-- 2. BLENDED LEARNING REFLECTIONS — one plain-text reflection per student
--    per LAS/module, with an optional teacher feedback reply on the same row.
-- ----------------------------------------------------------------------------
create table if not exists reflections (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references modules(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  section_id uuid not null references sections(id) on delete cascade,
  reflection_text text not null,
  submitted_at timestamptz default now(),
  updated_at timestamptz default now(),
  teacher_feedback text,
  feedback_at timestamptz,
  unique (module_id, student_id)
);
create index if not exists idx_reflections_module on reflections(module_id);
create index if not exists idx_reflections_section on reflections(section_id);

-- ----------------------------------------------------------------------------
-- 3. ROW LEVEL SECURITY — mirrors the existing lessons/modules/submissions
--    pattern exactly: public (anon = student) read, teacher-of-section
--    manages everything, and since students authenticate with a class code
--    rather than full Supabase Auth, inserts/updates from anon are allowed
--    with check(true) (same trust model already used by "submissions").
-- ----------------------------------------------------------------------------
alter table topic_ratings enable row level security;
alter table reflections enable row level security;

drop policy if exists "public read topic_ratings" on topic_ratings;
create policy "public read topic_ratings" on topic_ratings for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "anyone insert topic_ratings" on topic_ratings;
create policy "anyone insert topic_ratings" on topic_ratings for insert with check (true);
drop policy if exists "anyone update topic_ratings" on topic_ratings;
create policy "anyone update topic_ratings" on topic_ratings for update using (true);
drop policy if exists "teacher delete topic_ratings" on topic_ratings;
create policy "teacher delete topic_ratings" on topic_ratings for delete using (
  is_teacher_of_section(section_id)
);

drop policy if exists "public read reflections" on reflections;
create policy "public read reflections" on reflections for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "anyone insert reflections" on reflections;
create policy "anyone insert reflections" on reflections for insert with check (true);
drop policy if exists "anyone update reflections" on reflections;
create policy "anyone update reflections" on reflections for update using (true);
drop policy if exists "teacher delete reflections" on reflections;
create policy "teacher delete reflections" on reflections for delete using (
  is_teacher_of_section(section_id)
);

-- ============================================================================
-- Done. Refresh the app — the teacher's "📊 Weekly Check-In" tab and the
-- Blended Learning "📄 Learning Activity Sheets" / "📝 Reflections" sub-tabs
-- will start working immediately.
-- ============================================================================
