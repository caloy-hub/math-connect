// ============================================================================
// MathConnect — Pet Event Reactions (MATHCONNECT 2.0 Phase 2)
//
// triggerPetEvent(eventType, payload) is the single entry point every
// learning activity calls when something happens the pet should react to.
// Each call does two independent things:
//
//   1. Nudges the follow-companion's state machine (petAnimation.js /
//      petState.js) into a matching animation state. Harmless no-op if the
//      companion isn't mounted (non-math section, no pet yet) or is
//      currently hidden for this tab — petCompanion.fsm.transition() is
//      always safe to call.
//   2. Pops a short reaction toast (pet icon + one contextual line) that
//      floats ABOVE gameplay's full-screen overlay — .drill-overlay is
//      z-index:500 (see style.css), this toast is 600 — so it's visible
//      mid-drill/quest/practice/daily-challenge, not just while browsing
//      the dashboard tabs where the companion widget itself lives.
//
// This is deliberately a SEPARATE, new mechanism from showPetCheerBubble()
// in petEngine.js, which is untouched by this phase: that one stays exactly
// what it was — a throttled, once-per-activity "good luck" shown when an
// activity STARTS. This file adds the NEW per-event reactions (correct /
// wrong / streak / level-up / rank-up / quest-complete / daily-challenge)
// that fire during play, without touching or duplicating that existing code.
//
// Deliberately NOT wired up yet:
//   - BATTLE_* events — Boss Battles gets its own dedicated arena UI first (Phase 5)
//   - Pet personality flavoring — not yet in the phase roadmap
// ============================================================================

const PET_EVENT_CONFIG = {
  OWNER_STUDY: {
    state: PET_STATE.OWNER_STUDY,
    lines: ["I'm studying with you! 📚", "Let's learn together!", "I'm right here with you."],
  },
  OWNER_SHOP: {
    state: PET_STATE.OWNER_SHOP,
    lines: ["Ooh, what's in the shop? 👀", "Shopping time!", "Should we pick something for me? 🐾"],
  },
  OWNER_CARE: {
    state: PET_STATE.OWNER_CARE,
    lines: ["Aww, thank you! 💚", "I feel loved!", "Best owner ever! 🥰"],
  },
  OWNER_FEED: {
    state: PET_STATE.OWNER_FEED,
    lines: ["Yum! Thank you! 🍪", "My favorite! 😋", "That was delicious!"],
  },
  OWNER_FOCUS: {
    state: PET_STATE.OWNER_FOCUS,
    lines: ["I'll stay focused with you.", "You've got this. 💚", "Quiet study buddy mode. 🤫"],
  },
  OWNER_ATTENDANCE: {
    state: PET_STATE.HAPPY,
    lines: ["You showed up! 🌱", "Another day together!", "I'm proud of you!"],
  },
  OWNER_RATING: {
    state: PET_STATE.HAPPY,
    lines: ["Thanks for reflecting! 💚", "Thinking about your learning — nice!", "Your reflection helps you grow! 🌱"],
  },
  OWNER_BATTLE: {
    state: PET_STATE.EXCITED,
    lines: ["Let's battle! ⚔️", "I'm cheering from the sidelines!", "Focus — you've got this!"],
  },
  QUESTION_CORRECT: {
    state: PET_STATE.EXCITED,
    lines: ["Nice one!", "Yes! 🎯", "You got it!", "Nailed it!", "Correct!"],
  },
  QUESTION_WRONG: {
    // "Mistakes are part of leveling up" — gentle, never shaming.
    state: PET_STATE.DISAPPOINTED,
    lines: ["So close!", "Almost — you'll get the next one.", "No worries, keep going!", "That's okay — next one!"],
  },
  STREAK_INCREASE: {
    state: PET_STATE.CHEER,
    lines: (p) => [
      p && p.streak ? `You're on fire! 🔥 x${p.streak}` : "You're on fire! 🔥",
      "Streak going strong! 🔥",
      "Keep that streak alive!",
    ],
  },
  LEVEL_UP: {
    state: PET_STATE.CELEBRATE,
    lines: ["Level up! 🎉", "Look at you go!", "New level unlocked!"],
  },
  RANK_UP: {
    state: PET_STATE.VICTORY,
    lines: ["Rank up! 🏅", "You're climbing the ranks!"],
  },
  QUEST_COMPLETE: {
    state: PET_STATE.CELEBRATE,
    lines: ["Quest cleared! 🗺️", "Level complete!"],
  },
  QUEST_CHAPTER_COMPLETE: {
    state: PET_STATE.VICTORY,
    lines: ["Chapter complete! 🏰", "You cleared the whole chapter!"],
  },
  DAILY_CHALLENGE_COMPLETE: {
    state: PET_STATE.HAPPY,
    lines: ["Daily Challenge done! 💚", "See you tomorrow for the next one!"],
  },
  GOLDEN_CORRECT: {
    // Golden Question critical hit (drills.js) — a bigger cheer than a
    // normal correct answer, since this one's worth 3x points.
    state: PET_STATE.CELEBRATE,
    lines: ["✨ GOLDEN! Triple points!", "Whoa, golden question! 🌟", "That one really shined! ✨"],
  },
};

let _petReactionToastEl = null;
let _petReactionHideTimer = null;

/** Safe to call from anywhere, any time — no-ops quietly (never throws) if
 *  there's no pet yet, the event type isn't recognized, or petState.js /
 *  petAnimation.js haven't loaded for some reason. */
function triggerPetEvent(eventType, payload) {
  const config = PET_EVENT_CONFIG[eventType];
  if (!config) return;
  if (!pstate || !pstate.loaded || !activePet()) return;

  if (typeof petCompanion !== "undefined" && petCompanion.fsm) {
    petCompanion.fsm.transition(config.state);
  }
  if (!payload || !payload.silent) showPetReactionToast(config, payload || {});
}

function showPetReactionToast(config, payload) {
  const pet = activePet();
  if (!pet) return;
  const stage = petGrowthStage(pet.growth_points);
  const form = petDisplayForm(pet.pet_type_key, stage.label);
  const pool = typeof config.lines === "function" ? config.lines(payload) : config.lines;
  const line = pool[Math.floor(Math.random() * pool.length)];

  clearTimeout(_petReactionHideTimer);
  if (!_petReactionToastEl) {
    _petReactionToastEl = document.createElement("div");
    _petReactionToastEl.className = "pet-reaction-toast";
    document.body.appendChild(_petReactionToastEl);
  }
  _petReactionToastEl.classList.remove("pet-reaction-out");
  _petReactionToastEl.innerHTML = `
    <div class="pet-reaction-icon">${petVisualHtml(form, PET_STATE_CLASS[config.state], null, 1.6)}</div>
    <div class="pet-reaction-text">${escapeHtml(line)}</div>`;
  // Force a reflow so the "in" transition replays even if the toast was
  // already visible from a moment ago (e.g. two correct answers back to back).
  void _petReactionToastEl.offsetWidth;
  _petReactionToastEl.classList.add("pet-reaction-in");

  _petReactionHideTimer = setTimeout(() => {
    if (_petReactionToastEl) _petReactionToastEl.classList.add("pet-reaction-out");
  }, 1300);
}
