-- ============================================================================
-- MathConnect — Migration 4: Real student accounts (password privacy)
-- ----------------------------------------------------------------------------
-- Gives every student an actual Supabase Auth account behind the scenes, so
-- the DATABASE itself enforces that a student can only ever read their own
-- grades/attendance/submissions — not just the app's screens hiding it.
--
-- Students never see or need a real email. Internally, each gets a
-- generated address like "st-<their row id>-v1@mathconnect.invalid" tied to
-- a password they choose the first time they log in. Class code + name still
-- finds their account; the password is the new part that proves it's them.
--
-- ⚠️ REQUIRED SETUP — this will NOT work until you do this:
-- Go to Supabase → Authentication → Providers → Email → turn "Confirm email"
-- OFF. Students' generated addresses can never receive a real confirmation
-- email, so if this stays on, students will be able to "create" a password
-- but will never be able to log in afterward.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- Then turn off "Confirm email" as described above.
-- ============================================================================

-- ---------- New columns on students: link to their Auth account ----------
alter table students add column if not exists auth_user_id uuid references auth.users(id) on delete set null;
alter table students add column if not exists auth_email_version integer not null default 1;
-- auth_email_version lets a teacher "reset" a student's password by bumping
-- this number — it forces a fresh internal email + fresh registration
-- without colliding with their old (now-abandoned) account.

-- ---------- STUDENTS: allow a student to read/claim their own row ----------
drop policy if exists "public read students" on students;
create policy "public read students" on students for select using (
  auth.role() = 'anon'
  or exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or auth_user_id = auth.uid()
);

-- Lets a freshly-registered student claim their row — but ONLY if the email
-- Supabase just authenticated them with exactly matches the generated
-- pattern for THIS row (so a student can't claim someone else's row).
drop policy if exists "student claims own row" on students;
create policy "student claims own row" on students for update using (
  auth_user_id is null
  and auth.jwt() ->> 'email' = 'st-' || replace(id::text, '-', '') || '-' || auth_email_version::text || '@mathconnect.invalid'
) with check (
  auth_user_id = auth.uid()
);

-- ---------- SECTIONS: a registered student can read their own section ----------
drop policy if exists "public read sections" on sections;
create policy "public read sections" on sections for select using (
  auth.role() = 'anon'
  or teacher_id = auth.uid()
  or exists (select 1 from students st where st.section_id = sections.id and st.auth_user_id = auth.uid())
);

-- ---------- TERMS, ASSESSMENTS, LESSONS, TASKS, MODULES, SCHEDULE, ANNOUNCEMENTS ----------
-- Section-wide classroom content: visible to the owning teacher, or to any
-- REGISTERED student in that section (no more anonymous/public reading —
-- these require a password now, closing the earlier privacy gap).
drop policy if exists "public read terms" on terms;
create policy "public read terms" on terms for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = terms.section_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read assessments" on assessments;
create policy "public read assessments" on assessments for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = assessments.section_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read lessons" on lessons;
create policy "public read lessons" on lessons for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = lessons.section_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read tasks" on tasks;
create policy "public read tasks" on tasks for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = tasks.section_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read modules" on modules;
create policy "public read modules" on modules for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = modules.section_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read schedule" on schedule;
create policy "public read schedule" on schedule for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = schedule.section_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read announcements" on announcements;
create policy "public read announcements" on announcements for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.section_id = announcements.section_id and st.auth_user_id = auth.uid())
);

-- ---------- SCORES, ATTENDANCE, SUBMISSIONS ----------
-- Per-student records: teacher sees everyone in their section; a student can
-- ONLY see their own — not classmates'.
drop policy if exists "public read scores" on scores;
create policy "public read scores" on scores for select using (
  exists (select 1 from assessments a join sections s on s.id = a.section_id where a.id = assessment_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.id = scores.student_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read attendance" on attendance;
create policy "public read attendance" on attendance for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.id = attendance.student_id and st.auth_user_id = auth.uid())
);

drop policy if exists "public read submissions" on submissions;
create policy "public read submissions" on submissions for select using (
  exists (select 1 from tasks t join sections s on s.id = t.section_id where t.id = task_id and s.teacher_id = auth.uid())
  or exists (select 1 from students st where st.id = submissions.student_id and st.auth_user_id = auth.uid())
);

-- Submissions insert/update: only the student themselves (now that they're
-- authenticated) or the teacher may write a submission — previously anyone
-- with the anon key could write to any submission row.
drop policy if exists "anyone insert submissions" on submissions;
create policy "student or teacher insert submissions" on submissions for insert with check (
  exists (select 1 from students st where st.id = student_id and st.auth_user_id = auth.uid())
  or exists (select 1 from tasks t join sections s on s.id = t.section_id where t.id = task_id and s.teacher_id = auth.uid())
);
drop policy if exists "anyone update submissions" on submissions;
create policy "student or teacher update submissions" on submissions for update using (
  exists (select 1 from students st where st.id = student_id and st.auth_user_id = auth.uid())
  or exists (select 1 from tasks t join sections s on s.id = t.section_id where t.id = task_id and s.teacher_id = auth.uid())
);

-- ---------- OTHER CONCERNS: teacher-only, intentionally not student-visible ----------
-- These are private anecdotal notes (behavior/health/family concerns) — by
-- design, students should NOT be able to read notes about themselves here,
-- the same way a private teacher's remark isn't shown to the student. Only
-- removing the old public-read; the existing teacher-only write policies are
-- untouched.
drop policy if exists "public read other_concerns" on other_concerns;
create policy "public read other_concerns" on other_concerns for select using (
  exists (select 1 from sections s where s.id = section_id and s.teacher_id = auth.uid())
);

-- Done. Next steps:
--  1. Turn OFF "Confirm email" in Supabase → Authentication → Providers → Email (required!)
--  2. Redeploy the updated app files
--  3. Your existing students will be asked to create a password the next
--     time they log in — their old class-code + name login still finds
--     their account, they just now also set a password on first use.
