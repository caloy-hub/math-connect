// ============================================================================
// MathConnect — Quest Mode UI (the "🗺️ Quest Mode" student tab)
// Map of 12 chapters (locked/unlocked) -> chapter view (10 level nodes with
// story blurbs) -> gameplay (reuses the Drill Arena's question generators
// and CSS via drills.js) -> results (stars, unlock banners).
// Depends on: questEngine.js, drills.js (generateDrillQuestion,
// checkDrillAnswer, fmtDrillAnswer), rankEngine.js (awardMasteryStars,
// renderRankBadge), supabase-client.js (escapeHtml, toast), student.js (sstate).
// ============================================================================

var quiState = { view: "map", chapterKey: null }; // "map" | "chapter"

// ============================================================================
// MAP VIEW (the tab's main render)
// ============================================================================
async function renderQuestHub() {
  const el = document.getElementById("tab-quest");
  el.innerHTML = `<div class="empty">Loading your quest map…</div>`;
  if (!qstate.loaded) await loadQuestProgress();
  quiState.view = "map";
  renderQuestMapView();
}

function renderQuestMapView() {
  const el = document.getElementById("tab-quest");
  const p = qstate.progress;
  const totalStars = questTotalStars(p.level_stars);
  const maxStars = QUEST_CHAPTERS.length * QUEST_MAX_LEVEL * 3;
  const unlockedCount = questChaptersUnlockedCount(p.level_stars);
  const currentIdx = questCurrentChapterIndex(p.level_stars);

  const pts = questPathLayout(QUEST_CHAPTERS.length);
  const totalH = pts[pts.length - 1].y + 90;
  const trailBg = questPathSmooth(pts);
  const trailDone = questPathSmooth(pts.slice(0, currentIdx + 1));
  const cur = pts[currentIdx];

  const nodesHtml = QUEST_CHAPTERS.map((c, i) => {
    const unlocked = questChapterUnlocked(p.level_stars, i);
    const complete = questChapterComplete(p.level_stars, c.key);
    const stars = questChapterStars(p.level_stars, c.key);
    const isCurrent = i === currentIdx;
    const pt = pts[i];
    return `
    <div class="quest-node ${unlocked ? "unlocked" : "locked"} ${complete ? "complete" : ""} ${isCurrent ? "current" : ""}"
         style="left:${pt.x}%;top:${pt.y}px;--chapter-color:${c.color};" ${unlocked ? `onclick="openQuestChapter('${c.key}')"` : ""}
         title="${escapeHtml(c.subject)}${unlocked ? "" : " — locked"}">
      <div class="quest-node-badge">${unlocked ? c.icon : "🔒"}${complete ? `<div class="quest-node-check">✓</div>` : ""}</div>
      <div class="quest-node-label">${escapeHtml(c.subject)}</div>
      ${unlocked ? `<div class="quest-node-stars">⭐ ${stars}/${QUEST_MAX_LEVEL * 3}</div>` : `<div class="quest-node-sub">Locked</div>`}
    </div>`;
  }).join("");

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <div>
          <div class="muted">🗺️ Quest Mode — Legends of Belcar Valley</div>
          <h2 style="margin:4px 0;">${unlockedCount}/${QUEST_CHAPTERS.length} chapters unlocked</h2>
        </div>
        <div style="text-align:right;">
          <div class="muted">Quest Stars</div>
          <h3 style="margin:2px 0;color:var(--gold);">⭐ ${totalStars} / ${maxStars}</h3>
          <div style="margin-top:6px;">${typeof certShelfButtonHtml === "function" ? certShelfButtonHtml("quest") : ""}</div>
        </div>
      </div>
      <div class="muted" style="margin-top:10px;">
        Every chapter is a subject you take in school — each with 10 story-driven levels. Clear a level (7/10 or better) to
        unlock the next one; clear all 10 to unlock the next chapter. Earn up to 3 stars per level for how well you do.
        Follow the trail below to see exactly where you are on the map.
      </div>
    </div>
    <div class="quest-path-scroll" id="questPathScroll">
      <div class="quest-path-wrap" style="height:${totalH}px;">
        <svg class="quest-path-svg" viewBox="0 0 100 ${totalH}" preserveAspectRatio="none">
          <path class="quest-path-trail-bg" d="${trailBg}"></path>
          <path class="quest-path-trail-done" d="${trailDone}" style="stroke:var(--forest);"></path>
        </svg>
        ${nodesHtml}
        <div class="quest-player-marker" style="left:${cur.x}%;top:${cur.y}px;">
          <div class="quest-player-flag">You are here</div>
          <div class="quest-player-pin">🚩</div>
        </div>
      </div>
    </div>`;
  questScrollToCurrent(cur.y);
}

/** Scrolls the path container so the player's current position lands roughly mid-view. */
function questScrollToCurrent(y) {
  requestAnimationFrame(() => {
    const scroller = document.getElementById("questPathScroll");
    if (scroller) scroller.scrollTop = Math.max(0, y - scroller.clientHeight / 2);
  });
}

// ============================================================================
// CHAPTER VIEW (10 level nodes + story arc blurb)
// ============================================================================
function openQuestChapter(chapterKey) {
  quiState.view = "chapter";
  quiState.chapterKey = chapterKey;
  renderQuestChapterView();
}

function renderQuestChapterView() {
  const el = document.getElementById("tab-quest");
  const p = qstate.progress;
  const chapter = QUEST_CHAPTERS.find((c) => c.key === quiState.chapterKey);
  const chapterIdx = QUEST_CHAPTERS.indexOf(chapter);
  const stars = p.level_stars[chapter.key] || new Array(QUEST_MAX_LEVEL).fill(0);
  const currentIdx = questCurrentLevelIndex(p.level_stars, chapter.key);

  const pts = questPathLayout(chapter.levels.length, { amp: 25, rowGap: 116 });
  const totalH = pts[pts.length - 1].y + 90;
  const trailBg = questPathSmooth(pts);
  const trailDone = questPathSmooth(pts.slice(0, currentIdx + 1));
  const cur = pts[currentIdx];

  const nodesHtml = chapter.levels.map((lvl, i) => {
    const unlocked = questLevelUnlocked(p.level_stars, chapter.key, i);
    const starCount = stars[i] || 0;
    const isCurrent = i === currentIdx;
    const pt = pts[i];
    return `
    <div class="quest-node ${unlocked ? "unlocked" : "locked"} ${starCount > 0 ? "complete" : ""} ${isCurrent ? "current" : ""}"
         style="left:${pt.x}%;top:${pt.y}px;--chapter-color:${chapter.color};" ${unlocked ? `onclick="showQuestLevelBlurb('${chapter.key}', ${i})"` : ""}
         title="Level ${i + 1}: ${escapeHtml(lvl.title)}${unlocked ? "" : " — locked"}">
      <div class="quest-node-badge">${unlocked ? i + 1 : "🔒"}</div>
      <div class="quest-node-label">${escapeHtml(lvl.title)}</div>
      ${unlocked ? `<div class="quest-node-stars">${"⭐".repeat(starCount)}${"☆".repeat(3 - starCount)}</div>` : `<div class="quest-node-sub">Locked</div>`}
    </div>`;
  }).join("");

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;border-left:5px solid ${chapter.color};">
      <button class="btn-outline" style="margin-bottom:10px;" onclick="renderQuestMapView()">← Back to Map</button>
      <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap;">
        <div style="font-size:2.6rem;">${chapter.icon}</div>
        <div style="flex:1;min-width:220px;">
          <div class="muted">Chapter ${chapterIdx + 1} · ${escapeHtml(chapter.subject)}</div>
          <h2 style="margin:2px 0;">${escapeHtml(chapter.title)}</h2>
          <p class="muted">${escapeHtml(chapter.arcBlurb)}</p>
        </div>
      </div>
    </div>
    <div class="quest-path-scroll" id="questPathScroll">
      <div class="quest-path-wrap" style="height:${totalH}px;">
        <svg class="quest-path-svg" viewBox="0 0 100 ${totalH}" preserveAspectRatio="none">
          <path class="quest-path-trail-bg" d="${trailBg}"></path>
          <path class="quest-path-trail-done" d="${trailDone}" style="stroke:${chapter.color};"></path>
        </svg>
        ${nodesHtml}
        <div class="quest-player-marker" style="left:${cur.x}%;top:${cur.y}px;">
          <div class="quest-player-flag" style="background:${chapter.color};">You are here</div>
          <div class="quest-player-pin">🚩</div>
        </div>
      </div>
    </div>`;
  questScrollToCurrent(cur.y);
}

// ============================================================================
// LEVEL STORY BLURB MODAL -> START RUN
// ============================================================================
function showQuestLevelBlurb(chapterKey, levelIdx) {
  const chapter = QUEST_CHAPTERS.find((c) => c.key === chapterKey);
  const lvl = chapter.levels[levelIdx];
  const stars = (qstate.progress.level_stars[chapterKey] || [])[levelIdx] || 0;
  showQuestModal(`
    <div class="drill-question-card" style="max-width:520px;">
      <div style="font-size:2.2rem;">${chapter.icon}</div>
      <div class="muted">${escapeHtml(chapter.subject)} · Level ${levelIdx + 1}</div>
      <h2 style="margin:6px 0;">${escapeHtml(lvl.title)}</h2>
      <p style="font-style:italic;">"${escapeHtml(lvl.blurb)}"</p>
      ${stars > 0 ? `<p class="muted">Best so far: ${"⭐".repeat(stars)}${"☆".repeat(3 - stars)}</p>` : ""}
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
        <button class="btn-primary" onclick="startQuestLevel('${chapterKey}', ${levelIdx})">▶ Start Level</button>
        <button class="btn-outline" onclick="closeQuestModal(); renderQuestChapterView();">Cancel</button>
      </div>
    </div>`);
}

function showQuestModal(innerHtml) {
  document.getElementById("modalRoot").innerHTML = `<div class="drill-overlay" style="align-items:center;justify-content:center;">${innerHtml}</div>`;
}
function closeQuestModal() { document.getElementById("modalRoot").innerHTML = ""; }

// ============================================================================
// GAMEPLAY — a 10-question run themed by chapter, questions/scoring reused
// straight from the Drill Arena engine in drills.js.
// ============================================================================
function startQuestLevel(chapterKey, levelIdx) {
  if (sstate.readOnly) { toast("⏸️ Your account is in read-only mode — Quest Mode is paused. See your teacher."); return; }
  const chapter = QUEST_CHAPTERS.find((c) => c.key === chapterKey);
  const levelNum = levelIdx + 1;
  const sequence = [];
  for (let i = 1; i <= QUEST_RUN_LENGTH; i++) {
    const topic = QUEST_TOPIC_CYCLE[(i - 1) % QUEST_TOPIC_CYCLE.length];
    sequence.push({ q: generateDrillQuestion(topic, levelNum) });
  }
  qgame = {
    chapter, levelIdx, levelNum, sequence, idx: 0,
    correct: 0, wrong: 0, streak: 0, bestStreakSession: 0, score: 0,
    timerId: null, timeLeft: 0, timeTotal: 0, answered: false,
  };
  if (typeof showPetCheerBubble === "function") showPetCheerBubble();
  renderQuestGameScreen();
}

// Extended 40% (was Math.max(10, 22 - level)) — same reasoning as drillTimeForLevel() in drills.js.
function questTimeForLevel(level) { return Math.round(Math.max(10, 22 - level) * 1.4); }

function renderQuestGameScreen() {
  const root = document.getElementById("modalRoot");
  const chapter = qgame.chapter;
  const answeredCount = qgame.correct + qgame.wrong;
  const dots = qgame.sequence.map((s, i) => {
    let cls = "drill-dot";
    if (i < qgame.idx) cls += s._result === "correct" ? " done-correct" : " done-wrong";
    if (i === qgame.idx) cls += " current";
    return `<div class="${cls}"></div>`;
  }).join("");

  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-top-row">
        <div>${chapter.icon} <strong>${escapeHtml(chapter.subject)}</strong> · Level ${qgame.levelNum} — ${escapeHtml(chapter.levels[qgame.levelIdx].title)}</div>
        <div>Correct: <strong style="color:var(--gold-light);">${qgame.correct}/${answeredCount}</strong> &nbsp;|&nbsp; Streak: 🔥 ${qgame.streak}</div>
        <button class="btn-outline" style="border-color:var(--gold-light);color:var(--gold-light);" onclick="quitQuestLevel()">✕ Quit</button>
      </div>
      <div class="drill-progress-dots">${dots}</div>
      <div id="questStage"></div>
    </div>`;
  renderQuestQuestionStage(qgame.sequence[qgame.idx].q);
}

function renderQuestQuestionStage(q) {
  qgame.answered = false;
  qgame.timeTotal = questTimeForLevel(qgame.levelNum);
  qgame.timeLeft = qgame.timeTotal;
  const stage = document.getElementById("questStage");
  stage.innerHTML = `
    <div class="drill-timerbar-track"><div id="questTimerFill" class="drill-timerbar-fill" style="width:100%;"></div></div>
    <div class="drill-question-card">
      <div class="drill-question-text">${escapeHtml(q.prompt)}</div>
      ${q.hint ? `<p class="muted" style="margin-top:8px;font-size:.78rem;">${escapeHtml(q.hint)}</p>` : ""}
      <input id="questAnswerInput" class="drill-answer-input" placeholder="${q.type === "fraction" ? "e.g. 3/4" : "your answer"}" autocomplete="off" />
      <div style="margin-top:16px;">
        <button class="btn-primary" onclick="submitQuestAnswer()">Submit</button>
      </div>
      <div id="questFeedback" class="drill-feedback"></div>
    </div>`;
  const input = document.getElementById("questAnswerInput");
  if (input) { input.focus(); input.addEventListener("keydown", (e) => { if (e.key === "Enter") submitQuestAnswer(); }); }
  attachNumericKeypad("questAnswerInput", { type: q.type });

  clearInterval(qgame.timerId);
  qgame.timerId = setInterval(() => {
    qgame.timeLeft -= 0.1;
    const pct = Math.max(0, (qgame.timeLeft / qgame.timeTotal) * 100);
    const fill = document.getElementById("questTimerFill");
    if (fill) {
      fill.style.width = pct + "%";
      fill.style.background = pct < 25 ? "var(--clay)" : pct < 55 ? "#F4C95D" : "var(--gold)";
    }
    if (qgame.timeLeft <= 0) { clearInterval(qgame.timerId); if (!qgame.answered) submitQuestAnswer(true); }
  }, 100);
}

function submitQuestAnswer(timedOut) {
  if (qgame.answered) return;
  qgame.answered = true;
  clearInterval(qgame.timerId);
  const q = qgame.sequence[qgame.idx].q;
  const input = document.getElementById("questAnswerInput");
  const raw = timedOut ? "" : (input ? input.value : "");
  const isCorrect = !timedOut && checkDrillAnswer(q, raw);
  const feedback = document.getElementById("questFeedback");

  if (isCorrect) {
    qgame.correct++;
    qgame.streak++;
    qgame.bestStreakSession = Math.max(qgame.bestStreakSession, qgame.streak);
    qgame.score += qgame.levelNum * 10;
    qgame.sequence[qgame.idx]._result = "correct";
    feedback.className = "drill-feedback correct";
    feedback.innerHTML = "✅ Correct!";
    if (typeof triggerPetEvent === "function") {
      triggerPetEvent("QUESTION_CORRECT");
      if (qgame.streak > 0 && qgame.streak % 3 === 0) triggerPetEvent("STREAK_INCREASE", { streak: qgame.streak });
    }
  } else {
    qgame.wrong++;
    qgame.streak = 0;
    qgame.sequence[qgame.idx]._result = "wrong";
    feedback.className = "drill-feedback wrong";
    feedback.innerHTML = `${timedOut ? "⏰ Time's up!" : "❌ Not quite."} Correct answer: <strong>${fmtDrillAnswer(q)}</strong>`;
    if (typeof triggerPetEvent === "function") triggerPetEvent("QUESTION_WRONG");
  }
  if (input) input.disabled = true;
  setTimeout(() => advanceQuestSequence(), 1400);
}

function advanceQuestSequence() {
  qgame.idx++;
  if (qgame.idx >= qgame.sequence.length) finishQuestLevel();
  else renderQuestGameScreen();
}

function quitQuestLevel() {
  clearInterval(qgame.timerId);
  document.getElementById("modalRoot").innerHTML = "";
  qgame = null;
  renderQuestChapterView();
}

async function finishQuestLevel() {
  clearInterval(qgame.timerId);
  const p = qstate.progress;
  const chapterKey = qgame.chapter.key;
  const starsEarned = questStarsForAccuracy(qgame.correct);
  const passed = starsEarned > 0;
  const prevBest = (p.level_stars[chapterKey] || [])[qgame.levelIdx] || 0;
  const improved = starsEarned > prevBest;

  if (improved) {
    const arr = (p.level_stars[chapterKey] || new Array(QUEST_MAX_LEVEL).fill(0)).slice();
    arr[qgame.levelIdx] = starsEarned;
    p.level_stars = { ...p.level_stars, [chapterKey]: arr };
  }
  p.runs_played = (p.runs_played || 0) + 1;
  const chapterCompleteNow = questChapterComplete(p.level_stars, chapterKey);
  const nextChapter = QUEST_CHAPTERS[QUEST_CHAPTERS.indexOf(qgame.chapter) + 1];
  // Only worth celebrating the unlock the moment it happens — i.e. this
  // level had no stars before this run, and completing it just finished
  // the whole chapter. Replaying an already-passed level shouldn't re-show it.
  const chapterUnlockedJustNow = chapterCompleteNow && prevBest === 0;

  await saveQuestProgress();
  await logQuestAttempt(chapterKey, qgame.levelNum, qgame.correct, starsEarned, qgame.score);
  if (typeof recordDailyActivity === "function") { await recordDailyActivity(); await renderTopbarStreakBadge(); }

  // Small MathLegends rank nudge, same currency Drills/Daily/Battles feed —
  // keeps Quest Mode plugged into the rank students already track.
  let rankResult = null;
  if (passed && typeof awardMasteryStars === "function") {
    rankResult = await awardMasteryStars(sstate.student.id, 1);
  }

  // Green Points for the Math Pet — mirrors Math Drills: 1 Green Point per
  // correct answer, awarded every run (not gated on "improved" the way
  // level_stars is, same as Drills paying out per correct answer on every
  // attempt). Level Cleared adds a flat +5 on top. Chapter Complete adds a
  // bigger +50, but only once, the moment the chapter is first fully cleared
  // (chapterUnlockedJustNow) — replaying an already-completed chapter's
  // levels doesn't re-pay it. If this run also promotes the student's
  // MathLegends rank ("reaches the math level"), the whole run's Green
  // Points are doubled. Uses boosted=false since these are Quest's own
  // explicit values, not subject to the general GREEN_POINTS_BOOST.
  let questGreenPointsEarned = 0;
  if (typeof awardGreenPoints === "function") {
    questGreenPointsEarned = qgame.correct; // 1 Green Point per correct answer, same as Drills
    if (passed) questGreenPointsEarned += 5; // Level Cleared bonus
    if (chapterUnlockedJustNow) questGreenPointsEarned += 50; // Chapter Complete bonus (one-time)
    if (rankResult && rankResult.promoted) questGreenPointsEarned *= 2; // Reached a new math level — double it
    if (questGreenPointsEarned > 0) await awardGreenPoints(questGreenPointsEarned, false);
  }
  if (typeof markDailyActivity === "function") await markDailyActivity("quest");

  if (typeof triggerPetEvent === "function") {
    if (chapterUnlockedJustNow) triggerPetEvent("QUEST_CHAPTER_COMPLETE");
    else if (passed) triggerPetEvent("QUEST_COMPLETE");
    if (rankResult && rankResult.promoted) triggerPetEvent("RANK_UP");
  }

  // v58 — certificates are per STATION (chapter), not per level: earned once every level of the chapter is
  // cleared with >= 80% overall accuracy (best run per level). Only a cleared level can change that.
  let certRec = null, certSum = null;
  if (passed && typeof certCheckQuestStation === "function") {
    const chk = await certCheckQuestStation(qgame, p.level_stars);
    certRec = chk.rec; certSum = chk.sum;
  }

  const root = document.getElementById("modalRoot");
  root.innerHTML = `
    <div class="drill-overlay">
      <div class="drill-question-card" style="max-width:520px;">
        ${chapterUnlockedJustNow ? `<div class="drill-levelup-banner">🎉 Chapter Complete! ${nextChapter ? `${nextChapter.icon} ${escapeHtml(nextChapter.subject)} is now unlocked!` : "You've cleared every chapter — Quest Mode complete!"}</div>` : ""}
        ${rankResult && rankResult.promoted ? `<div class="drill-levelup-banner">🏅 Rank Up! You're now ${renderRankBadge(rankResult.tierObj)}!</div>` : ""}
        <h2>${qgame.chapter.icon} ${passed ? "Level Cleared!" : "Not quite — try again!"}</h2>
        <div class="drill-stat-row">
          <div class="drill-stat"><div class="num">${qgame.correct}/${QUEST_RUN_LENGTH}</div><div class="muted">Correct</div></div>
          <div class="drill-stat"><div class="num" style="color:var(--gold);">${"⭐".repeat(starsEarned)}${"☆".repeat(3 - starsEarned)}</div><div class="muted">Stars earned</div></div>
          <div class="drill-stat"><div class="num">🔥 ${qgame.bestStreakSession}</div><div class="muted">Best Streak</div></div>
        </div>
        <p class="muted">${passed ? "Score 7/10 or better clears a level — nice work!" : "You need 7/10 correct to clear this level. Give it another shot!"}</p>
        ${questGreenPointsEarned ? `<div class="muted" style="margin-top:4px;">💚 +${questGreenPointsEarned} Green Points${chapterUnlockedJustNow ? " (includes chapter-complete bonus!)" : ""} for your Math Pet</div>` : ""}
        ${certEarnedBannerHtml(certRec)}
        ${certRec ? "" : certStationProgressHtml(certSum, qgame.chapter.title)}
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
          <button class="btn-primary" onclick="startQuestLevel('${chapterKey}', ${qgame.levelIdx})">▶ Play Again</button>
          <button class="btn-outline" onclick="closeQuestGameToChapter()">Back to Chapter Map</button>
        </div>
      </div>
    </div>`;
  qgame = null;
}

function closeQuestGameToChapter() {
  document.getElementById("modalRoot").innerHTML = "";
  renderQuestChapterView();
}
