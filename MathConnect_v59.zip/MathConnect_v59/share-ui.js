// ============================================================================
// SHARE — student-to-student gifting of Coins, Green Points, and (spare)
// Adoption Chances. Depends on: supabase-client.js (supabase, toast,
// escapeHtml), student.js (sstate), streakEngine.js (estate, loadEngagement),
// petEngine.js (pstate, loadPets). All the actual balance math happens
// server-side in the share_resource RPC (migration-37) — this file just
// gathers who's shareable, renders the form, and reflects the result.
// ============================================================================

var sharestate = { loaded: false, classmates: [], history: [] };

async function loadShareClassmates() {
  const { data } = await supabase.from("students").select("id, full_name")
    .eq("section_id", sstate.section.id).neq("id", sstate.student.id).order("full_name");
  sharestate.classmates = data || [];
}

async function loadShareHistory() {
  const { data } = await supabase.from("resource_shares")
    .select("*, sender:sender_student_id(full_name), receiver:receiver_student_id(full_name)")
    .or(`sender_student_id.eq.${sstate.student.id},receiver_student_id.eq.${sstate.student.id}`)
    .order("created_at", { ascending: false }).limit(30);
  sharestate.history = data || [];
}

// adoption_chance is retired (migration-38) — kept in the map only so any
// pre-existing resource_shares history rows still render a readable label.
const SHARE_RESOURCE_META = {
  coins: { icon: "🪙", label: "Coins" },
  green_points: { icon: "💚", label: "Green Points" },
  adoption_chance: { icon: "🐣", label: "Adoption Chance (retired)" },
};

function shareFmtDateTime(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

async function renderShareTab() {
  const el = document.getElementById("tab-share");
  if (!el) return;
  el.innerHTML = `<div class="card"><p class="muted">Loading…</p></div>`;

  if (!estate.loaded) await loadEngagement();
  if (!pstate.loaded && typeof loadPets === "function") await loadPets();
  await Promise.all([loadShareClassmates(), loadShareHistory()]);
  sharestate.loaded = true;

  const coins = (estate.data && estate.data.coins) || 0;
  const gp = (estate.data && estate.data.green_points) || 0;

  el.innerHTML = `
    <div class="dash-grid">
      <div class="card">
        <h3 style="margin:0 0 6px;">🤝 Share With a Classmate</h3>
        <p class="muted" style="font-size:.85rem;">Send Coins or Green Points to someone in your section.</p>

        <div style="display:flex;gap:16px;flex-wrap:wrap;margin:12px 0;">
          <div class="muted">🪙 Coins: <strong style="color:var(--gold-dark,#B8790E);">${coins}</strong></div>
          <div class="muted">💚 Green Points: <strong style="color:var(--forest-dark);">${gp}</strong></div>
        </div>

        ${sharestate.classmates.length === 0 ? `<p class="muted">No classmates found in your section yet.</p>` : `
        <div style="display:grid;gap:10px;max-width:420px;">
          <label class="muted" style="font-size:.8rem;">Send to
            <select id="shareRecipient" style="width:100%;padding:8px;border:1px solid var(--paper-line);border-radius:8px;margin-top:4px;">
              ${sharestate.classmates.map((c) => `<option value="${c.id}">${escapeHtml(c.full_name)}</option>`).join("")}
            </select>
          </label>
          <label class="muted" style="font-size:.8rem;">What to share
            <select id="shareResourceType" onchange="renderShareAmountField()" style="width:100%;padding:8px;border:1px solid var(--paper-line);border-radius:8px;margin-top:4px;">
              <option value="coins" ${coins < 1 ? "disabled" : ""}>🪙 Coins</option>
              <option value="green_points" ${gp < 1 ? "disabled" : ""}>💚 Green Points</option>
            </select>
          </label>
          <div id="shareAmountFieldWrap"></div>
          <button class="btn-primary" onclick="handleSendShare()">🤝 Send</button>
        </div>`}
      </div>

      <div class="card">
        <h3 style="margin:0 0 6px;">📜 Share History</h3>
        <p class="muted" style="font-size:.85rem;">Everything you've sent or received, most recent first.</p>
        ${sharestate.history.length === 0 ? `<p class="muted">No shares yet.</p>` : `
        <div style="max-height:420px;overflow-y:auto;">
          ${sharestate.history.map((h) => {
            const meta = SHARE_RESOURCE_META[h.resource_type] || { icon: "🎁", label: h.resource_type };
            const iSent = h.sender_student_id === sstate.student.id;
            return `
            <div class="card" style="margin-top:10px;padding:10px 12px;border-left:4px solid ${iSent ? "var(--clay)" : "var(--gold)"};">
              <div>${meta.icon} ${iSent
                ? `You sent <strong>${h.amount} ${escapeHtml(meta.label)}</strong> to <strong>${escapeHtml(h.receiver ? h.receiver.full_name : "Unknown")}</strong>`
                : `<strong>${escapeHtml(h.sender ? h.sender.full_name : "Unknown")}</strong> sent you <strong>${h.amount} ${escapeHtml(meta.label)}</strong>`}</div>
              <div class="muted" style="font-size:.75rem;margin-top:2px;">${shareFmtDateTime(h.created_at)}</div>
            </div>`;
          }).join("")}
        </div>`}
      </div>
    </div>`;

  renderShareAmountField();
}

function renderShareAmountField() {
  const wrap = document.getElementById("shareAmountFieldWrap");
  const typeSel = document.getElementById("shareResourceType");
  if (!wrap || !typeSel) return;
  const type = typeSel.value;
  const max = type === "coins" ? ((estate.data && estate.data.coins) || 0) : ((estate.data && estate.data.green_points) || 0);
  wrap.innerHTML = `
    <label class="muted" style="font-size:.8rem;">Amount (you have ${max})
      <input id="shareAmount" type="number" min="1" max="${max}" value="${Math.min(5, max) || 1}"
        style="width:100%;padding:8px;border:1px solid var(--paper-line);border-radius:8px;margin-top:4px;">
    </label>`;
}

async function handleSendShare() {
  const recipientSel = document.getElementById("shareRecipient");
  const typeSel = document.getElementById("shareResourceType");
  if (!recipientSel || !typeSel) return;
  const receiverId = recipientSel.value;
  const resourceType = typeSel.value;
  const amountInput = document.getElementById("shareAmount");
  const amount = parseInt(amountInput && amountInput.value, 10);
  if (!amount || amount < 1) { toast("Enter an amount greater than zero."); return; }

  const { data, error } = await supabase.rpc("share_resource", {
    p_sender_id: sstate.student.id, p_receiver_id: receiverId, p_resource_type: resourceType, p_amount: amount,
  });
  if (error) { toast("That didn't work — please try again."); return; }
  const row = Array.isArray(data) ? data[0] : data;
  toast(row.message);
  if (!row.success) return;

  // The RPC already committed server-side, so just re-pull fresh balances
  // (and pet/adoption counts, in case an Adoption Chance moved) rather than
  // hand-computing deltas here.
  await loadEngagement();
  if (typeof loadPets === "function") await loadPets();
  renderShareTab();
  if (typeof renderTopbarStreakBadge === "function") renderTopbarStreakBadge();
}
