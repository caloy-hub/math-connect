-- ============================================================================
-- Migration 51 — Dynamic fix for any remaining delete-blocking FK
-- Run this once in Supabase → SQL Editor.
--
-- WHY THIS ONE IS DIFFERENT:
-- Migrations 49 and 50 used ALTER TABLE ... DROP CONSTRAINT IF EXISTS
-- "<guessed_name>", assuming Postgres's default auto-generated constraint
-- name (<table>_<column>_fkey). If your database's real constraint has a
-- different name, that DROP silently matched nothing (IF EXISTS = no-op),
-- and the ADD CONSTRAINT that followed just added a SECOND foreign key
-- alongside the original still-blocking one — which explains why deletes
-- can still fail after running both.
--
-- This migration doesn't guess names. It asks Postgres directly ("find
-- every foreign key that points at students, teachers, or battles, and is
-- still set to block deletes"), and fixes exactly those, using their real
-- name, whatever it is. It's safe to run even if 49/50 already fully
-- worked — it will simply find nothing left to do.
-- ============================================================================

do $$
declare
  r record;
begin
  for r in
    select
      con.conname,
      con.conrelid::regclass::text as child_table,
      att.attname as child_column,
      con.confrelid::regclass::text as parent_table
    from pg_constraint con
    join pg_attribute att
      on att.attrelid = con.conrelid and att.attnum = any(con.conkey)
    where con.contype = 'f'
      and con.confrelid::regclass::text in ('students', 'teachers', 'battles')
      and con.confdeltype in ('a', 'r')   -- a = no action, r = restrict (both block deletes)
  loop
    raise notice 'Fixing %.% -> % (constraint %, was blocking)', r.child_table, r.child_column, r.parent_table, r.conname;
    execute format('alter table %s drop constraint %I', r.child_table, r.conname);
    execute format(
      'alter table %s add constraint %I foreign key (%I) references %s (id) on delete set null',
      r.child_table, r.conname, r.child_column, r.parent_table
    );
  end loop;
end $$;

-- After running, check the "Messages" / "Notices" panel in the SQL Editor
-- (not just "Results") — it lists exactly which constraint(s), if any,
-- were found and fixed. If it lists nothing, there was nothing left
-- blocking on students/teachers/battles specifically, and the 409 you're
-- seeing is coming from somewhere outside this list — at that point I do
-- need the exact response body (Network tab → the failed request →
-- Response tab) to go further, since static code review won't find it.
