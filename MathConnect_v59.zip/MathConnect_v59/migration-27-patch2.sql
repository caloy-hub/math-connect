-- ============================================================================
-- Migration 27 — Patch 2
-- Adds a unique constraint on module_parent_notes.module_id so the app can
-- upsert one parent note per Learning Activity Sheet. Safe to re-run.
-- ============================================================================
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'module_parent_notes_module_unique'
  ) then
    alter table module_parent_notes add constraint module_parent_notes_module_unique unique (module_id);
  end if;
end $$;
