// ============================================================================
// MathConnect — Teacher view of the Math Drill Arena
// Read-only: shows the current class's per-station drill standings (which
// stations each student has answered vs. left untouched), fair PER-STATION
// leaderboards (class + school-wide by grade level), class-wide statistics,
// and each student's overall MathLegends Rank.
// Depends on: state (teacher.js), escapeHtml (supabase-client.js),
// rankEngine.js (RANK_TIERS, rankTierByLevel, renderRankBadge).
//
// NOTE: DRILL_TOPICS intentionally mirrors drills.js (the student-side
// file) — this file is loaded standalone on the teacher dashboard and has
// no shared bundler, so if you ever add/rename a station, update both files.
// The MathLegends rank tier list itself lives in ONE place: rankEngine.js.
// ============================================================================

const TDRILL_TOPICS = [
  { key: "basic", icon: "➕", name: "Basic Operations" },
  { key: "order", icon: "🔢", name: "Order of Operations" },
  { key: "integers", icon: "➖", name: "Integers" },
  { key: "fractions", icon: "🍕", name: "Fractions" },
  { key: "decimals", icon: "💯", name: "Decimals" },
  { key: "algebra", icon: "🅧", name: "Algebraic Expressions" },
  // Term 2 additions (migration-22) — keep in sync with DRILL_TOPICS in drills.js
  { key: "ratio", icon: "⚖️", name: "Ratio & Proportion" },
  { key: "percent", icon: "💸", name: "Percent" },
  { key: "geometry", icon: "📐", name: "Geometry" },
  { key: "patterns", icon: "🧩", name: "Patterns & Sequences" },
  { key: "statistics", icon: "📊", name: "Statistics" },
  { key: "probability", icon: "🎡", name: "Probability" },
  // High School expansion (migration-47) — keep in sync with DRILL_TOPICS in drills.js
  { key: "exponents", icon: "⚡", name: "Exponents & Radicals" },
  { key: "equations", icon: "⚖️", name: "Equation Scale" },
  { key: "factoring", icon: "🧩", name: "Factor Vault" },
  { key: "measurement", icon: "🌾", name: "Farm Measure" },
  { key: "coordinates", icon: "📈", name: "Grid Navigator" },
  { key: "pythagoras", icon: "📐", name: "Surveyor's Post" },
];
const TDRILL_MAX_LEVEL = 15; // keep in sync with DRILL_MAX_LEVEL in drills.js

// Station locks are admin-controlled and read-only here — teachers see which
// of the Term 2 stations are still locked so they know why a station shows
// no activity yet. See migration-22-new-drill-stations.sql.
var tstate_stationLocks = {};
async function loadTeacherStationLocks() {
  const { data } = await supabase.from("drill_station_locks").select("station_key, locked");
  const map = {};
  (data || []).forEach((r) => (map[r.station_key] = r.locked));
  tstate_stationLocks = map;
}

// MathLegends rank data (RANK_TIERS, rankTierByLevel, renderRankBadge) now
// lives in rankEngine.js — loaded before this file on teacher.html. The
// overall rank shown per student comes straight from drill_progress'
// mastery_tier / mastery_stars (star-driven), NOT from topic_levels.

// ============================================================================
// DATA FETCH
// ============================================================================
function tDefaultTopicLevels() { const o = {}; TDRILL_TOPICS.forEach((t) => (o[t.key] = 1)); return o; }
function tDefaultTopicPoints() { const o = {}; TDRILL_TOPICS.forEach((t) => (o[t.key] = 0)); return o; }
// `played` = we have evidence the student ran this station (a logged run in
// drill_attempts, OR a raised level / banked points in drill_progress).
// `logMissing` = evidence of play exists but NO run was ever logged for it.
function tDefaultStationStats() { const o = {}; TDRILL_TOPICS.forEach((t) => (o[t.key] = { attempts: 0, correct: 0, total: 0, played: false, logMissing: false })); return o; }

// Health info about the most recent load — rendered as a status line so the
// teacher can SEE how much data the numbers are built from, and is warned
// (instead of shown silent zeros) when something failed to load.
var tdrillLoad = { runs: 0, errors: [], unknownTopicRuns: 0, unknownTopics: [], loadedAt: null };

// v46 FIX — "0/23 players" on stations students had actually played.
// Root cause: this used a bare `.select()` on drill_attempts, which
// PostgREST silently caps at ~1,000 rows. Once a class had logged more than
// that many runs, the newest rows (= the newest stations) were the ones
// dropped, and the dashboard reported zeros with no warning. It now (a) pages
// through EVERY run, (b) reports load errors instead of hiding them, and
// (c) cross-checks drill_progress — a raised level or banked points is proof
// a student played a station even if its run log is missing.
async function fetchClassDrillStandings(students) {
  const studentIds = students.map((s) => s.id);
  tdrillLoad = { runs: 0, errors: [], unknownTopicRuns: 0, unknownTopics: [], loadedAt: new Date() };
  if (studentIds.length === 0) return [];

  const [progressRes, attemptsRes] = await Promise.all([
    fetchAllRowsChecked(() => supabase.from("drill_progress").select("*").in("student_id", studentIds)),
    fetchAllRowsChecked(() => supabase.from("drill_attempts").select("student_id, topic, correct_count, total_questions, played_at").in("student_id", studentIds)),
  ]);
  if (progressRes.error) tdrillLoad.errors.push(`student progress (${progressRes.error.message})`);
  if (attemptsRes.error) tdrillLoad.errors.push(`run history (${attemptsRes.error.message})`);
  if (attemptsRes.truncated) tdrillLoad.errors.push("run history (too many rows to load in full)");
  const progress = progressRes.data;
  const attempts = attemptsRes.data;
  tdrillLoad.runs = attempts.length;

  const progressByStudent = {};
  progress.forEach((p) => (progressByStudent[p.student_id] = p));

  const statsByStudent = {};
  const lastPlayedByStudent = {};
  studentIds.forEach((id) => (statsByStudent[id] = tDefaultStationStats()));
  const unknown = {};
  attempts.forEach((a) => {
    const s = statsByStudent[a.student_id];
    if (!s) return;
    if (!s[a.topic]) { tdrillLoad.unknownTopicRuns += 1; unknown[a.topic] = true; return; } // station this file doesn't know about — keep count so it's not silently dropped
    s[a.topic].attempts += 1;
    s[a.topic].correct += a.correct_count || 0;
    s[a.topic].total += a.total_questions || 0;
    if (a.played_at && (!lastPlayedByStudent[a.student_id] || a.played_at > lastPlayedByStudent[a.student_id])) lastPlayedByStudent[a.student_id] = a.played_at;
  });
  tdrillLoad.unknownTopics = Object.keys(unknown);

  return students
    .map((s) => {
      const p = progressByStudent[s.id];
      // merge over defaults so a row created before a station existed still
      // has an entry for it
      const topicLevels = { ...tDefaultTopicLevels(), ...((p && p.topic_levels) || {}) };
      const topicPoints = { ...tDefaultTopicPoints(), ...((p && p.topic_points) || {}) };
      const stationStats = statsByStudent[s.id];
      TDRILL_TOPICS.forEach((t) => {
        const st = stationStats[t.key];
        const progressEvidence = (topicLevels[t.key] || 1) > 1 || (topicPoints[t.key] || 0) > 0;
        st.played = st.attempts > 0 || progressEvidence;
        st.logMissing = st.attempts === 0 && progressEvidence;
      });
      const stationsAttempted = TDRILL_TOPICS.filter((t) => stationStats[t.key].played).length;
      return {
        student: s,
        total_points: p ? p.total_points || 0 : 0,
        games_played: p ? p.games_played || 0 : 0,
        best_streak: p ? p.best_streak || 0 : 0,
        topic_levels: topicLevels,
        topic_points: topicPoints,
        stationStats,
        stationsAttempted,
        lastPlayedAt: lastPlayedByStudent[s.id] || (p && p.games_played > 0 ? p.updated_at : null) || null,
        masteryStars: p ? (p.mastery_stars || 0) : 0,
        overallTier: rankTierByLevel(p ? p.mastery_tier : 1),
      };
    })
    .sort((a, b) => b.total_points - a.total_points);
}

async function fetchGradeLevelDrillBoard(gradeLevel, highlightSectionId) {
  const { data, error } = await supabase.rpc("grade_level_drill_leaderboard", { target_grade_level: gradeLevel, result_limit: 10 });
  if (error) tdrillLoad.errors.push(`overall leaderboard (${error.message})`); // shown in the warning banner instead of a misleading "No scores yet"
  if (error || !data) return [];
  return data.map((r) => ({ ...r, isOwnSection: r.section_id === highlightSectionId }));
}

async function fetchStationBoardSchoolWide(gradeLevel, topic, highlightSectionId) {
  const { data, error } = await supabase.rpc("station_leaderboard", { target_grade_level: gradeLevel, target_topic: topic, result_limit: 10 });
  if (error) tdrillLoad.errors.push(`station leaderboard (${error.message})`);
  if (error || !data) return [];
  return data.map((r) => ({ ...r, isOwnSection: r.section_id === highlightSectionId }));
}

// ============================================================================
// CLASS-WIDE STATISTICS (participation, station popularity, tier spread)
// ============================================================================
function computeClassStats(classRows) {
  const n = classRows.length;
  const participated = classRows.filter((r) => r.stationsAttempted > 0).length;
  const perStation = TDRILL_TOPICS.map((t) => {
    const playedBy = classRows.filter((r) => r.stationStats[t.key].played);
    const withLogs = playedBy.filter((r) => r.stationStats[t.key].attempts > 0);
    const runs = withLogs.reduce((sum, r) => sum + r.stationStats[t.key].attempts, 0);
    const totalCorrect = withLogs.reduce((sum, r) => sum + r.stationStats[t.key].correct, 0);
    const totalQ = withLogs.reduce((sum, r) => sum + r.stationStats[t.key].total, 0);
    const avgLevel = playedBy.length ? playedBy.reduce((sum, r) => sum + (r.topic_levels[t.key] || 1), 0) / playedBy.length : 0;
    return {
      topic: t, studentsAttempted: playedBy.length, runs,
      accuracy: totalQ > 0 ? Math.round((totalCorrect / totalQ) * 100) : null,
      avgLevel: playedBy.length ? avgLevel.toFixed(1) : null,
    };
  });
  // "Least played" only makes sense among stations students CAN play — an
  // admin-locked station would otherwise always "win" that title.
  const playable = perStation.filter((s) => !tstate_stationLocks[s.topic.key]);
  const pool = playable.length ? playable : perStation;
  const mostPlayed = participated ? pool.slice().sort((a, b) => b.studentsAttempted - a.studentsAttempted || b.runs - a.runs)[0] : null;
  const leastPlayed = participated ? pool.slice().sort((a, b) => a.studentsAttempted - b.studentsAttempted || a.runs - b.runs)[0] : null;
  const tierCounts = {};
  RANK_TIERS.forEach((t) => (tierCounts[t.name] = 0));
  classRows.forEach((r) => (tierCounts[r.overallTier.name] += 1));
  const logGapPairs = classRows.reduce((sum, r) => sum + TDRILL_TOPICS.filter((t) => r.stationStats[t.key].logMissing).length, 0);
  return { n, participated, perStation, mostPlayed, leastPlayed, tierCounts, logGapPairs };
}

// Status line + warnings shown above the class statistics table.
function renderDrillLoadStatus(stats) {
  const when = tdrillLoad.loadedAt ? tdrillLoad.loadedAt.toLocaleTimeString("en-PH", { hour: "numeric", minute: "2-digit" }) : "";
  const errs = tdrillLoad.errors;
  return `
    <div class="muted" style="font-size:.78rem;margin-bottom:8px;">
      Counted from ${tdrillLoad.runs.toLocaleString()} logged drill run${tdrillLoad.runs === 1 ? "" : "s"} · ${stats.participated}/${stats.n} students have played · updated ${when}
      &nbsp;<a href="#" onclick="renderTeacherDrills();return false;">↻ Refresh</a>
    </div>
    ${errs.length ? `<div style="border-left:4px solid var(--clay);background:var(--paper);padding:8px 12px;margin-bottom:10px;border-radius:6px;font-size:.85rem;">
      ⚠️ Some data didn't load: ${errs.map((e) => escapeHtml(e)).join("; ")}. The numbers below may be <strong>incomplete rather than zero</strong> — tap Refresh to try again.</div>` : ""}
    ${tdrillLoad.unknownTopicRuns ? `<div style="border-left:4px solid var(--gold);background:var(--paper);padding:8px 12px;margin-bottom:10px;border-radius:6px;font-size:.85rem;">
      ℹ️ ${tdrillLoad.unknownTopicRuns} logged run${tdrillLoad.unknownTopicRuns === 1 ? "" : "s"} belong to station key(s) this dashboard doesn't list (${tdrillLoad.unknownTopics.map((k) => escapeHtml(k)).join(", ")}) and aren't included below. If you added a station in drills.js, add it to TDRILL_TOPICS in teacher-drills.js too.</div>` : ""}
    ${stats.logGapPairs ? `<div class="muted" style="font-size:.78rem;margin-bottom:8px;">
      ℹ️ ${stats.logGapPairs} student-station pair${stats.logGapPairs === 1 ? "" : "s"} show progress (a raised level or banked points) but no saved run history. They're counted as played; their accuracy just can't be calculated.</div>` : ""}`;
}

function renderClassStatsCard(stats) {
  const participationPct = stats.n ? Math.round((stats.participated / stats.n) * 100) : 0;
  return `
    <div class="card" style="margin-bottom:16px;">
      <h3>📈 Class Statistics — Math Drills</h3>
      ${renderDrillLoadStatus(stats)}
      <div class="drill-stat-row" style="justify-content:flex-start;">
        <div class="drill-stat"><div class="num">${stats.participated}/${stats.n}</div><div class="muted">Students who've played (${participationPct}%)</div></div>
        <div class="drill-stat"><div class="num">${stats.mostPlayed ? `${stats.mostPlayed.topic.icon}` : "—"}</div><div class="muted">Most-played station${stats.mostPlayed ? `: ${escapeHtml(stats.mostPlayed.topic.name)}` : ""}</div></div>
        <div class="drill-stat"><div class="num">${stats.leastPlayed ? `${stats.leastPlayed.topic.icon}` : "—"}</div><div class="muted">Least-played open station${stats.leastPlayed ? `: ${escapeHtml(stats.leastPlayed.topic.name)}` : ""}</div></div>
      </div>
      <table style="margin-top:6px;">
        <thead><tr><th>Station</th><th class="num">Students Played</th><th class="num">Runs</th><th class="num">Avg. Level</th><th class="num">Class Accuracy</th></tr></thead>
        <tbody>
          ${stats.perStation.map((s) => `
            <tr>
              <td>${s.topic.icon} ${escapeHtml(s.topic.name)}${tstate_stationLocks[s.topic.key] ? ` <span class="muted" style="font-size:.75rem;">🔒 locked by admin</span>` : ""}</td>
              <td class="num">${s.studentsAttempted}/${stats.n}</td>
              <td class="num">${s.runs}</td>
              <td class="num">${s.avgLevel ?? "—"}</td>
              <td class="num">${s.accuracy != null ? s.accuracy + "%" : "—"}</td>
            </tr>`).join("")}
        </tbody>
      </table>
      <div style="margin-top:14px;">
        <div class="muted" style="margin-bottom:6px;">MathLegends rank spread across the class</div>
        ${RANK_TIERS.slice().reverse().map((t) => {
          const count = stats.tierCounts[t.name] || 0;
          if (count === 0) return "";
          const pct = stats.n ? Math.round((count / stats.n) * 100) : 0;
          return `<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
            <div style="width:220px;">${renderRankBadge(t, { size: "small" })}</div>
            <div style="flex:1;background:var(--gold-light);border-radius:6px;overflow:hidden;height:14px;">
              <div style="width:${pct}%;background:${t.color};height:100%;"></div>
            </div>
            <div class="muted" style="width:70px;text-align:right;">${count} student${count === 1 ? "" : "s"}</div>
          </div>`;
        }).join("") || `<p class="empty">No drill activity yet.</p>`}
      </div>
    </div>`;
}

// ============================================================================
// PER-STUDENT STATION BREAKDOWN (which stations answered vs. left untouched)
// ============================================================================
function renderStudentStationDetail(row) {
  return `<table style="margin-top:6px;">
    <thead><tr><th>Station</th><th>Status</th><th class="num">Level</th><th class="num">Points</th><th class="num">Accuracy</th></tr></thead>
    <tbody>
      ${TDRILL_TOPICS.map((t) => {
        const st = row.stationStats[t.key];
        const lvl = row.topic_levels[t.key] || 1;
        const pts = row.topic_points[t.key] || 0;
        const acc = st.total > 0 ? Math.round((st.correct / st.total) * 100) : null;
        let status;
        if (st.attempts > 0) status = `<span style="color:#1F9D5C;">✅ Answered</span> (${st.attempts} run${st.attempts === 1 ? "" : "s"})`;
        else if (st.played) status = `<span style="color:#1F9D5C;">✅ Played</span> <span class="muted">(run history not saved)</span>`;
        else status = `<span class="muted">➖ Left / not started</span>`;
        return `<tr>
          <td>${t.icon} ${escapeHtml(t.name)}</td>
          <td>${status}</td>
          <td class="num">${lvl}/${TDRILL_MAX_LEVEL}</td>
          <td class="num">${pts}</td>
          <td class="num">${acc != null ? acc + "%" : "—"}</td>
        </tr>`;
      }).join("")}
    </tbody>
  </table>`;
}

// ============================================================================
// STATION LEADERBOARDS (class-scoped + school-wide-by-grade-level)
// ============================================================================
var tdlbState = { schoolWideTopic: TDRILL_TOPICS[0].key };

function renderStationLeaderboardsCard(classRows) {
  return `
    <div class="card" style="margin-bottom:16px;">
      <h3>🏆 Top Scorers by Station (this section)</h3>
      <p class="muted">Ranked fairly — each station's leaderboard only counts points earned in that station, so a student strong in one topic can't crowd out a classmate who's mastering another.</p>
      <div class="drill-grid" style="grid-template-columns:repeat(3,1fr);">
        ${TDRILL_TOPICS.map((t) => {
          const ranked = classRows
            .filter((r) => (r.topic_points[t.key] || 0) > 0)
            .slice()
            .sort((a, b) => (b.topic_points[t.key] || 0) - (a.topic_points[t.key] || 0))
            .slice(0, 5);
          return `
          <div class="drill-card" style="text-align:left;">
            <h4 style="margin:0 0 8px;">${t.icon} ${escapeHtml(t.name)}</h4>
            ${ranked.length === 0 ? `<p class="empty" style="font-size:.8rem;">No scores yet.</p>` : `
              <ol style="margin:0;padding-left:18px;font-size:.85rem;">
                ${ranked.map((r) => `<li>${escapeHtml(r.student.full_name)} — <strong>${r.topic_points[t.key]}</strong> pts</li>`).join("")}
              </ol>`}
          </div>`;
        }).join("")}
      </div>
    </div>`;
}

function schoolWideStationTabsHtml() {
  return `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;">
    ${TDRILL_TOPICS.map((t) => `<button class="btn-outline" style="padding:5px 10px;font-size:.78rem;${tdlbState.schoolWideTopic === t.key ? "background:var(--gold-light);border-color:var(--gold);" : ""}" onclick="setTeacherSchoolWideStationTab('${t.key}')">${tstate_stationLocks[t.key] ? "🔒 " : ""}${t.icon} ${t.name}</button>`).join("")}
  </div>`;
}
function setTeacherSchoolWideStationTab(key) { tdlbState.schoolWideTopic = key; renderTeacherDrills(); }

// ============================================================================
// MAIN RENDER (the "🎮 Math Drills" tab on the teacher dashboard)
// ============================================================================
// ============================================================================
// CLASS QUEST (teacher management) — one shared XP bar per section. Students
// contribute automatically from drill points; the teacher just sets the
// goal and the reward, then can peek at a private "top contributors" list
// for quiet 1:1 encouragement (never shown to the class as a ranked list).
// ============================================================================
async function fetchActiveClassQuest() {
  const { data } = await supabase.rpc("get_active_class_quest", { p_section_id: state.section.id });
  return data || null;
}

async function renderTeacherClassQuestWidget() {
  const quest = await fetchActiveClassQuest();
  if (!quest) {
    return `
      <div class="card" style="margin-bottom:16px;border:2px dashed var(--sage);">
        <h3 style="margin-top:0;">🌱 Class Quest</h3>
        <p class="muted">No active quest for ${escapeHtml(state.section.section_name)} right now. Set a shared points goal the whole class works toward together — no individual ranking shown to students, just one shared bar.</p>
        <button class="btn-primary" onclick="openClassQuestModal()">+ Start a Class Quest</button>
      </div>`;
  }
  const pct = Math.min(100, Math.round((quest.current_points / quest.goal_points) * 100));
  const done = !!quest.completed_at;
  const targetMeta = quest.target_topic ? TDRILL_TOPICS.find((t) => t.key === quest.target_topic) : null;
  return `
    <div class="card" style="margin-bottom:16px;border:2px solid var(--sage);">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
        <h3 style="margin:0;">🌱 Class Quest — ${escapeHtml(quest.title)}</h3>
        <div style="display:flex;gap:8px;">
          <button class="btn-outline btn-sm" onclick="viewQuestContributors('${quest.id}')">👥 Top Contributors</button>
          <button class="btn-outline btn-sm" onclick="endClassQuest('${quest.id}')">${done ? "Start New Quest" : "End Quest"}</button>
        </div>
      </div>
      ${quest.description ? `<p class="muted" style="margin:4px 0 10px;">${escapeHtml(quest.description)}</p>` : ""}
      <p class="muted" style="margin:4px 0 10px;">${targetMeta ? `${targetMeta.icon} Only ${escapeHtml(targetMeta.name)} points count toward this quest.` : "Any drill station counts toward this quest."}</p>
      <div style="background:var(--sage-light);border-radius:8px;height:16px;overflow:hidden;">
        <div style="background:${done ? "var(--gold)" : "var(--forest)"};height:100%;width:${pct}%;"></div>
      </div>
      <div class="muted" style="margin-top:6px;font-size:.85rem;">
        ${quest.current_points} / ${quest.goal_points} pts (${pct}%)${done ? " · 🎉 Goal reached!" : ""}${quest.reward_text ? ` · 🎁 Reward: ${escapeHtml(quest.reward_text)}` : ""}
      </div>
    </div>`;
}

function openClassQuestModal() {
  showModal(`
    <h3>🌱 Start a Class Quest</h3>
    <p class="muted">Every student's drill practice contributes to this shared goal automatically. Students only see the shared bar and their own contribution — never a ranked list of classmates.</p>
    <div class="field"><label>Title</label><input type="text" id="cq_title" placeholder="e.g. 1,000 Points for a Movie Afternoon"></div>
    <div class="field"><label>Description (optional)</label><textarea id="cq_desc" rows="2" placeholder="What is this quest about?"></textarea></div>
    <div class="field"><label>Target drill station</label>
      <select id="cq_topic">
        <option value="">Any station (all drill practice counts)</option>
        ${TDRILL_TOPICS.map((t) => `<option value="${t.key}">${t.icon} ${escapeHtml(t.name)} only</option>`).join("")}
      </select>
      <div class="muted" style="margin-top:2px;">If you pick a specific station, only points earned on that station count toward the goal — great for focusing practice on a topic the class needs (e.g. Ratio & Proportion before a quiz).</div>
    </div>
    <div class="field"><label>Goal (combined points across the whole class)</label><input type="number" id="cq_goal" min="1" value="1000"></div>
    <div class="field"><label>Reward (shown to students once completed)</label><input type="text" id="cq_reward" placeholder="e.g. Free-choice activity Friday"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="saveClassQuest()">Start Quest</button>
    </div>`);
}

async function saveClassQuest() {
  const title = document.getElementById("cq_title").value.trim();
  const goal = Number(document.getElementById("cq_goal").value);
  if (!title) { toast("Please enter a title."); return; }
  if (!goal || goal <= 0) { toast("Please enter a goal greater than 0."); return; }
  const payload = {
    section_id: state.section.id,
    title,
    description: document.getElementById("cq_desc").value.trim() || null,
    reward_text: document.getElementById("cq_reward").value.trim() || null,
    goal_points: goal,
    target_topic: document.getElementById("cq_topic").value || null,
  };
  const { error } = await supabase.from("class_quests").insert(payload);
  if (error) { toast("Error starting quest: " + error.message); return; }
  closeModal();
  toast("🌱 Class Quest started!");
  renderTeacherDrills();
}

async function endClassQuest(questId) {
  if (!confirm("End this Class Quest? Students will no longer see it, and a new quest can be started afterward.")) return;
  const { error } = await supabase.from("class_quests").update({ is_active: false }).eq("id", questId);
  if (error) { toast("Error ending quest: " + error.message); return; }
  renderTeacherDrills();
}

async function viewQuestContributors(questId) {
  const { data, error } = await supabase.rpc("get_class_quest_contributors", { p_quest_id: questId });
  if (error) { toast("Error loading contributors: " + error.message); return; }
  const rows = data || [];
  showModal(`
    <h3>👥 Top Contributors</h3>
    <p class="muted">Private to you — a nice list to draw from for a quiet shout-out or a word of encouragement. Not shown to students.</p>
    ${rows.length === 0 ? `<div class="empty">No contributions logged yet.</div>` : `
      <table>
        <thead><tr><th>Student</th><th>Points Contributed</th></tr></thead>
        <tbody>${rows.map((r) => `<tr><td>${escapeHtml(r.full_name)}</td><td class="num">${r.total_contributed}</td></tr>`).join("")}</tbody>
      </table>`}
    <div style="display:flex;justify-content:flex-end;margin-top:16px;">
      <button class="btn-outline" onclick="closeModal()">Close</button>
    </div>`);
}

// ============================================================================
// WEEKLY PROGRESS (teacher) — same numbers students see in "My Week"
// (migration-56: section_weekly_progress). Shows EVERY student in the section,
// including those who opted out of the public leaderboards.
// ============================================================================
var tdrillWeeksAgo = 0;
async function setTdrillWeek(n) {
  tdrillWeeksAgo = n;
  const box = document.getElementById("tdrillWeekly");
  if (box) box.innerHTML = await renderTeacherWeeklyProgress(n);
}

async function renderTeacherWeeklyProgress(weeksAgo) {
  const { data, error } = await supabase.rpc("section_weekly_progress", { p_section_id: state.section.id, p_weeks_ago: weeksAgo || 0 });
  if (error) return `<div class="card" style="margin-bottom:16px;"><h3>📈 Weekly Progress</h3><p class="muted">Couldn't load this yet (${escapeHtml(error.message)}). Has migration-56 been run?</p></div>`;
  const rows = data || [];
  const growing = rows.filter((r) => r.progress_pts > 0).sort((a, b) => b.progress_pts - a.progress_pts);
  // Teacher-only "who might like a check-in": nothing played, OR accuracy clearly below their own usual.
  const checkIn = rows.filter((r) => r.answers === 0 || (r.acc_gain != null && r.acc_gain <= -10)).sort((a, b) => a.full_name.localeCompare(b.full_name));
  const cell = "padding:6px 8px;";
  const gain = (r) => r.acc_gain == null ? `<span class="muted">—</span>` : r.acc_gain > 0 ? `<span style="color:var(--forest);font-weight:600;">+${Math.round(r.acc_gain)}</span>` : `<span class="muted">${Math.round(r.acc_gain)}</span>`;
  return `
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
        <h3 style="margin:0;">📈 Weekly Progress — growth against each student's own usual</h3>
        <div style="display:flex;gap:6px;">
          ${[[0, "This week"], [1, "Last week"]].map(([n, label]) => `<button class="${(weeksAgo || 0) === n ? "btn-gold" : "btn-outline"} btn-sm" onclick="setTdrillWeek(${n})">${label}</button>`).join("")}
        </div>
      </div>
      <p class="muted" style="margin:6px 0 10px;">Progress points = 1 per accuracy point above the student's usual (max 30, needs 20+ answers this week and a usual to compare with) + 5 per level climbed. Students see only their gains; the negative figures below are for you.</p>
      ${rows.length === 0 ? `<p class="empty">No students in this section yet.</p>` : `
      <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:.86rem;">
        <thead><tr style="text-align:left;border-bottom:2px solid var(--paper-line);"><th style="${cell}">Student</th><th style="${cell}">Answers</th><th style="${cell}">Accuracy</th><th style="${cell}">Usual</th><th style="${cell}">Change (pts)</th><th style="${cell}">Levels</th><th style="${cell}">Days</th><th style="${cell}">🌟 Progress</th></tr></thead>
        <tbody>${rows.map((r) => `
          <tr style="border-bottom:1px solid var(--paper-line);">
            <td style="${cell}">${escapeHtml(r.full_name)}${r.tag === "comeback" ? " 🔁" : r.tag === "new" ? " 🌱" : ""}</td>
            <td style="${cell}">${r.answers}</td>
            <td style="${cell}">${r.accuracy != null ? Math.round(r.accuracy) + "%" : "—"}</td>
            <td style="${cell}">${r.base_accuracy != null ? Math.round(r.base_accuracy) + "%" : "—"}${r.base_kind === "history" ? ` <span class="muted" style="font-size:.7rem;">(earlier)</span>` : ""}</td>
            <td style="${cell}">${gain(r)}</td>
            <td style="${cell}">${r.level_ups || "—"}</td>
            <td style="${cell}">${r.days_active}</td>
            <td style="${cell}font-weight:700;color:var(--gold);">${r.progress_pts || "—"}</td>
          </tr>`).join("")}</tbody>
      </table></div>
      <div style="display:flex;gap:24px;flex-wrap:wrap;margin-top:12px;">
        <div style="flex:1;min-width:220px;"><strong>🌟 Worth celebrating</strong><div class="muted" style="font-size:.85rem;margin-top:2px;">${growing.length ? growing.slice(0, 6).map((r) => `${escapeHtml(r.full_name)} (${r.progress_pts})`).join(" · ") : "Nobody has grown enough yet this week."}</div></div>
        <div style="flex:1;min-width:220px;"><strong>💬 Might like a check-in</strong><div class="muted" style="font-size:.85rem;margin-top:2px;">${checkIn.length ? checkIn.map((r) => `${escapeHtml(r.full_name)}${r.answers === 0 ? "" : " (below their usual)"}`).join(" · ") : "Everyone is on track."}</div></div>
      </div>`}
    </div>`;
}

async function renderTeacherDrills() {
  const el = document.getElementById("tab-drills");
  el.innerHTML = `<div class="empty">Loading drill standings…</div>`;

  const [classRows, gradeRows, stationSchoolWideRows] = await Promise.all([
    fetchClassDrillStandings(state.students),
    fetchGradeLevelDrillBoard(state.section.grade_level, state.section.id),
    fetchStationBoardSchoolWide(state.section.grade_level, tdlbState.schoolWideTopic, state.section.id),
    loadTeacherStationLocks(),
  ]);

  const medals = ["🥇", "🥈", "🥉"];
  const classStats = computeClassStats(classRows);
  const schoolWideTopicMeta = TDRILL_TOPICS.find((t) => t.key === tdlbState.schoolWideTopic);

  el.innerHTML = `
    ${await renderTeacherClassQuestWidget()}
    ${renderClassStatsCard(classStats)}
    <div id="tdrillWeekly">${await renderTeacherWeeklyProgress(tdrillWeeksAgo)}</div>

    <div class="card" style="margin-bottom:16px;">
      <h3>🎮 ${escapeHtml(state.section.section_name)} — Drill Standings</h3>
      <p class="muted">Overall points (all stations combined) and MathLegends Rank per student. Click a row to see which stations they've answered vs. left untouched, plus their per-station level, points, and accuracy.</p>
      ${classRows.length === 0 ? `<p class="empty">No students in this section yet.</p>` : classRows.map((r, i) => `
        <details style="border-bottom:1px solid var(--paper-line);padding:8px 0;">
          <summary style="cursor:pointer;display:flex;align-items:center;gap:12px;flex-wrap:wrap;list-style:none;">
            <span style="width:22px;">${i + 1}</span>
            <strong style="min-width:160px;">${escapeHtml(r.student.full_name)}</strong>
            ${renderRankBadge(r.overallTier, { size: "small", withStars: true, stars: r.masteryStars })}
            <span class="muted">${r.stationsAttempted}/${TDRILL_TOPICS.length} stations answered</span>
            <span class="muted">${r.lastPlayedAt ? "last played " + new Date(r.lastPlayedAt).toLocaleDateString("en-PH", { month: "short", day: "numeric" }) : "hasn't played yet"}</span>
            <span class="muted">🔥 ${r.best_streak} best streak</span>
            <span style="margin-left:auto;font-weight:700;color:var(--gold);">${r.total_points} pts total</span>
          </summary>
          ${renderStudentStationDetail(r)}
        </details>`).join("")}
    </div>

    ${renderStationLeaderboardsCard(classRows)}

    <div class="card" style="margin-bottom:16px;">
      <h3>📊 Top 10 by Station — ${escapeHtml(state.section.grade_level)} (School-wide)</h3>
      <p class="muted">Same station-scoped fairness as the student view — every teacher's sections at this grade level, one station at a time.</p>
      ${schoolWideStationTabsHtml()}
      ${stationSchoolWideRows.length === 0 ? `<p class="empty">No ${escapeHtml(schoolWideTopicMeta.name)} scores yet for ${escapeHtml(state.section.grade_level)}.</p>` : `
      <table>
        <thead><tr><th>#</th><th>Student</th><th>Section</th><th class="num">Level</th><th class="num">Points</th></tr></thead>
        <tbody>
          ${stationSchoolWideRows.map((r, i) => `
            <tr style="${r.isOwnSection ? "background:var(--gold-light);" : ""}">
              <td>${i < 3 ? medals[i] : i + 1}</td>
              <td>${escapeHtml(r.full_name)}</td>
              <td class="muted">${escapeHtml(r.section_name)}</td>
              <td class="num">${r.topic_level}/${TDRILL_MAX_LEVEL}</td>
              <td class="num">${r.topic_points}</td>
            </tr>`).join("")}
        </tbody>
      </table>`}
    </div>

    <div class="card">
      <h3>🏆 Top 10 (Overall, all stations combined) — ${escapeHtml(state.section.grade_level)}</h3>
      <p class="muted">Lifetime points across every station — kept for reference alongside the fairer, per-station boards above.</p>
      ${gradeRows.length === 0 ? `<p class="empty">No drill scores yet for ${escapeHtml(state.section.grade_level)}.</p>` : `
      <table>
        <thead><tr><th>#</th><th>Student</th><th>Section</th><th class="num">Points</th></tr></thead>
        <tbody>
          ${gradeRows.map((r, i) => `
            <tr style="${r.isOwnSection ? "background:var(--gold-light);" : ""}">
              <td>${i < 3 ? medals[i] : i + 1}</td>
              <td>${escapeHtml(r.full_name)}</td>
              <td class="muted">${escapeHtml(r.section_name)}</td>
              <td class="num">${r.total_points}</td>
            </tr>`).join("")}
        </tbody>
      </table>`}
    </div>`;
}
