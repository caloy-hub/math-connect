// ============================================================================
// MathConnect — Challenges tab UI
// Renders the streak header (with 7-day progress dots), active power-up,
// skip-pass count, coin balance, and today's Daily Challenge card.
// Depends on: streakEngine.js, dailyChallenge.js, sstate (student.js),
// escapeHtml/toast (supabase-client.js).
// ============================================================================

const DC_POWERUP_LABELS = { "2x_coins": "🪙×2 Coin Multiplier (24h)" };

function leStreakDotsHtml(streak) {
  const posInCycle = streak % LE_STREAK_MILESTONE; // 0 right after hitting a milestone
  const filled = posInCycle === 0 && streak > 0 ? LE_STREAK_MILESTONE : posInCycle;
  let dots = "";
  for (let i = 1; i <= LE_STREAK_MILESTONE; i++) {
    dots += `<div style="width:14px;height:14px;border-radius:50%;background:${i <= filled ? "var(--clay)" : "var(--sage-light)"};"></div>`;
  }
  return `<div style="display:flex;gap:6px;">${dots}</div>`;
}

async function renderTopbarStreakBadge() {
  const label = document.getElementById("streakBadge");
  if (!label) return;
  if (!estate.loaded) await loadEngagement();
  const e = estate.data;
  const flameHtml = typeof renderTopbarMiniFlame === "function" ? renderTopbarMiniFlame() : `🔥 ${e.current_streak}d`;
  label.innerHTML = `${flameHtml} &nbsp;·&nbsp; <span title="Coins — spend them in the Shop" style="cursor:pointer;" onclick="switchStudentTab('shop')">🪙 ${e.coins}</span> &nbsp;·&nbsp; <span title="Green Points — feed your Math Pet" style="cursor:pointer;" onclick="switchStudentTab('pet')">💚 ${e.green_points || 0}</span>${e.gemstones > 0 ? ` &nbsp;·&nbsp; <span title="All-Rounder Gemstones — use on your pet in My Pet" style="cursor:pointer;" onclick="switchStudentTab('pet')">💎 ${e.gemstones}</span>` : ""}${e.skip_passes > 0 ? ` &nbsp;·&nbsp; ⏭️ ${e.skip_passes}` : ""}${e.streak_off ? ` &nbsp;·&nbsp; <span title="Your streak is off — restore it from My Attendance" style="cursor:pointer;color:var(--clay);" onclick="switchStudentTab('attendance')">restore streak</span>` : ""}`;
  const titleLabel = document.getElementById("studentTitleLabel");
  if (titleLabel) titleLabel.textContent = e.active_title ? `🏷️ ${e.active_title}` : "";
  if (typeof _maybePlayLevelUp === "function") _maybePlayLevelUp("topbar");
}

async function renderChallengesTab() {
  const el = document.getElementById("tab-challenges");
  el.innerHTML = `<div class="empty">Loading your streak…</div>`;
  if (!estate.loaded) await loadEngagement();
  const e = estate.data;
  const today = phDateString(0);
  const challenge = getDailyChallenge(today);
  const completion = await fetchTodayCompletion();

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;">
        <div>
          <div class="muted">Daily Streak</div>
          <h2 style="margin:4px 0;color:var(--clay);">${e.streak_off ? "🔥💨 Streak off" : `🔥 ${e.current_streak} day${e.current_streak === 1 ? "" : "s"}`}</h2>
          <div class="muted" style="font-size:.78rem;">Longest streak: ${e.longest_streak} · Your streak now follows your <a href="#" onclick="switchStudentTab('attendance');return false;">attendance</a> — Present or Late keeps it lit, an absence puts it out.</div>
        </div>
        <div>
          <div class="muted" style="margin-bottom:6px;">Next Power-Up in:</div>
          ${leStreakDotsHtml(e.current_streak)}
        </div>
        <div style="text-align:right;">
          <div class="muted">Coin Balance</div>
          <h3 style="margin:2px 0;color:var(--gold);">🪙 ${e.coins}</h3>
        </div>
      </div>
      ${isPowerupActive() ? `
        <div style="margin-top:14px;padding:10px 14px;background:var(--gold-light);border-radius:8px;">
          ⚡ Active Power-Up: <strong>${DC_POWERUP_LABELS[e.active_powerup] || e.active_powerup}</strong>
          &nbsp;·&nbsp; Expires ${new Date(e.powerup_expires_at).toLocaleString("en-PH", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
        </div>` : ""}
      ${e.skip_passes > 0 ? `<div class="muted" style="margin-top:8px;">⏭️ You have <strong>${e.skip_passes}</strong> Skip Question pass${e.skip_passes === 1 ? "" : "es"} — usable in Math Drills or Intelligent Practice.</div>` : ""}
      <p class="muted" style="margin-top:10px;font-size:.78rem;">Every 7-day streak unlocks a new Power-Up (a 24-hour 🪙×2 coin multiplier) plus a Skip Question pass.</p>
    </div>

    <div class="card">
      <h2 style="margin:0 0 4px;">${challenge.icon} Today's Real-World Challenge</h2>
      <p class="muted" style="font-size:.82rem;">A fresh word problem every day — same one for your whole class, so you can compare notes!</p>
      ${completion ? `
        <div style="margin-top:14px;padding:16px;background:var(--gold-light);border-radius:8px;">
          <p style="margin:0;"><strong>✅ Completed today!</strong> You earned 🪙 ${completion.coins_awarded} coins.</p>
          <p class="muted" style="margin-top:6px;">Come back tomorrow for a new challenge.</p>
        </div>` : `
        <div class="drill-question-card" style="max-width:560px;margin-top:14px;">
          <p style="margin:0 0 10px;font-weight:600;">${escapeHtml(challenge.story)}</p>
          <div class="drill-question-text" style="font-size:1.2rem;">${escapeHtml(challenge.prompt)}</div>
          <input id="dcAnswerInput" class="drill-answer-input" placeholder="${challenge.type === "decimal" ? "e.g. 4.50" : "your answer in pesos"}" autocomplete="off" />
          <div style="margin-top:16px;"><button class="btn-primary" onclick="submitDailyChallenge()">Submit Answer</button></div>
          <div id="dcFeedback" class="drill-feedback"></div>
        </div>`}
    </div>`;

  if (!completion) {
    const input = document.getElementById("dcAnswerInput");
    if (input) { input.focus(); input.addEventListener("keydown", (ev) => { if (ev.key === "Enter") submitDailyChallenge(); }); }
    attachNumericKeypad("dcAnswerInput", { type: challenge.type === "decimal" ? "decimal" : "integer" });
    window._dcCurrentChallenge = challenge;
  }
}

async function submitDailyChallenge() {
  const challenge = window._dcCurrentChallenge;
  const input = document.getElementById("dcAnswerInput");
  const feedback = document.getElementById("dcFeedback");
  const raw = input ? input.value : "";

  if (checkChallengeAnswer(challenge, raw)) {
    const result = await completeDailyChallenge(DC_BASE_COINS);
    feedback.className = "drill-feedback correct";
    feedback.innerHTML = `✅ Correct! +${result.coinsAwarded} coins${result.multiplier > 1 ? " (2x power-up applied!)" : ""}${result.newPowerup ? " · 🎉 New Power-Up unlocked!" : ""}`
      + `<div style="margin-top:6px;">⭐ +${result.starsEarned} MathLegends star${result.starsEarned === 1 ? "" : "s"}`
      + (result.rankResult.promoted ? ` · 🏅 Rank Up! You're now ${renderRankBadge(result.rankResult.tierObj)}!` : "")
      + `</div>`;
    if (input) input.disabled = true;
    renderTopbarStreakBadge();
    if (typeof triggerPetEvent === "function") {
      triggerPetEvent("DAILY_CHALLENGE_COMPLETE");
      if (result.rankResult.promoted) triggerPetEvent("RANK_UP");
    }
    setTimeout(() => renderChallengesTab(), 1600);
  } else {
    feedback.className = "drill-feedback wrong";
    feedback.innerHTML = `❌ ${escapeHtml(dcHint(challenge, raw))}`;
    if (typeof triggerPetEvent === "function") triggerPetEvent("QUESTION_WRONG");
  }
}
