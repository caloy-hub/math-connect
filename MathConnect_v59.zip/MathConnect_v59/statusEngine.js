// ============================================================================
// MathConnect — Consolidated Status Panel ("📋 Status")
// Pulls every engagement/progress signal (everything EXCEPT grades, which
// stay on their own Class Record / My Grades tabs) into one place, so a
// student or teacher can see it all at a glance instead of hunting across
// the Roster, Math Drills, Quest Mode, Challenges, and Boss Raids tabs.
//
// Covers: login frequency, Math Drill points, current MathLegends Rank,
// coins earned, Intelligent Learning status, stars earned (toward next
// rank), practice streak, Daily Challenge streak, Quest Mode status, plus
// Boss Raid record, equipped shop title, and account status.
//
// Depends on (must be loaded first): supabase-client.js (supabase,
// escapeHtml), rankEngine.js (rankTierByLevel, rankStarsToPromote,
// renderRankBadge), questEngine.js (QUEST_CHAPTERS, questChapterComplete) —
// on the student side these are already loaded for Drills/Quest; on the
// teacher side rankEngine.js and questEngine.js are loaded ahead of this
// file too (see teacher.html).
// Used by: student.js (tab "status"), teacher.js (tab "status").
// ============================================================================

const STATUS_DOMAINS = [
  { key: "addition", icon: "➕", name: "Addition" },
  { key: "subtraction", icon: "➖", name: "Subtraction" },
  { key: "multiplication", icon: "✖️", name: "Multiplication" },
  { key: "division", icon: "➗", name: "Division" },
  { key: "fractions", icon: "🍕", name: "Fractions" },
  { key: "decimals", icon: "💯", name: "Decimals" },
];
const STATUS_TIER_NAMES = { 1: "Easy", 2: "Medium", 3: "Hard", 4: "Expert" };

const STATUS_ACCOUNT_META = {
  active: { label: "Active", color: "#2E8F5B" },
  readonly: { label: "Read-only", color: "#C08552" },
  frozen: { label: "Paused", color: "#C0392B" },
};
function statusAccountMeta(accountStatus) {
  return STATUS_ACCOUNT_META[accountStatus] || STATUS_ACCOUNT_META.active;
}

// ---------------------------------------------------------------------------
// Streak math — reusable for both the general practice streak (which is
// already stored on student_engagement) and the Daily-Challenge-ONLY streak
// (computed fresh here from completion history, since the app only stores
// one combined streak today).
// ---------------------------------------------------------------------------
function statusPhDateString(offsetDays) {
  const d = new Date();
  if (offsetDays) d.setDate(d.getDate() + offsetDays);
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Manila" }); // "YYYY-MM-DD"
}

// dateStrings: array of "YYYY-MM-DD" strings, any order, duplicates OK.
// Returns { current, longest } counting consecutive Philippine-calendar days.
function computeStreakFromDates(dateStrings) {
  const sorted = Array.from(new Set(dateStrings || [])).sort(); // ascending
  if (sorted.length === 0) return { current: 0, longest: 0 };

  let longest = 1, run = 1;
  for (let i = 1; i < sorted.length; i++) {
    const diffDays = Math.round((new Date(sorted[i] + "T00:00:00") - new Date(sorted[i - 1] + "T00:00:00")) / 86400000);
    run = diffDays === 1 ? run + 1 : 1;
    longest = Math.max(longest, run);
  }

  const today = statusPhDateString(0), yesterday = statusPhDateString(-1);
  const lastDate = sorted[sorted.length - 1];
  let current = 0;
  if (lastDate === today || lastDate === yesterday) {
    current = 1;
    for (let i = sorted.length - 1; i > 0; i--) {
      const diffDays = Math.round((new Date(sorted[i] + "T00:00:00") - new Date(sorted[i - 1] + "T00:00:00")) / 86400000);
      if (diffDays === 1) current++; else break;
    }
  }
  return { current, longest };
}

function statusAvgMastery(skillProficiency) {
  if (!skillProficiency) return null;
  const vals = STATUS_DOMAINS.map((d) => skillProficiency[d.key] || 0);
  return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
}

function statusQuestChaptersCompleted(quest) {
  if (!quest || typeof QUEST_CHAPTERS === "undefined") return 0;
  return QUEST_CHAPTERS.filter((c) => questChapterComplete(quest.level_stars || {}, c.key)).length;
}
function statusQuestChaptersTotal() {
  return typeof QUEST_CHAPTERS !== "undefined" ? QUEST_CHAPTERS.length : 12;
}

// Pet status is purely presentational here (same growth-stage math pet-ui.js
// uses) — requires petEngine.js to be loaded first for PET_TYPE_META /
// petGrowthStage / petDisplayForm / petLiveHunger / petHungerLabel.
// `petRows` is ALL of a student's student_pets rows. Since migration-35 a
// student can own MULTIPLE living pets at once (once each earlier one
// reaches Legendary), so this surfaces whichever living pet most needs a
// teacher's attention — resting first, then sick, then still-growing, falling back to
// the first — and reports counts so a sick 2nd/3rd pet is never hidden
// behind a healthy 1st one.
const STATUS_WAKE_REASONS = {
  forgot: { icon: "😴", label: "forgot" }, internet: { icon: "📶", label: "no internet / load" },
  busy: { icon: "📚", label: "busy with other things" }, hard: { icon: "😕", label: "math felt hard" },
};
function statusPetInfo(petRows) {
  const rows = petRows || [];
  if (!rows.length) return { adopted: false, everAdopted: false, adoptionsUsed: 0 };
  const aliveRows = rows.filter((p) => p.alive);
  const adoptionsUsed = rows.length;
  if (!aliveRows.length) {
    const last = rows[rows.length - 1];
    return { adopted: false, everAdopted: true, adoptionsUsed, dead: true, name: last.pet_name, died_at: last.died_at, cause_of_death: last.cause_of_death };
  }
  const peakThreshold = typeof PEAK_GROWTH_THRESHOLD !== "undefined" ? PEAK_GROWTH_THRESHOLD : 5000;
  const isPeak = (p) => (p.growth_points || 0) >= peakThreshold;
  const pet = aliveRows.find((p) => p.resting) || aliveRows.find((p) => p.sick) || aliveRows.find((p) => !isPeak(p)) || aliveRows[0];
  const meta = (typeof PET_TYPE_META !== "undefined" && PET_TYPE_META[pet.pet_type_key]) || { icon: "🐾" };
  const stage = typeof petGrowthStage === "function" ? petGrowthStage(pet.growth_points) : { label: "—" };
  const form = typeof petDisplayForm === "function" ? petDisplayForm(pet.pet_type_key, stage.label) : { icon: meta.icon };
  const hunger = isPeak(pet) ? 100 : (typeof petLiveHunger === "function" ? petLiveHunger(pet) : (pet.hunger || 0));
  const hungerInfo = typeof petHungerLabel === "function" ? petHungerLabel(hunger) : { label: "—", color: "var(--ink-soft)" };
  return {
    adopted: true, everAdopted: true, adoptionsUsed, icon: form.icon, image: form.image || null, name: pet.pet_name || null, typeKey: pet.pet_type_key,
    stageLabel: stage.label, growthPoints: pet.growth_points || 0, hunger, hungerInfo, sick: pet.sick && !pet.resting, resting: !!pet.resting, restedSince: pet.rested_since || null, wakeCount: pet.wake_count || 0, peak: isPeak(pet),
    adoptedAt: pet.adopted_at || null,
    petCount: aliveRows.length, sickCount: aliveRows.filter((p) => p.sick && !p.resting).length, restingCount: aliveRows.filter((p) => p.resting).length, peakCount: aliveRows.filter(isPeak).length,
  };
}

// Boss Raids are team fights, so a student's record is just raids won / lost
// (there are no draws). Rows are boss_raid_members joined to their finished
// raid: { student_id, correct_count, raid: { status: 'won' | 'lost' } }.
// The result keeps the old { played, wins, losses, draws } shape so every
// screen that reads it keeps working; draws is always 0.
function statusTallyBattles(raidRows) {
  let wins = 0, losses = 0;
  (raidRows || []).forEach((r) => {
    if (!r.raid) return;
    if (r.raid.status === "won") wins++;
    else if (r.raid.status === "lost") losses++;
  });
  return { played: wins + losses, wins, losses, draws: 0 };
}

// Assembles the full status object from raw rows — shared by both the
// single-student and whole-class fetchers below so the shape never drifts.
function statusAssemble({ student, drillProg, engagement, quest, learning, dcDates, battleRows, studentId, pet }) {
  const tier = rankTierByLevel((drillProg && drillProg.mastery_tier) || 1);
  const stars = (drillProg && drillProg.mastery_stars) || 0;
  return {
    login: { count: (student && student.login_count) || 0, lastLogin: (student && student.last_login_at) || null },
    accountStatus: (student && student.account_status) || "active",
    drillPoints: (drillProg && drillProg.total_points) || 0,
    rank: { tier, stars, starsNeeded: rankStarsToPromote(tier.level) },
    coins: (engagement && engagement.coins) || 0,
    activeTitle: (engagement && engagement.active_title) || null,
    streak: { current: (engagement && engagement.current_streak) || 0, longest: (engagement && engagement.longest_streak) || 0 },
    dailyChallengeStreak: computeStreakFromDates(dcDates),
    intelligentLearning: {
      avgMastery: statusAvgMastery(learning && learning.skill_proficiency),
      domains: STATUS_DOMAINS.map((d) => ({
        ...d,
        tier: (learning && learning.adaptive_levels && learning.adaptive_levels[d.key]) || 1,
        mastery: (learning && learning.skill_proficiency && learning.skill_proficiency[d.key]) || 0,
      })),
    },
    questMode: {
      chaptersUnlocked: (quest && quest.chapters_unlocked) || 1,
      chaptersTotal: statusQuestChaptersTotal(),
      chaptersCompleted: statusQuestChaptersCompleted(quest),
      totalStars: (quest && quest.total_stars) || 0,
    },
    battles: statusTallyBattles(battleRows),
    pet: statusPetInfo(pet),
  };
}

// ---------------------------------------------------------------------------
// SINGLE STUDENT — the student's own "📋 My Status" tab.
// ---------------------------------------------------------------------------
async function fetchOwnFullStatus(studentId) {
  const [
    { data: student },
    { data: drillProg },
    { data: engagement },
    { data: quest },
    { data: learning },
    { data: dcRows },
    { data: battleRows },
    { data: pet },
  ] = await Promise.all([
    supabase.from("students").select("login_count, last_login_at, account_status").eq("id", studentId).maybeSingle(),
    supabase.from("drill_progress").select("total_points, mastery_tier, mastery_stars").eq("student_id", studentId).maybeSingle(),
    supabase.from("student_engagement").select("coins, current_streak, longest_streak, active_title").eq("student_id", studentId).maybeSingle(),
    supabase.from("quest_progress").select("chapters_unlocked, total_stars, level_stars").eq("student_id", studentId).maybeSingle(),
    supabase.from("learning_engine_state").select("skill_proficiency, adaptive_levels").eq("student_id", studentId).maybeSingle(),
    supabase.from("daily_challenge_completions").select("challenge_date").eq("student_id", studentId),
    supabase.from("boss_raid_members").select("student_id, correct_count, raid:raid_id!inner(status)")
      .eq("student_id", studentId).in("raid.status", ["won", "lost"]),
    supabase.from("student_pets").select("*").eq("student_id", studentId).order("adoption_number"),
  ]);

  return statusAssemble({
    student, drillProg, engagement, quest, learning, studentId, pet,
    dcDates: (dcRows || []).map((r) => r.challenge_date),
    battleRows,
  });
}

// ---------------------------------------------------------------------------
// WHOLE CLASS — the teacher's "📋 Status" tab (batches one query per table
// instead of one per student, so a 40-student roster still loads fast).
// ---------------------------------------------------------------------------
async function fetchClassFullStatus(students) {
  const ids = students.map((s) => s.id);
  const out = {};
  if (!ids.length) return out;

  const [
    { data: drillRows },
    { data: engagementRows },
    { data: questRows },
    { data: learningRows },
    { data: dcRows },
    { data: battleRows },
    { data: petRows },
  ] = await Promise.all([
    supabase.from("drill_progress").select("student_id, total_points, mastery_tier, mastery_stars").in("student_id", ids),
    supabase.from("student_engagement").select("student_id, coins, current_streak, longest_streak, active_title").in("student_id", ids),
    supabase.from("quest_progress").select("student_id, chapters_unlocked, total_stars, level_stars").in("student_id", ids),
    supabase.from("learning_engine_state").select("student_id, skill_proficiency, adaptive_levels").in("student_id", ids),
    // v46: these two grow without bound (one row per student per day / per
    // battle) so a bare select() silently stopped at ~1,000 rows and understated
    // Daily-Challenge streaks and W-L records for the whole class. Page them.
    fetchAllRowsChecked(() => supabase.from("daily_challenge_completions").select("student_id, challenge_date").in("student_id", ids)),
    fetchAllRowsChecked(() => supabase.from("boss_raid_members").select("student_id, correct_count, raid:raid_id!inner(status)")
      .in("student_id", ids).in("raid.status", ["won", "lost"])),
    supabase.from("student_pets").select("*").in("student_id", ids),
  ]);

  // Recompute wellbeing (hunger decay -> sickness -> resting) for every
  // currently-alive pet in the class in parallel, so the teacher's Status
  // tab shows accurate sick/resting states even for students who
  // haven't opened the app today — matches what loadMyPets() does on the
  // student side (see checkPetWellbeing() in petEngine.js). Peak
  // (Legendary) pets are skipped server-side — they're immune — so this
  // is only ever meaningful for still-growing pets.
  const alivePets = (petRows || []).filter((p) => p.alive);
  if (alivePets.length && typeof supabase.rpc === "function") {
    // supabase.rpc() returns a "thenable" query builder, not always a real
    // Promise — it supports await/.then but isn't guaranteed to have
    // .catch(), so chaining .catch() directly on it can throw synchronously.
    // Wrapping each call in a real async function makes try/catch reliable.
    const safeCheckWellbeing = async (studentId) => {
      try {
        return await supabase.rpc("check_pet_wellbeing", { target_student_id: studentId });
      } catch (e) {
        return null;
      }
    };
    const results = await Promise.all(alivePets.map((p) => safeCheckWellbeing(p.student_id)));
    results.forEach((res, i) => {
      const row = res && (Array.isArray(res.data) ? res.data[0] : res.data);
      if (!row) return;
      const pet = alivePets[i];
      if (row.resting) { pet.resting = true; pet.sick = false; if (!pet.rested_since) pet.rested_since = new Date().toISOString(); }
      else pet.sick = row.sick;
    });
  }

  const byId = (rows) => { const m = {}; (rows || []).forEach((r) => (m[r.student_id] = r)); return m; };
  const drillById = byId(drillRows), engById = byId(engagementRows), questById = byId(questRows), learnById = byId(learningRows);
  const petsByStudent = {};
  (petRows || []).forEach((p) => { (petsByStudent[p.student_id] = petsByStudent[p.student_id] || []).push(p); });

  const dcDatesByStudent = {};
  (dcRows || []).forEach((r) => { (dcDatesByStudent[r.student_id] = dcDatesByStudent[r.student_id] || []).push(r.challenge_date); });

  const battlesByStudent = {};
  ids.forEach((id) => (battlesByStudent[id] = []));
  (battleRows || []).forEach((b) => { if (battlesByStudent[b.student_id]) battlesByStudent[b.student_id].push(b); });

  // Latest "what got in the way" answer from each student's most recent pet wake-up
  // (migration-55). Shown to the teacher as a signal for support, never a mark.
  // Quietly skipped if that migration hasn't been run yet.
  const lastWakeByStudent = {};
  const wakeRes = await fetchAllRowsChecked(() => supabase.from("pet_wake_log").select("student_id, reason, woke_at").in("student_id", ids));
  (wakeRes.data || []).forEach((w) => {
    if (!w.reason || w.reason === "skip") return;
    const cur = lastWakeByStudent[w.student_id];
    if (!cur || w.woke_at > cur.at) lastWakeByStudent[w.student_id] = { at: w.woke_at, ...(STATUS_WAKE_REASONS[w.reason] || { icon: "•", label: w.reason }) };
  });

  students.forEach((s) => {
    out[s.id] = statusAssemble({
      student: s, // state.students rows already come from select("*")
      drillProg: drillById[s.id], engagement: engById[s.id], quest: questById[s.id], learning: learnById[s.id],
      dcDates: dcDatesByStudent[s.id] || [], battleRows: battlesByStudent[s.id], studentId: s.id, pet: petsByStudent[s.id],
    });
    if (out[s.id].pet && out[s.id].pet.adopted && lastWakeByStudent[s.id]) out[s.id].pet.lastWake = lastWakeByStudent[s.id];
  });
  return out;
}

// ---------------------------------------------------------------------------
// STUDENT-SIDE RENDER — "📋 My Status" tab
// ---------------------------------------------------------------------------
function statusStatCard(icon, label, value, sub) {
  return `
    <div class="card" style="text-align:center;">
      <div style="font-size:1.5rem;">${icon}</div>
      <div class="muted" style="font-size:.72rem;margin-top:4px;">${label}</div>
      <div style="font-size:1.3rem;font-weight:700;font-family:'Poppins';margin-top:2px;">${value}</div>
      ${sub ? `<div class="muted" style="font-size:.68rem;margin-top:2px;">${sub}</div>` : ""}
    </div>`;
}

async function renderStatusPanel() {
  const el = document.getElementById("tab-status");
  if (!el) return;
  el.innerHTML = `<div class="empty">Loading your status…</div>`;
  await loadPetCatalog(); // so 🐾 Pet's hunger/decay math has vitamin/equipment rates to work with — always refreshed, not just cached-once
  const st = await fetchOwnFullStatus(sstate.student.id);
  const acct = statusAccountMeta(st.accountStatus);

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;border-left:4px solid ${st.rank.tier.color};">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:14px;">
        <div>
          <div class="muted">🏅 Current Rank</div>
          <div style="margin-top:6px;">${renderRankBadge(st.rank.tier, { withStars: true, stars: st.rank.stars })}</div>
        </div>
        ${st.activeTitle ? `<div style="text-align:right;"><div class="muted" style="font-size:.72rem;">🏷️ Equipped Title</div><strong>${escapeHtml(st.activeTitle)}</strong></div>` : ""}
        <div style="text-align:right;">
          <div class="muted" style="font-size:.72rem;">Account Status</div>
          <span class="badge" style="background:${acct.color}22;color:${acct.color};">${acct.label}</span>
        </div>
      </div>
    </div>

    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;">
      ${statusStatCard("🔑", "Login Frequency", st.login.count, st.login.lastLogin ? `Last: ${new Date(st.login.lastLogin).toLocaleDateString()}` : "No logins yet")}
      ${statusStatCard("🏆", "Math Drill Points", st.drillPoints)}
      ${statusStatCard("🪙", "Coins Earned", st.coins)}
      ${statusStatCard("⭐", "Stars Earned", st.rank.starsNeeded != null ? `${st.rank.stars}/${st.rank.starsNeeded}` : `${st.rank.stars}`, st.rank.starsNeeded != null ? "toward next rank" : "MAX RANK")}
      ${statusStatCard("🔥", "Streak", `${st.streak.current}d`, `Longest: ${st.streak.longest}d`)}
      ${statusStatCard("🎯", "Daily Challenge Streak", `${st.dailyChallengeStreak.current}d`, `Longest: ${st.dailyChallengeStreak.longest}d`)}
      ${statusStatCard("🧠", "Intelligent Learning", st.intelligentLearning.avgMastery != null ? `${st.intelligentLearning.avgMastery}%` : "—", "avg. mastery, all domains")}
      ${statusStatCard("🗺️", "Quest Mode", `${st.questMode.chaptersCompleted}/${st.questMode.chaptersTotal}`, `chapters cleared · ⭐ ${st.questMode.totalStars}`)}
      ${statusStatCard("🐉", "Boss Raids", `${st.battles.wins}-${st.battles.losses}`, `${st.battles.played} fought (won-lost)`)}
    </div>

    <div class="card" style="margin-top:16px;">
      <h3 style="margin-top:0;">🧠 Intelligent Learning — by domain</h3>
      <table>
        <thead><tr><th>Domain</th><th>Tier</th><th>Mastery</th></tr></thead>
        <tbody>
          ${st.intelligentLearning.domains.map((d) => `
            <tr>
              <td>${d.icon} ${d.name}</td>
              <td>${STATUS_TIER_NAMES[d.tier] || d.tier}</td>
              <td style="min-width:160px;">
                <div class="gbar" style="margin:0;"><div style="width:${d.mastery}%;"></div></div>
                <span class="muted" style="font-size:.72rem;">${d.mastery}%</span>
              </td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>
    <p class="muted" style="margin-top:10px;font-size:.78rem;">Everything here except grades — see 📊 My Grades for your grade breakdown.</p>`;
}

// ---------------------------------------------------------------------------
// TEACHER-SIDE RENDER — "📋 Status" tab (consolidated ranking table)
// ---------------------------------------------------------------------------
var statusSortKey = "rank";
const STATUS_SORTERS = {
  rank: (a, b) => b.st.rank.tier.level - a.st.rank.tier.level || b.st.rank.stars - a.st.rank.stars || b.st.drillPoints - a.st.drillPoints,
  points: (a, b) => b.st.drillPoints - a.st.drillPoints,
  coins: (a, b) => b.st.coins - a.st.coins,
  streak: (a, b) => b.st.streak.current - a.st.streak.current,
  quest: (a, b) => b.st.questMode.totalStars - a.st.questMode.totalStars,
  learning: (a, b) => (b.st.intelligentLearning.avgMastery || 0) - (a.st.intelligentLearning.avgMastery || 0),
  pet: (a, b) => (b.st.pet.adopted ? b.st.pet.growthPoints : -1) - (a.st.pet.adopted ? a.st.pet.growthPoints : -1),
};

async function renderTeacherStatus() {
  const el = document.getElementById("tab-status");
  if (!el) return;
  if (typeof pstate !== "undefined") await loadPetCatalog(); // so 🐾 Pet's hunger/decay math has vitamin/equipment rates to work with — always refreshed, not just cached-once
  if (!state._statusById) {
    el.innerHTML = `<div class="empty">Loading class status…</div>`;
    state._statusById = await fetchClassFullStatus(state.students);
  }
  el.innerHTML = teacherStatusHtml(state._statusById);
}

function statusSetSort(v) { statusSortKey = v; renderTeacherStatus(); }

function teacherStatusHtml(statusById) {
  const rows = state.students.map((s) => ({ s, st: statusById[s.id] })).filter((r) => r.st);
  rows.sort(STATUS_SORTERS[statusSortKey] || STATUS_SORTERS.rank);

  return `
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px;">
        <h3 style="margin:0;">📋 Consolidated Status &amp; Ranking — ${rows.length} student(s)</h3>
        <div>
          <label class="muted" style="font-size:.78rem;margin-right:6px;">Rank by</label>
          <select onchange="statusSetSort(this.value)" style="width:auto;display:inline-block;">
            <option value="rank" ${statusSortKey === "rank" ? "selected" : ""}>🏅 MathLegends Rank</option>
            <option value="points" ${statusSortKey === "points" ? "selected" : ""}>🏆 Drill Points</option>
            <option value="coins" ${statusSortKey === "coins" ? "selected" : ""}>🪙 Coins</option>
            <option value="streak" ${statusSortKey === "streak" ? "selected" : ""}>🔥 Streak</option>
            <option value="quest" ${statusSortKey === "quest" ? "selected" : ""}>🗺️ Quest Stars</option>
            <option value="learning" ${statusSortKey === "learning" ? "selected" : ""}>🧠 Learning Mastery</option>
            <option value="pet" ${statusSortKey === "pet" ? "selected" : ""}>🐾 Pet Growth</option>
          </select>
        </div>
      </div>
      ${rows.length === 0 ? `<div class="empty">No students yet.</div>` : `
      <div style="overflow-x:auto;">
      <table>
        <thead><tr>
          <th>#</th><th>Student</th><th>🏅 Rank</th><th class="num">🏆 Drill Pts</th><th class="num">🪙 Coins</th>
          <th class="num">🔥 Streak</th><th class="num">🎯 DC Streak</th><th class="num">🔑 Logins</th>
          <th class="num">🧠 IL Mastery</th><th class="num">🗺️ Quest</th><th class="num">🐉 Raids W-L</th>
          <th>🐾 Pet</th><th>🏷️ Title</th><th>Account</th>
        </tr></thead>
        <tbody>
          ${rows.map(({ s, st }, i) => {
            const acct = statusAccountMeta(st.accountStatus);
            return `
            <tr>
              <td class="num">${i + 1}</td>
              <td><strong>${escapeHtml(displayName(s))}</strong></td>
              <td>${renderRankBadge(st.rank.tier, { size: "small" })}</td>
              <td class="num">${st.drillPoints}</td>
              <td class="num">${st.coins}</td>
              <td class="num">${st.streak.current}d</td>
              <td class="num">${st.dailyChallengeStreak.current}d</td>
              <td class="num">${st.login.count}${st.login.lastLogin ? `<br><span class="muted" style="font-size:.66rem;">${new Date(st.login.lastLogin).toLocaleDateString()}</span>` : ""}</td>
              <td class="num">${st.intelligentLearning.avgMastery != null ? st.intelligentLearning.avgMastery + "%" : "—"}</td>
              <td class="num">${st.questMode.chaptersCompleted}/${st.questMode.chaptersTotal} <span class="muted" style="font-size:.66rem;">⭐${st.questMode.totalStars}</span></td>
              <td class="num">${st.battles.wins}-${st.battles.losses}</td>
              <td>${statusPetCell(st.pet)}</td>
              <td>${st.activeTitle ? escapeHtml(st.activeTitle) : `<span class="muted">—</span>`}</td>
              <td><span class="badge" style="background:${acct.color}22;color:${acct.color};">${acct.label}</span></td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>
      </div>`}
      <p class="muted" style="margin-top:12px;font-size:.78rem;">Everything here except grades — see 📊 Class Record for grades. Click "Rank by" to re-sort the whole class by any metric.</p>
      ${petAdoptionSummaryHtml(rows)}
    </div>`;
}

/** Renders one student's 🐾 Pet cell: name/type + evolution stage + a hunger
 *  dot for a living pet (😴 if it is resting); a 🕊️ note for a pet lost before v49; or a
 *  muted "No pet" if they've never adopted one. */
function statusPetCell(pet) {
  if (!pet || !pet.everAdopted) return `<span class="muted">— No pet</span>`;
  if (!pet.adopted) {
    return `
      <div style="white-space:nowrap;">
        <span style="font-size:1.1rem;opacity:.6;">🕊️</span>
        <strong style="color:var(--clay);">${escapeHtml(pet.name || "Unnamed")}</strong>
        <div class="muted" style="font-size:.66rem;">Passed away${pet.cause_of_death === "untreated_illness" ? " (untreated illness)" : pet.cause_of_death === "starvation" ? " (neglect)" : ""} · ${pet.adoptionsUsed} adopted so far</div>
      </div>`;
  }
  const badge = (typeof PET_STAGE_BADGE !== "undefined" && PET_STAGE_BADGE[pet.stageLabel]) || "";
  const hungerColor = pet.hungerInfo ? pet.hungerInfo.color : "var(--ink-soft)";
  const moreCount = (pet.petCount || 1) - 1;
  return `
    <div style="white-space:nowrap;">
      ${pet.image
        ? `<img src="${pet.image}" alt="Legendary pet" style="height:1.4rem;width:auto;max-width:1.9rem;object-fit:contain;vertical-align:-3px;">`
        : `<span style="font-size:1.1rem;">${pet.icon}</span>`}
      <strong>${escapeHtml(pet.name || "Unnamed")}</strong> ${badge}${pet.resting ? " 😴" : pet.sick ? " 🤒" : ""}${moreCount > 0 ? ` <span class="muted" style="font-size:.66rem;">+${moreCount} more${pet.sickCount > 1 ? `, ${pet.sickCount} sick` : ""}</span>` : ""}
      <div class="muted" style="font-size:.68rem;">${escapeHtml(pet.stageLabel)} · ${pet.growthPoints} pts</div>
      <div style="font-size:.66rem;color:${pet.resting ? "#4B5680" : pet.sick ? "var(--clay)" : hungerColor};">● ${pet.resting ? "Resting — needs a Wake-up Warm-up" : pet.sick ? "Sick — needs a vaccine" : (pet.peak ? "Immune (Legendary)" : (pet.hungerInfo ? pet.hungerInfo.label : ""))}</div>
      ${pet.lastWake ? `<div class="muted" style="font-size:.64rem;">Last wake-up: ${pet.lastWake.icon} ${escapeHtml(pet.lastWake.label)}</div>` : ""}
    </div>`;
}

/** Small roll-up card above/below the table: how many of the class have ever
 *  adopted a pet, how many have a living one right now and where they land
 *  across evolution stages, and how many are resting or were lost — the "who's
 *  adopted, what status" view at a glance. */
function petAdoptionSummaryHtml(rows) {
  if (!rows.length) return "";
  const everAdopted = rows.filter((r) => r.st.pet.everAdopted);
  const living = rows.filter((r) => r.st.pet.adopted);
  const dead = rows.filter((r) => r.st.pet.everAdopted && !r.st.pet.adopted);
  const sick = living.filter((r) => r.st.pet.sick);
  const resting = living.filter((r) => r.st.pet.resting);
  const byStage = {};
  living.forEach((r) => { const k = r.st.pet.stageLabel; byStage[k] = (byStage[k] || 0) + 1; });
  const stageOrder = (typeof PET_GROWTH_STAGES !== "undefined" ? PET_GROWTH_STAGES.map((s) => s.label) : Object.keys(byStage));
  return `
    <div class="card" style="margin-top:14px;background:var(--sage-light,#EAF0EA);">
      <h4 style="margin:0 0 8px;">🐾 Pet Adoption — ${everAdopted.length}/${rows.length} student(s) have adopted a pet</h4>
      <div class="muted" style="font-size:.8rem;margin-bottom:8px;">${living.length} living${sick.length ? `, ${sick.length} 🤒 sick` : ""}${resting.length ? `, ${resting.length} 😴 resting` : ""}${dead.length ? `, ${dead.length} 🕊️ lost before pets could rest (see migration 58)` : ""}.</div>
      ${living.length ? `
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
          ${stageOrder.filter((label) => byStage[label]).map((label) => `
            <span class="badge" style="background:#fff;color:var(--ink);">${label}: ${byStage[label]}</span>`).join("")}
        </div>` : `<p class="muted" style="margin:0;font-size:.82rem;">No one has a living pet right now — they can adopt for free in the 🛒 Rewards Shop.</p>`}
    </div>`;
}
