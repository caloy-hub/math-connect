# MathConnect v49 — kinder pets, real "Most Improved", Shout-outs

## Deploy
Run in the Supabase SQL Editor, in this order (each is safe to re-run; they don't depend on each other except 58 needs 55):
1. `migration-55-pets-rest-not-die.sql`   — pets rest instead of dying, Wake-up, Care Promise
2. `migration-56-weekly-improvement.sql`  — Most Improved + My Week
3. `migration-57-shoutouts.sql`           — Shout-outs
4. *(optional)* `migration-58-revive-passed-pets.sql` — bring back pets lost before v49

Then upload the files (service worker bumped to `mathconnect-v49-1`). Until a migration is run, its feature is
simply absent (the panel stays hidden, the My Week card doesn't show); nothing breaks.

---

## 1. 😬 BOKYA removed
The Mystery Box no longer takes points away. Odds are now: bonus 40%, jackpot 12%, pet snack 20%, coins 18%,
gemstone shard 6%, empty box 4%. (Wrong-answer point penalties in drills are unchanged — you only asked about Bokya.)

## 2. 🐾 Pets no longer die — responsibility through repair
**Before:** sick for 36 h untreated or empty for 108 h ⇒ permanent death.
**Now:** the same clocks apply, but the pet **falls asleep** ("resting"). Name, growth, items, mentor links are all kept.
- **Wake-up Warm-up:** 5 gentle questions (Level 1–2, five different open stations), get 3 right. Unlimited tries, no timer,
  no penalty — coming back is a small, winnable dose of math.
- **"What got in the way?"** — 😴 I forgot · 📶 no internet/load · 📚 busy · 😕 math felt hard · 🤐 rather not say.
  Framed as *not a punishment*. Teachers see the latest answer next to the pet in the Status tab (a signal for support,
  e.g. "no internet" or "math felt hard"), never a mark.
- **🎗️ Care Promise:** each week the student chooses to visit their pet on 2–7 days (feeding counts). It can be raised but
  not lowered, shows dots that fill as they go, and a lifetime **promises kept** total with Bronze/Silver/Gold caretaker
  ribbons at 1/4/8. It is a running total, not a streak — a missed week never erases it.
- Legendary and Gemstone-shielded pets are unchanged. Feeding buttons are hidden while a pet sleeps.
- Teacher Status tab: 😴 Resting (with the wake-up reason) replaces "passed away".
- Pets lost **before** this update: migration 58 (optional) revives each pet-less student's most recent pet, asleep.
  Students who already adopted again are untouched.

## 3. 📈 "Most Improved" now measures improvement
The old board ranked points earned in 7 days — really "who played most".
**Progress points** = 1 per accuracy percentage point above *your own usual* (max +30; needs 20+ answers this week and a
usual to compare with — the previous 28 days, else earlier history) **+ 5 per level climbed** (max 4).
- Rows show the real numbers: `accuracy +14 pts (58% → 72%) · 🪜 +2 levels · 📅 4 days · 🌟 24`.
- Nobody is ever shown a negative number. Not-yet-improving students aren't listed.
- 🌱 **New starters** and 🔁 **comebacks** are celebrated in their own unranked, unscored list (so it can't be gamed).
- Respects "Show me on leaderboards"; grade-level scope, Monday–Sunday in Asia/Manila; **This week / Last week** toggle.
- **📈 My Week** card at the top of the Drills hub for every student: questions, accuracy, days, level-ups, vs their usual,
  vs last week, strongest station, rank — only ever framed as growth ("Your usual is about 60%. New topics can feel harder
  before they click — keep going" instead of a lower number).
- Teacher → Math Drills → **Weekly Progress**: every student, same numbers, plus 🌟 worth celebrating and 💬 might like
  a check-in (nothing played, or well below their usual — supportive wording, teacher-only).

## 4. 🌟 Shout-outs (the live side panel)
A 💬 button opens a panel that slides in from the right, out of the way of drills (it hides itself during Boss Raid fights).
- **Give a shout-out:** pick a classmate, pick what they did — 🤝 helped me understand · 👥 great teammate · 💪 never gave up ·
  📈 improving so fast · 💡 clever way to solve it · 💛 was kind to me. Others can react 👏 🔥 🌟.
- **Live:** new shout-outs, reactions and moderation appear on classmates' screens within a second (Realtime broadcast
  pings), with a 30 s poll (10 s while open) as a safety net. A shout-out for you gives a toast, a badge and a pulsing button.
- After a Boss Raid: one-tap **👏 Thank a teammate** (own-class teammates only, optional).
- **It's a wall of appreciation, not a free chat** — deliberately, because the users are minors: no private messages, no open
  replies, no links or images, **no points/coins/streaks** (so it stays voluntary and sincere).
- **Teacher controls per section (Shout-outs tab):** Off · Kinds of thanks only *(default)* · Kinds + a short 80-character
  message that must pass a filter (no links, contact details, insults or profanity in English/Filipino/Bisaya — a first line
  of defence, not a guarantee). Sees everything with full names, can Hide / Restore / Delete, sees what students reported,
  and sees **who hasn't received one yet this week** (private) so quieter classmates can be noticed.
- **Safety in the database:** limits of 5 per student per day, 1 per classmate per day, 4 s apart; students can only reach their
  own section; **two different reports auto-hide a shout-out for everyone** until the teacher reviews it; paused accounts can't
  send. The tables have *no* direct student access — only the functions can read/write (stricter than the rest of the app).

## Tested
- **Postgres (pglite), each migration applied twice:** 55 — 25 checks (old death rules → resting, peak/gem immunity, no pet can
  die, wake rules, wrong-owner/short-score refusals, promise raise-not-lower, kept-total maths); 56 — 22 checks (baseline
  choice, caps, minimum answers, opt-out, other grade, no negatives, week boundaries, last-week view, teacher gating);
  57 — 35 checks (modes, filter blocks leetspeak/spaced/stretched insults and links/phone numbers yet allows "class",
  "pass", "animal", limits, cross-section isolation, reactions, 2-report auto-hide, teacher moderation, RLS shows a student
  **zero rows**); 58 — selection rules.
- **Real DOM (jsdom):** pets — resting card, full warm-up flow incl. retry, wake call, promise states, no scary wording (24);
  My Week + board (18); teacher weekly card (8); shout-outs **end-to-end with three student UIs and a teacher panel on the real
  database and a fake broadcast bus (30)**; raid thank row (5). All earlier suites still pass.
- **Not tested:** on your live Supabase project, real Realtime broadcast delivery (the poll covers a missed ping), or on
  phones. The profanity filter can't be exhaustive — please read the first weeks of any section you set to "short message".
  Please try each with a test class before students see it.

## Things I'd like you to decide
1. Are the Filipino/Bisaya filter words right for your students (`_shoutout_text_problem` in migration 57)? Add or remove freely.
2. Should shout-outs be enabled for every section, or only Mathematics? (Right now: every section, teacher can switch it off.)
3. Wrong-answer point loss in drills is still there — say the word if you'd like that softened too.
