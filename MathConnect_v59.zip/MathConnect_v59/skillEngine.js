// ============================================================================
// MathConnect — Skill Proficiency Engine
// Owns the 0-100 mastery bar per domain. This is deliberately a DIFFERENT
// number from the arcade-style points in drills.js/drill_progress — mastery
// only grows from getting things right (first try or with effort on a
// retry), never from streak/speed/mystery-box bonuses, so it reads as a true
// "how much of this domain have you mastered" signal for the teacher.
// ============================================================================

// Points a fully-correct FIRST-try answer is worth, per tier. Higher tiers
// are worth more so the bar rewards tackling harder material, not just
// grinding easy questions.
const LE_BASE_POINTS_BY_TIER = { 1: 4, 2: 6, 3: 8, 4: 10 };
// A correct 2nd-try answer still earns effort credit — exactly 50% of what
// a clean first-try answer at that tier would have earned.
const LE_RETRY_CREDIT_RATIO = 0.5;

function basePointsForTier(tier) {
  return LE_BASE_POINTS_BY_TIER[Math.max(1, Math.min(4, tier || 1))];
}

function clampProficiency(v) {
  return Math.max(0, Math.min(100, Math.round(v)));
}

/**
 * updateSkillBar(currentProficiency, tier, isCorrect, attemptNumber)
 *  - currentProficiency: 0-100, the domain's mastery bar before this answer
 *  - tier: 1-4, the difficulty tier the question was asked at
 *  - isCorrect: whether THIS attempt was correct
 *  - attemptNumber: 1 (first try) or 2 (retry after an initial miss)
 *
 * Returns { newProficiency, pointsAwarded }.
 *   - Correct on attempt 1 -> full base points for that tier.
 *   - Correct on attempt 2 -> 50% of base points ("effort" credit — the
 *     Crucial Constraint from the spec).
 *   - Wrong (either attempt, when the run of attempts for this question
 *     ends in a miss) -> 0 points, bar unchanged. Mastery only grows on
 *     demonstrated correctness; it never goes down for a miss either — a
 *     bad day doesn't erase progress already earned.
 */
function updateSkillBar(currentProficiency, tier, isCorrect, attemptNumber) {
  const base = basePointsForTier(tier);
  let pointsAwarded = 0;

  if (isCorrect) {
    pointsAwarded = attemptNumber >= 2 ? Math.round(base * LE_RETRY_CREDIT_RATIO) : base;
  }

  const newProficiency = clampProficiency((currentProficiency || 0) + pointsAwarded);
  return { newProficiency, pointsAwarded };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { LE_BASE_POINTS_BY_TIER, LE_RETRY_CREDIT_RATIO, basePointsForTier, updateSkillBar };
}
