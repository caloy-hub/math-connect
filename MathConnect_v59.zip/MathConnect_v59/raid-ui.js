// ============================================================================
// MathConnect — Team Boss Raids: screens
// Hub (pick a boss / join a team) → Lobby (team assembles) → Fight (live
// boss, clock, your own questions) → Results. All game and network logic is in
// raidEngine.js; this file only draws state and reacts to clicks.
// The fight screen is built ONCE and then updated in place (HP bar, timer,
// team chips, question) — never re-rendered wholesale — so the keypad, the
// input focus and the animations survive the constant live updates.
// ============================================================================

const RAID_SCOPE_LABEL = { section: "My section", grade: "Whole grade" };
function raidEl() { return document.getElementById("tab-battle"); }
function raidFmtClock(ms) { const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; }
function raidFirstName(full) { return String(full || "Student").trim().split(/\s+/)[0]; }
function raidDiffChip(d) { const x = RAID_DIFFICULTIES[d] || RAID_DIFFICULTIES.normal; return `${x.icon} ${x.label}`; }

// ============================================================================
// HUB
// ============================================================================
async function renderRaidHub() {
  const el = raidEl();
  if (!el) return;
  // Coming back to this tab in the middle of a raid → reconnect to it.
  if (rstate.raid && rstate.raid.id) { enterRaid(rstate.raid.id); return; }
  rstate.screen = "hub";
  stopHubPolling();
  el.innerHTML = `<div class="empty">Summoning the bosses…</div>`;
  await Promise.all([
    dstate.loaded ? null : loadDrillProgress(),
    dstate.locksLoaded ? null : loadStationLocks(),
    loadRaidLobbies(), loadMyOpenRaid(), loadRaidCodex(),
  ]);
  if (rstate.screen !== "hub" || rstate.raid) return; // the student moved on while we loaded

  const codex = rstate.codex || {};
  const stationKeys = DRILL_TOPICS.map((t) => t.key);
  const defeated = stationKeys.filter((k) => codex[k]).length;
  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <h2 style="margin:0 0 4px;">🐉 Boss Raids</h2>
      <p class="muted" style="margin:0;">Team up with <strong>at least ${RAID_MIN_PLAYERS} classmates</strong> and take down a station's boss before the clock runs out.
        Every <strong>correct answer</strong> hurts the boss — every <strong>wrong answer heals it</strong>. Everyone answers at the same time, so the whole team fights at once!</p>
      ${sstate.readOnly ? `<p style="margin:10px 0 0;color:var(--clay);">⏸️ Your account is in read-only mode — raids are paused. See your teacher.</p>` : ""}
    </div>
    <div id="raidMyRaidBox"></div>
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px;">
        <h3 style="margin:0;">🚪 Open teams</h3>
        <span class="muted" style="font-size:.8rem;">Updates automatically</span>
      </div>
      <div id="raidLobbyList"></div>
    </div>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
        <div>
          <h3 style="margin:0;">⚔️ Start a raid</h3>
          <div class="muted" style="font-size:.85rem;">Bosses defeated: <strong>${defeated}/${stationKeys.length}</strong>${codex.mixed ? " · 👾 Grand Boss slain!" : ""}</div>
        </div>
        <div id="raidPrefs"></div>
      </div>
      <div class="raid-boss-grid" id="raidBossGrid"></div>
    </div>`;
  renderRaidPrefs(); renderRaidBossGrid(); renderRaidLobbyList(); renderRaidMyRaidBox();

  rstate.hubPollId = setInterval(async () => {
    if (rstate.screen !== "hub" || rstate.raid || !document.getElementById("raidLobbyList")) return;
    await Promise.all([loadRaidLobbies(), loadMyOpenRaid()]);
    renderRaidLobbyList(); renderRaidMyRaidBox();
  }, 5000);
}

function renderRaidMyRaidBox() {
  const box = document.getElementById("raidMyRaidBox");
  if (!box) return;
  const r = rstate.myOpenRaid;
  if (!r) { box.innerHTML = ""; return; }
  const b = raidBoss(r.topic);
  box.innerHTML = `
    <div class="card" style="margin-bottom:16px;border-left:4px solid var(--gold);display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
      <div><strong>${b.emoji} You're in a raid vs ${escapeHtml(b.name)}</strong>
        <div class="muted" style="font-size:.85rem;">${r.status === "active" ? "The fight is on — your team needs you!" : "Still gathering the team."}</div></div>
      <button class="btn btn-primary btn-sm" onclick="enterRaid('${r.id}')">${r.status === "active" ? "Rejoin the fight ⚔️" : "Back to the lobby"}</button>
    </div>`;
}

function renderRaidPrefs() {
  const box = document.getElementById("raidPrefs");
  if (!box) return;
  const p = rstate.prefs;
  const seg = (group, entries, current) => entries.map(([k, label]) =>
    `<div class="tab ${current === k ? "active" : ""}" style="padding:6px 12px;" onclick="setRaidPref('${group}','${k}')">${label}</div>`).join("");
  box.innerHTML = `
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
      <div class="tabs" style="margin:0;" title="Boss HP per player">${seg("difficulty", Object.entries(RAID_DIFFICULTIES).map(([k, d]) => [k, `${d.icon} ${d.label}`]), p.difficulty)}</div>
      <div class="tabs" style="margin:0;" title="Who can join">${seg("scope", [["section", "My section"], ["grade", `Whole ${escapeHtml(sstate.section.grade_level || "grade")}`]], p.scope)}</div>
    </div>
    <div class="muted" style="font-size:.78rem;margin-top:4px;text-align:right;">${RAID_DIFFICULTIES[p.difficulty].blurb} · boss HP ${RAID_DIFFICULTIES[p.difficulty].hpPerPlayer} × players</div>`;
}
function setRaidPref(group, value) { rstate.prefs[group] = value; renderRaidPrefs(); }

function renderRaidBossGrid() {
  const box = document.getElementById("raidBossGrid");
  if (!box) return;
  const codex = rstate.codex || {};
  const cards = DRILL_TOPICS.map((t) => ({ key: t.key, station: `${t.icon} ${t.name}`, locked: isStationLocked(t.key) }))
    .concat([{ key: "mixed", station: "🎲 Every station", locked: false }]);
  box.innerHTML = cards.map((c) => {
    const b = raidBoss(c.key), cx = codex[c.key];
    const disabled = c.locked || sstate.readOnly;
    return `
      <div class="raid-boss-card ${c.locked ? "locked" : ""} ${cx ? "beaten" : ""} ${c.key === "mixed" ? "grand" : ""}">
        <div class="raid-boss-card-emoji">${b.emoji}</div>
        <div class="raid-boss-card-name">${escapeHtml(b.name)}</div>
        <div class="muted" style="font-size:.78rem;">${escapeHtml(c.station)}</div>
        <div class="raid-boss-card-codex">${c.locked ? "🔒 Station locked" : cx ? `✅ Defeated ×${cx.wins} · best ${raidDiffChip(cx.best)}` : "Not defeated yet"}</div>
        <button class="btn btn-primary btn-sm" style="width:100%;margin-top:8px;" ${disabled ? "disabled" : ""}
          onclick="createRaid('${c.key}', rstate.prefs.difficulty, rstate.prefs.scope)">Assemble a team</button>
      </div>`;
  }).join("");
}

function renderRaidLobbyList() {
  const box = document.getElementById("raidLobbyList");
  if (!box) return;
  const list = rstate.lobbies.filter((l) => !(rstate.myOpenRaid && l.id === rstate.myOpenRaid.id));
  if (!list.length) { box.innerHTML = `<div class="empty">No open teams right now. Pick a boss below and start one — then tell your classmates to open <em>Boss Raids</em> and join you!</div>`; return; }
  box.innerHTML = list.map((l) => {
    const b = raidBoss(l.topic);
    const full = l.playerCount >= RAID_MAX_PLAYERS;
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--paper-line);flex-wrap:wrap;">
        <div>
          <div><span style="font-size:1.4rem;vertical-align:middle;">${b.emoji}</span> <strong>${escapeHtml(b.name)}</strong></div>
          <div class="muted" style="font-size:.82rem;">Host ${escapeHtml(raidFirstName(l.host && l.host.full_name))} · ${l.playerCount}/${RAID_MAX_PLAYERS} players · ${raidDiffChip(l.difficulty)} · ${RAID_SCOPE_LABEL[l.scope]}</div>
        </div>
        <button class="btn btn-primary btn-sm" ${full || sstate.readOnly ? "disabled" : ""} onclick="joinRaid('${l.id}')">${full ? "Full" : "Join ⚔️"}</button>
      </div>`;
  }).join("");
}

// ============================================================================
// LOBBY
// ============================================================================
function renderRaidLobby() {
  const el = raidEl();
  const r = rstate.raid;
  if (!el || !r || rstate.screen !== "lobby") return;
  const b = raidBoss(r.topic), d = RAID_DIFFICULTIES[r.difficulty] || RAID_DIFFICULTIES.normal;
  const n = rstate.members.length, ready = n >= RAID_MIN_PLAYERS, isHost = r.host_id === raidMe();
  el.innerHTML = `
    <div class="card" style="text-align:center;">
      <div class="raid-boss idle" style="font-size:4.4rem;">${b.emoji}</div>
      <h2 style="margin:4px 0;">${escapeHtml(b.name)}</h2>
      <div class="muted">${escapeHtml(raidTopicLabel(r.topic))} · ${raidDiffChip(r.difficulty)} · ${RAID_SCOPE_LABEL[r.scope]}</div>
      <p style="font-style:italic;margin:8px 0 0;">“${escapeHtml(b.taunt)}”</p>
      <div class="muted" style="margin-top:8px;font-size:.85rem;">Boss HP <strong>${d.hpPerPlayer * Math.max(n, RAID_MIN_PLAYERS)}</strong> with ${Math.max(n, RAID_MIN_PLAYERS)} players (${d.hpPerPlayer} per player) · <strong>4:00</strong> on the clock</div>
    </div>
    <div class="card" style="margin-top:12px;">
      <h3 style="margin:0 0 8px;">Your team (${n}/${RAID_MAX_PLAYERS})</h3>
      <div class="raid-team" style="margin-bottom:8px;">
        ${rstate.members.map((m) => `<div class="raid-chip ${m.student_id === raidMe() ? "me" : ""}">${m.is_host ? "👑 " : ""}${escapeHtml(raidFirstName(m.full_name))}</div>`).join("")}
      </div>
      <div class="muted" style="font-size:.85rem;">${ready ? "✅ Enough players to fight — more players make the boss stronger, but the team stronger too." : `⏳ Need at least ${RAID_MIN_PLAYERS} players to start — ${RAID_MIN_PLAYERS - n} more to go. Tell your classmates to open <em>Boss Raids</em> and tap Join!`}</div>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
        ${isHost
          ? `<button class="btn btn-primary" ${ready ? "" : "disabled"} onclick="startRaid()">Start the raid ⚔️</button>`
          : `<div class="muted" style="align-self:center;">Waiting for ${escapeHtml(raidFirstName((rstate.members.find((m) => m.is_host) || {}).full_name))} to start…</div>`}
        <button class="btn btn-outline btn-sm" onclick="leaveRaidLobby()">${isHost ? "Close this lobby" : "Leave"}</button>
      </div>
    </div>`;
}

// ============================================================================
// FIGHT — built once, then updated in place
// ============================================================================
function renderRaidFight() {
  const el = raidEl();
  const r = rstate.raid;
  if (!el || !r) return;
  const b = raidBoss(r.topic);
  el.innerHTML = `
    <div class="raid-arena">
      <div class="raid-topbar">
        <div class="raid-timer" id="raidTimer">--:--</div>
        <div class="muted" style="font-size:.85rem;text-align:right;">${escapeHtml(raidTopicLabel(r.topic))} · ${raidDiffChip(r.difficulty)}</div>
      </div>
      <div class="raid-stage">
        <div class="raid-boss idle" id="raidBoss">${b.emoji}</div>
        <div class="raid-float-layer" id="raidFloat"></div>
        <div class="raid-boss-name">${escapeHtml(b.name)}</div>
        <div class="raid-hp"><div class="raid-hp-fill" id="raidHpFill"></div><div class="raid-hp-text" id="raidHpText"></div></div>
      </div>
      <div class="raid-team" id="raidTeam"></div>
      <div class="card raid-question">
        <div class="raid-countdown" id="raidCountdown"></div>
        <div id="raidQuestionBody" style="visibility:hidden;">
          <div id="raidSvg" style="display:flex;justify-content:center;"></div>
          <div class="raid-prompt" id="raidPrompt"></div>
          <div id="raidHint" class="muted" style="font-size:.8rem;margin-bottom:6px;"></div>
          <div id="raidInputWrap" style="max-width:320px;margin:0 auto;">
            <input id="raidAnswerInput" type="text" placeholder="Your answer" autocomplete="off"
              style="width:100%;padding:10px;border-radius:8px;border:1px solid var(--paper-line);text-align:center;font-size:1.1rem;" />
          </div>
          <div style="display:flex;gap:10px;justify-content:center;margin-top:10px;">
            <button class="btn btn-primary" onclick="raidSubmitFromInput()">Attack! ⚔️</button>
            <button class="btn btn-outline btn-sm" onclick="submitRaidAnswer('', true)" title="Counts as a wrong answer — the boss heals">Skip ⏭️</button>
          </div>
        </div>
        <div class="raid-feedback" id="raidFeedback"></div>
      </div>
      <div class="raid-log" id="raidLog"></div>
      <div style="text-align:center;margin-top:10px;"><button class="btn btn-outline btn-sm" onclick="raidFlee()">Leave raid</button></div>
    </div>`;
  const input = document.getElementById("raidAnswerInput");
  input.onkeydown = (e) => { if (e.key === "Enter") raidSubmitFromInput(); };
  renderRaidHp(); renderRaidTeam(); renderRaidLog();
}

function raidSubmitFromInput() {
  const input = document.getElementById("raidAnswerInput");
  if (!input || !input.value.trim()) return;
  const v = input.value.trim();
  input.value = "";
  submitRaidAnswer(v, false);
}

function raidFlee() {
  if (!confirm("Leave this raid? Your team keeps fighting without you — you can rejoin from Boss Raids until time runs out.")) return;
  teardownRaidChannels();
  rstate.raid = null; rstate.question = null; rstate.screen = "hub";
  renderRaidHub();
}

function renderRaidTimer(ms) {
  const t = document.getElementById("raidTimer");
  if (!t) return;
  t.textContent = raidFmtClock(ms);
  t.classList.toggle("urgent", ms <= 30000 && ms > 10000);
  t.classList.toggle("danger", ms <= 10000);
}

function renderRaidHp() {
  const r = rstate.raid, fill = document.getElementById("raidHpFill"), text = document.getElementById("raidHpText");
  if (!r || !fill || !text || r.boss_max_hp == null) return;
  const pct = Math.max(0, Math.min(100, (r.boss_hp / r.boss_max_hp) * 100));
  fill.style.width = pct + "%";
  fill.classList.toggle("low", pct <= 25);
  text.textContent = `${Math.max(0, r.boss_hp)} / ${r.boss_max_hp} HP`;
}

function renderRaidTeam() {
  const box = document.getElementById("raidTeam");
  if (!box || rstate.screen !== "fight") return;
  box.innerHTML = rstate.members.map((m) => `
    <div class="raid-chip ${m.student_id === raidMe() ? "me" : ""}" title="${m.correct_count} correct · ${m.wrong_count} wrong">
      <div><strong>${escapeHtml(raidFirstName(m.full_name))}</strong></div>
      <div class="muted" style="font-size:.72rem;">⚔️ ${m.damage_dealt} · ✅${m.correct_count} ❌${m.wrong_count}</div>
    </div>`).join("");
}

function renderRaidLog() {
  const box = document.getElementById("raidLog");
  if (!box) return;
  box.innerHTML = rstate.log.map((e, i) => `<div class="raid-log-line ${e.kind}" style="opacity:${1 - i * 0.18};">${escapeHtml(e.text)}</div>`).join("");
}

function renderRaidQuestion() {
  const q = rstate.question;
  const body = document.getElementById("raidQuestionBody");
  if (!q || !body) return;
  body.style.visibility = "visible";
  document.getElementById("raidPrompt").textContent = q.prompt;
  document.getElementById("raidSvg").innerHTML = q.svg || "";
  document.getElementById("raidHint").textContent = q.hint || "";
  const input = document.getElementById("raidAnswerInput");
  input.value = "";
  attachNumericKeypad("raidAnswerInput", { type: q.type }); // layout follows the answer type; replaces any previous keypad
  input.focus();
}

function raidFeedback(text, kind) {
  const f = document.getElementById("raidFeedback");
  if (!f) return;
  f.className = "raid-feedback " + (kind || "");
  f.textContent = text;
}

function raidBossReact(kind) {
  const el = document.getElementById("raidBoss");
  if (!el) return;
  el.classList.remove("hit", "heal");
  void el.offsetWidth; // restart the CSS animation
  el.classList.add(kind);
  setTimeout(() => el.classList.remove(kind), 500);
}

function spawnRaidFloat(text, kind) {
  const layer = document.getElementById("raidFloat");
  if (!layer || !text) return;
  const s = document.createElement("span");
  s.className = "raid-float " + kind;
  s.textContent = text;
  s.style.left = (20 + Math.random() * 60) + "%";
  layer.appendChild(s);
  setTimeout(() => s.remove(), 1100);
}

function showRaidCountdown(n) {
  const c = document.getElementById("raidCountdown");
  if (!c) return;
  if (n > 0) { c.style.display = "block"; c.textContent = `Get ready… ${n}`; }
  else if (c.style.display !== "none") { c.textContent = "FIGHT!"; setTimeout(() => { c.style.display = "none"; }, 700); }
}

function raidFinalBlow() {
  const el = document.getElementById("raidBoss");
  if (el) el.classList.add(rstate.raid && rstate.raid.status === "won" ? "defeated" : "victorious");
}

// ============================================================================
// RESULTS
// ============================================================================
function renderRaidResults() {
  const el = raidEl(), r = rstate.raid;
  if (!el || !r) return;
  rstate.screen = "results";
  const won = r.status === "won", b = raidBoss(r.topic);
  claimRaidRewards();

  const members = rstate.members.slice();
  const withAcc = members.map((m) => {
    const total = m.correct_count + m.wrong_count;
    return { ...m, total, acc: total ? Math.round((m.correct_count / total) * 100) : null };
  });
  const topDmg = withAcc.reduce((best, m) => (m.damage_dealt > (best ? best.damage_dealt : 0) ? m : best), null);
  const sharp = withAcc.filter((m) => m.total >= 8).reduce((best, m) => (!best || m.acc > best.acc || (m.acc === best.acc && m.correct_count > best.correct_count) ? m : best), null);
  const teamCorrect = members.reduce((s, m) => s + m.correct_count, 0), teamTotal = members.reduce((s, m) => s + m.correct_count + m.wrong_count, 0);
  const spare = r.ended_at && r.ends_at ? Math.max(0, Date.parse(r.ends_at) - Date.parse(r.ended_at)) : 0;
  const pctLeft = r.boss_max_hp ? Math.round((r.boss_hp / r.boss_max_hp) * 100) : 0;
  const rw = rstate.lastReward;

  el.innerHTML = `
    <div class="card" style="text-align:center;padding:28px 18px;">
      <div class="raid-boss ${won ? "defeated" : "victorious"}" style="font-size:4rem;">${b.emoji}</div>
      <h2 style="margin:6px 0 4px;">${won ? "🏆 Victory!" : "💀 The boss survived…"}</h2>
      <p class="muted" style="margin:0;">${won
        ? `Your team defeated <strong>${escapeHtml(b.name)}</strong>${spare > 1000 ? ` with <strong>${raidFmtClock(spare)}</strong> to spare` : " right at the buzzer"}!`
        : `<strong>${escapeHtml(b.name)}</strong> finished with ${r.boss_hp} HP (${pctLeft}%) left. So close — regroup and go again, sharper and faster!`}</p>
      <div class="muted" style="margin-top:6px;font-size:.85rem;">Team accuracy ${teamTotal ? Math.round((teamCorrect / teamTotal) * 100) : 0}% · ${teamCorrect} hits · ${teamTotal - teamCorrect} misses</div>
      ${rw && rw.firstDefeat ? `<div style="margin-top:10px;font-weight:700;color:var(--gold-dark, #a67c00);">📖 New entry in your Boss Codex: ${escapeHtml(b.name)}!</div>` : ""}
    </div>

    <div class="card" style="margin-top:12px;">
      <h3 style="margin:0 0 8px;">Team report</h3>
      <div style="overflow-x:auto;"><table>
        <thead><tr><th>Player</th><th class="num">✅</th><th class="num">❌</th><th class="num">Accuracy</th><th class="num">Damage</th><th></th></tr></thead>
        <tbody>${withAcc.map((m) => `
          <tr ${m.student_id === raidMe() ? `style="background:var(--gold-light);"` : ""}>
            <td>${m.is_host ? "👑 " : ""}${escapeHtml(m.full_name || "")}${m.student_id === raidMe() ? " (you)" : ""}</td>
            <td class="num">${m.correct_count}</td><td class="num">${m.wrong_count}</td>
            <td class="num">${m.acc != null ? m.acc + "%" : "—"}</td><td class="num">${m.damage_dealt}</td>
            <td>${topDmg && m.student_id === topDmg.student_id ? "🗡️ Top damage " : ""}${sharp && m.student_id === sharp.student_id ? "🎯 Sharpshooter" : ""}</td>
          </tr>`).join("")}</tbody>
      </table></div>
    </div>

    ${raidThankRowHtml(members)}

    <div class="card" style="margin-top:12px;text-align:center;">
      ${!rw ? `<div class="muted">Collecting your rewards…</div>`
        : !rw.contributed ? `<div class="muted">Land at least 5 correct hits in a raid to earn rewards — you'll get them next time! 💪</div>`
        : `<div><strong>Your rewards</strong></div>
           <div style="margin-top:6px;">${rw.stars ? `<span style="color:var(--gold);">⭐ +${rw.stars} MathLegends star</span> · ` : ""}🌱 +${rw.green} Green Points</div>
           ${rw.promoted ? `<div style="margin-top:8px;">🏅 Rank Up! You're now ${renderRankBadge(rw.tierObj)}!</div>` : ""}`}
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
        <button class="btn btn-primary" onclick="raidAgain()">⚔️ Raid again</button>
        <button class="btn btn-outline" onclick="leaveRaidScreen()">Back to Boss Raids</button>
      </div>
    </div>`;

  if (won && rstate.confettiShownFor !== r.id) { rstate.confettiShownFor = r.id; launchConfetti(); }
}

// One-tap "thank a teammate" after a raid (Shout-outs, migration-57). Only teammates
// from the student's own class can be thanked; it never nags and stays hidden if
// Shout-outs are off. Sending is the student's own choice — nothing is rewarded.
function raidThankRowHtml(members) {
  if (typeof sendShoutout !== "function" || typeof sostate === "undefined" || !sostate.started || sostate.mode === "off") return "";
  const classmates = new Set((sostate.roster || []).map((r) => r.id));
  const mates = members.filter((m) => m.student_id !== raidMe() && classmates.has(m.student_id));
  if (!mates.length) return "";
  return `
    <div class="card" style="margin-top:12px;text-align:center;">
      <div><strong>👏 Thank a teammate?</strong> <span class="muted" style="font-size:.8rem;">Just one tap — totally optional.</span></div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:8px;">
        ${mates.map((m) => `<button class="btn-outline btn-sm" id="raidThank_${m.student_id}" onclick="raidThank('${m.student_id}')">👏 ${escapeHtml(raidFirstName(m.full_name))}</button>`).join("")}
      </div>
    </div>`;
}
async function raidThank(studentId) {
  const btn = document.getElementById("raidThank_" + studentId);
  if (btn) btn.disabled = true;
  const res = await sendShoutout(studentId, "teamwork", null);
  if (btn) { if (res && res.ok) { btn.textContent = "Thanked ✓"; } else { btn.disabled = false; } }
}

function raidAgain() {
  const r = rstate.raid;
  if (!r) return leaveRaidScreen();
  const { topic, difficulty, scope } = r;
  teardownRaidChannels();
  rstate.raid = null; rstate.members = [];
  createRaid(topic, difficulty, scope);
}

// ============================================================================
// VICTORY CONFETTI — small self-contained canvas burst, no external library.
// Runs once, then removes itself; respects reduced-motion preferences.
// ============================================================================
function launchConfetti() {
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const canvas = document.createElement("canvas");
  canvas.style.cssText = "position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:9999;";
  document.body.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) { canvas.remove(); return; } // canvas unavailable — skip the celebration rather than break the results screen
  const dpr = window.devicePixelRatio || 1;
  function resize() { canvas.width = window.innerWidth * dpr; canvas.height = window.innerHeight * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
  resize();
  window.addEventListener("resize", resize);
  const COLORS = ["#FDB913", "#B5651D", "#2E7D32", "#C0392B", "#1F5C99", "#8E44AD"];
  const GRAVITY = 0.18, DRAG = 0.995, COUNT = 140;
  const pieces = Array.from({ length: COUNT }, () => ({
    x: Math.random() * window.innerWidth, y: -20 - Math.random() * window.innerHeight * 0.4,
    w: 6 + Math.random() * 5, h: 8 + Math.random() * 6, color: COLORS[Math.floor(Math.random() * COLORS.length)],
    vx: (Math.random() - 0.5) * 6, vy: 2 + Math.random() * 3, rot: Math.random() * Math.PI * 2, vrot: (Math.random() - 0.5) * 0.3,
    shape: Math.random() < 0.5 ? "rect" : "circle",
  }));
  const startedAt = Date.now(), DURATION_MS = 3200;
  function frame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pieces.forEach((p) => {
      p.vy += GRAVITY; p.vx *= DRAG; p.x += p.vx; p.y += p.vy; p.rot += p.vrot;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = p.color;
      if (p.shape === "rect") ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      else { ctx.beginPath(); ctx.arc(0, 0, p.w / 2, 0, Math.PI * 2); ctx.fill(); }
      ctx.restore();
    });
    if (Date.now() - startedAt < DURATION_MS) requestAnimationFrame(frame);
    else { window.removeEventListener("resize", resize); canvas.remove(); }
  }
  requestAnimationFrame(frame);
}
