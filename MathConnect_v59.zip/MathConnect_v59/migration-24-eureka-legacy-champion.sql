-- ============================================================================
-- MathConnect — Migration 24: Eureka Gem Sub-Tiers, the Archimedes Trial,
-- and the Grade-Level Grand Champion system
-- Run this once in Supabase → SQL Editor if MathConnect was already set up.
-- New projects don't need this once supabase-schema.sql is updated to
-- include it (not yet folded in — always run this one on top).
--
-- WHAT THIS ADDS
--   1. Eureka Gem Sub-Tiers — once a student hits mastery_tier 15
--      (Archimedes/Eureka), stars keep flowing from the same sources
--      (Drills, Daily Challenge, Boss Battles, Quest Mode) into a NEW
--      post_eureka_stars counter, climbing Bronze -> Silver -> Gold ->
--      Platinum -> Diamond -> Emerald -> Sapphire -> Ruby -> Amethyst ->
--      Obsidian (then Obsidian II, III... uncapped). The gem thresholds
--      themselves live in rankEngine.js (RANK_EUREKA_GEMS) — this
--      migration only adds the column that stores the count. No demotion,
--      same permanence rule as reaching Eureka itself.
--
--   2. Registries for LIVE-COUNTED content — practice_domains and
--      quest_chapters_registry mirror the existing drill_station_locks
--      pattern: a small table listing what currently exists, so the
--      Archimedes Trial (and future terms' new content) can be checked
--      against a live count instead of a number hardcoded into SQL. When
--      Term 2/3 adds new Intelligent Practice domains or Quest chapters,
--      add a row here — no other function in this file needs to change.
--
--   3. The Archimedes Trial — eureka_trial_status() computes 6 checks
--      LIVE every time it's called (never a stored pass/fail flag), so it
--      naturally re-locks itself as new content raises the bar in later
--      terms. eureka_trial_check_and_record() is the one write path: call
--      it after the student views/attempts the Trial, and it bumps
--      trial_clears_count + trial_last_cleared_at exactly once per
--      false->true transition, so history survives even while the live
--      badge is temporarily dark waiting on new content.
--
--   4. The Grade-Level Grand Champion — championship_score() computes an
--      absolute (not cohort-relative) 0-100 composite across Rank
--      Progress, Drill Mastery, Quest Mode, Boss Battles, Intelligent
--      Practice, and Consistency. Only Eureka-tier (mastery_tier = 15)
--      students are eligible. grade_champion_standings() is the live
--      leaderboard; finalize_school_year() is the one-time admin action
--      that freezes each grade level's #1 into school_year_champions —
--      a permanent Hall of Fame record, once per grade per school year.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file →
-- Run. Safe to re-run.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. New columns on drill_progress
-- ----------------------------------------------------------------------------
alter table drill_progress add column if not exists post_eureka_stars integer not null default 0;
alter table drill_progress add column if not exists trial_clears_count integer not null default 0;
alter table drill_progress add column if not exists trial_last_cleared_at timestamptz;
-- Tracks the Trial's LIVE pass/fail as of the last check, purely so
-- eureka_trial_check_and_record() can detect a false->true edge (a fresh
-- clear) vs. the student just still being cleared from last time.
alter table drill_progress add column if not exists trial_currently_cleared boolean not null default false;

-- ----------------------------------------------------------------------------
-- 2. Content registries (mirrors drill_station_locks) — the live "how many
--    of X currently exist" source of truth for the Trial's growing bar.
-- ----------------------------------------------------------------------------
create table if not exists practice_domains (
  domain_key text primary key,
  label text not null,
  term_added int not null default 1,
  active boolean not null default true
);
alter table practice_domains enable row level security;
drop policy if exists "public read practice_domains" on practice_domains;
create policy "public read practice_domains" on practice_domains for select using (true);
drop policy if exists "admin write practice_domains" on practice_domains;
create policy "admin write practice_domains" on practice_domains for insert with check (is_admin());
drop policy if exists "admin update practice_domains" on practice_domains;
create policy "admin update practice_domains" on practice_domains for update using (is_admin());

insert into practice_domains (domain_key, label, term_added) values
  ('basic', 'Addition & Subtraction', 1), ('order', 'Order of Operations', 1),
  ('integers', 'Integers', 1), ('fractions', 'Fractions', 1),
  ('decimals', 'Decimals', 1), ('algebra', 'Algebraic Expressions', 1)
on conflict (domain_key) do nothing;

create table if not exists quest_chapters_registry (
  chapter_key text primary key,
  label text not null,
  term_added int not null default 1,
  active boolean not null default true
);
alter table quest_chapters_registry enable row level security;
drop policy if exists "public read quest_chapters_registry" on quest_chapters_registry;
create policy "public read quest_chapters_registry" on quest_chapters_registry for select using (true);
drop policy if exists "admin write quest_chapters_registry" on quest_chapters_registry;
create policy "admin write quest_chapters_registry" on quest_chapters_registry for insert with check (is_admin());
drop policy if exists "admin update quest_chapters_registry" on quest_chapters_registry;
create policy "admin update quest_chapters_registry" on quest_chapters_registry for update using (is_admin());

insert into quest_chapters_registry (chapter_key, label, term_added) values
  ('science', 'Science', 1), ('english', 'English', 1), ('filipino', 'Filipino', 1),
  ('ap', 'Araling Panlipunan', 1), ('values', 'Values Education', 1),
  ('musicarts', 'Music and Arts', 1), ('pe', 'PE and Health', 1),
  ('tve_food', 'TVE — Food Processing', 1), ('tve_swine', 'TVE — Swine Production', 1),
  ('tve_crops', 'TVE — Agricultural Crops Production', 1),
  ('tve_motor', 'TVE — Motorcycle/Small Engine Servicing', 1), ('math', 'Math', 1)
on conflict (chapter_key) do nothing;

-- ----------------------------------------------------------------------------
-- 3. Hall of Fame — permanent, one row per grade level per school year.
-- ----------------------------------------------------------------------------
create table if not exists school_year_champions (
  id uuid primary key default gen_random_uuid(),
  school_year text not null,
  grade_level text not null,
  student_id uuid references students(id) on delete set null,
  full_name_snapshot text not null,       -- kept even if the student record later changes/leaves
  championship_score numeric not null,
  score_breakdown jsonb not null,
  finalized_by uuid references admins(id),
  finalized_at timestamptz default now(),
  unique (school_year, grade_level)
);
alter table school_year_champions enable row level security;
drop policy if exists "public read school_year_champions" on school_year_champions;
create policy "public read school_year_champions" on school_year_champions for select using (true);
drop policy if exists "admin write school_year_champions" on school_year_champions;
create policy "admin write school_year_champions" on school_year_champions for insert with check (is_admin());
drop policy if exists "admin delete school_year_champions" on school_year_champions;
create policy "admin delete school_year_champions" on school_year_champions for delete using (is_admin());

-- ----------------------------------------------------------------------------
-- 4. grade_level_roster_count — whole grade level, every section, every
--    teacher (same cross-teacher join pattern as grade_level_drill_leaderboard).
-- ----------------------------------------------------------------------------
create or replace function public.grade_level_roster_count(target_student_id uuid)
returns int language sql security definer stable as $$
  select count(*)::int from students st join sections se on se.id = st.section_id
  where se.grade_level = (
    select se2.grade_level from students st2 join sections se2 on se2.id = st2.section_id
    where st2.id = target_student_id
  ) and st.id <> target_student_id;
$$;
grant execute on function public.grade_level_roster_count(uuid) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 5. distinct_opponents_beaten — how many DIFFERENT grade-level classmates
--    this student has beaten in a completed Boss Battle. Distinct by
--    construction, so no separate "farming" guard is needed here — beating
--    the same student 20 times still only counts once.
-- ----------------------------------------------------------------------------
create or replace function public.distinct_opponents_beaten(target_student_id uuid)
returns int language sql security definer stable as $$
  select count(distinct opp)::int from (
    select case when student_a_id = target_student_id then student_b_id else student_a_id end as opp
    from battles
    where status = 'completed' and winner_id = target_student_id
      and (student_a_id = target_student_id or student_b_id = target_student_id)
  ) x;
$$;
grant execute on function public.distinct_opponents_beaten(uuid) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 6. eureka_trial_status — the 6-item checklist, computed live. Returns a
--    jsonb object so the client can render each checkbox individually.
-- ----------------------------------------------------------------------------
create or replace function public.eureka_trial_status(target_student_id uuid)
returns jsonb language plpgsql security definer stable as $$
declare
  dp drill_progress%rowtype;
  eng student_engagement%rowtype;
  les learning_engine_state%rowtype;
  qp quest_progress%rowtype;
  domain_total int := 0; domain_pass int := 0;
  station_total int := 0; station_attempted int := 0; station_maxed int := 0;
  chapter_total int := 0; chapter_cleared int := 0;
  r record;
  roster_half int;
  opponents_beaten int;
  result jsonb;
begin
  select * into dp from drill_progress where student_id = target_student_id;
  select * into eng from student_engagement where student_id = target_student_id;
  select * into les from learning_engine_state where student_id = target_student_id;
  select * into qp from quest_progress where student_id = target_student_id;

  -- Check 1: every active practice domain at Expert tier (4) + 100 mastery
  for r in select domain_key from practice_domains where active loop
    domain_total := domain_total + 1;
    if les.id is not null
       and coalesce((les.adaptive_levels ->> r.domain_key)::int, 0) = 4
       and coalesce((les.skill_proficiency ->> r.domain_key)::int, 0) = 100
    then domain_pass := domain_pass + 1; end if;
  end loop;

  -- Checks 2 & 3: every UNLOCKED station attempted at least once, and at
  -- level 15. "Attempted" = at least one drill_attempts row for that topic.
  for r in select station_key from drill_station_locks where not locked loop
    station_total := station_total + 1;
    if exists (select 1 from drill_attempts where student_id = target_student_id and topic = r.station_key) then
      station_attempted := station_attempted + 1;
    end if;
    if dp.id is not null and coalesce((dp.topic_levels ->> r.station_key)::int, 1) = 15 then
      station_maxed := station_maxed + 1;
    end if;
  end loop;

  -- Check 4: more than half of currently-active Quest chapters fully
  -- cleared (all 10 levels have at least 1 star each).
  for r in select chapter_key from quest_chapters_registry where active loop
    chapter_total := chapter_total + 1;
    if qp.id is not null and jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       and jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       and not exists (
         select 1 from jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e
         where e::int < 1
       )
    then chapter_cleared := chapter_cleared + 1; end if;
  end loop;

  roster_half := ceil(coalesce(public.grade_level_roster_count(target_student_id), 0) / 2.0);
  opponents_beaten := coalesce(public.distinct_opponents_beaten(target_student_id), 0);

  result := jsonb_build_object(
    'practice_expert', jsonb_build_object('passed', domain_pass = domain_total and domain_total > 0, 'progress', domain_pass, 'needed', domain_total),
    'all_stations_attempted', jsonb_build_object('passed', station_attempted = station_total and station_total > 0, 'progress', station_attempted, 'needed', station_total),
    'all_stations_level15', jsonb_build_object('passed', station_maxed = station_total and station_total > 0, 'progress', station_maxed, 'needed', station_total),
    'quest_half_cleared', jsonb_build_object('passed', chapter_cleared > (chapter_total / 2.0), 'progress', chapter_cleared, 'needed', floor(chapter_total / 2.0) + 1),
    'attendance_streak_30', jsonb_build_object('passed', coalesce(eng.current_streak, 0) >= 30 and coalesce(eng.streak_off, false) = false, 'progress', coalesce(eng.current_streak, 0), 'needed', 30),
    'grade_dominance', jsonb_build_object('passed', opponents_beaten >= roster_half and roster_half > 0, 'progress', opponents_beaten, 'needed', roster_half)
  );

  result := result || jsonb_build_object('overall_cleared',
    (result -> 'practice_expert' ->> 'passed')::boolean
    and (result -> 'all_stations_attempted' ->> 'passed')::boolean
    and (result -> 'all_stations_level15' ->> 'passed')::boolean
    and (result -> 'quest_half_cleared' ->> 'passed')::boolean
    and (result -> 'attendance_streak_30' ->> 'passed')::boolean
    and (result -> 'grade_dominance' ->> 'passed')::boolean
  );
  return result;
end;
$$;
grant execute on function public.eureka_trial_status(uuid) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 7. eureka_trial_check_and_record — the one write path. Safe to call every
--    time a student opens the Trial card; only writes on a false->true edge.
-- ----------------------------------------------------------------------------
create or replace function public.eureka_trial_check_and_record(target_student_id uuid)
returns jsonb language plpgsql security definer as $$
declare
  status jsonb;
  was_cleared boolean;
  now_cleared boolean;
begin
  status := public.eureka_trial_status(target_student_id);
  now_cleared := (status ->> 'overall_cleared')::boolean;

  select trial_currently_cleared into was_cleared from drill_progress where student_id = target_student_id;
  was_cleared := coalesce(was_cleared, false);

  if now_cleared and not was_cleared then
    update drill_progress
    set trial_clears_count = trial_clears_count + 1,
        trial_last_cleared_at = now(),
        trial_currently_cleared = true
    where student_id = target_student_id;
  elsif not now_cleared and was_cleared then
    update drill_progress set trial_currently_cleared = false where student_id = target_student_id;
  end if;

  return status;
end;
$$;
grant execute on function public.eureka_trial_check_and_record(uuid) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 8. championship_score — absolute 0-100 composite, six weighted parts.
--    Eligibility (mastery_tier = 15) is returned alongside so the client
--    can show "keep going" instead of a score for non-Eureka students.
-- ----------------------------------------------------------------------------
create or replace function public.championship_score(target_student_id uuid)
returns jsonb language plpgsql security definer stable as $$
declare
  dp drill_progress%rowtype; eng student_engagement%rowtype;
  les learning_engine_state%rowtype; qp quest_progress%rowtype;
  eligible boolean := false;
  gem_score numeric := 0; trial_score numeric := 0; rank_progress numeric := 0;
  avg_level numeric := 0; accuracy numeric := 0; drill_score numeric := 0;
  chapter_total int := 0; chapter_cleared int := 0; quest_score numeric := 0;
  max_stars int := 0;
  wins int := 0; capped_wins int := 0; capped_games int := 0; win_rate numeric := 0;
  coverage numeric := 0; battle_score numeric := 0; roster int := 0;
  domain_total int := 0; domain_sum numeric := 0; practice_score numeric := 0;
  streak_score numeric := 0; daily_count int := 0; daily_score numeric := 0; consistency_score numeric := 0;
  total numeric := 0;
  station_count int := 0;
  r record;
  gem_index int := 0;
begin
  select * into dp from drill_progress where student_id = target_student_id;
  select * into eng from student_engagement where student_id = target_student_id;
  select * into les from learning_engine_state where student_id = target_student_id;
  select * into qp from quest_progress where student_id = target_student_id;

  eligible := dp.id is not null and dp.mastery_tier = 15;

  -- ---- 1. Rank Progress (30%) ----
  -- Gem index: how many 5/10/15/25/35/50/70/95/125-cumulative thresholds
  -- cleared, +1 per 30 stars beyond Obsidian (mirrors RANK_EUREKA_GEMS in
  -- rankEngine.js — kept in sync manually since thresholds rarely change).
  if dp.post_eureka_stars >= 125 then gem_index := 9 + floor((dp.post_eureka_stars - 125) / 30.0);
  elsif dp.post_eureka_stars >= 95 then gem_index := 8;
  elsif dp.post_eureka_stars >= 70 then gem_index := 7;
  elsif dp.post_eureka_stars >= 50 then gem_index := 6;
  elsif dp.post_eureka_stars >= 35 then gem_index := 5;
  elsif dp.post_eureka_stars >= 25 then gem_index := 4;
  elsif dp.post_eureka_stars >= 15 then gem_index := 3;
  elsif dp.post_eureka_stars >= 10 then gem_index := 2;
  elsif dp.post_eureka_stars >= 5 then gem_index := 1;
  else gem_index := 0; end if;
  gem_score := least(gem_index / 14.0 * 60, 60);
  trial_score := least(coalesce(dp.trial_clears_count, 0), 2) * 20;
  rank_progress := gem_score + trial_score;

  -- ---- 2. Drill Mastery (20%) ----
  select count(*) into station_count from drill_station_locks where not locked;
  if dp.id is not null and station_count > 0 then
    select avg((dp.topic_levels ->> sl.station_key)::int) into avg_level
    from (select station_key from drill_station_locks where not locked) sl;
    avg_level := coalesce(avg_level, 1);
  end if;
  select case when coalesce(sum(total_questions), 0) = 0 then 0
    else sum(correct_count)::numeric / sum(total_questions) * 100 end
  into accuracy from drill_attempts where student_id = target_student_id;
  drill_score := (coalesce(avg_level, 1) / 15.0 * 100) * 0.5 + coalesce(accuracy, 0) * 0.5;

  -- ---- 3. Quest Mode (15%) ----
  for r in select chapter_key from quest_chapters_registry where active loop
    chapter_total := chapter_total + 1;
    if qp.id is not null and jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       and jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       and not exists (select 1 from jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e where e::int < 1)
    then chapter_cleared := chapter_cleared + 1; end if;
  end loop;
  max_stars := chapter_total * 10 * 3;
  quest_score := case when chapter_total = 0 then 0 else (chapter_cleared::numeric / chapter_total * 100) * 0.5 end
    + case when max_stars = 0 then 0 else (coalesce(qp.total_stars, 0)::numeric / max_stars * 100) * 0.5 end;

  -- ---- 4. Boss Battles (15%), anti-farm cap of 3 wins/opponent ----
  select coalesce(sum(least(w, 3)), 0), coalesce(sum(least(g, 3)), 0) into capped_wins, capped_games
  from (
    select case when student_a_id = target_student_id then student_b_id else student_a_id end as opp,
      count(*) filter (where winner_id = target_student_id) as w,
      count(*) as g
    from battles
    where status = 'completed' and (student_a_id = target_student_id or student_b_id = target_student_id)
    group by 1
  ) x;
  win_rate := case when capped_games = 0 then 0 else capped_wins::numeric / capped_games * 100 end;
  roster := coalesce(public.grade_level_roster_count(target_student_id), 0);
  coverage := case when roster = 0 then 0 else least(public.distinct_opponents_beaten(target_student_id)::numeric / roster * 100, 100) end;
  battle_score := win_rate * 0.5 + coverage * 0.5;

  -- ---- 5. Intelligent Practice (10%) ----
  for r in select domain_key from practice_domains where active loop
    domain_total := domain_total + 1;
    domain_sum := domain_sum + coalesce((les.skill_proficiency ->> r.domain_key)::int, 0);
  end loop;
  practice_score := case when domain_total = 0 then 0 else domain_sum / domain_total end;

  -- ---- 6. Consistency (10%) ----
  streak_score := least(coalesce(eng.current_streak, 0), 60) / 60.0 * 100;
  select count(*) into daily_count from daily_challenge_completions where student_id = target_student_id;
  daily_score := least(daily_count, 60) / 60.0 * 100;
  consistency_score := streak_score * 0.5 + daily_score * 0.5;

  total := rank_progress * 0.30 + drill_score * 0.20 + quest_score * 0.15 + battle_score * 0.15
    + practice_score * 0.10 + consistency_score * 0.10;

  return jsonb_build_object(
    'eligible', eligible,
    'total', round(total, 2),
    'breakdown', jsonb_build_object(
      'rank_progress', round(rank_progress, 2),
      'drill_mastery', round(drill_score, 2),
      'quest_mode', round(quest_score, 2),
      'boss_battles', round(battle_score, 2),
      'intelligent_practice', round(practice_score, 2),
      'consistency', round(consistency_score, 2)
    )
  );
end;
$$;
grant execute on function public.championship_score(uuid) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 9. grade_champion_standings — live leaderboard, Eureka-tier only, one
--    grade level at a time, cross-section/cross-teacher.
-- ----------------------------------------------------------------------------
create or replace function public.grade_champion_standings(target_grade_level text, result_limit int default 50)
returns table(student_id uuid, full_name text, section_name text, total numeric, breakdown jsonb)
language plpgsql security definer stable as $$
declare r record; score jsonb; rows jsonb := '[]'::jsonb;
begin
  for r in
    select st.id, st.full_name, se.section_name
    from drill_progress dp
    join students st on st.id = dp.student_id
    join sections se on se.id = st.section_id
    where se.grade_level = target_grade_level and dp.mastery_tier = 15
  loop
    score := public.championship_score(r.id);
    rows := rows || jsonb_build_array(jsonb_build_object(
      'student_id', r.id, 'full_name', r.full_name, 'section_name', r.section_name,
      'total', (score ->> 'total')::numeric, 'breakdown', score -> 'breakdown'
    ));
  end loop;

  return query
    select (elem ->> 'student_id')::uuid, elem ->> 'full_name', elem ->> 'section_name',
      (elem ->> 'total')::numeric, elem -> 'breakdown'
    from jsonb_array_elements(rows) elem
    order by (elem ->> 'total')::numeric desc
    limit result_limit;
end;
$$;
grant execute on function public.grade_champion_standings(text, int) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 10. finalize_school_year — admin-only. Freezes grade level's #1 (tie-break:
--     longer current attendance streak) into the permanent Hall of Fame.
--     Safe to re-run for the same (school_year, grade_level): overwrites.
-- ----------------------------------------------------------------------------
create or replace function public.finalize_school_year(target_grade_level text, target_school_year text)
returns jsonb language plpgsql security definer as $$
declare
  winner record;
  admin_id uuid := auth.uid();
begin
  if not is_admin() then
    raise exception 'Only an admin can finalize the school year champion.';
  end if;

  select gs.student_id, gs.full_name, gs.total, gs.breakdown, coalesce(eng.current_streak, 0) as streak
  into winner
  from public.grade_champion_standings(target_grade_level, 1000) gs
  left join student_engagement eng on eng.student_id = gs.student_id
  order by gs.total desc, streak desc
  limit 1;

  -- Check FOUND (not winner.student_id) — an unassigned `record` variable
  -- raises an error on field access if the query returned zero rows.
  if not found then
    return jsonb_build_object('crowned', false, 'reason', 'No Eureka-tier student found in this grade level.');
  end if;

  insert into school_year_champions (school_year, grade_level, student_id, full_name_snapshot, championship_score, score_breakdown, finalized_by)
  values (target_school_year, target_grade_level, winner.student_id, winner.full_name, winner.total, winner.breakdown, admin_id)
  on conflict (school_year, grade_level) do update
    set student_id = excluded.student_id, full_name_snapshot = excluded.full_name_snapshot,
        championship_score = excluded.championship_score, score_breakdown = excluded.score_breakdown,
        finalized_by = excluded.finalized_by, finalized_at = now();

  return jsonb_build_object('crowned', true, 'student_id', winner.student_id, 'full_name', winner.full_name, 'total', winner.total);
end;
$$;
grant execute on function public.finalize_school_year(text, text) to authenticated;

-- ============================================================================
-- Done. Next: load rankEngine.js's RANK_EUREKA_GEMS additions, trialEngine.js,
-- and championshipEngine.js in student.html / admin.html (see README).
-- ============================================================================
