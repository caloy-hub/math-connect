// ============================================================================
// MathConnect — Team Boss Raids (engine)
// A team of 3–8 classmates fights ONE station's boss monster together, against
// a clock. Every correct answer damages the boss; every wrong answer (or skip)
// heals it. Beat the boss before time runs out.
//
// Everyone answers their OWN question stream at their OWN station level, all
// at the same time — nobody waits on anybody. The only shared state is the
// boss's HP and the clock, and BOTH live in the database
// (migration-53-boss-raids.sql):
//   • every hit goes through the raid_submit_answer() function, which locks the
//     raid row, so simultaneous answers can't overwrite each other;
//   • the clock is the server's `ends_at`; this file measures the gap between
//     the server's clock and the device's clock (`skewMs`) so a wrong laptop
//     clock can't shorten or lengthen the fight;
//   • Supabase Realtime pushes teammates' hits live, and a 3–5 s poll of
//     boss_raid_sync() backs it up if a realtime message is ever missed.
//
// Depends on: supabase-client.js (supabase, escapeHtml, toast), student.js
// (sstate), drills.js (DRILL_TOPICS, generateDrillQuestion, checkDrillAnswer,
// fmtDrillAnswer, isStationLocked, loadStationLocks, dstate, loadDrillProgress,
// pick), rankEngine.js (awardMasteryStars), streakEngine.js (awardGreenPoints,
// markDailyActivity), shopEngine.js (shopEffects). raid-ui.js does the rendering.
// ============================================================================

const RAID_MIN_PLAYERS = 3;
const RAID_MAX_PLAYERS = 8;
const RAID_LOBBY_TTL_MS = 15 * 60 * 1000;

// Difficulty only changes how much HP the boss has PER PLAYER (the server owns
// the real numbers — these are for display). Question difficulty is each
// student's own station level, so weaker students still get fair questions.
const RAID_DIFFICULTIES = {
  easy:   { icon: "🟢", label: "Easy",   hpPerPlayer: 70,  blurb: "A friendly warm-up" },
  normal: { icon: "🟡", label: "Normal", hpPerPlayer: 100, blurb: "A fair fight for a team that practices" },
  hard:   { icon: "🔴", label: "Hard",   hpPerPlayer: 150, blurb: "Only sharp, fast teams win" },
};

// ---------------------------------------------------------------------------
// THE BOSSES — one monster per Drill station, plus the Grand Boss ("mixed":
// questions from every open station). Keep the keys in step with DRILL_TOPICS.
// ---------------------------------------------------------------------------
const BOSS_ROSTER = {
  basic:       { emoji: "👹", name: "Grumbo the Number Ogre",   taunt: "Grrr! Nobody out-counts Grumbo!" },
  order:       { emoji: "🐉", name: "PEMDAS the Puzzle Dragon", taunt: "Parentheses first… or you'll be toast!" },
  integers:    { emoji: "🤖", name: "Negatron",                 taunt: "Positive? Negative? You'll never know!" },
  fractions:   { emoji: "🦖", name: "Slice-o-saurus",           taunt: "I'll cut your score into pieces!" },
  decimals:    { emoji: "🦀", name: "Dot the Decimal Crab",     taunt: "Watch where you put that point… snap!" },
  algebra:     { emoji: "🐍", name: "Vex the Variable Viper",   taunt: "Solve for me if you dare, sss!" },
  ratio:       { emoji: "🐗", name: "Boarus the Mix-Master",    taunt: "Keep the ratio… or the feed goes bad!" },
  percent:     { emoji: "🐙", name: "Markdown the Kraken",      taunt: "Everything's on sale — including your points!" },
  geometry:    { emoji: "🐊", name: "Sir Perimeter Gator",      taunt: "Fence me in if you can!" },
  patterns:    { emoji: "🦉", name: "Cipher the Code Owl",      taunt: "Whooo can crack my pattern?" },
  statistics:  { emoji: "🕷️", name: "Median Widow",             taunt: "You're right in the middle of my web…" },
  probability: { emoji: "🦊", name: "Lady Luck the Fox",        taunt: "The odds are never in your favor!" },
  exponents:   { emoji: "🐂", name: "Powerhorn the Bull",       taunt: "I'm raising the stakes — to the 10th power!" },
  equations:   { emoji: "🦍", name: "Kong-Equal",               taunt: "Keep the scale balanced, little ones!" },
  factoring:   { emoji: "🗿", name: "The Vault Golem",          taunt: "Break my code… if you can factor it." },
  measurement: { emoji: "🦂", name: "Scorpio Scale",            taunt: "Convert THIS — sting!" },
  coordinates: { emoji: "👻", name: "The Grid Wraith",          taunt: "Find me on the plane… if you can." },
  pythagoras:  { emoji: "🐲", name: "Hypotenuse the Hydra",     taunt: "Cut one leg and two more grow!" },
  mixed:       { emoji: "👾", name: "Omega Mathoid — the Grand Boss", taunt: "I contain every station. Prepare yourselves." },
};
function raidBoss(topic) { return BOSS_ROSTER[topic] || BOSS_ROSTER.mixed; }
function raidTopicLabel(topic) {
  if (topic === "mixed") return "🎲 Every station";
  const t = (typeof DRILL_TOPICS !== "undefined" ? DRILL_TOPICS : []).find((x) => x.key === topic);
  return t ? `${t.icon} ${t.name}` : topic;
}

var rstate = {
  screen: "hub",                // hub | lobby | fight | results
  raid: null, members: [],
  skewMs: 0,                    // server clock minus device clock
  channels: [], timerId: null, pollId: null, hubPollId: null, syncTimer: null,
  fightStarted: false, finishCalled: false,
  question: null, qStartedAt: 0,
  log: [], shieldUsed: false,
  lobbies: [], myOpenRaid: null, codex: null,
  prefs: { difficulty: "normal", scope: "section" },
  resultsHandledFor: null, lastReward: null,
  lastMemberStats: {},          // student_id -> {correct, wrong, dmg, heal}, to turn teammates' updates into log lines
};

function serverNow() { return Date.now() + rstate.skewMs; }
function noteServerTime(iso) { if (iso) { const t = Date.parse(iso); if (!isNaN(t)) rstate.skewMs = t - Date.now(); } }
function raidMe() { return sstate.student.id; }

// ============================================================================
// SETUP / TEARDOWN
// ============================================================================
function stopRaidLoops() {
  if (rstate.timerId) { clearInterval(rstate.timerId); rstate.timerId = null; }
  if (rstate.pollId) { clearInterval(rstate.pollId); rstate.pollId = null; }
  if (rstate.syncTimer) { clearTimeout(rstate.syncTimer); rstate.syncTimer = null; }
}
function stopHubPolling() { if (rstate.hubPollId) { clearInterval(rstate.hubPollId); rstate.hubPollId = null; } }
function teardownRaidChannels() {
  rstate.channels.forEach((ch) => { try { supabase.removeChannel(ch); } catch (e) {} });
  rstate.channels = [];
  stopRaidLoops();
  stopHubPolling();
  // A finished raid is done with — coming back to the tab should show the hub,
  // not the old results (an unfinished one is kept so the tab can reconnect).
  if (rstate.screen === "results") { rstate.raid = null; rstate.members = []; rstate.screen = "hub"; }
}
// Called by student.js before switching tabs. Returns false to cancel the switch.
function raidLeaveGuard(nextTab) {
  if (nextTab === "battle") return true;
  if (rstate.screen === "fight" && rstate.raid && rstate.raid.status === "active") {
    return confirm("⚔️ You're in the middle of a Boss Raid — your team is counting on you!\n\nLeave anyway? (The fight keeps going; you can jump back in from Boss Raids until time runs out.)");
  }
  return true;
}

// ============================================================================
// DATA
// ============================================================================
async function loadRaidLobbies() {
  const cutoff = new Date(Date.now() - RAID_LOBBY_TTL_MS).toISOString();
  const grade = String(sstate.section.grade_level || "").replace(/"/g, "");
  const { data, error } = await supabase.from("boss_raids")
    .select("*, host:host_id(full_name), boss_raid_members(count)")
    .eq("status", "lobby").gte("created_at", cutoff)
    .or(`and(scope.eq.section,section_id.eq.${sstate.section.id}),and(scope.eq.grade,grade_level.eq."${grade}")`)
    .order("created_at", { ascending: false }).limit(30);
  if (error) { console.warn("loadRaidLobbies:", error.message); rstate.lobbies = []; return; }
  rstate.lobbies = (data || []).map((r) => ({ ...r, playerCount: (r.boss_raid_members && r.boss_raid_members[0] && r.boss_raid_members[0].count) || 0 }));
}

// The raid (if any) this student is already part of — so a refresh or a
// slipped tab never strands them outside their own team's fight.
async function loadMyOpenRaid() {
  const { data } = await supabase.from("boss_raid_members")
    .select("raid:raid_id!inner(*)").eq("student_id", raidMe()).in("raid.status", ["lobby", "active"]);
  const now = Date.now();
  const open = (data || []).map((r) => r.raid).filter((r) => r && (
    (r.status === "lobby" && Date.parse(r.created_at) > now - RAID_LOBBY_TTL_MS) ||
    (r.status === "active" && Date.parse(r.ends_at) + 2000 > serverNow())));
  rstate.myOpenRaid = open[0] || null;
}

// Bosses defeated (the "Codex"): per station, how many wins and the hardest difficulty beaten.
async function loadRaidCodex() {
  const { data } = await fetchAllRowsChecked(() => supabase.from("boss_raid_members")
    .select("raid:raid_id!inner(topic, difficulty, status)").eq("student_id", raidMe()).eq("raid.status", "won"));
  const rank = { easy: 1, normal: 2, hard: 3 };
  const codex = {};
  (data || []).forEach((row) => {
    const r = row.raid; if (!r) return;
    const c = (codex[r.topic] = codex[r.topic] || { wins: 0, best: "easy" });
    c.wins += 1;
    if (rank[r.difficulty] > rank[c.best]) c.best = r.difficulty;
  });
  rstate.codex = codex;
}

// One round-trip: raid row + roster with live stats + the server's clock.
async function syncRaid() {
  if (!rstate.raid) return null;
  const { data, error } = await supabase.rpc("boss_raid_sync", { p_raid_id: rstate.raid.id });
  if (error || !data || !data.ok) return null;
  noteServerTime(data.server_now);
  applyMembers(data.members, false);
  applyRaidRow(data.raid);
  return data;
}
function scheduleSync(ms) {
  if (rstate.syncTimer) return;
  rstate.syncTimer = setTimeout(() => { rstate.syncTimer = null; syncRaid(); }, ms || 300);
}

// ============================================================================
// APPLYING STATE (from RPC replies, realtime pushes, or polls)
// ============================================================================
function applyMembers(list, animate) {
  const prev = rstate.lastMemberStats;
  const next = {};
  (list || []).forEach((m) => {
    next[m.student_id] = { correct: m.correct_count, wrong: m.wrong_count, dmg: m.damage_dealt, heal: m.healed_boss };
    // Turn a TEAMMATE's stat change into a live combat-log line + floating number
    const p = prev[m.student_id];
    if (animate && p && m.student_id !== raidMe()) {
      const name = (m.full_name || "A teammate").split(" ")[0];
      if (m.correct_count > p.correct && m.damage_dealt > p.dmg) raidLogEvent(`⚔️ ${name} hit for ${m.damage_dealt - p.dmg}`, "hit", `-${m.damage_dealt - p.dmg}`);
      else if (m.wrong_count > p.wrong) raidLogEvent(m.healed_boss > p.heal ? `💚 ${name} missed — boss +${m.healed_boss - p.heal}` : `🛡️ ${name}'s shield held`, "heal", m.healed_boss > p.heal ? `+${m.healed_boss - p.heal}` : "");
    }
  });
  rstate.lastMemberStats = next;
  // never let a slightly late snapshot make MY counters go backwards
  const me = raidMe();
  const old = rstate.members.find((x) => x.student_id === me);
  rstate.members = (list || []).map((m) => {
    if (m.student_id === me && old) {
      return { ...m, correct_count: Math.max(m.correct_count, old.correct_count), wrong_count: Math.max(m.wrong_count, old.wrong_count), damage_dealt: Math.max(m.damage_dealt, old.damage_dealt), healed_boss: Math.max(m.healed_boss, old.healed_boss) };
    }
    return m;
  });
  if (typeof renderRaidTeam === "function") renderRaidTeam();
  if (rstate.screen === "lobby" && typeof renderRaidLobby === "function") renderRaidLobby();
}

function applyRaidRow(row) {
  if (!row || !rstate.raid || row.id !== rstate.raid.id) return;
  const old = rstate.raid;
  // ignore a stale copy of the SAME status (out-of-order message); status changes always apply
  if (row.status === old.status && (row.event_seq || 0) < (old.event_seq || 0)) return;
  rstate.raid = { ...old, ...row };
  const hpChanged = old.boss_hp != null && row.boss_hp != null && row.boss_hp !== old.boss_hp;

  if (row.status !== old.status) return onRaidStatusChange(old.status, row.status);
  if (rstate.screen === "fight") {
    if (hpChanged && (row.event_seq || 0) > (old.event_seq || 0)) raidBossReact(row.boss_hp < old.boss_hp ? "hit" : "heal");
    if (typeof renderRaidHp === "function") renderRaidHp();
  }
}

function onRaidStatusChange(from, to) {
  if (to === "cancelled") { toast("The host closed this raid lobby."); leaveRaidScreen(); return; }
  if (to === "active" && rstate.screen !== "fight") { startFight(); return; }
  if ((to === "won" || to === "lost")) { endFight(); }
}

// ============================================================================
// ACTIONS: create / join / leave / start
// ============================================================================
function raidErrorText(code, res) {
  return ({
    already_in_raid: "You're already in another raid — finish or leave it first.",
    station_locked: "That station is locked by your admin right now.",
    account_paused: "⏸️ Your account is in read-only mode — raids are paused. See your teacher.",
    wrong_section: "That raid is only open to its own section.",
    wrong_grade: "That raid is for a different grade level.",
    raid_full: `That team is full (${RAID_MAX_PLAYERS} players).`,
    not_open: "That raid already started or was closed.",
    raid_not_found: "That raid isn't available anymore.",
    need_more_players: `You need at least ${RAID_MIN_PLAYERS} players to start${res && res.have ? ` (you have ${res.have})` : ""}.`,
    host_only: "Only the host can start the raid.",
  })[code] || "Something went wrong — please try again.";
}

async function createRaid(topic, difficulty, scope) {
  if (sstate.readOnly) { toast("⏸️ Your account is in read-only mode — raids are paused. See your teacher."); return; }
  const { data, error } = await supabase.rpc("create_boss_raid", { p_student_id: raidMe(), p_topic: topic, p_difficulty: difficulty, p_scope: scope });
  if (error || !data) { toast("Couldn't open the raid — check your connection."); return; }
  if (!data.ok) {
    toast(raidErrorText(data.error, data));
    if (data.error === "already_in_raid" && data.raid_id) enterRaid(data.raid_id);
    return;
  }
  toast(`${raidBoss(topic).emoji} Raid lobby open — waiting for your team!`);
  enterRaid(data.raid.id);
}

async function joinRaid(raidId) {
  if (sstate.readOnly) { toast("⏸️ Your account is in read-only mode — raids are paused. See your teacher."); return; }
  const { data, error } = await supabase.rpc("join_boss_raid", { p_raid_id: raidId, p_student_id: raidMe() });
  if (error || !data) { toast("Couldn't join — check your connection."); return; }
  if (!data.ok) { toast(raidErrorText(data.error, data)); if (data.raid_id) enterRaid(data.raid_id); else renderRaidHub(); return; }
  enterRaid(raidId);
}

async function leaveRaidLobby() {
  if (!rstate.raid) return leaveRaidScreen();
  await supabase.rpc("leave_boss_raid", { p_raid_id: rstate.raid.id, p_student_id: raidMe() });
  leaveRaidScreen();
}

async function startRaid() {
  if (!rstate.raid) return;
  const { data, error } = await supabase.rpc("start_boss_raid", { p_raid_id: rstate.raid.id, p_student_id: raidMe() });
  if (error || !data) { toast("Couldn't start — check your connection."); return; }
  if (!data.ok) { toast(raidErrorText(data.error, data)); if (data.error === "need_more_players") syncRaid(); return; }
  noteServerTime(data.server_now);
  applyRaidRow(data.raid); // -> active -> startFight()
}

// ============================================================================
// ENTERING A RAID
// ============================================================================
async function enterRaid(raidId) {
  teardownRaidChannels();
  resetFightState();
  // First look at the raid: read it straight into state (no "status changed"
  // side effects) — routeRaidScreen() below decides which screen to show.
  const { data, error } = await supabase.rpc("boss_raid_sync", { p_raid_id: raidId });
  if (error || !data || !data.ok) { toast("That raid isn't available anymore."); rstate.raid = null; return renderRaidHub(); }
  noteServerTime(data.server_now);
  rstate.raid = data.raid;
  rstate.screen = data.raid.status === "lobby" ? "lobby" : rstate.screen;
  rstate.lastMemberStats = {};
  applyMembers(data.members, false);

  const ch = supabase.channel(`raid-${raidId}`)
    .on("postgres_changes", { event: "UPDATE", schema: "public", table: "boss_raids", filter: `id=eq.${raidId}` }, (p) => applyRaidRow(p.new))
    .on("postgres_changes", { event: "*", schema: "public", table: "boss_raid_members", filter: `raid_id=eq.${raidId}` }, (p) => {
      if (p.eventType === "UPDATE" && p.new) {
        // full row arrives with the update — apply it in place (no round-trip)
        const idx = rstate.members.findIndex((m) => m.student_id === p.new.student_id);
        if (idx >= 0) {
          const merged = rstate.members.map((m) => m.student_id === p.new.student_id
            ? { ...m, correct_count: p.new.correct_count, wrong_count: p.new.wrong_count, damage_dealt: p.new.damage_dealt, healed_boss: p.new.healed_boss } : m);
          applyMembers(merged, true);
          return;
        }
      }
      scheduleSync(250); // someone joined / left — names aren't in the push, so ask the server
    })
    .subscribe();
  rstate.channels.push(ch);
  // The poll is the safety net behind realtime (a dropped message must never freeze a raid).
  rstate.pollId = setInterval(syncRaid, rstate.raid.status === "lobby" ? 3000 : 5000);

  if (typeof showPetCheerBubble === "function") showPetCheerBubble();
  routeRaidScreen();
}

function routeRaidScreen() {
  const s = rstate.raid.status;
  if (s === "lobby") { rstate.screen = "lobby"; renderRaidLobby(); }
  else if (s === "active") startFight();
  else if (s === "won" || s === "lost") { rstate.screen = "results"; renderRaidResults(); }
  else { toast("That raid was closed."); leaveRaidScreen(); }
}

function resetFightState() {
  rstate.fightStarted = false; rstate.finishCalled = false;
  rstate.question = null; rstate.log = []; rstate.shieldUsed = false;
  rstate.resultsHandledFor = null; rstate.lastReward = null;
}

function leaveRaidScreen() {
  teardownRaidChannels();
  rstate.raid = null; rstate.members = []; rstate.screen = "hub"; rstate.question = null;
  renderRaidHub();
}

// ============================================================================
// THE FIGHT
// ============================================================================
function startFight() {
  rstate.screen = "fight";
  if (rstate.pollId) clearInterval(rstate.pollId);
  rstate.pollId = setInterval(syncRaid, 5000);
  rstate.fightStarted = false; rstate.finishCalled = false; rstate.question = null;
  renderRaidFight();
  if (rstate.timerId) clearInterval(rstate.timerId);
  rstate.timerId = setInterval(tickFight, 200);
  tickFight();
}

function tickFight() {
  const r = rstate.raid;
  if (!r || rstate.screen !== "fight") return;
  const now = serverNow();
  const startsIn = Date.parse(r.started_at) - now;
  if (startsIn > 0) { if (typeof showRaidCountdown === "function") showRaidCountdown(Math.ceil(startsIn / 1000)); return; }
  if (!rstate.fightStarted) {
    rstate.fightStarted = true;
    if (typeof showRaidCountdown === "function") showRaidCountdown(0);
    nextRaidQuestion();
  }
  const left = Date.parse(r.ends_at) - now;
  if (typeof renderRaidTimer === "function") renderRaidTimer(Math.max(0, left));
  // Time's up (plus a 1.5 s grace the server allows for answers still in flight)
  if (left <= -1600 && !rstate.finishCalled && r.status === "active") {
    rstate.finishCalled = true;
    finishRaid().then(() => { setTimeout(() => { rstate.finishCalled = false; }, 1500); }); // allow a retry if the server clock disagrees
  }
}

async function finishRaid() {
  const { data } = await supabase.rpc("finish_boss_raid", { p_raid_id: rstate.raid.id });
  if (data && data.ok) { noteServerTime(data.server_now); applyRaidRow(data.raid); }
}

function endFight() {
  rstate.question = null;
  if (rstate.timerId) { clearInterval(rstate.timerId); rstate.timerId = null; }
  if (rstate.screen === "results") return;
  rstate.screen = "results";
  // one last look at the final stats, then show the results after the finishing blow lands
  syncRaid().then(() => setTimeout(() => { if (rstate.screen === "results") renderRaidResults(); }, rstate.raid && rstate.raid.status === "won" ? 1400 : 600));
  if (typeof raidFinalBlow === "function") raidFinalBlow();
}

// Each student's questions come from the Drill generators at THEIR OWN level
// in the boss's station (the Grand Boss draws from every open station).
function nextRaidQuestion() {
  const topic = rstate.raid.topic === "mixed"
    ? pick((DRILL_TOPICS.filter((t) => !isStationLocked(t.key)).length ? DRILL_TOPICS.filter((t) => !isStationLocked(t.key)) : DRILL_TOPICS).map((t) => t.key))
    : rstate.raid.topic;
  const levels = (dstate.progress && dstate.progress.topic_levels) || {};
  const level = Math.max(1, Math.min(DRILL_MAX_LEVEL, levels[topic] || 1));
  rstate.question = generateDrillQuestion(topic, level);
  rstate.question._topic = topic;
  rstate.qStartedAt = Date.now();
  if (typeof renderRaidQuestion === "function") renderRaidQuestion();
}

async function submitRaidAnswer(raw, isSkip) {
  const r = rstate.raid, q = rstate.question;
  if (!r || !q || rstate.screen !== "fight" || r.status !== "active") return;
  if (sstate.readOnly) { toast("⏸️ Your account is in read-only mode."); return; }
  const correct = !isSkip && checkDrillAnswer(q, raw);
  const ms = Date.now() - rstate.qStartedAt;
  const shielded = !correct && typeof shopEffects !== "undefined" && shopEffects.shieldArmed && !rstate.shieldUsed;
  const answerText = fmtDrillAnswer(q);

  // Next question goes up IMMEDIATELY — the team's clock is ticking, nobody
  // waits on the network. The server's verdict is applied when it arrives.
  nextRaidQuestion();

  if (typeof triggerPetEvent === "function") triggerPetEvent(correct ? "QUESTION_CORRECT" : "QUESTION_WRONG");
  const { data, error } = await supabase.rpc("raid_submit_answer", {
    p_raid_id: r.id, p_student_id: raidMe(), p_correct: correct, p_ms: ms, p_shielded: !!shielded,
  });
  if (error || !data) { toast("Connection hiccup — that last answer may not have counted."); return; }
  noteServerTime(data.server_now);

  if (!data.ok) {
    if (data.error === "too_fast") toast("Easy! One answer at a time 🙂");
    else if (data.error === "time_up" || data.error === "not_active") { syncRaid(); }
    return;
  }
  // my own counters, right away (realtime/poll only ever raise them further)
  const meRow = rstate.members.find((m) => m.student_id === raidMe());
  if (meRow) {
    if (correct) { meRow.correct_count += 1; meRow.damage_dealt += -data.delta; }
    else { meRow.wrong_count += 1; meRow.healed_boss += Math.max(0, data.delta); }
  }
  if (data.shield_absorbed) { rstate.shieldUsed = true; if (typeof shopEffects !== "undefined") shopEffects.shieldArmed = false; }

  // Apply the boss HP the server just computed (unless a newer event already did)
  const wasSeq = rstate.raid.event_seq || 0;
  if ((data.event_seq || 0) >= wasSeq) {
    rstate.raid = { ...rstate.raid, boss_hp: data.boss_hp, event_seq: data.event_seq, status: data.status };
  }
  if (correct) {
    raidBossReact("hit");
    raidLogEvent(`⚔️ You hit for ${-data.delta}`, "hit", `-${-data.delta}`);
    raidFeedback(`✅ −${-data.delta} HP to the boss!`, "good");
  } else if (data.shield_absorbed) {
    raidLogEvent("🛡️ Your Shield absorbed the mistake", "shield", "🛡️");
    raidFeedback(`🛡️ Shield! The boss didn't heal.  Answer: ${answerText}`, "shield");
  } else {
    raidBossReact("heal");
    raidLogEvent(`💚 ${isSkip ? "Skipped" : "Missed"} — boss +${data.delta}`, "heal", `+${data.delta}`);
    raidFeedback(`${isSkip ? "⏭️ Skipped" : "❌ Wrong"} — the boss healed ${data.delta} HP.  Answer: ${answerText}`, "bad");
  }
  if (typeof renderRaidHp === "function") renderRaidHp();
  if (typeof renderRaidTeam === "function") renderRaidTeam();
  if (data.status === "won" || data.status === "lost") onRaidStatusChange("active", data.status);
}

function raidLogEvent(text, kind, floatText) {
  rstate.log.unshift({ text, kind, at: Date.now() });
  rstate.log = rstate.log.slice(0, 5);
  if (typeof renderRaidLog === "function") renderRaidLog();
  if (floatText && typeof spawnRaidFloat === "function") spawnRaidFloat(floatText, kind);
}

// ============================================================================
// REWARDS — claimed once per student per raid, enforced by the server
// ============================================================================
async function claimRaidRewards() {
  const r = rstate.raid;
  if (!r || rstate.resultsHandledFor === r.id) return;
  rstate.resultsHandledFor = r.id;
  const { data } = await supabase.rpc("claim_boss_raid_rewards", { p_raid_id: r.id, p_student_id: raidMe() });
  if (!data || !data.ok || !data.claimed) return; // already paid on another screen/device
  const reward = { won: data.won, contributed: data.contributed, stars: 0, green: 0, promoted: false, tierObj: null, firstDefeat: false };
  if (data.contributed) {
    if (data.won) {
      reward.green = 20; reward.stars = 1;
      try {
        const res = await awardMasteryStars(raidMe(), 1);
        reward.promoted = !!res.promoted; reward.tierObj = res.tierObj;
      } catch (e) { reward.stars = 0; }
    } else { reward.green = 5; }
    if (typeof awardGreenPoints === "function") awardGreenPoints(reward.green, false);
    if (typeof markDailyActivity === "function") markDailyActivity("battle");
  }
  await loadRaidCodex();
  if (data.won && rstate.codex && rstate.codex[r.topic] && rstate.codex[r.topic].wins === 1) reward.firstDefeat = true;
  rstate.lastReward = reward;
  if (rstate.raid && rstate.raid.id === r.id && rstate.screen === "results") renderRaidResults();
}
