-- ============================================================================
-- MathConnect — Migration 8: Simplify student login to a login code
-- ----------------------------------------------------------------------------
-- Replaces the "students set their own password via a real account" system
-- with something much simpler and more reliable: each student gets a short
-- login code from their teacher (shown in Roster). Student sign-in becomes
-- just Class Code + Login Code — no name typing, no password creation, no
-- Supabase Auth account per student, no more of the account-linking bugs
-- we've been chasing.
--
-- Trade-off, stated plainly: like the very first version of this app,
-- reading a student's data at the database level again only requires the
-- right class code + login code (or, at the database level, the anon key)
-- rather than a full password-protected account. This is appropriate for a
-- low-stakes classroom tool, and matches what you had before student
-- accounts were introduced — just with a code instead of a name for
-- students to identify themselves.
--
-- Safe to run on your existing database. Nothing is deleted — the old
-- auth_user_id/auth_email_version columns are simply left unused.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

-- ---------- Add login_code to students ----------
alter table students add column if not exists login_code text;
create unique index if not exists students_section_login_code_idx on students (section_id, login_code);

-- Auto-generate a login code for any existing students who don't have one yet
update students
set login_code = upper(substr(md5(random()::text || id::text), 1, 6))
where login_code is null;

-- ---------- Revert read access: back to anon (class code + login code app
-- logic) OR the owning teacher OR an admin — no more per-student auth check ----------
drop policy if exists "public read students" on students;
create policy "public read students" on students for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "student claims own row" on students;

drop policy if exists "public read sections" on sections;
create policy "public read sections" on sections for select using (
  auth.role() = 'anon' or teacher_id = auth.uid() or is_admin()
);

drop policy if exists "public read terms" on terms;
create policy "public read terms" on terms for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read assessments" on assessments;
create policy "public read assessments" on assessments for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read lessons" on lessons;
create policy "public read lessons" on lessons for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read tasks" on tasks;
create policy "public read tasks" on tasks for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read modules" on modules;
create policy "public read modules" on modules for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read schedule" on schedule;
create policy "public read schedule" on schedule for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read announcements" on announcements;
create policy "public read announcements" on announcements for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read scores" on scores;
create policy "public read scores" on scores for select using (
  auth.role() = 'anon' or is_teacher_of_assessment(assessment_id) or is_admin()
);
drop policy if exists "public read attendance" on attendance;
create policy "public read attendance" on attendance for select using (
  auth.role() = 'anon' or is_teacher_of_section(section_id) or is_admin()
);
drop policy if exists "public read submissions" on submissions;
create policy "public read submissions" on submissions for select using (
  auth.role() = 'anon' or is_teacher_of_task(task_id) or is_admin()
);

-- Submissions insert/update: back to open (student isn't an authenticated
-- identity anymore) — matches the very original design.
drop policy if exists "student or teacher insert submissions" on submissions;
create policy "anyone insert submissions" on submissions for insert with check (true);
drop policy if exists "student or teacher update submissions" on submissions;
create policy "anyone update submissions" on submissions for update using (true);

-- Done. Redeploy the updated app files. Existing students already have a
-- login code generated for them — check Roster to see/share each one.
