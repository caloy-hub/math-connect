-- ============================================================================
-- Migration 13 — Math Drill Arena (gamified drill exercises + leaderboard)
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this — supabase-schema.sql already
-- includes it.
-- ============================================================================

-- ---------- DRILL PROGRESS (one row per student — cumulative points & level per topic) ----------
create table if not exists drill_progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade unique,
  total_points integer not null default 0,
  games_played integer not null default 0,
  best_streak integer not null default 0,
  -- highest unlocked level (1-10) per topic
  topic_levels jsonb not null default '{"basic":1,"order":1,"integers":1,"fractions":1,"decimals":1,"algebra":1}'::jsonb,
  updated_at timestamptz default now()
);

-- ---------- DRILL ATTEMPTS (log of every completed run — history + anti-cheat trail) ----------
create table if not exists drill_attempts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  topic text not null,
  level int not null,
  correct_count int not null,
  total_questions int not null,
  points_earned int not null,
  bonus_points int not null default 0,
  penalty_points int not null default 0,
  leveled_up boolean not null default false,
  played_at timestamptz default now()
);
create index if not exists drill_attempts_student_idx on drill_attempts (student_id);

-- ---------- RLS HELPER ----------
create or replace function public.is_teacher_of_student(target_student_id uuid)
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from students st join sections s on s.id = st.section_id
    where st.id = target_student_id and s.teacher_id = auth.uid()
  );
$$;

alter table drill_progress enable row level security;
alter table drill_attempts enable row level security;

-- Same security model as the rest of the app (see note in supabase-schema.sql):
-- students are anon requests, so reads are public (needed for the school-wide,
-- same-grade-level leaderboard) and writes are open client-side, matching the
-- existing pattern used for "submissions". Teachers can only delete rows
-- belonging to their own students.
drop policy if exists "public read drill_progress" on drill_progress;
create policy "public read drill_progress" on drill_progress for select using (true);
drop policy if exists "anyone insert drill_progress" on drill_progress;
create policy "anyone insert drill_progress" on drill_progress for insert with check (true);
drop policy if exists "anyone update drill_progress" on drill_progress;
create policy "anyone update drill_progress" on drill_progress for update using (true);
drop policy if exists "teacher delete drill_progress" on drill_progress;
create policy "teacher delete drill_progress" on drill_progress for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read drill_attempts" on drill_attempts;
create policy "public read drill_attempts" on drill_attempts for select using (true);
drop policy if exists "anyone insert drill_attempts" on drill_attempts;
create policy "anyone insert drill_attempts" on drill_attempts for insert with check (true);
drop policy if exists "teacher delete drill_attempts" on drill_attempts;
create policy "teacher delete drill_attempts" on drill_attempts for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ----------------------------------------------------------------------------
-- Grade-level leaderboard, exposed as narrow SECURITY DEFINER functions.
-- Teachers normally can't read other teachers' sections/students (by design —
-- see the multi-teacher isolation notes in supabase-schema.sql), so a plain
-- query for a school-wide "same grade level" leaderboard would silently miss
-- other teachers' students when called from a signed-in teacher's session.
-- These functions return only the few aggregate fields the leaderboard needs
-- (name, section, points) — never full roster/grade/attendance data — so
-- both students (anon) and teachers can see the same complete leaderboard.
-- ----------------------------------------------------------------------------
create or replace function public.grade_level_drill_leaderboard(target_grade_level text, result_limit int default 10)
returns table(student_id uuid, full_name text, section_id uuid, section_name text, total_points integer, games_played integer, best_streak integer)
language sql security definer stable as $$
  select st.id, st.full_name, se.id, se.section_name, dp.total_points, dp.games_played, dp.best_streak
  from drill_progress dp
  join students st on st.id = dp.student_id
  join sections se on se.id = st.section_id
  where se.grade_level = target_grade_level
  order by dp.total_points desc
  limit result_limit;
$$;
grant execute on function public.grade_level_drill_leaderboard(text, int) to anon, authenticated;

create or replace function public.student_drill_rank(target_student_id uuid)
returns table(rnk bigint, total_points integer, total_students bigint)
language sql security definer stable as $$
  with target_grade as (
    select se.grade_level from students st join sections se on se.id = st.section_id where st.id = target_student_id
  ), board as (
    select dp.student_id, dp.total_points, row_number() over (order by dp.total_points desc) as rnk
    from drill_progress dp
    join students st on st.id = dp.student_id
    join sections se on se.id = st.section_id
    where se.grade_level = (select grade_level from target_grade)
  )
  select b.rnk, b.total_points, (select count(*) from board) from board b where b.student_id = target_student_id;
$$;
grant execute on function public.student_drill_rank(uuid) to anon, authenticated;

-- ============================================================================
-- Done. Students will see a new "🎮 Math Drills" tab on their dashboard next
-- time they load the app — no other setup needed.
-- ============================================================================
