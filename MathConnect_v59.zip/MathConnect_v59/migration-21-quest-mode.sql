-- ============================================================================
-- Migration 21 — Quest Mode (story-driven chapter map over the Drill Arena)
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this — supabase-schema.sql already
-- includes it.
-- ============================================================================

-- ---------- QUEST PROGRESS (one row per student — stars per chapter/level) ----------
create table if not exists quest_progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade unique,
  -- { "science": [0,0,0,0,0,0,0,0,0,0], "english": [...], ... } — 0-3 stars per level, 10 levels per chapter.
  level_stars jsonb not null default '{}'::jsonb,
  total_stars integer not null default 0,
  chapters_unlocked integer not null default 1,
  runs_played integer not null default 0,
  updated_at timestamptz default now()
);

-- ---------- QUEST ATTEMPTS (log of every completed level run) ----------
create table if not exists quest_attempts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  chapter_key text not null,
  level_num int not null,
  correct_count int not null,
  total_questions int not null,
  stars_earned int not null default 0,
  points_earned int not null default 0,
  played_at timestamptz default now()
);
create index if not exists quest_attempts_student_idx on quest_attempts (student_id);

-- ---------- RLS ----------
-- Same security model as drill_progress/drill_attempts (see migration-13):
-- students are anon requests, so reads/writes are open client-side; teachers
-- can only delete rows belonging to their own students. Reuses the
-- is_teacher_of_student() helper created by migration-13-math-drills.sql /
-- supabase-schema.sql.
alter table quest_progress enable row level security;
alter table quest_attempts enable row level security;

drop policy if exists "public read quest_progress" on quest_progress;
create policy "public read quest_progress" on quest_progress for select using (true);
drop policy if exists "anyone insert quest_progress" on quest_progress;
create policy "anyone insert quest_progress" on quest_progress for insert with check (true);
drop policy if exists "anyone update quest_progress" on quest_progress;
create policy "anyone update quest_progress" on quest_progress for update using (true);
drop policy if exists "teacher delete quest_progress" on quest_progress;
create policy "teacher delete quest_progress" on quest_progress for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

drop policy if exists "public read quest_attempts" on quest_attempts;
create policy "public read quest_attempts" on quest_attempts for select using (true);
drop policy if exists "anyone insert quest_attempts" on quest_attempts;
create policy "anyone insert quest_attempts" on quest_attempts for insert with check (true);
drop policy if exists "teacher delete quest_attempts" on quest_attempts;
create policy "teacher delete quest_attempts" on quest_attempts for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ============================================================================
-- Done. Students will see a new "🗺️ Quest Mode" tab on their dashboard, and
-- teachers a matching read-only "🗺️ Quest Mode" tab, next time they load the
-- app — no other setup needed.
-- ============================================================================
