// ============================================================================
// MathConnect — MathLegends Mathematician Spotlight
// Background + contributions for the real mathematician behind the student's
// CURRENT overall MathLegends rank (see rankEngine.js for the 15-tier list).
// Rendered in two places:
//   1. A modal that pops up automatically every time a student logs in
//      (triggered from student.js -> initStudent()).
//   2. A persistent "Meet Your Rank's Mathematician" card on the Overview
//      ("This Week") tab, so it's always visible on the dashboard too.
//
// Portraits are fetched at runtime from the Wikipedia REST API (public-domain
// historical portraits) and cached in memory. If a portrait can't be fetched
// (offline, blocked, page renamed, etc.) the card gracefully falls back to
// the mathematician's tier emoji/color instead of a broken image.
//
// Loaded by: student.html — AFTER rankEngine.js (needs RANK tier objects)
// and BEFORE student.js is *executed* (script tags run in order, and
// initStudent()'s first await gives later tags time to load — see comment
// at the top of student.js for why this ordering is safe).
// ============================================================================

const MATH_BIOS = {
  Pythagoras: {
    period: "c. 570 – 495 BCE",
    place: "Samos, Greece",
    wiki: "Pythagoras",
    tagline: "Greek philosopher who founded a school built around numbers.",
    contributions: [
      "Best known for the Pythagorean theorem relating the sides of a right triangle (a² + b² = c²), foundational to geometry and trigonometry.",
      "Taught that numbers and numerical ratios underlie music, astronomy, and nature itself.",
      "His followers, the Pythagoreans, were among the first to treat mathematics as a subject worth studying for its own sake.",
    ],
  },
  Euclid: {
    period: "c. 300 BCE",
    place: "Alexandria, Egypt",
    wiki: "Euclid",
    tagline: "The \"Father of Geometry.\"",
    contributions: [
      "Wrote 'Elements', a 13-book compilation that organized geometry into a system of definitions, axioms, and logically proven theorems.",
      "Introduced the axiomatic method — starting from a few accepted truths and proving everything else from them — still the model for how mathematics is done today.",
      "'Elements' remained a standard textbook for over 2,000 years, longer than almost any other book in history.",
    ],
  },
  "Al-Khwarizmi": {
    period: "c. 780 – 850 CE",
    place: "Baghdad, House of Wisdom",
    wiki: "Muhammad ibn Musa al-Khwarizmi",
    tagline: "The scholar who gave us the word \"algebra.\"",
    contributions: [
      "Wrote 'Al-Jabr', a book on solving linear and quadratic equations — the word \"algebra\" comes directly from its title.",
      "Systematized methods for balancing and simplifying equations, laying the groundwork for algebra as a distinct branch of mathematics.",
      "His name, Latinized as 'Algoritmi', is the origin of the word \"algorithm.\"",
    ],
  },
  Fibonacci: {
    period: "c. 1170 – 1250",
    place: "Pisa, Italy",
    wiki: "Fibonacci",
    tagline: "Introduced Europe to the number system we use today.",
    contributions: [
      "Wrote 'Liber Abaci', which introduced the Hindu-Arabic numeral system (0–9 and place value) to Europe, replacing clumsy Roman numerals.",
      "Popularized the Fibonacci sequence (1, 1, 2, 3, 5, 8, 13...) through a problem about rabbit population growth.",
      "The Fibonacci sequence turns up throughout nature — in flower petals, pinecones, and spiral shells — and is a favorite gateway into patterns for young mathematicians.",
    ],
  },
  Descartes: {
    period: "1596 – 1650",
    place: "France",
    wiki: "René Descartes",
    tagline: "Merged algebra and geometry into one picture.",
    contributions: [
      "Invented the Cartesian coordinate system (the x-y plane) that lets algebraic equations be drawn as shapes and graphs.",
      "This fusion of algebra and geometry — analytic geometry — is the reason we can plot a line, a parabola, or a circle from an equation.",
      "Also a major philosopher (\"I think, therefore I am\"), showing math and philosophy often grow from the same rigorous habits of mind.",
    ],
  },
  Pascal: {
    period: "1623 – 1662",
    place: "France",
    wiki: "Blaise Pascal",
    tagline: "Built one of the first mechanical calculators and co-founded probability theory.",
    contributions: [
      "Co-founded probability theory with Pierre de Fermat while working out how to fairly divide stakes in an interrupted game of chance.",
      "Discovered \"Pascal's Triangle,\" a triangular array of numbers used in algebra, probability, and combinatorics.",
      "Built the 'Pascaline', one of the earliest mechanical calculators, to help his father with tax calculations.",
    ],
  },
  Newton: {
    period: "1642 – 1727",
    place: "England",
    wiki: "Isaac Newton",
    tagline: "Co-invented calculus and explained the motion of the planets.",
    contributions: [
      "Independently developed calculus (alongside Leibniz), giving mathematics tools to describe change and motion precisely.",
      "Formulated the laws of motion and universal gravitation, unifying the physics of falling apples and orbiting planets under one theory.",
      "Used mathematics not just to describe the world but to predict it — a turning point for both math and science.",
    ],
  },
  Leibniz: {
    period: "1646 – 1716",
    place: "Germany",
    wiki: "Gottfried Wilhelm Leibniz",
    tagline: "Gave calculus the notation we still use today.",
    contributions: [
      "Independently co-invented calculus and created the dy/dx and ∫ (integral sign) notation still used in classrooms worldwide.",
      "Did pioneering work on binary number systems — the 0s and 1s that all modern computers run on.",
      "Believed in building calculating machines and symbolic systems to make reasoning itself more mechanical and reliable.",
    ],
  },
  Euler: {
    period: "1707 – 1783",
    place: "Switzerland",
    wiki: "Leonhard Euler",
    tagline: "The most prolific mathematician in history.",
    contributions: [
      "Introduced much of modern mathematical notation, including f(x) for functions, e for Euler's number, and Σ for summation.",
      "Discovered Euler's Identity (e^(iπ) + 1 = 0), often called the most beautiful equation in mathematics for linking five fundamental constants.",
      "Made foundational contributions across nearly every branch of math — number theory, graph theory, mechanics — despite going blind later in life.",
    ],
  },
  Gauss: {
    period: "1777 – 1855",
    place: "Germany",
    wiki: "Carl Friedrich Gauss",
    tagline: "Called the \"Prince of Mathematicians.\"",
    contributions: [
      "As a child, famously found a shortcut to sum 1 to 100 instantly by pairing numbers — a trick still taught to introduce mathematical thinking.",
      "Developed the normal (Gaussian) distribution, the \"bell curve\" used throughout statistics, science, and data analysis.",
      "Made deep contributions to number theory, geometry, and astronomy, and helped lay the foundations of modern statistics.",
    ],
  },
  Riemann: {
    period: "1826 – 1866",
    place: "Germany",
    wiki: "Bernhard Riemann",
    tagline: "Reimagined the geometry of curved space.",
    contributions: [
      "Developed Riemannian geometry, a way of describing curved, non-flat spaces — decades later, this became the mathematical backbone of Einstein's general relativity.",
      "Proposed the Riemann Hypothesis about the pattern of prime numbers, still one of the most famous unsolved problems in mathematics.",
      "Extended calculus and analysis in ways that reshaped how mathematicians think about space, functions, and infinity.",
    ],
  },
  Cantor: {
    period: "1845 – 1918",
    place: "Germany",
    wiki: "Georg Cantor",
    tagline: "Proved that not all infinities are the same size.",
    contributions: [
      "Created set theory, the branch of mathematics that studies collections of objects and now underlies almost all of modern math.",
      "Proved that some infinite sets (like the real numbers) are strictly larger than others (like the counting numbers) — a mind-bending result that was controversial in his lifetime.",
      "Introduced the idea of different \"sizes\" of infinity, giving mathematicians precise language to reason about the infinite.",
    ],
  },
  Noether: {
    period: "1882 – 1935",
    place: "Germany",
    wiki: "Emmy Noether",
    tagline: "Called by Einstein \"the most significant creative mathematical genius\" of her time.",
    contributions: [
      "Proved Noether's Theorem, showing that every symmetry in physics corresponds to a conservation law (like energy or momentum) — a cornerstone of modern physics.",
      "Made foundational contributions to abstract algebra, essentially building the modern theory of rings, fields, and algebraic structures.",
      "Did groundbreaking work despite being barred for years from paid academic positions because she was a woman — she kept teaching and publishing anyway.",
    ],
  },
  Ramanujan: {
    period: "1887 – 1920",
    place: "Tamil Nadu, India",
    wiki: "Srinivasa Ramanujan",
    tagline: "A self-taught genius who reshaped number theory.",
    contributions: [
      "With almost no formal training, independently discovered thousands of results in number theory, infinite series, and continued fractions.",
      "His notebooks, sent to mathematician G. H. Hardy in England, contained formulas so original that mathematicians are still finding uses for them a century later.",
      "Proved that raw mathematical talent and intuition can rival — and sometimes outpace — formal academic training.",
    ],
  },
  Archimedes: {
    period: "c. 287 – 212 BCE",
    place: "Syracuse, Sicily",
    wiki: "Archimedes",
    tagline: "Ancient Greece's greatest mathematician, physicist, and engineer.",
    contributions: [
      "Calculated an extremely accurate approximation of π using polygons with many sides, centuries before calculus existed.",
      "Worked out formulas for the area and volume of spheres, cylinders, and other curved shapes — an early precursor to integral calculus.",
      "Applied mathematics to real engineering, from the Archimedes screw (used to lift water) to principles of buoyancy and levers still used today.",
    ],
  },
};

// ---------------------------------------------------------------------------
// Portrait fetching — Wikipedia REST API, cached in memory for the session.
// Fails silently (returns null) so the UI can fall back gracefully.
// ---------------------------------------------------------------------------
const _mathBioImageCache = {};
async function fetchMathBioImage(wikiTitle) {
  if (Object.prototype.hasOwnProperty.call(_mathBioImageCache, wikiTitle)) return _mathBioImageCache[wikiTitle];
  try {
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(wikiTitle)}`);
    if (!res.ok) throw new Error("wiki summary fetch failed");
    const data = await res.json();
    const url = (data.thumbnail && data.thumbnail.source) || (data.originalimage && data.originalimage.source) || null;
    _mathBioImageCache[wikiTitle] = url;
    return url;
  } catch (e) {
    _mathBioImageCache[wikiTitle] = null;
    return null;
  }
}

// Swaps the placeholder emoji circle for the real portrait once it loads.
// No-op (leaves the emoji fallback in place) if the image can't be fetched.
async function _hydrateMathBioPortrait(imgWrapId, wikiTitle, tierColor) {
  const url = await fetchMathBioImage(wikiTitle);
  const wrap = document.getElementById(imgWrapId);
  if (!wrap || !url) return;
  const img = new Image();
  img.onload = () => { wrap.innerHTML = `<img src="${url}" alt="Portrait" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />`; };
  img.onerror = () => {}; // keep emoji fallback
  img.src = url;
}

// Renders the bio card's inner HTML for a given tier (from rankEngine.js's
// RANK_TIERS). `idSuffix` keeps element ids unique when the card is rendered
// in more than one place (overview tab vs. login modal) at once.
function renderMathBioCardHtml(tierObj, idSuffix) {
  const bio = MATH_BIOS[tierObj.short] || MATH_BIOS[tierObj.math];
  const imgWrapId = `mathbio-portrait-${idSuffix}`;
  if (!bio) {
    return `<div class="card"><p class="muted">No background available for this rank yet.</p></div>`;
  }
  const html = `
    <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap;">
      <div id="${imgWrapId}" style="width:84px;height:84px;border-radius:50%;flex-shrink:0;background:${tierObj.color}22;border:2px solid ${tierObj.color}66;display:flex;align-items:center;justify-content:center;font-size:2.2rem;">${tierObj.emoji}</div>
      <div style="flex:1;min-width:200px;">
        <div class="muted" style="font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;">Your Rank's Mathematician</div>
        <h3 style="margin:2px 0;">${escapeHtml(bio.wiki)}</h3>
        <div class="muted" style="font-size:.82rem;">${escapeHtml(bio.period)} · ${escapeHtml(bio.place)}</div>
        <p style="margin:8px 0 0;font-weight:600;">${escapeHtml(bio.tagline)}</p>
      </div>
    </div>
    <div style="margin-top:14px;">
      <div class="muted" style="font-size:.78rem;font-weight:600;text-transform:uppercase;letter-spacing:.03em;">Contributions to Mathematics</div>
      <ul style="margin:8px 0 0;padding-left:20px;">
        ${bio.contributions.map((c) => `<li style="margin-bottom:6px;">${escapeHtml(c)}</li>`).join("")}
      </ul>
    </div>`;
  // Fire-and-forget: try to swap the emoji for a real portrait.
  _hydrateMathBioPortrait(imgWrapId, bio.wiki, tierObj.color);
  return html;
}

// Persistent dashboard card — used on the Overview ("This Week") tab.
function renderMathBioOverviewCard(tierObj, stars) {
  return `
    <div class="card" style="margin-top:16px;border-left:4px solid ${tierObj.color};">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
        <h3 style="margin:0;">🏛️ Meet Your Rank's Mathematician</h3>
        ${renderRankBadge(tierObj, { size: "small", withStars: true, stars: stars || 0 })}
      </div>
      <div style="margin-top:12px;">${renderMathBioCardHtml(tierObj, "overview")}</div>
    </div>`;
}

// Login modal — pops up automatically every time a student logs in
// (called from student.js -> initStudent()).
function showMathBioLoginModal(tierObj) {
  const root = document.getElementById("modalRoot");
  if (!root || !tierObj) return;
  root.innerHTML = `
    <div class="modal-backdrop" onclick="if(event.target===this) document.getElementById('modalRoot').innerHTML=''">
      <div class="modal" style="max-width:560px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
          <div class="pill" style="background:${tierObj.color}22;color:${tierObj.color};">${tierObj.emoji} Welcome back!</div>
          <button class="btn-outline btn-sm" onclick="document.getElementById('modalRoot').innerHTML=''">✕ Close</button>
        </div>
        <p class="muted" style="margin:8px 0 14px;">You're currently ranked <strong>${escapeHtml(tierObj.name)}</strong>. Here's the mathematician behind your rank:</p>
        ${renderMathBioCardHtml(tierObj, "modal")}
        <div style="margin-top:18px;text-align:right;">
          <button class="btn-primary" onclick="document.getElementById('modalRoot').innerHTML=''">Let's Go! 🚀</button>
        </div>
      </div>
    </div>`;
}
