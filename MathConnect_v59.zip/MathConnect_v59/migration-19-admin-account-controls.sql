-- ============================================================================
-- Migration 19 — Admin account controls
-- ----------------------------------------------------------------------------
-- Upgrades the admin role from read-only oversight (migration-6) to also
-- being able to, for ANY teacher or student account:
--   - Pause it: "Read-only" (can still log in, can't create/change/delete
--     anything) or "Frozen" (can't log in at all)
--   - Delete the account entirely
--   - Correct the "joined" timestamp (created_at) on the account itself
--   - Correct or delete individual activity entries — attendance records,
--     scores, and drill attempts — including their timestamps
--
-- ⚠️ IMPORTANT SECURITY NOTE (read before relying on this):
--   Teachers sign in with real Supabase Auth (email+password), so "Read-only"
--   for a teacher is enforced two ways: the app blocks them at login/UI, AND
--   the database itself rejects their writes via RLS below — real
--   enforcement, not just a UI suggestion.
--
--   Students do NOT have real accounts — they sign in with a teacher-assigned
--   code, and the whole app already trusts the browser to say "I am student
--   X" for every write (drill attempts, battle answers, shop purchases, etc.)
--   with no server-side identity check. This is the same trust model already
--   documented for Math Drills and Boss Battles elsewhere in this app. That
--   means a paused STUDENT is enforced at login (frozen can't log in) and in
--   the app's UI (read-only disables the buttons that submit new data), but
--   NOT at the database level — a technically sophisticated student could
--   still call the API directly while paused. Making that fully unbreakable
--   would require moving students onto real Supabase Auth accounts, which is
--   a bigger change than this migration. For a classroom app this is an
--   acceptable, but real, limitation — flagging it clearly rather than
--   pretending otherwise.
--
-- Safe to run on your existing database — nothing is deleted, existing rows
-- default to account_status = 'active' (unaffected).
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

-- ---------- Status columns ----------
alter table teachers add column if not exists account_status text not null default 'active'
  check (account_status in ('active', 'readonly', 'frozen'));
alter table teachers add column if not exists status_note text;
alter table teachers add column if not exists status_updated_at timestamptz;

alter table students add column if not exists account_status text not null default 'active'
  check (account_status in ('active', 'readonly', 'frozen'));
alter table students add column if not exists status_note text;
alter table students add column if not exists status_updated_at timestamptz;

-- ---------- Helper: is the CURRENTLY SIGNED-IN teacher allowed to write? ----------
-- Frozen teachers can't reach this point anyway (app blocks login), but this
-- is what actually stops a Read-only teacher's writes at the database level.
create or replace function public.teacher_writable()
returns boolean language sql security definer stable as $$
  select coalesce(
    (select account_status = 'active' from teachers where id = auth.uid()),
    false
  );
$$;
grant execute on function public.teacher_writable() to anon, authenticated;

-- ============================================================================
-- ADMIN CAN NOW MANAGE (not just read) TEACHER & STUDENT ACCOUNTS
-- ============================================================================
drop policy if exists "admin manage teachers" on teachers;
create policy "admin manage teachers" on teachers for update using (is_admin());
drop policy if exists "admin delete teachers" on teachers;
create policy "admin delete teachers" on teachers for delete using (is_admin());

drop policy if exists "admin manage students" on students;
create policy "admin manage students" on students for update using (is_admin());
drop policy if exists "admin delete students" on students;
create policy "admin delete students" on students for delete using (is_admin());

-- ============================================================================
-- ENFORCE "READ-ONLY" FOR TEACHERS AT THE DATABASE LEVEL
-- Re-creates each teacher-owned write policy with the same ownership check
-- as before, PLUS teacher_writable(). Read/select policies are untouched —
-- a read-only teacher can still see everything, just not change it.
-- ============================================================================
drop policy if exists "teacher insert sections" on sections;
create policy "teacher insert sections" on sections for insert with check (auth.uid() = teacher_id and teacher_writable());
drop policy if exists "teacher update sections" on sections;
create policy "teacher update sections" on sections for update using (auth.uid() = teacher_id and teacher_writable());
drop policy if exists "teacher delete sections" on sections;
create policy "teacher delete sections" on sections for delete using (auth.uid() = teacher_id and teacher_writable());

drop policy if exists "teacher write students" on students;
create policy "teacher write students" on students for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update students" on students;
create policy "teacher update students" on students for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete students" on students;
create policy "teacher delete students" on students for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write terms" on terms;
create policy "teacher write terms" on terms for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update terms" on terms;
create policy "teacher update terms" on terms for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete terms" on terms;
create policy "teacher delete terms" on terms for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write assessments" on assessments;
create policy "teacher write assessments" on assessments for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update assessments" on assessments;
create policy "teacher update assessments" on assessments for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete assessments" on assessments;
create policy "teacher delete assessments" on assessments for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write scores" on scores;
create policy "teacher write scores" on scores for insert with check (is_teacher_of_assessment(assessment_id) and teacher_writable());
drop policy if exists "teacher update scores" on scores;
create policy "teacher update scores" on scores for update using (is_teacher_of_assessment(assessment_id) and teacher_writable());
drop policy if exists "teacher delete scores" on scores;
create policy "teacher delete scores" on scores for delete using (is_teacher_of_assessment(assessment_id) and teacher_writable());

drop policy if exists "teacher write attendance" on attendance;
create policy "teacher write attendance" on attendance for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update attendance" on attendance;
create policy "teacher update attendance" on attendance for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete attendance" on attendance;
create policy "teacher delete attendance" on attendance for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write lessons" on lessons;
create policy "teacher write lessons" on lessons for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update lessons" on lessons;
create policy "teacher update lessons" on lessons for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete lessons" on lessons;
create policy "teacher delete lessons" on lessons for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write tasks" on tasks;
create policy "teacher write tasks" on tasks for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update tasks" on tasks;
create policy "teacher update tasks" on tasks for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete tasks" on tasks;
create policy "teacher delete tasks" on tasks for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write modules" on modules;
create policy "teacher write modules" on modules for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update modules" on modules;
create policy "teacher update modules" on modules for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete modules" on modules;
create policy "teacher delete modules" on modules for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write schedule" on schedule;
create policy "teacher write schedule" on schedule for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update schedule" on schedule;
create policy "teacher update schedule" on schedule for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete schedule" on schedule;
create policy "teacher delete schedule" on schedule for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teacher write announcements" on announcements;
create policy "teacher write announcements" on announcements for insert with check (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher update announcements" on announcements;
create policy "teacher update announcements" on announcements for update using (is_teacher_of_section(section_id) and teacher_writable());
drop policy if exists "teacher delete announcements" on announcements;
create policy "teacher delete announcements" on announcements for delete using (is_teacher_of_section(section_id) and teacher_writable());

drop policy if exists "teachers insert learners" on learners;
create policy "teachers insert learners" on learners for insert with check (auth.uid() is not null and teacher_writable());
drop policy if exists "teachers update learners" on learners;
create policy "teachers update learners" on learners for update using (auth.uid() is not null and teacher_writable());

-- ============================================================================
-- ADMIN CAN NOW EDIT/DELETE INDIVIDUAL ACTIVITY ENTRIES (and their timestamps)
-- Teacher-owned write access to these three tables is unchanged; this only
-- ADDS a parallel admin path (for correcting a wrong date or removing a bad
-- entry from the admin panel, independent of which teacher owns the class).
-- ============================================================================
drop policy if exists "admin update attendance" on attendance;
create policy "admin update attendance" on attendance for update using (is_admin());
drop policy if exists "admin delete attendance" on attendance;
create policy "admin delete attendance" on attendance for delete using (is_admin());

drop policy if exists "admin update scores" on scores;
create policy "admin update scores" on scores for update using (is_admin());
drop policy if exists "admin delete scores" on scores;
create policy "admin delete scores" on scores for delete using (is_admin());

alter table drill_attempts enable row level security;
drop policy if exists "admin update drill_attempts" on drill_attempts;
create policy "admin update drill_attempts" on drill_attempts for update using (is_admin());
drop policy if exists "admin delete drill_attempts" on drill_attempts;
create policy "admin delete drill_attempts" on drill_attempts for delete using (is_admin());
drop policy if exists "admin read drill_attempts" on drill_attempts;
create policy "admin read drill_attempts" on drill_attempts for select using (is_admin());

-- ============================================================================
-- Done. Reload the admin panel — teacher and student rows now show a status
-- control (Active / Read-only / Frozen), a Delete button, and an editable
-- "Joined" date. Attendance, Scores, and Drill Attempts entries can be
-- corrected or removed from each student's expanded row.
-- ============================================================================
