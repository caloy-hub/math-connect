-- ============================================================================
-- Migration 32 — Math Pet (v1: adopt + feed)
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this if supabase-schema.sql was
-- already updated to include it.
--
-- Scope of this first drop (per the agreed plan): adopt a free pet from the
-- Shop, feed it with Green Points (earned everywhere) or with Food (bought
-- in the Shop with Coins). Pet dialogue/reactions (hungry/lonely/cheering)
-- are intentionally NOT in this migration — that's a follow-up slice, same
-- as how Exams shipped Core first and Bulk Add / shuffle came later.
--
-- Design notes:
--   - Green Points is a brand-new currency, separate from Coins. It lives on
--     the same per-student wallet row Coins already use (student_engagement)
--     rather than a second disconnected store — same reasoning as how
--     migration-17 added `inventory` to that row instead of a new table.
--   - EARNING Green Points is client-writable, same trust tier as Coins
--     today (see the security note at the bottom of migration-17 — this app
--     already accepts that tradeoff for the existing coins/points columns).
--     awardGreenPoints() in streakEngine.js is the client-side equivalent of
--     awardCoins().
--   - SPENDING Green Points or Coins on the pet (feeding, buying food,
--     adopting) goes through security-definer RPCs, same pattern as
--     purchase_shop_item — so a double-tap or a tampered client can't feed
--     a negative amount or buy food at a fake price. Unlike shop_items,
--     student_pets has NO general "anyone update" RLS policy — every write
--     to it goes through one of the RPCs below.
-- ============================================================================

-- ---------- Green Points wallet ----------
alter table student_engagement add column if not exists green_points integer not null default 0;

-- ---------- Pet catalog (free to adopt — a teacher/admin could retune this later) ----------
create table if not exists pet_types (
  key text primary key,
  name text not null,
  icon text not null,              -- emoji, keeps this dependency-free like SHOP_ITEM_META
  description text,
  sort_order integer not null default 0,
  active boolean not null default true
);

insert into pet_types (key, name, icon, description, sort_order) values
  ('numo_fox',      'Numo the Number Fox',    '🦊', 'Quick, clever, and always counting something.',        1),
  ('pico_penguin',  'Pico the Pi Penguin',    '🐧', 'Waddles in perfect circles. Loves rounding up snacks.',  2),
  ('digit_dragon',  'Digit the Digit Dragon', '🐲', 'Breathes out equations instead of fire (mostly).',       3),
  ('sumi_bunny',    'Sumi the Sum Bunny',     '🐰', 'Hops from problem to problem, adding up wins.',          4),
  ('ari_owl',       'Ari the Abacus Owl',     '🦉', 'Wise, patient, and great at late-night reviewing.',      5)
on conflict (key) do update set
  name = excluded.name, icon = excluded.icon, description = excluded.description,
  sort_order = excluded.sort_order, active = true;

alter table pet_types enable row level security;
drop policy if exists "public read pet_types" on pet_types;
create policy "public read pet_types" on pet_types for select using (true);

-- ---------- Food catalog (bought with Coins in the Shop) ----------
create table if not exists pet_food_items (
  key text primary key,
  name text not null,
  icon text not null,
  cost_coins integer not null,
  restore_amount integer not null,  -- hunger points restored, capped at 100 by feed_pet_food()
  sort_order integer not null default 0,
  active boolean not null default true
);

insert into pet_food_items (key, name, icon, cost_coins, restore_amount, sort_order) values
  ('math_snack',    'Math Snack',        '🍪', 5,  20,  1),
  ('number_nuggets','Number Nuggets',    '🍱', 10, 45,  2),
  ('equation_cake', 'Equation Cake',     '🎂', 20, 100, 3)
on conflict (key) do update set
  name = excluded.name, icon = excluded.icon, cost_coins = excluded.cost_coins,
  restore_amount = excluded.restore_amount, sort_order = excluded.sort_order, active = true;

alter table pet_food_items enable row level security;
drop policy if exists "public read pet_food_items" on pet_food_items;
create policy "public read pet_food_items" on pet_food_items for select using (true);

-- ---------- One pet per student ----------
create table if not exists student_pets (
  student_id uuid primary key references students(id) on delete cascade,
  pet_type_key text not null references pet_types(key),
  pet_name text,
  hunger integer not null default 100,       -- 0-100, restored by feeding
  growth_points integer not null default 0,  -- cumulative Green Points fed — drives the pet's growth stage
  food_inventory jsonb not null default '{}'::jsonb,  -- food key -> owned count, same shape as shop inventory
  adopted_at timestamptz default now(),
  last_fed_at timestamptz,
  updated_at timestamptz default now()
);

alter table student_pets enable row level security;
drop policy if exists "public read student_pets" on student_pets;
create policy "public read student_pets" on student_pets for select using (true);
drop policy if exists "teacher delete student_pets" on student_pets;
create policy "teacher delete student_pets" on student_pets for delete using (
  is_teacher_of_student(student_id) or is_admin()
);
-- Note: intentionally no "anyone insert/update" policy — every write goes
-- through adopt_pet / feed_pet_green_points / feed_pet_food / purchase_pet_food
-- below, which run as security definer and so bypass RLS.

-- ---------- Feeding log (append-only, mirrors shop_purchases / quest_attempts) ----------
create table if not exists pet_feed_log (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  fed_with text not null check (fed_with in ('green_points', 'food')),
  food_key text references pet_food_items(key),
  amount integer not null,
  fed_at timestamptz default now()
);
create index if not exists pet_feed_log_student_idx on pet_feed_log (student_id);

alter table pet_feed_log enable row level security;
drop policy if exists "public read pet_feed_log" on pet_feed_log;
create policy "public read pet_feed_log" on pet_feed_log for select using (true);
drop policy if exists "teacher delete pet_feed_log" on pet_feed_log;
create policy "teacher delete pet_feed_log" on pet_feed_log for delete using (
  is_teacher_of_student(student_id) or is_admin()
);

-- ----------------------------------------------------------------------------
-- adopt_pet — one free pet per student. Row-locked so two rapid taps (e.g. a
-- laggy connection retry) can't both succeed and silently overwrite each
-- other's pet_type choice.
-- ----------------------------------------------------------------------------
create or replace function public.adopt_pet(target_student_id uuid, target_pet_type_key text, target_pet_name text default null)
returns table(success boolean, message text, pet jsonb)
language plpgsql security definer as $$
declare
  type_active boolean;
  existing record;
begin
  select active into type_active from pet_types where key = target_pet_type_key;
  if type_active is null then
    return query select false, 'That pet does not exist.', null::jsonb;
    return;
  end if;
  if not type_active then
    return query select false, 'That pet is not available right now.', null::jsonb;
    return;
  end if;

  select * into existing from student_pets where student_id = target_student_id for update;
  if found then
    return query select false, 'You already have a pet!', to_jsonb(existing);
    return;
  end if;

  insert into student_pets (student_id, pet_type_key, pet_name, hunger, growth_points, food_inventory)
  values (target_student_id, target_pet_type_key, nullif(trim(target_pet_name), ''), 100, 0, '{}'::jsonb)
  returning * into existing;

  return query select true, 'Adopted!', to_jsonb(existing);
end;
$$;
grant execute on function public.adopt_pet(uuid, text, text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- feed_pet_green_points — spends Green Points to grow the pet. Increases
-- growth_points (drives the pet's growth stage in the UI) and tops up hunger
-- by the same amount (capped at 100) — nurturing feeds it too, not just food.
-- ----------------------------------------------------------------------------
create or replace function public.feed_pet_green_points(target_student_id uuid, amount integer)
returns table(success boolean, message text, new_green_points integer, new_hunger integer, new_growth_points integer)
language plpgsql security definer as $$
declare
  current_gp integer;
  pet record;
begin
  if amount is null or amount <= 0 then
    return query select false, 'Invalid amount.', null::integer, null::integer, null::integer;
    return;
  end if;

  select green_points into current_gp from student_engagement where student_id = target_student_id for update;
  if current_gp is null then
    return query select false, 'No Green Points wallet found yet — go play something first!', null::integer, null::integer, null::integer;
    return;
  end if;
  if current_gp < amount then
    return query select false, format('Not enough Green Points — need %s, have %s.', amount, current_gp), current_gp, null::integer, null::integer;
    return;
  end if;

  select * into pet from student_pets where student_id = target_student_id for update;
  if not found then
    return query select false, 'Adopt a pet first!', current_gp, null::integer, null::integer;
    return;
  end if;

  current_gp := current_gp - amount;
  update student_engagement set green_points = current_gp, updated_at = now() where student_id = target_student_id;

  update student_pets
    set growth_points = pet.growth_points + amount,
        hunger = least(100, pet.hunger + amount),
        last_fed_at = now(), updated_at = now()
    where student_id = target_student_id
    returning hunger, growth_points into pet.hunger, pet.growth_points;

  insert into pet_feed_log (student_id, fed_with, amount) values (target_student_id, 'green_points', amount);

  return query select true, 'Fed!', current_gp, pet.hunger, pet.growth_points;
end;
$$;
grant execute on function public.feed_pet_green_points(uuid, integer) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- purchase_pet_food — buys 1 unit of a food item with Coins. Mirrors
-- purchase_shop_item exactly (server-side price lookup + row-locked balance
-- check), just writing into student_pets.food_inventory instead of
-- student_engagement.inventory.
-- ----------------------------------------------------------------------------
create or replace function public.purchase_pet_food(target_student_id uuid, target_food_key text)
returns table(success boolean, message text, new_coins integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare
  food_cost integer;
  food_active boolean;
  current_coins integer;
  current_inventory jsonb;
  owned_count integer;
begin
  select cost_coins, active into food_cost, food_active from pet_food_items where key = target_food_key;
  if food_cost is null then
    return query select false, 'That food does not exist.', null::integer, null::jsonb;
    return;
  end if;
  if not food_active then
    return query select false, 'That food is no longer available.', null::integer, null::jsonb;
    return;
  end if;

  if not exists (select 1 from student_pets where student_id = target_student_id) then
    return query select false, 'Adopt a pet first!', null::integer, null::jsonb;
    return;
  end if;

  select coins into current_coins from student_engagement where student_id = target_student_id for update;
  if current_coins is null then
    return query select false, 'No coin wallet found yet — go play something first!', null::integer, null::jsonb;
    return;
  end if;
  if current_coins < food_cost then
    return query select false, format('Not enough coins — need %s, have %s.', food_cost, current_coins), current_coins, null::jsonb;
    return;
  end if;

  select coalesce(food_inventory, '{}'::jsonb) into current_inventory from student_pets where student_id = target_student_id for update;
  owned_count := coalesce((current_inventory ->> target_food_key)::integer, 0);
  current_inventory := jsonb_set(current_inventory, array[target_food_key], to_jsonb(owned_count + 1));
  current_coins := current_coins - food_cost;

  update student_engagement set coins = current_coins, updated_at = now() where student_id = target_student_id;
  update student_pets set food_inventory = current_inventory, updated_at = now() where student_id = target_student_id;

  return query select true, 'Purchased!', current_coins, current_inventory;
end;
$$;
grant execute on function public.purchase_pet_food(uuid, text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- feed_pet_food — spends 1 owned unit of a food item to restore hunger.
-- ----------------------------------------------------------------------------
create or replace function public.feed_pet_food(target_student_id uuid, target_food_key text)
returns table(success boolean, message text, new_hunger integer, new_food_inventory jsonb)
language plpgsql security definer as $$
declare
  pet record;
  restore_amt integer;
  owned_count integer;
  new_inventory jsonb;
begin
  select restore_amount into restore_amt from pet_food_items where key = target_food_key;
  if restore_amt is null then
    return query select false, 'That food does not exist.', null::integer, null::jsonb;
    return;
  end if;

  select * into pet from student_pets where student_id = target_student_id for update;
  if not found then
    return query select false, 'Adopt a pet first!', null::integer, null::jsonb;
    return;
  end if;

  owned_count := coalesce((pet.food_inventory ->> target_food_key)::integer, 0);
  if owned_count <= 0 then
    return query select false, 'You don''t own any of that food — buy some in the Shop!', pet.hunger, pet.food_inventory;
    return;
  end if;

  new_inventory := jsonb_set(pet.food_inventory, array[target_food_key], to_jsonb(owned_count - 1));

  update student_pets
    set hunger = least(100, pet.hunger + restore_amt), food_inventory = new_inventory,
        last_fed_at = now(), updated_at = now()
    where student_id = target_student_id
    returning hunger into pet.hunger;

  insert into pet_feed_log (student_id, fed_with, food_key, amount) values (target_student_id, 'food', target_food_key, restore_amt);

  return query select true, 'Fed!', pet.hunger, new_inventory;
end;
$$;
grant execute on function public.feed_pet_food(uuid, text) to anon, authenticated;
