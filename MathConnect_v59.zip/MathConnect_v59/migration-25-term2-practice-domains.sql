-- ============================================================================
-- MathConnect — Migration 25: Term 2 Intelligent Practice domains
-- (Ratio & Proportion, Percent, Geometry, Patterns & Sequences, Statistics,
-- Probability) with admin lock/unlock, matching the Term 2 Drill Stations
-- pattern from migration-22. Run this AFTER migration-24.
--
-- ALSO FIXES A BUG FOUND WHILE BUILDING THIS: migration-24's
-- eureka_trial_status()/championship_score() looped over
-- "drill_station_locks where not locked" to find "every currently unlocked
-- station" — but migration-22 only ever inserted rows for the SIX NEW Term
-- 2 stations, never the original six. That loop was silently only ever
-- checking the Term 2 stations (once unlocked) and never the original six
-- at all. Section 1 below fixes it by backfilling the missing rows.
--
-- It also corrects migration-24's practice_domains seed data, which
-- accidentally used the OLD (unused) column-default keys from
-- migration-15's schema ("basic","order","integers","algebra") instead of
-- the keys learningEngine.js's LE_DOMAINS actually uses at runtime
-- ("addition","subtraction","multiplication","division"). "fractions" and
-- "decimals" were already correct in both and are untouched.
--
-- WHAT THIS ADDS
--   1. Backfills drill_station_locks with explicit locked=false rows for
--      the original six Drill stations (bug fix, see above).
--   2. Adds locked/note/locked_by/locked_at to practice_domains — the SAME
--      table doubles as both the domain registry (for Trial/Championship
--      counting) AND the admin lock control, exactly mirroring how
--      drill_station_locks works for Drills.
--   3. Corrects the original six practice_domains rows to the real keys,
--      and adds the six new Term 2 domains, locked by default.
--   4. Re-points eureka_trial_status() / championship_score() (from
--      migration-24) at "practice_domains where active and not locked",
--      so locked domains don't count against a student until an admin
--      unlocks them — same rule Drill stations already follow.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file →
-- Run. Safe to re-run.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. Bug fix: backfill the original six Drill stations into
--    drill_station_locks (unlocked), so migration-24's Trial/Championship
--    checks actually see all 12 stations, not just the Term 2 six.
-- ----------------------------------------------------------------------------
insert into drill_station_locks (station_key, locked, note) values
  ('basic', false, null), ('order', false, null), ('integers', false, null),
  ('fractions', false, null), ('decimals', false, null), ('algebra', false, null)
on conflict (station_key) do nothing;

-- ----------------------------------------------------------------------------
-- 2. Lock columns on practice_domains (mirrors drill_station_locks exactly).
-- ----------------------------------------------------------------------------
alter table practice_domains add column if not exists locked boolean not null default false;
alter table practice_domains add column if not exists note text;
alter table practice_domains add column if not exists locked_by uuid references admins(id);
alter table practice_domains add column if not exists locked_at timestamptz;

-- ----------------------------------------------------------------------------
-- 3. Correct the original six keys, add the six new Term 2 domains.
-- ----------------------------------------------------------------------------
delete from practice_domains where domain_key in ('basic', 'order', 'integers', 'algebra');
insert into practice_domains (domain_key, label, term_added, active, locked) values
  ('addition', 'Addition', 1, true, false),
  ('subtraction', 'Subtraction', 1, true, false),
  ('multiplication', 'Multiplication', 1, true, false),
  ('division', 'Division', 1, true, false)
on conflict (domain_key) do nothing;
-- fractions/decimals rows already exist and were already correct — just
-- make sure they're explicitly unlocked (the new column defaults to false
-- anyway, this just documents intent).
update practice_domains set locked = false where domain_key in ('fractions', 'decimals');

insert into practice_domains (domain_key, label, term_added, active, locked, note) values
  ('ratio', 'Ratio & Proportion', 2, true, true, 'Coming for Term 2!'),
  ('percent', 'Percent', 2, true, true, 'Coming for Term 2!'),
  ('geometry', 'Geometry', 2, true, true, 'Coming for Term 2!'),
  ('patterns', 'Patterns & Sequences', 2, true, true, 'Coming for Term 2!'),
  ('statistics', 'Statistics', 2, true, true, 'Coming for Term 2!'),
  ('probability', 'Probability', 2, true, true, 'Coming for Term 2!')
on conflict (domain_key) do update set label = excluded.label, term_added = excluded.term_added;

-- ----------------------------------------------------------------------------
-- 4. Re-point eureka_trial_status() and championship_score() at the fixed
--    registries. Full function bodies re-supplied (create or replace) —
--    only the two "practice_domains" loop filters changed from migration-24
--    (added "and not locked"); everything else is identical.
-- ----------------------------------------------------------------------------
create or replace function public.eureka_trial_status(target_student_id uuid)
returns jsonb language plpgsql security definer stable as $$
declare
  dp drill_progress%rowtype;
  eng student_engagement%rowtype;
  les learning_engine_state%rowtype;
  qp quest_progress%rowtype;
  domain_total int := 0; domain_pass int := 0;
  station_total int := 0; station_attempted int := 0; station_maxed int := 0;
  chapter_total int := 0; chapter_cleared int := 0;
  r record;
  roster_half int;
  opponents_beaten int;
  result jsonb;
begin
  select * into dp from drill_progress where student_id = target_student_id;
  select * into eng from student_engagement where student_id = target_student_id;
  select * into les from learning_engine_state where student_id = target_student_id;
  select * into qp from quest_progress where student_id = target_student_id;

  for r in select domain_key from practice_domains where active and not locked loop
    domain_total := domain_total + 1;
    if les.id is not null
       and coalesce((les.adaptive_levels ->> r.domain_key)::int, 0) = 4
       and coalesce((les.skill_proficiency ->> r.domain_key)::int, 0) = 100
    then domain_pass := domain_pass + 1; end if;
  end loop;

  for r in select station_key from drill_station_locks where not locked loop
    station_total := station_total + 1;
    if exists (select 1 from drill_attempts where student_id = target_student_id and topic = r.station_key) then
      station_attempted := station_attempted + 1;
    end if;
    if dp.id is not null and coalesce((dp.topic_levels ->> r.station_key)::int, 1) = 15 then
      station_maxed := station_maxed + 1;
    end if;
  end loop;

  for r in select chapter_key from quest_chapters_registry where active loop
    chapter_total := chapter_total + 1;
    if qp.id is not null and jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       and jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       and not exists (
         select 1 from jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e
         where e::int < 1
       )
    then chapter_cleared := chapter_cleared + 1; end if;
  end loop;

  roster_half := ceil(coalesce(public.grade_level_roster_count(target_student_id), 0) / 2.0);
  opponents_beaten := coalesce(public.distinct_opponents_beaten(target_student_id), 0);

  result := jsonb_build_object(
    'practice_expert', jsonb_build_object('passed', domain_pass = domain_total and domain_total > 0, 'progress', domain_pass, 'needed', domain_total),
    'all_stations_attempted', jsonb_build_object('passed', station_attempted = station_total and station_total > 0, 'progress', station_attempted, 'needed', station_total),
    'all_stations_level15', jsonb_build_object('passed', station_maxed = station_total and station_total > 0, 'progress', station_maxed, 'needed', station_total),
    'quest_half_cleared', jsonb_build_object('passed', chapter_cleared > (chapter_total / 2.0), 'progress', chapter_cleared, 'needed', floor(chapter_total / 2.0) + 1),
    'attendance_streak_30', jsonb_build_object('passed', coalesce(eng.current_streak, 0) >= 30 and coalesce(eng.streak_off, false) = false, 'progress', coalesce(eng.current_streak, 0), 'needed', 30),
    'grade_dominance', jsonb_build_object('passed', opponents_beaten >= roster_half and roster_half > 0, 'progress', opponents_beaten, 'needed', roster_half)
  );

  result := result || jsonb_build_object('overall_cleared',
    (result -> 'practice_expert' ->> 'passed')::boolean
    and (result -> 'all_stations_attempted' ->> 'passed')::boolean
    and (result -> 'all_stations_level15' ->> 'passed')::boolean
    and (result -> 'quest_half_cleared' ->> 'passed')::boolean
    and (result -> 'attendance_streak_30' ->> 'passed')::boolean
    and (result -> 'grade_dominance' ->> 'passed')::boolean
  );
  return result;
end;
$$;

create or replace function public.championship_score(target_student_id uuid)
returns jsonb language plpgsql security definer stable as $$
declare
  dp drill_progress%rowtype; eng student_engagement%rowtype;
  les learning_engine_state%rowtype; qp quest_progress%rowtype;
  eligible boolean := false;
  gem_score numeric := 0; trial_score numeric := 0; rank_progress numeric := 0;
  avg_level numeric := 0; accuracy numeric := 0; drill_score numeric := 0;
  chapter_total int := 0; chapter_cleared int := 0; quest_score numeric := 0;
  max_stars int := 0;
  capped_wins int := 0; capped_games int := 0; win_rate numeric := 0;
  coverage numeric := 0; battle_score numeric := 0; roster int := 0;
  domain_total int := 0; domain_sum numeric := 0; practice_score numeric := 0;
  streak_score numeric := 0; daily_count int := 0; daily_score numeric := 0; consistency_score numeric := 0;
  total numeric := 0;
  station_count int := 0;
  r record;
  gem_index int := 0;
begin
  select * into dp from drill_progress where student_id = target_student_id;
  select * into eng from student_engagement where student_id = target_student_id;
  select * into les from learning_engine_state where student_id = target_student_id;
  select * into qp from quest_progress where student_id = target_student_id;

  eligible := dp.id is not null and dp.mastery_tier = 15;

  if dp.post_eureka_stars >= 125 then gem_index := 9 + floor((dp.post_eureka_stars - 125) / 30.0);
  elsif dp.post_eureka_stars >= 95 then gem_index := 8;
  elsif dp.post_eureka_stars >= 70 then gem_index := 7;
  elsif dp.post_eureka_stars >= 50 then gem_index := 6;
  elsif dp.post_eureka_stars >= 35 then gem_index := 5;
  elsif dp.post_eureka_stars >= 25 then gem_index := 4;
  elsif dp.post_eureka_stars >= 15 then gem_index := 3;
  elsif dp.post_eureka_stars >= 10 then gem_index := 2;
  elsif dp.post_eureka_stars >= 5 then gem_index := 1;
  else gem_index := 0; end if;
  gem_score := least(gem_index / 14.0 * 60, 60);
  trial_score := least(coalesce(dp.trial_clears_count, 0), 2) * 20;
  rank_progress := gem_score + trial_score;

  select count(*) into station_count from drill_station_locks where not locked;
  if dp.id is not null and station_count > 0 then
    select avg((dp.topic_levels ->> sl.station_key)::int) into avg_level
    from (select station_key from drill_station_locks where not locked) sl;
    avg_level := coalesce(avg_level, 1);
  end if;
  select case when coalesce(sum(total_questions), 0) = 0 then 0
    else sum(correct_count)::numeric / sum(total_questions) * 100 end
  into accuracy from drill_attempts where student_id = target_student_id;
  drill_score := (coalesce(avg_level, 1) / 15.0 * 100) * 0.5 + coalesce(accuracy, 0) * 0.5;

  for r in select chapter_key from quest_chapters_registry where active loop
    chapter_total := chapter_total + 1;
    if qp.id is not null and jsonb_typeof(qp.level_stars -> r.chapter_key) = 'array'
       and jsonb_array_length(qp.level_stars -> r.chapter_key) = 10
       and not exists (select 1 from jsonb_array_elements_text(qp.level_stars -> r.chapter_key) e where e::int < 1)
    then chapter_cleared := chapter_cleared + 1; end if;
  end loop;
  max_stars := chapter_total * 10 * 3;
  quest_score := case when chapter_total = 0 then 0 else (chapter_cleared::numeric / chapter_total * 100) * 0.5 end
    + case when max_stars = 0 then 0 else (coalesce(qp.total_stars, 0)::numeric / max_stars * 100) * 0.5 end;

  select coalesce(sum(least(w, 3)), 0), coalesce(sum(least(g, 3)), 0) into capped_wins, capped_games
  from (
    select case when student_a_id = target_student_id then student_b_id else student_a_id end as opp,
      count(*) filter (where winner_id = target_student_id) as w,
      count(*) as g
    from battles
    where status = 'completed' and (student_a_id = target_student_id or student_b_id = target_student_id)
    group by 1
  ) x;
  win_rate := case when capped_games = 0 then 0 else capped_wins::numeric / capped_games * 100 end;
  roster := coalesce(public.grade_level_roster_count(target_student_id), 0);
  coverage := case when roster = 0 then 0 else least(public.distinct_opponents_beaten(target_student_id)::numeric / roster * 100, 100) end;
  battle_score := win_rate * 0.5 + coverage * 0.5;

  -- Only unlocked domains count, same rule as the Trial (see fix note above).
  for r in select domain_key from practice_domains where active and not locked loop
    domain_total := domain_total + 1;
    domain_sum := domain_sum + coalesce((les.skill_proficiency ->> r.domain_key)::int, 0);
  end loop;
  practice_score := case when domain_total = 0 then 0 else domain_sum / domain_total end;

  streak_score := least(coalesce(eng.current_streak, 0), 60) / 60.0 * 100;
  select count(*) into daily_count from daily_challenge_completions where student_id = target_student_id;
  daily_score := least(daily_count, 60) / 60.0 * 100;
  consistency_score := streak_score * 0.5 + daily_score * 0.5;

  total := rank_progress * 0.30 + drill_score * 0.20 + quest_score * 0.15 + battle_score * 0.15
    + practice_score * 0.10 + consistency_score * 0.10;

  return jsonb_build_object(
    'eligible', eligible,
    'total', round(total, 2),
    'breakdown', jsonb_build_object(
      'rank_progress', round(rank_progress, 2),
      'drill_mastery', round(drill_score, 2),
      'quest_mode', round(quest_score, 2),
      'boss_battles', round(battle_score, 2),
      'intelligent_practice', round(practice_score, 2),
      'consistency', round(consistency_score, 2)
    )
  );
end;
$$;

-- Grants unchanged (create or replace keeps existing grants), but re-issued
-- here for safety in case these functions didn't exist yet on this project.
grant execute on function public.eureka_trial_status(uuid) to anon, authenticated;
grant execute on function public.championship_score(uuid) to anon, authenticated;

-- ============================================================================
-- Done. Next: reload learningEngine.js / adaptive-practice.js (Term 2
-- domains ship locked), and admin.html's new "🧠 Intelligent Practice
-- Domains" card to switch them on when Term 2 begins.
-- ============================================================================
