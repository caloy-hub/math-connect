# MathConnect — Migration 59 Changelog
## New: Literacy Arena (vocabulary, spelling, reading comprehension) — cross-subject

Unlike every other gamified feature, this one is deliberately **not** Math-only
and **not** locked to `student_id`. See the long comment at the top of
`migration-59-literacy-arena.sql` for the full reasoning — short version: a
real student has a separate `students.id` per section/subject, so anything
meant to follow them everywhere has to key off the shared `learners.id`
instead, with a graceful per-section fallback when a student isn't linked to
one yet.

## 1. New tables (migration-59-literacy-arena.sql)
- `literacy_passages` — reading passages for the Comprehension Chamber
- `literacy_questions` — shared bank across all 4 skill types (`vocabulary`,
  `spelling`, `comprehension`, `grammar`), multiple-choice or typed
- `literacy_progress` — one row per real student where possible
  (`progress_key` = `learner_id`, falling back to a `student_id`-scoped key)
- `literacy_attempts` — every answered question, incl. raw typed response
  (needed later for a "most-missed words" teacher report)
- Helper functions: `upsert_literacy_progress()` (atomic, resolves identity
  server-side to avoid duplicate rows on concurrent logins) and
  `section_literacy_roster()` (teacher rollup, works for any section
  regardless of subject)

## 2. Student side (literacyEngine.js, student.html, student.js)
- New **📚 Literacy** tab — shown for every subject, unlike Math Drills/Quest/
  Boss Raids/etc. Added to `student.html` (desktop tab bar + mobile "More"
  drawer + bottom-nav "more" group) and deliberately left OUT of
  `STUDENT_MATH_ONLY_TABS` in `student.js`.
- Three playable stations: Vocabulary Vault, Spelling Bee Station (with
  TTS word playback via `speechSynthesis`), Comprehension Chamber.
- v1 is intentionally simple — a flat 10-question run per station, no
  streak/mystery-box layer like Math Drills has. Extend `literacyEngine.js`
  if you want deeper parity later.

## 3. Teacher side (teacher-literacy.js, teacher.html, teacher.js)
- New **📚 Literacy** tab, added to `ALWAYS_ALLOWED_TABS` (works for every
  subject's section, not gated by `MATH_ONLY_TABS`).
- Shows class standings via `section_literacy_roster()` — total points,
  per-station breakdown, last-played date.
- Flags any student who isn't yet linked to the shared `learners` directory
  (⚠️ badge + explanatory note), since their literacy progress won't follow
  them across their other classes until a teacher links them via Roster.

## 4. What's NOT included yet — you'll need to seed content
No starter question bank is included. Before this is usable in a class,
add rows to `literacy_passages` / `literacy_questions` (grade-level tagged)
— either hand-authored to match specific MELC competencies, or generated
and then curated. Nothing renders in a station until questions exist for
that grade level.

## 5. Known limitation carried over from the existing data model
Students added before this migration (or added without a directory match)
have `learner_id = null`. Their literacy progress stays scoped to the one
section they earned it in until a teacher links them to a shared learner
record — same limitation the shared-directory search already has for
Math/Science roster de-duplication.
