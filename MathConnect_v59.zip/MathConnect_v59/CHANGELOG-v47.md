# MathConnect v47 — Team Boss Raids, Tournaments removed

## Deploy
1. **Supabase → SQL Editor:** run `migration-53-boss-raids.sql` (safe to re-run).
   Needs migrations 18, 19, 22 and 44 to be in place already (they are, if you're on v45/v46).
2. **Deploy the files** as usual. The service worker is bumped to `mathconnect-v47-1`.
3. *(Optional, destructive)* `migration-54-drop-tournament-data.sql` permanently deletes old tournament
   records. Skip it if you might ever want the history — nothing depends on those tables any more.

Deploy 1 and 2 together: the old student/teacher Boss Battle screens no longer exist, and the new ones need the migration.

---

## 1. Tournament feature removed
Removed: student + teacher Tournament tabs and nav entries, `tournamentEngine.js`, `tournament-ui.js`,
`teacher-tournament.js`, the bracket/Arena CSS, landing-page and README mentions. Migration 53 drops the database
trigger and functions that hooked tournaments into `battles` (so nothing dead is left running); the tournament
*tables* stay until you run migration 54.

## 2. Boss Battles → Team Boss Raids

**How a raid plays**
- A student picks a boss (one monster per Drill station, 18 of them, plus the 👾 Grand Boss that mixes every open
  station), a difficulty and who may join (own section / whole grade), and opens a lobby.
- Classmates see it under **Open teams** and tap Join. **3 to 8 players.** The host starts once 3 have joined.
- 4-second countdown, then **240 seconds**. Everyone answers their own questions (their own station level, same
  keypad as Drills) at the same time. **Correct = damage** (10 + 0–5 speed bonus for answers under 10 s).
  **Wrong or Skip = the boss heals 8 HP** (never above its max). Boss HP = **70 / 100 / 150 × players**
  (Easy / Normal / Hard). Drop it to 0 before the clock does to win.
- Live screen: boss with hit/heal animations and floating numbers, HP bar, big clock, team chips with each
  player's damage/✅/❌, combat log. Leaving the tab mid-fight asks first; you can rejoin until time runs out.
- Results: team report (accuracy, damage, 🗡️ Top damage, 🎯 Sharpshooter), rewards, **Raid again**.
- **Rewards** (once per student per raid, enforced by the database; need ≥ 5 correct answers so idling doesn't pay):
  win = +1 MathLegends star, +20 Green Points; loss = +5 Green Points; either counts for the daily "battle" checklist.
  No star penalty for losing (it's a team game).
- **Boss Codex:** each boss card shows how many times that boss has been defeated and the hardest difficulty beaten.
- **🛡️ Shield** (shop item that used to say "battle mode coming soon") now absorbs your first wrong answer in a raid.

**Balance** (Monte Carlo, 4,000 simulated raids per cell; teams of 3, 5, 8):

| Class of players | Easy (70) | Normal (100) | Hard (150) |
|---|---|---|---|
| Struggling (62% acc, 13 s/answer) | ≈ 39–46% win | ≈ 6–18% | ≈ 0–2% |
| Average (72% acc, 10 s) | ≈ 94–99% | ≈ 79–91% | ≈ 41% |
| Strong (85% acc, 7 s) | 100% (≈ 60 s) | 100% (≈ 85 s) | 100% (≈ 125 s) |

Tune the numbers in `start_boss_raid` (HP per player), `raid_submit_answer` (10 / 8 / bonus) and the
`duration_seconds` default in migration 53 — the client only displays them.

**Fairness / integrity**
- The boss's HP and the clock live in the database. Every hit goes through `raid_submit_answer()`, which locks the
  raid row, so simultaneous hits never overwrite each other; the clock is the server's, so a wrong laptop clock
  can't help or hurt.
- The raid tables have **no direct write access** for students — only the migration's functions can change them.
- As in Math Drills, correctness is checked in the student's browser. A pacing guard (≥ 0.5 s between answers) and
  one Shield per student per raid limit abuse. Not built for high-stakes use.
- Stale lobbies auto-close after 15 minutes; a raid whose clock ran out closes as lost even if everyone left.

## 3. Everything that read the old duels was updated
- **Teacher → 🐉 Boss Raids** (was Boss Battles): raids finished, win rate, students who've raided, average team size,
  live raids; results by boss; per-student table; recent raids with the full team named.
- **Status tab** (student and teacher): Boss Raids won–lost instead of W-L-D.
- **Report card:** "Boss Raids (Team Fights)" section and radar axis; earlier 1-v-1 duels in the same term appear
  as a one-line note, so older terms still print correctly.
- **Championship score** (Boss component, 10%): now counts raids (half "raids won, capped at 5", half "victory
  rate", only raids with ≥ 5 correct answers). The old PvP win-rate is kept as a floor (`GREATEST`), so no student's
  standing drops because of the switch. The function is a verbatim copy of migration 44 with only that block changed.
- Old duel data (`battles`, `battle_rounds`, …) is untouched.

## Tested
- **Real Postgres (pglite)**, migration 53 applied twice: 57 checks — create/join/leave/start rules (min 3, max 8,
  section vs grade scope, locked stations, paused accounts, one raid per student), HP scaling, damage/heal/cap,
  speed bonus, Shield once per raid, pacing guard, killing blow, deadline + 1.5 s grace, stale-lobby cleanup,
  once-only rewards, direct writes blocked by RLS, tournament hooks gone, championship formula unchanged for
  students without raids. (It caught a real bug in my first draft: an alias named `r` clashed with the function's
  loop variable — fixed.)
- **End-to-end:** three separate client instances running the real `raidEngine.js` against that real database — lobby,
  start, live hits/heals/shield, killing blow, results on every client, rewards paid once (a player with < 5 hits
  gets none), and a raid the clock ended (28 checks).
- **Real DOM (jsdom)** with the real on-screen keypad: hub (19 bosses, codex, locked stations, open teams), lobby
  (host vs member, Start enabled at 3), fight (timer states, HP bar, keypad → Enter submits, Skip, animations clean
  up), results (victory/defeat/rewards/no-reward), HTML-escaping of names (38 checks).
- Teacher panel and report card computations (11 + 3 checks). All earlier v46 test suites still pass.

**Not tested:** against your live Supabase project, real Realtime delivery (the app falls back to a 3–5 s poll if a
push is missed), or with a real classroom of phones. Please run one raid with three test students first
(create → join → start → fight → results), and try one on a phone for the keypad layout.
