// ============================================================================
// MathConnect — Teacher view of Shout-outs
// The teacher decides how open the wall is for this section (Off / kinds only /
// short filtered message), sees everything that was posted — including what
// students reported — and can hide, restore or delete any shout-out. It also
// shows who has NOT received a shout-out this week, purely so the teacher can
// notice and encourage; students never see this list.
// See migration-57-shoutouts.sql for the safety design.
// Depends on: state (teacher.js), escapeHtml, toast (supabase-client.js).
// ============================================================================

const TSO_KINDS = {
  helped: "🤝 helped me understand", teamwork: "👥 was a great teammate", effort: "💪 never gave up",
  improved: "📈 is improving so fast", creative: "💡 found a clever way to solve it", kind: "💛 was kind to me",
};
const TSO_MODES = {
  off: { label: "Off", desc: "Nothing is shown or sent for this section." },
  kinds_only: { label: "Kinds of thanks only (recommended)", desc: "Students pick who and what — six friendly options. No typed text at all." },
  short_text: { label: "Kinds + a short message", desc: "Adds an optional message, up to 200 characters, so students can write in their own words. It must pass a filter (no links, contact details, insults or profanity in English, Filipino or Bisaya) — a first line of defence, so check the feed now and then." },
};
var tsoLast = null;

async function renderTeacherShoutouts() {
  const el = document.getElementById("tab-shoutouts");
  if (!el) return;
  el.innerHTML = `<div class="empty">Loading shout-outs…</div>`;
  if (!state.section) { el.innerHTML = `<div class="empty">Pick a section first.</div>`; return; }
  const { data, error } = await supabase.rpc("teacher_shoutout_overview", { p_section_id: state.section.id, p_limit: 80 });
  if (error || !data || !data.ok) {
    el.innerHTML = `<div class="card"><h2 style="margin:0 0 4px;">🌟 Shout-outs</h2><p class="muted">Couldn't load yet${error ? " (" + escapeHtml(error.message) + ")" : ""}. Has <code>migration-57-shoutouts.sql</code> been run?</p></div>`;
    return;
  }
  tsoLast = data;
  const items = data.items || [], part = data.participation || [];
  const flagged = items.filter((i) => i.report_count > 0 || i.status === "hidden");
  const notReceived = part.filter((p) => p.received_week === 0).map((p) => p.full_name);
  const notSent = part.filter((p) => p.sent_week === 0).map((p) => p.full_name);
  const sentWeek = part.reduce((n, p) => n + p.sent_week, 0);
  const cell = "padding:6px 8px;vertical-align:top;";
  const row = (i) => `
    <tr style="border-bottom:1px solid var(--paper-line);${i.status === "hidden" ? "opacity:.65;" : ""}">
      <td style="${cell}white-space:nowrap;">${new Date(i.created_at).toLocaleDateString("en-PH", { month: "short", day: "numeric" })}</td>
      <td style="${cell}">${escapeHtml(i.from_name)} → ${escapeHtml(i.to_name)}</td>
      <td style="${cell}">${TSO_KINDS[i.kind] || i.kind}${i.message ? `<div style="font-style:italic;">“${escapeHtml(i.message)}”</div>` : ""}</td>
      <td style="${cell}">${i.status === "hidden" ? `<span class="badge" style="background:#FCEBEA;color:var(--clay);">Hidden${i.hidden_reason === "reports" ? " (reported)" : ""}</span>` : `<span class="badge" style="background:#EAF0EA;color:var(--forest-dark);">Visible</span>`}${i.report_count ? ` <span class="muted">⚑ ${i.report_count}</span>` : ""}</td>
      <td style="${cell}white-space:nowrap;">
        ${i.status === "hidden" ? `<button class="btn-outline btn-sm" onclick="tsoModerate('${i.id}','restore')">Restore</button>` : `<button class="btn-outline btn-sm" onclick="tsoModerate('${i.id}','hide')">Hide</button>`}
        <button class="btn-outline btn-sm" onclick="tsoModerate('${i.id}','delete')">🗑️</button>
      </td>
    </tr>`;
  const table = (list) => `<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:.86rem;">
      <thead><tr style="text-align:left;border-bottom:2px solid var(--paper-line);"><th style="${cell}">When</th><th style="${cell}">Who</th><th style="${cell}">What</th><th style="${cell}">Status</th><th style="${cell}"></th></tr></thead>
      <tbody>${list.map(row).join("")}</tbody></table></div>`;

  el.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <h2 style="margin:0 0 4px;">🌟 Shout-outs</h2>
      <p class="muted" style="margin:0 0 10px;">A wall of appreciation for ${escapeHtml(state.section.section_name)} — classmates thank and cheer each other in a side panel. It is voluntary and carries no points. Not a free chat: no private messages, no links, no images. Limits: 5 sent per student per day, one per classmate per day. Two student reports hide a shout-out for everyone until you review it.</p>
      <div style="display:flex;flex-direction:column;gap:6px;">
        ${Object.entries(TSO_MODES).map(([k, m]) => `
          <label style="display:flex;gap:8px;align-items:flex-start;cursor:pointer;">
            <input type="radio" name="tsoMode" value="${k}" ${data.mode === k ? "checked" : ""} onchange="tsoSetMode('${k}')" style="margin-top:4px;">
            <span><strong>${m.label}</strong><br><span class="muted" style="font-size:.82rem;">${m.desc}</span></span>
          </label>`).join("")}
      </div>
    </div>

    ${flagged.length ? `
    <div class="card" style="margin-bottom:16px;border-left:4px solid var(--clay);">
      <h3 style="margin:0 0 8px;">⚑ Needs your attention (${flagged.length})</h3>
      ${table(flagged)}
    </div>` : ""}

    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin:0 0 8px;">This week</h3>
      <div style="display:flex;gap:28px;flex-wrap:wrap;margin-bottom:10px;">
        <div><div class="muted">Shout-outs sent</div><h3 style="margin:2px 0;">${sentWeek}</h3></div>
        <div><div class="muted">Students who received one</div><h3 style="margin:2px 0;">${part.length - notReceived.length}/${part.length}</h3></div>
        <div><div class="muted">Students who sent one</div><h3 style="margin:2px 0;">${part.length - notSent.length}/${part.length}</h3></div>
      </div>
      <div style="font-size:.88rem;"><strong>💛 Haven't received one yet:</strong> <span class="muted">${notReceived.length ? notReceived.map(escapeHtml).join(" · ") : "everyone has — lovely!"}</span></div>
      <div class="muted" style="font-size:.78rem;margin-top:4px;">Only you see this list. A kind word from you (or a nudge to the class to notice quieter classmates) goes a long way.</div>
    </div>

    <div class="card">
      <h3 style="margin:0 0 8px;">Recent shout-outs</h3>
      ${items.length ? table(items) : `<p class="empty">No shout-outs yet. Students will find the 💬 button on their screen.</p>`}
    </div>`;
}

async function tsoSetMode(mode) {
  const { data, error } = await supabase.rpc("set_shoutout_mode", { p_section_id: state.section.id, p_mode: mode });
  if (error || !data || !data.ok) { toast("Couldn't change the mode — please try again."); return renderTeacherShoutouts(); }
  toast(`Shout-outs: ${TSO_MODES[mode].label.replace(" (recommended)", "")}.`);
  if (state.section) state.section.shoutout_mode = mode;
  renderTeacherShoutouts();
}

async function tsoModerate(id, action) {
  if (action === "delete" && !confirm("Delete this shout-out for good? Its reactions and reports go with it.")) return;
  const { data, error } = await supabase.rpc("moderate_shoutout", { p_shoutout_id: id, p_action: action });
  if (error || !data || !data.ok) { toast("Couldn't do that — please try again."); return; }
  toast(action === "hide" ? "Hidden." : action === "restore" ? "Restored." : "Deleted.");
  renderTeacherShoutouts();
}
