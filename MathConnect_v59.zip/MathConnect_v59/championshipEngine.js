// ============================================================================
// MathConnect — Grade-Level Grand Champion
// A composite 0-100 score across Rank Progress, Drill Mastery, Quest Mode,
// Cooperation, Boss Battles, Intelligent Practice, and Consistency (see
// migration-24's championship_score() / grade_champion_standings(), revised
// by migration-44 to add the Cooperation component and drop the old
// "beat N classmates" Boss Battles sub-score — see that file for the exact
// formula). Only students who've reached tier 15 (Eureka) are eligible —
// enforced server-side, so this file just displays what the RPC returns.
//
// Loaded AFTER rankEngine.js. Used by student.js (live standings + own
// score) and admin.js (the "Finalize School Year" action + Hall of Fame).
// ============================================================================

const CHAMPIONSHIP_COMPONENT_LABELS = {
  rank_progress: { icon: "💎", label: "Rank Progress", weight: 25 },
  drill_mastery: { icon: "🎮", label: "Drill Mastery", weight: 20 },
  quest_mode: { icon: "🗺️", label: "Quest Mode", weight: 10 },
  cooperation: { icon: "🌱", label: "Cooperation (Class Quests)", weight: 15 },
  boss_battles: { icon: "⚔️", label: "Boss Battles", weight: 10 },
  intelligent_practice: { icon: "🧠", label: "Intelligent Practice", weight: 10 },
  consistency: { icon: "🗓️", label: "Consistency", weight: 10 },
};

async function fetchMyChampionshipScore(studentId) {
  const { data, error } = await supabase.rpc("championship_score", { target_student_id: studentId });
  if (error) { console.error("Championship score error:", error); return null; }
  return data;
}

async function fetchGradeChampionStandings(gradeLevel, limit) {
  const { data, error } = await supabase.rpc("grade_champion_standings", { target_grade_level: gradeLevel, result_limit: limit || 50 });
  if (error) { console.error("Grade champion standings error:", error); return []; }
  return data || [];
}

function renderChampionshipBreakdownBars(breakdown) {
  if (!breakdown) return "";
  return Object.keys(CHAMPIONSHIP_COMPONENT_LABELS).map((key) => {
    const meta = CHAMPIONSHIP_COMPONENT_LABELS[key];
    const val = breakdown[key] || 0;
    return `
    <div style="margin-bottom:8px;">
      <div style="display:flex;justify-content:space-between;font-size:.78rem;"><span>${meta.icon} ${meta.label} <span class="muted">(${meta.weight}%)</span></span><span class="muted">${val.toFixed(1)}/100</span></div>
      <div style="background:var(--paper-line);border-radius:6px;height:6px;overflow:hidden;margin-top:2px;">
        <div style="background:var(--gold);height:100%;width:${Math.min(100, val)}%;"></div>
      </div>
    </div>`;
  }).join("");
}

// Card for a student's OWN score — shown whether eligible or not, with a
// nudge toward Eureka if they haven't reached it yet.
function renderMyChampionshipCard(scoreData) {
  if (!scoreData) return "";
  if (!scoreData.eligible) {
    return `
    <div class="card" style="border-left:4px solid var(--sky);">
      <div class="pill" style="background:var(--sky-light);color:var(--forest);">🏆 Grade Champion Race</div>
      <h3 style="margin:10px 0 4px;">Reach Eureka (Tier 15) to compete</h3>
      <p class="muted">The Grade Champion board is open only to MathLegends who've reached the top of the main ladder. Keep climbing!</p>
    </div>`;
  }
  return `
  <div class="card" style="border-left:4px solid var(--gold);">
    <div class="pill" style="background:var(--gold-light);color:var(--forest-dark);">🏆 Grade Champion Race</div>
    <h3 style="margin:10px 0 4px;">Your Championship Score: <span style="color:var(--gold);">${scoreData.total.toFixed(1)}</span> / 100</h3>
    ${renderChampionshipBreakdownBars(scoreData.breakdown)}
  </div>`;
}

// Live leaderboard for a grade level.
function renderChampionshipStandingsCard(rows, gradeLevel, myStudentId) {
  if (!rows || rows.length === 0) {
    return `<div class="card"><div class="pill">🏆 ${escapeHtml(gradeLevel || "Grade")} Championship Standings</div><p class="muted" style="margin-top:10px;">No one has reached Eureka rank yet this school year — be the first!</p></div>`;
  }
  return `
  <div class="card">
    <div class="pill">🏆 ${escapeHtml(gradeLevel || "Grade")} Championship Standings</div>
    <p class="muted" style="font-size:.8rem;margin-top:6px;">Live — recalculated every time this loads. One Grand Champion is crowned per grade level at the end of the school year.</p>
    <div style="margin-top:10px;">
      ${rows.map((r, i) => `
        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--paper-line);${r.student_id === myStudentId ? "background:var(--gold-light);border-radius:6px;padding-left:6px;" : ""}">
          <div style="width:26px;text-align:center;font-weight:700;">${i === 0 ? "👑" : "#" + (i + 1)}</div>
          <div style="flex:1;">
            <div style="font-weight:600;">${escapeHtml(r.full_name)}${r.student_id === myStudentId ? " (you)" : ""}</div>
            <div class="muted" style="font-size:.76rem;">${escapeHtml(r.section_name || "")}</div>
          </div>
          <div style="font-weight:700;color:var(--gold);">${Number(r.total).toFixed(1)}</div>
        </div>
      `).join("")}
    </div>
  </div>`;
}
