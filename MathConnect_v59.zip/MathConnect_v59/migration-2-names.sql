-- ============================================================================
-- MathConnect — Migration 2: Structured name fields for roster sorting
-- ----------------------------------------------------------------------------
-- Safe to run on your EXISTING Supabase project — it only adds new columns
-- and fills them in for students you've already added. Nothing is deleted,
-- and student login (which matches on full_name) keeps working exactly the
-- same as before.
--
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

alter table students add column if not exists last_name text;
alter table students add column if not exists first_name text;
alter table students add column if not exists middle_name text;

-- Best-effort backfill for students already in your roster: assumes the last
-- word of the existing full name is the surname. Please double-check these
-- in the Roster tab afterward (there's a new "Edit" button) and correct any
-- that guessed wrong (e.g. names with multi-word surnames like "Dela Cruz").
update students
set
  last_name = coalesce(last_name, split_part(trim(full_name), ' ', array_length(regexp_split_to_array(trim(full_name), '\s+'), 1))),
  first_name = coalesce(first_name, nullif(regexp_replace(trim(full_name), '\s+\S+$', ''), ''))
where last_name is null or first_name is null;

-- Done. Refresh the app and open Roster — students are now grouped by
-- gender and sorted alphabetically by surname.
