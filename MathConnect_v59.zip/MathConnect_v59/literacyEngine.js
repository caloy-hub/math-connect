// ============================================================================
// MathConnect — Literacy Arena (reading comprehension, vocabulary, spelling)
// Unlike drills.js, this is NOT Math-only — see migration-59 for why progress
// is keyed to learner_id (falls back to student_id when a student has no
// shared-directory link yet). Depends on: supabase-client.js (supabase,
// escapeHtml, toast), student.js (sstate: session/student/section loaded).
// ============================================================================

const LITERACY_STATIONS = [
  { key: "vocabulary",   icon: "📖", name: "Vocabulary Vault",         desc: "Synonyms, antonyms, word-in-context, roots & affixes" },
  { key: "grammar",      icon: "🧩", name: "Grammar Check Station",    desc: "Subject-verb agreement, tricky agreement rules, sentence correctness" },
  { key: "comprehension",icon: "🔍", name: "Comprehension Chamber",    desc: "Short passages — main idea, inference, sequence" },
];
const LITERACY_RUN_LENGTH = 20;

// Student-selectable difficulty. Tiers are RELATIVE, not tied to fixed
// difficulty numbers — for each grade+skill pool we sort by the `difficulty`
// column and split into thirds by rank. That means Easy/Medium/Hard always
// means "easier/harder than this grade's own average," which keeps working
// correctly as more grades and more questions (with their own difficulty
// scales) get added to the bank later, with no code changes needed.
const LITERACY_TIERS = [
  { key: "easy",   label: "Easy",   icon: "🟢", bucket: 0 },
  { key: "medium", label: "Medium", icon: "🟡", bucket: 1 },
  { key: "hard",   label: "Hard",   icon: "🔴", bucket: 2 },
];

var lstate = { progress: null, loaded: false, session: null };

function literacyProgressKey() {
  const learnerId = sstate.student && sstate.student.learner_id;
  return learnerId ? learnerId : "S-" + sstate.student.id;
}

// ----------------------------------------------------------------------------
// PROGRESS — one row per real student where possible (see migration-59).
// Loaded by the computed progress_key so it's found regardless of WHICH
// section/subject the student is currently logged in through.
// ----------------------------------------------------------------------------
async function loadLiteracyProgress() {
  const key = literacyProgressKey();
  const { data } = await supabase.from("literacy_progress").select("*").eq("progress_key", key).maybeSingle();
  if (data) {
    lstate.progress = data;
  } else {
    const fresh = {
      learner_id: sstate.student.learner_id || null,
      student_id: sstate.student.id,
      total_points: 0, games_played: 0, best_streak: 0,
      station_points: { vocabulary: 0, grammar: 0, comprehension: 0 },
      mastery_tier: 1, mastery_stars: 0,
    };
    const { data: inserted } = await supabase.from("literacy_progress").insert(fresh).select().maybeSingle();
    lstate.progress = inserted || { ...fresh, id: null, progress_key: key };
  }
  lstate.loaded = true;
}

// ----------------------------------------------------------------------------
// QUESTIONS — pulled from the shared bank, scoped to grade level and split
// into a relative difficulty tier (see LITERACY_TIERS above).
// ----------------------------------------------------------------------------

// Splits a difficulty-sorted pool into 3 roughly-equal rank buckets (0=easy,
// 1=medium, 2=hard) and returns just the items in `bucketIndex`. Falls back
// outward (medium, then the full pool) if the requested bucket is empty —
// e.g. a 4-item comprehension pool won't always have items in all 3 buckets.
function literacyBucketByTier(sortedPool, bucketIndex) {
  const n = sortedPool.length;
  if (n === 0) return [];
  const bucketed = sortedPool.filter((_, i) => Math.min(2, Math.floor((i * 3) / n)) === bucketIndex);
  if (bucketed.length > 0) return bucketed;
  // Fall back to an adjacent bucket, then to the whole pool, rather than
  // showing "no questions" just because one tier happens to be thin.
  const adjacent = [1, 0, 2].map((b) => sortedPool.filter((_, i) => Math.min(2, Math.floor((i * 3) / n)) === b)).find((b) => b.length > 0);
  return adjacent || sortedPool;
}

function literacyShuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

// Samples `count` items from `pool`, cycling through freshly-shuffled copies
// of the pool if it's smaller than `count` (a 6-item pool can still fill a
// 20-question run) and nudging away from the same item repeating back-to-back.
function literacySampleWithRepeat(pool, count) {
  if (pool.length === 0) return [];
  const out = [];
  while (out.length < count) {
    let batch = literacyShuffle(pool);
    if (out.length > 0 && batch[0].id === out[out.length - 1].id && batch.length > 1) {
      [batch[0], batch[1]] = [batch[1], batch[0]];
    }
    out.push(...batch);
  }
  return out.slice(0, count);
}

async function fetchLiteracyQuestions(skillType, tierKey, count) {
  const rawGradeLevel = (sstate.section && sstate.section.grade_level) || sstate.student.grade_level || "Grade 8";
  // Section grade_level is free-typed by the teacher (see Section Info settings),
  // so match it case-insensitively and ignore stray leading/trailing whitespace —
  // a strict .eq() here silently returns zero rows for e.g. "grade 10" or "Grade 10 ".
  const gradeLevel = rawGradeLevel.trim();
  const { data, error } = await supabase
    .from("literacy_questions")
    .select("*")
    .eq("skill_type", skillType)
    .ilike("grade_level", gradeLevel)
    .limit(500); // pull the full grade+skill pool; tiering/sampling happens client-side
  if (error || !data || data.length === 0) return [];

  const sorted = [...data].sort((a, b) => (a.difficulty || 0) - (b.difficulty || 0));
  const tier = LITERACY_TIERS.find((t) => t.key === tierKey) || LITERACY_TIERS[1];
  const bucket = literacyBucketByTier(sorted, tier.bucket);

  if (skillType === "comprehension") {
    // Comprehension questions are meaningless without their passage attached
    // and shown to the student — fetch it, and keep each passage's questions
    // grouped together in the run instead of scattering them by chance.
    const withPassages = await literacyAttachPassages(bucket);
    return literacyBuildComprehensionRun(withPassages, count);
  }
  return literacySampleWithRepeat(bucket, count);
}

// Attaches each comprehension question's passage (title/body/genre) as `_passage`
// so the run/UI never has to re-query mid-session. One batched IN() query.
async function literacyAttachPassages(questions) {
  const ids = [...new Set(questions.map((q) => q.passage_id).filter(Boolean))];
  if (ids.length === 0) return questions;
  const { data } = await supabase.from("literacy_passages").select("id,title,body,genre,difficulty").in("id", ids);
  const byId = {};
  (data || []).forEach((p) => { byId[p.id] = p; });
  return questions.map((q) => ({ ...q, _passage: q.passage_id ? byId[q.passage_id] : null }));
}

// Builds a comprehension run that keeps every passage's questions consecutive
// (shuffled passage order, shuffled within each passage) instead of the plain
// global shuffle used elsewhere — so a student reads a passage once and
// answers its questions together, rather than the passage changing underfoot
// every single question.
function literacyBuildComprehensionRun(pool, count) {
  const groups = {};
  pool.forEach((q) => {
    const key = q.passage_id || "none";
    (groups[key] = groups[key] || []).push(q);
  });
  const passageKeys = Object.keys(groups);
  if (passageKeys.length === 0) return [];
  const out = [];
  while (out.length < count) {
    literacyShuffle(passageKeys).forEach((key) => out.push(...literacyShuffle(groups[key])));
  }
  return out.slice(0, count);
}

function literacyNormalize(text) {
  return (text || "").trim().toLowerCase().replace(/\s+/g, " ");
}

// ----------------------------------------------------------------------------
// ANSWER SUBMISSION — logs the attempt (needed for "most-missed words" on the
// teacher side) and banks points through the upsert_literacy_progress RPC,
// which resolves the learner_id server-side so concurrent logins for the
// same real student can't create duplicate progress rows.
// ----------------------------------------------------------------------------
async function submitLiteracyAnswer(question, rawResponse) {
  const isTyped = question.question_format === "typed";
  const isCorrect = isTyped
    ? literacyNormalize(rawResponse) === literacyNormalize(question.correct_answer)
    : rawResponse === question.correct_answer;
  const points = isCorrect ? 10 : 0;

  await supabase.from("literacy_attempts").insert({
    learner_id: sstate.student.learner_id || null,
    student_id: sstate.student.id,
    question_id: question.id,
    skill_type: question.skill_type,
    is_correct: isCorrect,
    response_text: rawResponse,
    points_earned: points,
  });

  await supabase.rpc("upsert_literacy_progress", {
    target_student_id: sstate.student.id,
    points_delta: points,
    skill: question.skill_type,
    was_correct: isCorrect,
  });

  return { isCorrect, points };
}

// ----------------------------------------------------------------------------
// DIFFICULTY PICKER — shown after tapping a station card, before the run
// starts. The student picks Easy/Medium/Hard each time; nothing is saved
// as a standing preference, so they can vary it run to run.
// ----------------------------------------------------------------------------
function startLiteracyStation(skillType) {
  const station = LITERACY_STATIONS.find((s) => s.key === skillType);
  const panel = document.getElementById("tab-literacy");
  if (!panel || !station) return;

  const tierButtons = LITERACY_TIERS.map((t) => `
    <button class="btn" style="display:block;width:100%;margin:10px 0;padding:14px;text-align:left;font-size:1.05rem;"
      onclick="beginLiteracyRun('${skillType}', '${t.key}')">
      ${t.icon} <strong>${t.label}</strong>
    </button>
  `).join("");

  panel.innerHTML = `
    <div style="max-width:480px;margin:0 auto 10px;">
      <button class="btn-outline btn-sm" onclick="renderLiteracyHub()">← Back to Literacy Arena</button>
    </div>
    <div class="card" style="max-width:480px;margin:0 auto;">
      <div style="font-size:2rem;text-align:center;">${station.icon}</div>
      <h2 style="text-align:center;">${escapeHtml(station.name)}</h2>
      <p style="color:#888;text-align:center;">Choose a difficulty to start a ${LITERACY_RUN_LENGTH}-question run.</p>
      ${tierButtons}
    </div>
  `;
}

// ----------------------------------------------------------------------------
// STATION SESSION — a linear run of LITERACY_RUN_LENGTH questions at the
// chosen difficulty. Kept deliberately simple (no streak/mystery-box layer
// like Math Drills) so it's easy to extend later if you want deeper parity.
// ----------------------------------------------------------------------------
async function beginLiteracyRun(skillType, tierKey) {
  const questions = await fetchLiteracyQuestions(skillType, tierKey, LITERACY_RUN_LENGTH);
  if (questions.length === 0) {
    toast("No questions yet for this station at your grade level — ask your teacher to add some.");
    return;
  }
  const tier = LITERACY_TIERS.find((t) => t.key === tierKey) || LITERACY_TIERS[1];
  lstate.session = { skillType, tier, questions, index: 0, correct: 0, total: questions.length, locked: false };
  renderLiteracyQuestion();
}

// Exits a run early back to the hub. Safe at any point — every answer is
// already saved to literacy_progress/literacy_attempts as it happens (see
// submitLiteracyAnswer), so leaving mid-run loses nothing already earned.
function exitLiteracyRun() {
  lstate.session = null;
  renderLiteracyHub();
}

function renderLiteracyQuestion() {
  const s = lstate.session;
  const panel = document.getElementById("tab-literacy");
  if (!s || s.index >= s.questions.length) return renderLiteracyResults();
  s.locked = false;
  const q = s.questions[s.index];
  const isTyped = q.question_format === "typed";
  const passage = q._passage;

  let answerUI;
  if (isTyped) {
    answerUI = `
      <input id="literacy-typed-answer" type="text" autocomplete="off" placeholder="Type your answer..."
        onkeydown="if(event.key==='Enter')literacySubmitTyped()"
        style="width:100%;padding:12px;font-size:1.1rem;border-radius:10px;border:2px solid #ccc;margin-top:12px;" />
      <button class="btn btn-primary" style="margin-top:12px;" onclick="literacySubmitTyped()">Submit</button>
    `;
  } else {
    const choices = (q.choices || []).map(
      (c) => `<button class="btn" style="display:block;width:100%;margin:8px 0;text-align:left;" onclick="literacySubmitChoice(${JSON.stringify(c)})">${escapeHtml(c)}</button>`
    ).join("");
    answerUI = `<div style="margin-top:12px;">${choices}</div>`;
  }

  // Comprehension questions carry their passage — shown above the question,
  // scrollable so a long passage doesn't push the question off-screen.
  const passageBlock = passage ? `
    <div class="card" style="max-width:640px;margin:0 auto 14px;background:#faf8f2;">
      <div style="display:flex;justify-content:space-between;align-items:baseline;">
        <span style="font-size:.78rem;color:#999;text-transform:uppercase;letter-spacing:.03em;">📖 Reading Passage</span>
        ${passage.genre ? `<span style="font-size:.75rem;color:#aaa;">${escapeHtml(passage.genre)}</span>` : ""}
      </div>
      <h3 style="margin:6px 0 10px;">${escapeHtml(passage.title)}</h3>
      <div style="max-height:260px;overflow-y:auto;line-height:1.6;padding-right:6px;">${escapeHtml(passage.body)}</div>
    </div>
  ` : "";

  panel.innerHTML = `
    <div style="max-width:640px;margin:0 auto 10px;display:flex;justify-content:space-between;align-items:center;">
      <button class="btn-outline btn-sm" onclick="exitLiteracyRun()">← Exit</button>
      <span style="color:#888;font-size:.9rem;">${s.tier.icon} ${s.tier.label} · Question ${s.index + 1} of ${s.total}</span>
    </div>
    ${passageBlock}
    <div class="card" style="max-width:640px;margin:0 auto;">
      <h3>${escapeHtml(q.prompt)}</h3>
      <div id="literacy-answer-area">${answerUI}</div>
      <div id="literacy-feedback" style="margin-top:14px;font-weight:600;"></div>
    </div>
  `;
}

async function literacySubmitChoice(choice) {
  await literacyHandleAnswer(choice);
}
async function literacySubmitTyped() {
  const input = document.getElementById("literacy-typed-answer");
  if (!input) return;
  await literacyHandleAnswer(input.value);
}

async function literacyHandleAnswer(rawResponse) {
  const s = lstate.session;
  if (!s || s.locked) return; // guards against double-submit while the request is in flight
  s.locked = true;
  const area = document.getElementById("literacy-answer-area");
  if (area) { area.style.opacity = "0.5"; area.style.pointerEvents = "none"; }

  const q = s.questions[s.index];
  const { isCorrect, points } = await submitLiteracyAnswer(q, rawResponse);
  if (isCorrect) s.correct += 1;

  const isLast = s.index + 1 >= s.total;
  const feedback = document.getElementById("literacy-feedback");
  if (feedback) {
    feedback.style.color = isCorrect ? "#2e7d32" : "#c62828";
    feedback.innerHTML = `
      <div>${isCorrect ? `Correct! +${points} pts` : `Not quite — correct answer: ${escapeHtml(q.correct_answer)}`}</div>
      ${q.explanation ? `<div style="margin-top:6px;font-weight:400;color:#666;font-size:.9rem;">${escapeHtml(q.explanation)}</div>` : ""}
      <button class="btn btn-primary" style="margin-top:12px;" onclick="literacyAdvance()">${isLast ? "See Results →" : "Next Question →"}</button>
    `;
  }
}

// Advances to the next question. Manual (button-driven) rather than a fixed
// timeout, so a student reading a passage or a grammar explanation isn't
// rushed to the next item before they're ready.
function literacyAdvance() {
  const s = lstate.session;
  if (!s) return;
  s.index += 1;
  renderLiteracyQuestion();
}

function renderLiteracyResults() {
  const s = lstate.session;
  const panel = document.getElementById("tab-literacy");
  const pct = s.total ? Math.round((s.correct / s.total) * 100) : 0;
  panel.innerHTML = `
    <div class="card" style="max-width:640px;margin:0 auto;text-align:center;">
      <h2>Run complete! 🎉</h2>
      <p>${s.tier.icon} ${s.tier.label} · ${s.correct} / ${s.total} correct (${pct}%)</p>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:14px;">
        <button class="btn btn-primary" onclick="beginLiteracyRun('${s.skillType}', '${s.tier.key}')">↻ Play Again</button>
        <button class="btn-outline" onclick="renderLiteracyHub()">← Back to Literacy Arena</button>
      </div>
    </div>
  `;
  lstate.session = null;
  loadLiteracyProgress(); // refresh points shown on the hub
}

// ----------------------------------------------------------------------------
// HUB — the tab's landing screen: points summary + the 3 station cards.
// ----------------------------------------------------------------------------
async function renderLiteracyHub() {
  if (!lstate.loaded) await loadLiteracyProgress();
  const p = lstate.progress;
  const panel = document.getElementById("tab-literacy");
  if (!panel) return;

  const stationCards = LITERACY_STATIONS.map((st) => `
    <div class="card" style="cursor:pointer;" onclick="startLiteracyStation('${st.key}')">
      <div style="font-size:2rem;">${st.icon}</div>
      <h3>${escapeHtml(st.name)}</h3>
      <p style="color:#888;">${escapeHtml(st.desc)}</p>
      <div style="font-weight:600;">${(p.station_points && p.station_points[st.key]) || 0} pts</div>
    </div>
  `).join("");

  panel.innerHTML = `
    <div style="text-align:center;margin-bottom:16px;">
      <h2>📚 Literacy Arena</h2>
      <p style="color:#888;">Total: ${p.total_points} pts · ${p.games_played} runs completed</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;">
      ${stationCards}
    </div>
  `;
}
