-- ============================================================================
-- Migration 22 — Term 2 Drill Stations + Admin Station Lock/Unlock
-- Run this once in Supabase → SQL Editor if MathConnect was set up BEFORE
-- this update. New projects don't need this — supabase-schema.sql already
-- includes it.
--
-- What this adds:
--   1. Six new Math Drill Arena stations for Term 2: Ratio & Proportion,
--      Percent, Geometry, Patterns & Sequences, Statistics, and Probability
--      — each with its own real-world theme + gameplay twist, layered on
--      top of the same 15-level foundational-skill ramp the original six
--      stations use (drills.js: genRatio/genPercent/genGeometry/
--      genPatterns/genStatistics/genProbability).
--   2. `drill_station_locks` — lets an ADMIN account lock or unlock any
--      station, school-wide, independent of which teacher's section a
--      student is in. The six new stations start LOCKED by default so
--      they can be prepped now and switched on together when Term 2
--      begins; the six original stations start unlocked (unaffected).
--
-- Safe to run on your existing database — nothing is deleted. Existing
-- students' topic_levels/topic_points simply gain the six new keys at
-- their default starting values (Level 1, 0 points).
-- HOW TO USE: Supabase → SQL Editor → New query → paste this whole file → Run.
-- ============================================================================

-- ---------- widen the two per-station JSON columns' defaults ----------
alter table drill_progress alter column topic_levels set default
  '{"basic":1,"order":1,"integers":1,"fractions":1,"decimals":1,"algebra":1,"ratio":1,"percent":1,"geometry":1,"patterns":1,"statistics":1,"probability":1}'::jsonb;
alter table drill_progress alter column topic_points set default
  '{"basic":0,"order":0,"integers":0,"fractions":0,"decimals":0,"algebra":0,"ratio":0,"percent":0,"geometry":0,"patterns":0,"statistics":0,"probability":0}'::jsonb;

-- ---------- backfill existing students with the 6 new keys ----------
-- (station_leaderboard / student_station_rank in migration-14 already read
-- these columns generically via ->> target_topic, so no function changes
-- are needed — they work for the new stations automatically.)
update drill_progress
set topic_levels = topic_levels || '{"ratio":1,"percent":1,"geometry":1,"patterns":1,"statistics":1,"probability":1}'::jsonb
where not (topic_levels ? 'ratio');

update drill_progress
set topic_points = topic_points
  || '{"ratio":0,"percent":0,"geometry":0,"patterns":0,"statistics":0,"probability":0}'::jsonb
where not (topic_points ? 'ratio');

-- ============================================================================
-- STATION LOCKS — admin can lock/unlock any station, school-wide
-- ============================================================================
create table if not exists drill_station_locks (
  station_key text primary key,
  locked boolean not null default false,
  note text,
  locked_by uuid references admins(id),
  locked_at timestamptz default now()
);

alter table drill_station_locks enable row level security;

-- Everyone (students + teachers, signed in or anon) needs to READ lock
-- status so the Drill Arena and Teacher dashboard can show the 🔒 state —
-- same public-read pattern already used for drill_progress/drill_attempts.
drop policy if exists "public read drill_station_locks" on drill_station_locks;
create policy "public read drill_station_locks" on drill_station_locks for select using (true);

-- Only admins can lock/unlock.
drop policy if exists "admin write drill_station_locks" on drill_station_locks;
create policy "admin write drill_station_locks" on drill_station_locks for insert with check (is_admin());
drop policy if exists "admin update drill_station_locks" on drill_station_locks;
create policy "admin update drill_station_locks" on drill_station_locks for update using (is_admin());
drop policy if exists "admin delete drill_station_locks" on drill_station_locks;
create policy "admin delete drill_station_locks" on drill_station_locks for delete using (is_admin());

-- ---------- seed rows for all 12 stations ----------
-- New Term 2 stations start LOCKED — unlock each from admin.html when
-- you're ready to launch it with your class. Original stations start
-- unlocked so nothing already in use is interrupted.
insert into drill_station_locks (station_key, locked, note) values
  ('basic', false, null),
  ('order', false, null),
  ('integers', false, null),
  ('fractions', false, null),
  ('decimals', false, null),
  ('algebra', false, null),
  ('ratio', true, 'Coming for Term 2!'),
  ('percent', true, 'Coming for Term 2!'),
  ('geometry', true, 'Coming for Term 2!'),
  ('patterns', true, 'Coming for Term 2!'),
  ('statistics', true, 'Coming for Term 2!'),
  ('probability', true, 'Coming for Term 2!')
on conflict (station_key) do nothing;

-- ============================================================================
-- Done. Reload drills.js (student) and teacher-drills.js — 6 new stations
-- appear (locked, greyed out) in the Drill Arena grid. Reload admin.html —
-- a new "🎮 Math Drill Stations" card lets the admin lock/unlock any of the
-- 12 stations school-wide, with an optional note shown to students.
-- ============================================================================
