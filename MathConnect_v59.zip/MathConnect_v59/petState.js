// ============================================================================
// MathConnect — Pet Animation State Machine
//
// A tiny, reusable state machine that drives which CSS animation class a pet
// visual is wearing. It knows nothing about Supabase, growth points, or
// where on screen the pet lives — petAnimation.js (the follow-companion
// widget) drives one instance of this today; raid-ui.js can drive another
// instance later (Phase 5) for the in-battle pets, and pet-ui.js could drive
// one for the big My Pet tab display, all reusing the exact same file.
//
// STEADY states persist until something else changes them (idle, follow,
// sleep). TRANSIENT states play once and automatically fall back to
// whichever steady state was active before them — the caller doesn't need
// to remember to "un-set" a reaction.
//
// To add a new state later: add it to PET_STATE, give it a CSS class in
// PET_STATE_CLASS + matching keyframes in style.css, and (if it should play
// once and revert rather than persist) a duration in PET_TRANSIENT_DURATIONS.
// Nothing else in this file needs to change.
// ============================================================================

const PET_STATE = {
  // steady
  IDLE: "idle",
  FOLLOW: "follow",
  SLEEP: "sleep",
  // transient (auto-revert to the steady state active beforehand)
  IDLE_LOOK: "idle-look",
  BLINK: "blink",
  WALK: "walk",
  HAPPY: "happy",
  EXCITED: "excited",
  CHEER: "cheer",
  CELEBRATE: "celebrate",
  THINK: "think",
  SURPRISED: "surprised",
  DISAPPOINTED: "disappointed",
  VICTORY: "victory",
  DEFEAT: "defeat",
  OWNER_STUDY: "owner-study",
  OWNER_SHOP: "owner-shop",
  OWNER_CARE: "owner-care",
  OWNER_FEED: "owner-feed",
  OWNER_FOCUS: "owner-focus",
};

// Transient states resolve back to the steady state after this many ms.
// Keep these in sync with the animation-duration values in style.css —
// they're intentionally kept as separate numbers (not read from the CSS)
// since JS can't cheaply introspect a keyframe's own duration.
const PET_TRANSIENT_DURATIONS = {
  [PET_STATE.IDLE_LOOK]: 1400,
  [PET_STATE.BLINK]: 220,
  [PET_STATE.WALK]: 650,
  [PET_STATE.HAPPY]: 1100,
  [PET_STATE.EXCITED]: 1200,
  [PET_STATE.CHEER]: 1400,
  [PET_STATE.CELEBRATE]: 1800,
  [PET_STATE.THINK]: 1300,
  [PET_STATE.SURPRISED]: 700,
  [PET_STATE.DISAPPOINTED]: 1200,
  [PET_STATE.VICTORY]: 2200,
  [PET_STATE.DEFEAT]: 1600,
  [PET_STATE.OWNER_STUDY]: 1800,
  [PET_STATE.OWNER_SHOP]: 1300,
  [PET_STATE.OWNER_CARE]: 1200,
  [PET_STATE.OWNER_FEED]: 1100,
  [PET_STATE.OWNER_FOCUS]: 1500,
};

// CSS class applied to the pet visual's wrapper for each state.
const PET_STATE_CLASS = {
  [PET_STATE.IDLE]: "pet-anim-idle",
  [PET_STATE.FOLLOW]: "pet-anim-follow",
  [PET_STATE.SLEEP]: "pet-anim-sleep",
  [PET_STATE.IDLE_LOOK]: "pet-anim-idle-look",
  [PET_STATE.BLINK]: "pet-anim-blink",
  [PET_STATE.WALK]: "pet-anim-walk",
  [PET_STATE.HAPPY]: "pet-anim-happy-idle",
  [PET_STATE.EXCITED]: "pet-anim-excited",
  [PET_STATE.CHEER]: "pet-anim-cheer",
  [PET_STATE.CELEBRATE]: "pet-anim-celebrate",
  [PET_STATE.THINK]: "pet-anim-think",
  [PET_STATE.SURPRISED]: "pet-anim-surprised",
  [PET_STATE.DISAPPOINTED]: "pet-anim-sad",
  [PET_STATE.VICTORY]: "pet-anim-victory",
  [PET_STATE.DEFEAT]: "pet-anim-defeat",
  [PET_STATE.OWNER_STUDY]: "pet-anim-owner-study",
  [PET_STATE.OWNER_SHOP]: "pet-anim-owner-shop",
  [PET_STATE.OWNER_CARE]: "pet-anim-owner-care",
  [PET_STATE.OWNER_FEED]: "pet-anim-owner-feed",
  [PET_STATE.OWNER_FOCUS]: "pet-anim-owner-focus",
};

// Idle variety (blink / idle-look) is only allowed to kick in while resting
// in one of these steady states — never mid-reaction.
const PET_IDLE_VARIETY_STEADY_STATES = [PET_STATE.IDLE, PET_STATE.FOLLOW];

/**
 * Creates one state machine instance driving one on-screen pet visual.
 *
 * @param {Function} render - called as render(cssClass, state) any time the
 *   active class changes. The caller applies it to whatever element it owns
 *   — this file never touches the DOM itself.
 * @param {boolean} reducedMotion - when true, purely decorative transient
 *   states (blink / idle-look / walk) are skipped entirely rather than
 *   played without motion, since there's nothing meaningful left to show
 *   once the movement is gone. Genuine reactions (happy, victory, defeat,
 *   etc.) still switch classes — style.css's own reduced-motion block is
 *   what strips their transform/keyframe motion, this flag just avoids
 *   pointless class-churn for idle-only flourishes.
 * @param {boolean} idleVariety - set false to disable the automatic
 *   occasional blink/idle-look while resting (e.g. for a small chip-sized
 *   instance where it wouldn't be noticeable anyway).
 */
function createPetStateMachine({ render, reducedMotion = false, idleVariety = true }) {
  let current = PET_STATE.IDLE;
  let steady = PET_STATE.IDLE; // the state a transient one plays FROM and returns TO
  let transientTimer = null;
  let idleVarietyTimer = null;
  let destroyed = false;

  function apply(state) {
    current = state;
    render(PET_STATE_CLASS[state] || PET_STATE_CLASS[PET_STATE.IDLE], state);
  }

  function scheduleIdleVariety() {
    clearTimeout(idleVarietyTimer);
    if (destroyed || !idleVariety || reducedMotion) return;
    if (!PET_IDLE_VARIETY_STEADY_STATES.includes(steady)) return;
    const delay = 4000 + Math.random() * 5000; // every ~4-9s while resting
    idleVarietyTimer = setTimeout(() => {
      if (destroyed || current !== steady) return; // something else took over meanwhile
      transition(Math.random() < 0.5 ? PET_STATE.BLINK : PET_STATE.IDLE_LOOK);
    }, delay);
  }

  /** Move to a new state. Steady states become the new "resting" state and
   *  stay applied; transient states play once then fall back to whatever
   *  steady state was active immediately before them. */
  function transition(state) {
    if (destroyed) return;
    clearTimeout(transientTimer);
    const duration = PET_TRANSIENT_DURATIONS[state];

    if (!duration) {
      steady = state;
      apply(state);
      scheduleIdleVariety();
      return;
    }

    if (reducedMotion && [PET_STATE.BLINK, PET_STATE.IDLE_LOOK, PET_STATE.WALK].includes(state)) {
      return; // purely decorative — nothing meaningful to show without motion
    }

    apply(state);
    transientTimer = setTimeout(() => {
      apply(steady);
      scheduleIdleVariety();
    }, duration);
  }

  apply(PET_STATE.IDLE);

  return {
    transition,
    getState: () => current,
    destroy() {
      destroyed = true;
      clearTimeout(transientTimer);
      clearTimeout(idleVarietyTimer);
    },
  };
}
