// Initializes the Supabase client for use across the app.
// Relies on config.js (loaded before this file) and the Supabase JS CDN script.
// Uses `var` (not `let`/`const`) deliberately: if this file ever gets included
// twice by accident (duplicate <script> tag), `var` re-declares harmlessly
// instead of throwing a page-breaking SyntaxError.

var supabase;

function initSupabase() {
  if (!SUPABASE_URL || SUPABASE_URL.includes("PASTE_YOUR")) {
    document.body.innerHTML = `
      <div style="max-width:560px;margin:80px auto;font-family:sans-serif;padding:24px;">
        <h2>⚙️ Setup needed</h2>
        <p>MathConnect isn't connected to Supabase yet. Open <code>js/config.js</code> and paste in your
        Supabase Project URL and anon public key (found in your Supabase project under
        Settings → API). See README.md for full setup steps.</p>
      </div>`;
    throw new Error("Supabase not configured");
  }
  supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  return supabase;
}

// ---------- small shared helpers used by teacher.js and student.js ----------

function toast(msg) {
  const el = document.createElement("div");
  el.className = "toast toast-in";
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => {
    el.classList.remove("toast-in");
    el.classList.add("toast-out");
    setTimeout(() => el.remove(), 240);
  }, 3000);
}

function genClassCode(gradeLevel, sectionName) {
  const base = (gradeLevel + sectionName).replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 6);
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${base}-${rand}`;
}

// Short, easy-to-type student login code — avoids ambiguous characters (0/O, 1/I).
function genLoginCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });
}

// ============================================================================
// AUDIT FIX (2026-09): Paginated bulk fetch.
// ----------------------------------------------------------------------------
// Supabase/PostgREST caps an unbounded `select()` at ~1,000 rows by default.
// admin.js used to call `.select("*")` directly on `scores`/`attendance`/
// `students` for the WHOLE SCHOOL with no `.range()`, so once any of those
// tables grew past ~1,000 rows the Admin Overview was silently averaging /
// summarizing an incomplete, arbitrarily-truncated slice of the data — while
// each teacher's own (much smaller, section-scoped) queries stayed complete.
// That was the root cause of "General Average / Attendance % differs between
// Admin and Teacher for the same section."
//
// fetchAllRows(buildQuery) pages through a Supabase query in chunks of 1000
// until a page comes back short, and concatenates every row. `buildQuery` is
// a zero-arg function that returns a FRESH PostgrestFilterBuilder each call
// (so we can call `.range()` on a new instance for every page) — e.g.:
//   const scores = await fetchAllRows(() => supabase.from("scores").select("*"));
// ============================================================================
async function fetchAllRows(buildQuery, pageSize = 1000) {
  let all = [];
  let from = 0;
  // Hard safety cap (200 pages = 200k rows) so a bug elsewhere can't spin
  // this into an infinite loop against a live database.
  for (let page = 0; page < 200; page++) {
    const { data, error } = await buildQuery().range(from, from + pageSize - 1);
    if (error) { console.warn("fetchAllRows error:", error.message); break; }
    if (!data || data.length === 0) break;
    all = all.concat(data);
    if (data.length < pageSize) break;
    from += pageSize;
  }
  return all;
}

// ============================================================================
// v46 — fetchAllRowsChecked(): the paginated fetch every teacher-side
// "pull the whole class's activity" query should use.
// ----------------------------------------------------------------------------
// Two problems with a bare `.select()` on an activity table (drill_attempts,
// quest_attempts, battle_answers, daily_challenge_completions…):
//   1. PostgREST silently caps it at ~1,000 rows. A class of 23 students who
//      each play a few dozen drill runs blows past that quickly, and the rows
//      that get dropped are the NEWEST ones — so recently-unlocked stations
//      showed "0/23 players" on the teacher dashboard even though students
//      had been playing them.
//   2. `const { data } = await …` throws the error away, so a failed request
//      looks exactly like "no students have played yet".
// This helper pages through every row (ordered by a stable column so pages
// never overlap or skip), advances by the number of rows actually returned
// (so it still works if the project's "Max rows" API setting is lower than
// 1000), and returns `{ data, error, truncated }` so callers can SHOW the
// teacher when something didn't load instead of silently displaying zeros.
//
//   const { data, error } = await fetchAllRowsChecked(
//     () => supabase.from("drill_attempts").select("student_id, topic").in("student_id", ids));
// Pass { orderBy: null } for a table with no `id` column.
// ============================================================================
async function fetchAllRowsChecked(buildQuery, opts) {
  const o = opts || {};
  const pageSize = o.pageSize || 1000;
  const orderBy = o.orderBy === undefined ? "id" : o.orderBy;
  const maxPages = o.maxPages || 200; // hard safety cap (200k rows at 1000/page)
  let all = [];
  let from = 0;
  let error = null;
  let truncated = false;
  for (let page = 0; ; page++) {
    if (page >= maxPages) { truncated = true; break; }
    let q = buildQuery();
    if (orderBy) q = q.order(orderBy, { ascending: true });
    const { data, error: err } = await q.range(from, from + pageSize - 1);
    if (err) { error = err; console.warn("fetchAllRowsChecked error:", err.message); break; }
    if (!data || data.length === 0) break; // only an EMPTY page proves we're done
    all = all.concat(data);
    from += data.length; // advance by what we actually got, not what we asked for
  }
  return { data: all, error, truncated };
}

// ============================================================================
// AUDIT FIX (2026-09): Single source of truth for a term's effective date
// range, shared by teacher.js (Attendance Summary) and student.js (My
// Attendance). Previously teacher.js bounded attendance queries with
// `.gte("attendance_date", term.start_date || "2000-01-01")` and NO upper
// bound at all, while student.js applied no date/term scoping whatsoever.
// Since `terms.start_date`/`end_date` were never written anywhere in the
// app, that fallback always fired — so "this term" silently meant "this
// section's entire history" everywhere it was used.
//
// This helper:
//   1. Uses the term's real start_date/end_date when they've been set
//      (via the new "Edit Term Dates" control in teacher.js).
//   2. Falls back to a sensible default computed from the section's
//      school_year (roughly three equal slices of the PH school calendar)
//      when they haven't — so the app is never silently unscoped, even
//      before a teacher fills in exact dates.
//   3. Never returns an open-ended upper bound, so switching terms always
//      changes what's shown.
// ============================================================================
function defaultSchoolYearRange(schoolYear) {
  const m = /^(\d{4})-(\d{4})$/.exec((schoolYear || "").trim());
  const y1 = m ? Number(m[1]) : new Date().getFullYear();
  const y2 = m ? Number(m[2]) : y1 + 1;
  // Approximate PH public-school calendar: mid-June to late March.
  return { start: `${y1}-06-01`, end: `${y2}-03-31` };
}
function termDateRange(term, schoolYear) {
  if (term && term.start_date && term.end_date) {
    return { start: term.start_date, end: term.end_date };
  }
  const { start, end } = defaultSchoolYearRange(schoolYear || (term && term.school_year));
  const n = (term && term.term_number) || 1;
  const startMs = new Date(start + "T00:00:00").getTime();
  const endMs = new Date(end + "T00:00:00").getTime();
  const slice = (endMs - startMs) / 3;
  const sliceStart = new Date(startMs + slice * (n - 1)).toISOString().slice(0, 10);
  const sliceEnd = n >= 3 ? end : new Date(startMs + slice * n - 86400000).toISOString().slice(0, 10);
  return {
    start: (term && term.start_date) || sliceStart,
    end: (term && term.end_date) || sliceEnd,
  };
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
}

// Turns a teacher-pasted material link into something embeddable inline in
// an <iframe> instead of only ever opening in a new tab — used by the
// Learning Activity Sheet (LAS) PDF viewer on both dashboards. Handles the
// two link shapes teachers actually paste (a direct .pdf URL, or a Google
// Drive "share" link); anything else is passed through as-is and still
// works for browsers that render PDFs natively in an iframe.
function toEmbeddablePdfUrl(url) {
  if (!url) return "";
  const driveMatch = url.match(/drive\.google\.com\/file\/d\/([^/]+)/);
  if (driveMatch) return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
  return url;
}
